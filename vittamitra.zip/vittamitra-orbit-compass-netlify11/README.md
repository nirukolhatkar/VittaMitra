# Personal Finance Manager — Phase 1 (Foundation)

An offline-first, mobile-first Progressive Web App (PWA) built with HTML5, CSS3, vanilla JavaScript ES modules, and IndexedDB (Dexie-compatible repository layer).

## Running Locally

Because ES modules and Service Workers require an HTTP/HTTPS origin (not `file://`), serve the project directory with any static web server:

```bash
# Option 1: Python 3
python3 -m http.server 8080

# Option 2: Node.js
npx serve . -l 8080
```

Then open **http://localhost:8080** in Chrome, Edge, or Safari.

## Installing as a PWA

* **Desktop (Chrome / Edge):** Open the app over `http://localhost:8080` or HTTPS, then click the **Install** icon in the address bar.
* **Android (Chrome):** Open over HTTPS, tap the browser menu (⋮) → **Install app** / **Add to Home screen**.
* **iOS (Safari):** Open over HTTPS, tap **Share** → **Add to Home Screen**.

Once loaded once, the Service Worker (`sw.js`) caches the full app shell so the application launches and persists data locally without internet access.

## Running Automated Tests

```bash
# 1. Node.js unit tests (paise math, Indian formatting, FY/dates, tag/account normalization, asset/liability ledger rules, repository CRUD/soft-delete)
node tests/run-unit-tests.mjs

# 2. Headless Chromium E2E test (IndexedDB persistence, reload, Service Worker offline launch, mobile & desktop layouts)
python3 tests/verify-browser.py
```

## Vendor Library Note (`vendor/dexie.js`)

To stay 100% offline-safe with zero build pipeline, `vendor/dexie.js` ships a lightweight, zero-dependency IndexedDB module implementing the Dexie v4 ES module API surface used by the application (`new Dexie`, `version().stores()`, `table()`, `transaction()`, `where().equals()`). If you prefer the upstream Dexie v4 ESM bundle in a networked environment, you can drop `dexie.js` directly into `vendor/dexie.js` without changing any application code.

## Phase 1 Scope Summary

* **Completed:** PWA shell, manifest, Service Worker offline caching, responsive mobile bottom nav + desktop sidebar, IndexedDB schema v1, BaseRepository (UUIDs, `user_id`, timestamps, version counter, soft-delete tombstones, `sync_queue` logging), default Expense/Income category seeding, Categories & Subcategories CRUD + archive/delete protection, Accounts CRUD (with explicit Asset vs Liability semantics and credit card exclusion from Available Balance), Family Members CRUD, Tags CRUD (`#` display + case/whitespace dedup), Dashboard shell with month/FY navigation, Settings (INR, FY 1 Apr – 31 Mar, Monday week start, Light/Dark/System theme, storage diagnostics), and automated unit + browser tests.
* **Pending (Phases 2–8):** Transactions/transfers/quick templates (Phase 2), Analytics & Budgets (Phase 3), Bills & Recurring Rules (Phase 4), Net Worth/Investments/Loans (Phase 5), Exact 8-column `Sheet1` XLSX Import/Export & JSON Backup (Phase 6), Supabase Auth/RLS/Multi-Device Sync (Phase 7), Release hardening (Phase 8).

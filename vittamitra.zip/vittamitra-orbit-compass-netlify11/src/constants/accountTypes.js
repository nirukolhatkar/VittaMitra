/**
 * Explicit account types and normal-balance accounting conventions.
 *
 * Supported account types (per user specification):
 *   1. bank_account  — Asset (included in Available Balance by default)
 *   2. credit_card   — Liability (excluded from Available Balance; tracks Outstanding & Credit Limit)
 *   3. wallet        — Asset (included in Available Balance by default)
 *   4. cash          — Asset (included in Available Balance by default)
 */

export const ACCOUNT_CLASS = Object.freeze({
  ASSET: 'asset',
  LIABILITY: 'liability',
});

export const ACCOUNT_TYPES = Object.freeze({
  bank_account: {
    code: 'bank_account',
    label: 'Bank Account',
    pluralLabel: 'Bank Accounts',
    accountClass: ACCOUNT_CLASS.ASSET,
    defaultIncludeInAvailableBalance: true,
    icon: '🏛️',
    color: '#38bdf8',
    order: 1,
  },
  credit_card: {
    code: 'credit_card',
    label: 'Credit Card',
    pluralLabel: 'Credit Cards',
    accountClass: ACCOUNT_CLASS.LIABILITY,
    defaultIncludeInAvailableBalance: false,
    icon: '💳',
    color: '#f59e0b',
    order: 2,
  },
  wallet: {
    code: 'wallet',
    label: 'Wallet',
    pluralLabel: 'Wallets',
    accountClass: ACCOUNT_CLASS.ASSET,
    defaultIncludeInAvailableBalance: true,
    icon: '👛',
    color: '#60a5fa',
    order: 3,
  },
  cash: {
    code: 'cash',
    label: 'Cash',
    pluralLabel: 'Cash',
    accountClass: ACCOUNT_CLASS.ASSET,
    defaultIncludeInAvailableBalance: true,
    icon: '💵',
    color: '#34d399',
    order: 4,
  },
});

export const ACCOUNT_TYPE_ORDER = ['bank_account', 'credit_card', 'wallet', 'cash'];

export function getAccountTypeMeta(typeCode) {
  // Gracefully map legacy 'savings_bank' to 'bank_account'
  if (typeCode === 'savings_bank') return ACCOUNT_TYPES.bank_account;
  return ACCOUNT_TYPES[typeCode] || ACCOUNT_TYPES.bank_account;
}

export function isLiabilityAccount(account) {
  if (!account) return false;
  if (account.account_class) {
    return account.account_class === ACCOUNT_CLASS.LIABILITY;
  }
  return getAccountTypeMeta(account.type).accountClass === ACCOUNT_CLASS.LIABILITY;
}

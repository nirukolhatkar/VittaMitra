import { BaseRepository } from './baseRepository.js';
import { MAX_ATTACHMENT_SIZE_BYTES } from '../../constants/defaultSeeds.js';
import { generateUUID } from '../../utils/uuid.js';
import { nowIsoUtc } from '../../utils/date.js';

/**
 * Manages receipt/bill attachment metadata (syncable) and binary blobs
 * in the separate local-only `attachment_blobs` store (5 MB per-file limit).
 */
export class AttachmentRepository extends BaseRepository {
  constructor(db) {
    super(db, 'attachments', { syncable: true });
  }

  async listByTransaction(transactionId) {
    const all = await this.getAll({ includeDeleted: false });
    return all.filter((a) => a.transaction_id === transactionId);
  }

  async saveAttachment(transactionId, file) {
    if (!file) throw new Error('No file selected');
    if (file.size > MAX_ATTACHMENT_SIZE_BYTES) {
      throw new Error('Attachment exceeds the 5 MB per-file limit');
    }

    const blobKey = generateUUID();
    const now = nowIsoUtc();

    // Store raw Blob/File in local-only attachment_blobs store (never pushed to sync_queue)
    await this.db.table('attachment_blobs').put({
      id: blobKey,
      blob: file,
      mime_type: file.type || 'application/octet-stream',
      size_bytes: file.size,
      created_at: now,
    });

    return this.create({
      transaction_id: transactionId,
      file_name: file.name || 'receipt',
      mime_type: file.type || 'application/octet-stream',
      size_bytes: file.size,
      local_blob_key: blobKey,
      storage_path: null,
    });
  }

  async getBlob(localBlobKey) {
    const rec = await this.db.table('attachment_blobs').get(localBlobKey);
    return rec ? rec.blob : null;
  }

  async addAttachment(transactionId, file) {
    return this.saveAttachment(transactionId, file);
  }

  async deleteAttachment(attachmentId) {
    return this.removeAttachment(attachmentId);
  }

  async removeAttachment(attachmentId) {
    const meta = await this.getById(attachmentId);
    if (!meta) return null;
    if (meta.local_blob_key) {
      await this.db.table('attachment_blobs').delete(meta.local_blob_key).catch(() => {});
    }
    return this.softDelete(attachmentId);
  }
}

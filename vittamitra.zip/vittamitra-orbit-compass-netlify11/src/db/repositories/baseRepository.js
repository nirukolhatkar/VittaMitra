import { generateUUID } from '../../utils/uuid.js';
import { nowIsoUtc } from '../../utils/date.js';

/**
 * Base repository enforcing:
 * - UUID v4 primary keys
 * - user_id ownership field (null offline until signed in; multi-user SaaS ready)
 * - created_at / updated_at ISO-8601 UTC timestamps
 * - Optimistic concurrency version counter (incremented on every mutation)
 * - Soft deletion via deleted_at tombstone (never silently hard-deletes domain records)
 * - Atomic sync_queue enqueue on every mutation (for Phase 7 cloud sync)
 */
export class BaseRepository {
  constructor(db, tableName, { syncable = true } = {}) {
    this.db = db;
    this.tableName = tableName;
    this.syncable = syncable;
  }

  get table() {
    return this.db.table(this.tableName);
  }

  async _enqueueSync(operation, record) {
    if (!this.syncable) return;
    await this.db.table('sync_queue').add({
      table_name: this.tableName,
      record_id: record.id,
      operation,
      version: record.version,
      payload: record,
      retry_count: 0,
      last_error: null,
      queued_at: nowIsoUtc(),
    });
  }

  async getById(id, { includeDeleted = false } = {}) {
    const rec = await this.table.get(id);
    if (!rec) return null;
    if (!includeDeleted && rec.deleted_at) return null;
    return rec;
  }

  async getAll({ includeDeleted = false } = {}) {
    const all = await this.table.toArray();
    if (includeDeleted) return all;
    return all.filter((item) => !item.deleted_at);
  }

  async create(data) {
    const now = nowIsoUtc();
    const record = {
      ...data,
      id: data.id || generateUUID(),
      user_id: data.user_id ?? null,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    };

    const stores = this.syncable ? [this.tableName, 'sync_queue'] : [this.tableName];
    await this.db.transaction('rw', stores, async () => {
      await this.table.add(record);
      await this._enqueueSync('insert', record);
    });
    return record;
  }

  async update(id, patch) {
    const stores = this.syncable ? [this.tableName, 'sync_queue'] : [this.tableName];
    let updatedRecord = null;

    await this.db.transaction('rw', stores, async () => {
      const existing = await this.table.get(id);
      if (!existing || existing.deleted_at) {
        throw new Error(`Record "${id}" not found in ${this.tableName}`);
      }
      updatedRecord = {
        ...existing,
        ...patch,
        id: existing.id,
        created_at: existing.created_at,
        updated_at: nowIsoUtc(),
        version: (existing.version || 1) + 1,
      };
      await this.table.put(updatedRecord);
      await this._enqueueSync('update', updatedRecord);
    });

    return updatedRecord;
  }

  async softDelete(id) {
    const stores = this.syncable ? [this.tableName, 'sync_queue'] : [this.tableName];
    let deletedRecord = null;

    await this.db.transaction('rw', stores, async () => {
      const existing = await this.table.get(id);
      if (!existing) {
        throw new Error(`Record "${id}" not found in ${this.tableName}`);
      }
      if (existing.deleted_at) {
        deletedRecord = existing;
        return;
      }
      const now = nowIsoUtc();
      deletedRecord = {
        ...existing,
        deleted_at: now,
        updated_at: now,
        version: (existing.version || 1) + 1,
      };
      await this.table.put(deletedRecord);
      await this._enqueueSync('delete', deletedRecord);
    });

    return deletedRecord;
  }

  async restore(id) {
    const stores = this.syncable ? [this.tableName, 'sync_queue'] : [this.tableName];
    let restored = null;

    await this.db.transaction('rw', stores, async () => {
      const existing = await this.table.get(id);
      if (!existing) {
        throw new Error(`Record "${id}" not found in ${this.tableName}`);
      }
      restored = {
        ...existing,
        deleted_at: null,
        updated_at: nowIsoUtc(),
        version: (existing.version || 1) + 1,
      };
      await this.table.put(restored);
      await this._enqueueSync('update', restored);
    });

    return restored;
  }
}

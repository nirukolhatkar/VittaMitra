import { BaseRepository } from './baseRepository.js';
import { parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';

export class BillRepository extends BaseRepository {
  constructor(db) {
    super(db, 'bills', { syncable: true });
  }

  async listAll() {
    const all = await this.getAll({ includeDeleted: false });
    return all.sort((a, b) => String(a.due_date || '').localeCompare(String(b.due_date || '')));
  }

  async createBill({
    name,
    category_id = null,
    amount_paise = undefined,
    amount_rupees = undefined,
    due_date = toLocalDateString(),
    account_id = null,
    frequency = 'monthly', // 'once' | 'monthly' | 'quarterly' | 'half_yearly' | 'yearly'
    reminder_date = null,
    notes = '',
  }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Bill name is required');
    const amountPaise =
      amount_rupees !== undefined ? parseRupeesToPaise(amount_rupees, { allowNegative: false }) : amount_paise;
    if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) {
      throw new Error('Bill amount must be greater than ₹0.00');
    }

    return this.create({
      name: cleanName,
      category_id: category_id || null,
      amount_paise: amountPaise,
      due_date: due_date || toLocalDateString(),
      account_id: account_id || null,
      frequency: frequency || 'monthly',
      reminder_date: reminder_date || due_date || toLocalDateString(),
      notes: String(notes || '').trim(),
      status: 'unpaid', // 'unpaid' | 'paid'
      paid_transaction_id: null,
      paid_at: null,
      snoozed_until: null,
      reminder_dismissed: false,
    });
  }

  async updateBill(id, patch) {
    const nextPatch = { ...patch };
    if (patch.amount_rupees !== undefined) {
      nextPatch.amount_paise = parseRupeesToPaise(patch.amount_rupees, { allowNegative: false });
      delete nextPatch.amount_rupees;
    }
    return this.update(id, nextPatch);
  }
}

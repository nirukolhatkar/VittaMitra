import { BaseRepository } from './baseRepository.js';
import { parseRupeesToPaise } from '../../utils/money.js';

export class BudgetRepository extends BaseRepository {
  constructor(db) {
    super(db, 'budgets', { syncable: true });
  }

  async listAll() {
    const all = await this.getAll({ includeDeleted: false });
    return all.sort((a, b) => {
      if (a.scope_type === 'overall' && b.scope_type !== 'overall') return -1;
      if (b.scope_type === 'overall' && a.scope_type !== 'overall') return 1;
      return String(a.name || '').localeCompare(String(b.name || ''));
    });
  }

  async createBudget({
    name,
    scope_type = 'overall', // 'overall' | 'category' | 'tag'
    scope_id = null,
    amount_paise = undefined,
    amount_rupees = undefined,
    period_month, // 'YYYY-MM'
    is_recurring = true,
    carry_forward = false,
    alert_thresholds = [50, 75, 90, 100],
  }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Budget name is required');
    if (!['overall', 'category', 'tag'].includes(scope_type)) {
      throw new Error('Invalid budget scope');
    }
    if (scope_type !== 'overall' && !scope_id) {
      throw new Error(`Please select a ${scope_type} for this budget`);
    }

    const amountPaise =
      amount_rupees !== undefined ? parseRupeesToPaise(amount_rupees, { allowNegative: false }) : amount_paise;
    if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) {
      throw new Error('Budget amount must be greater than ₹0.00');
    }

    const cleanThresholds = Array.from(
      new Set(
        (alert_thresholds || [])
          .map((n) => Number(n))
          .filter((n) => Number.isFinite(n) && n > 0 && n <= 200)
      )
    ).sort((a, b) => a - b);

    return this.create({
      name: cleanName,
      scope_type,
      scope_id: scope_type === 'overall' ? null : scope_id,
      amount_paise: amountPaise,
      period_month: period_month || new Date().toISOString().slice(0, 7),
      is_recurring: Boolean(is_recurring),
      carry_forward: Boolean(carry_forward),
      alert_thresholds: cleanThresholds.length ? cleanThresholds : [50, 75, 90, 100],
      triggered_alerts: {}, // { 'YYYY-MM': [50, 75] } — prevents duplicate alerts for same threshold
    });
  }

  async updateBudget(id, patch) {
    const nextPatch = { ...patch };
    if (patch.amount_rupees !== undefined) {
      nextPatch.amount_paise = parseRupeesToPaise(patch.amount_rupees, { allowNegative: false });
      delete nextPatch.amount_rupees;
    }
    return this.update(id, nextPatch);
  }
}

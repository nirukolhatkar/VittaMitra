import { BaseRepository } from './baseRepository.js';

export class CategoryRepository extends BaseRepository {
  constructor(db) {
    super(db, 'categories', { syncable: true });
  }

  async list({ type = null, includeArchived = false } = {}) {
    const all = await this.getAll({ includeDeleted: false });
    return all
      .filter((c) => {
        if (type && c.type !== type) return false;
        if (!includeArchived && c.is_archived) return false;
        return true;
      })
      .sort((a, b) => (a.sort_order || 999) - (b.sort_order || 999) || a.name.localeCompare(b.name));
  }

  async listTree({ type = null, includeArchived = false } = {}) {
    const items = await this.list({ type, includeArchived });
    const parents = items.filter((c) => !c.parent_id);
    const childrenByParent = new Map();
    for (const c of items) {
      if (c.parent_id) {
        if (!childrenByParent.has(c.parent_id)) childrenByParent.set(c.parent_id, []);
        childrenByParent.get(c.parent_id).push(c);
      }
    }
    return parents.map((p) => ({
      ...p,
      subcategories: childrenByParent.get(p.id) || [],
    }));
  }

  async createCategory({ name, type, parent_id = null, icon = '🏷️', color = '#475569' }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Category name is required');
    if (type !== 'expense' && type !== 'income') {
      throw new Error('Category type must be "expense" or "income"');
    }

    if (parent_id) {
      const parent = await this.getById(parent_id);
      if (!parent) throw new Error('Parent category does not exist');
      if (parent.type !== type) {
        throw new Error('Subcategory must have the same type as its parent category');
      }
      if (parent.parent_id) {
        throw new Error('Only one level of subcategories is supported');
      }
    }

    const existing = await this.list({ type, includeArchived: true });
    const duplicate = existing.find(
      (c) =>
        (c.parent_id || null) === (parent_id || null) &&
        c.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (duplicate) {
      throw new Error(`Category "${cleanName}" already exists`);
    }

    return this.create({
      name: cleanName,
      type,
      parent_id: parent_id || null,
      icon: icon || '🏷️',
      color: color || '#475569',
      is_default: false,
      is_archived: false,
      sort_order: existing.length + 1,
    });
  }

  async updateCategory(id, patch) {
    const current = await this.getById(id);
    if (!current) throw new Error('Category not found');

    const nextName = patch.name !== undefined ? String(patch.name).trim() : current.name;
    if (!nextName) throw new Error('Category name cannot be empty');

    const nextParentId = patch.parent_id !== undefined ? patch.parent_id || null : current.parent_id;
    if (nextParentId === id) {
      throw new Error('A category cannot be its own parent');
    }

    const existing = await this.list({ type: current.type, includeArchived: true });
    const duplicate = existing.find(
      (c) =>
        c.id !== id &&
        (c.parent_id || null) === nextParentId &&
        c.name.trim().toLowerCase() === nextName.toLowerCase()
    );
    if (duplicate) {
      throw new Error(`Category "${nextName}" already exists`);
    }

    return this.update(id, {
      ...patch,
      name: nextName,
      parent_id: nextParentId,
    });
  }

  async setArchived(id, isArchived) {
    return this.update(id, { is_archived: Boolean(isArchived) });
  }

  /**
   * Soft-delete a category only if it has no active subcategories.
   * In Phase 2+, transaction usage check will also require archiving or reassignment
   * before soft-deleting any category with linked transactions.
   */
  async deleteCategorySafe(id, { referencedTransactionCount = 0 } = {}) {
    if (referencedTransactionCount > 0) {
      throw new Error(
        'Cannot delete a category linked to existing transactions. Archive it or reassign transactions first.'
      );
    }
    const all = await this.list({ includeArchived: true });
    const activeChildren = all.filter((c) => c.parent_id === id);
    if (activeChildren.length > 0) {
      throw new Error('Cannot delete a parent category that still has subcategories. Archive it or remove subcategories first.');
    }
    return this.softDelete(id);
  }
}

import { BaseRepository } from './baseRepository.js';

export const DEBT_TYPES = {
  RECEIVABLE: 'RECEIVABLE',
  PAYABLE: 'PAYABLE',
};

export const DEBT_EVENT_TYPES = {
  LENT: 'LENT',
  BORROWED: 'BORROWED',
  PRINCIPAL_RECEIVED: 'PRINCIPAL_RECEIVED',
  PRINCIPAL_PAID: 'PRINCIPAL_PAID',
  INTEREST_RECEIVED: 'INTEREST_RECEIVED',
  INTEREST_PAID: 'INTEREST_PAID',
  PRINCIPAL_ADJUSTMENT: 'PRINCIPAL_ADJUSTMENT',
  DEBT_WRITTEN_OFF: 'DEBT_WRITTEN_OFF',
  DEBT_FORGIVEN: 'DEBT_FORGIVEN',
};

export const DEBT_STATUS = {
  ACTIVE: 'ACTIVE',
  PARTIALLY_SETTLED: 'PARTIALLY_SETTLED',
  SETTLED: 'SETTLED',
  OVERDUE: 'OVERDUE',
  WRITTEN_OFF: 'WRITTEN_OFF',
};

export class DebtRepository extends BaseRepository {
  constructor(db) {
    super(db, 'debts', { syncable: true });
    this.events = new BaseRepository(db, 'debt_events', { syncable: true });
  }

  async listDebts() {
    const rows = await this.getAll({ includeDeleted: false });
    return rows.sort((a, b) => String(b.start_date || '').localeCompare(String(a.start_date || '')));
  }

  async listEvents(debtId = null) {
    const rows = await this.events.getAll({ includeDeleted: false });
    return rows
      .filter((e) => (!debtId || e.debt_id === debtId))
      .sort((a, b) => String(a.event_date || '').localeCompare(String(b.event_date || '')) || String(a.created_at || '').localeCompare(String(b.created_at || '')));
  }

  async getEventById(eventId) {
    return this.events.getById(eventId);
  }

  async findEventByIdempotencyKey(key) {
    if (!key) return null;
    const all = await this.events.getAll({ includeDeleted: false });
    return all.find((e) => e.idempotency_key === key) || null;
  }
}

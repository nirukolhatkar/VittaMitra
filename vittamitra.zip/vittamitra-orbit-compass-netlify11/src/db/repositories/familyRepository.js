import { BaseRepository } from './baseRepository.js';

export class FamilyRepository extends BaseRepository {
  constructor(db) {
    super(db, 'family_members', { syncable: true });
  }

  async list({ includeInactive = true } = {}) {
    const all = await this.getAll({ includeDeleted: false });
    return all
      .filter((m) => (includeInactive ? true : m.is_active))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  async createMember({ name, relationship = 'Other family member', icon = '👤', is_active = true }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Family member name is required');

    const all = await this.list({ includeInactive: true });
    const duplicate = all.find((m) => m.name.trim().toLowerCase() === cleanName.toLowerCase());
    if (duplicate) {
      throw new Error(`Family member "${cleanName}" already exists`);
    }

    return this.create({
      name: cleanName,
      relationship: String(relationship || 'Other family member').trim(),
      icon: icon || '👤',
      is_active: Boolean(is_active),
    });
  }

  async updateMember(id, patch) {
    const current = await this.getById(id);
    if (!current) throw new Error('Family member not found');

    const nextName = patch.name !== undefined ? String(patch.name).trim() : current.name;
    if (!nextName) throw new Error('Family member name cannot be empty');

    const all = await this.list({ includeInactive: true });
    const duplicate = all.find(
      (m) => m.id !== id && m.name.trim().toLowerCase() === nextName.toLowerCase()
    );
    if (duplicate) {
      throw new Error(`Family member "${nextName}" already exists`);
    }

    return this.update(id, { ...patch, name: nextName });
  }
}

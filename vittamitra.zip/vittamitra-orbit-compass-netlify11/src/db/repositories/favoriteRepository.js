import { BaseRepository } from './baseRepository.js';

export const MAX_FAVORITE_TEMPLATES = 5;

export class FavoriteRepository extends BaseRepository {
  constructor(db) {
    super(db, 'favorite_templates', { syncable: true });
  }

  async list() {
    const all = await this.getAll({ includeDeleted: false });
    return all.sort((a, b) => (a.sort_order || 99) - (b.sort_order || 99) || a.name.localeCompare(b.name));
  }

  async createFavorite({
    name,
    type,
    amount_paise,
    category_id = null,
    account_id,
    to_account_id = null,
    description = '',
    notes = '',
    family_member_id = null,
    tag_ids = [],
  }) {
    const existing = await this.list();
    if (existing.length >= MAX_FAVORITE_TEMPLATES) {
      throw new Error(`You can save up to ${MAX_FAVORITE_TEMPLATES} favourite templates. Remove one to add another.`);
    }

    const cleanName = String(name || description || '').trim();
    if (!cleanName) throw new Error('Favourite template name is required');
    if (!['expense', 'income', 'transfer'].includes(type)) {
      throw new Error('Invalid transaction type');
    }
    if (!Number.isSafeInteger(amount_paise) || amount_paise <= 0) {
      throw new Error('Amount must be positive');
    }
    if (!account_id) throw new Error('Account is required');

    return this.create({
      name: cleanName,
      type,
      amount_paise,
      category_id: type === 'transfer' ? null : category_id || null,
      account_id,
      to_account_id: type === 'transfer' ? to_account_id || null : null,
      description: String(description || '').trim(),
      notes: String(notes || '').trim(),
      family_member_id: family_member_id || null,
      tag_ids: Array.isArray(tag_ids) ? [...tag_ids] : [],
      sort_order: existing.length + 1,
    });
  }
}

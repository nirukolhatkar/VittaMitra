import { BaseRepository } from './baseRepository.js';
import { parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';

export const INVESTMENT_ASSET_TYPES = [
  { key: 'mutual_fund', label: 'Mutual Fund / SIP', icon: '📊', defaultReturn: 12 },
  { key: 'stocks', label: 'Stocks / Equity', icon: '📈', defaultReturn: 14 },
  { key: 'fd_rd', label: 'FD / RD', icon: '🏦', defaultReturn: 7 },
  { key: 'ppf_epf', label: 'PPF / EPF / NPS', icon: '🛡️', defaultReturn: 8 },
  { key: 'gold', label: 'Gold / SGB', icon: '🪙', defaultReturn: 10 },
  { key: 'real_estate', label: 'Real Estate', icon: '🏠', defaultReturn: 9 },
  { key: 'other', label: 'Other Investment', icon: '💼', defaultReturn: 10 },
];

export class InvestmentRepository extends BaseRepository {
  constructor(db) {
    super(db, 'investments');
    this.txRepo = new BaseRepository(db, 'investment_transactions');
  }

  async listAll() {
    const rows = await this.getAll({ includeDeleted: false });
    return rows.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  }

  async listTransactions(investmentId = null) {
    const rows = await this.txRepo.getAll({ includeDeleted: false });
    return rows
      .filter((r) => (!investmentId || r.investment_id === investmentId))
      .sort((a, b) => String(a.date_key || '').localeCompare(String(b.date_key || '')));
  }

  async createInvestment({
    name,
    asset_type = 'mutual_fund',
    invested_rupees = '0',
    invested_paise = null,
    current_value_rupees = null,
    current_value_paise = null,
    expected_annual_return_pct = 12,
    monthly_sip_rupees = '0',
    monthly_sip_paise = null,
    goal_name = '',
    goal_target_rupees = '0',
    goal_target_paise = null,
    goal_target_date = '',
    start_date = toLocalDateString(),
    notes = '',
  }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Investment name is required.');

    const invPaise =
      invested_paise !== null
        ? Number(invested_paise)
        : parseRupeesToPaise(invested_rupees || '0', { allowZero: true, allowNegative: false });

    const curPaise =
      current_value_paise !== null
        ? Number(current_value_paise)
        : current_value_rupees !== null && current_value_rupees !== ''
          ? parseRupeesToPaise(current_value_rupees, { allowZero: true, allowNegative: false })
          : invPaise;

    const sipPaise =
      monthly_sip_paise !== null
        ? Number(monthly_sip_paise)
        : parseRupeesToPaise(monthly_sip_rupees || '0', { allowZero: true, allowNegative: false });

    const goalPaise =
      goal_target_paise !== null
        ? Number(goal_target_paise)
        : parseRupeesToPaise(goal_target_rupees || '0', { allowZero: true, allowNegative: false });

    const record = await this.create({
      name: cleanName,
      asset_type,
      invested_paise: invPaise,
      current_value_paise: curPaise,
      expected_annual_return_pct: Number(expected_annual_return_pct) || 0,
      monthly_sip_paise: sipPaise,
      goal_name: String(goal_name || '').trim(),
      goal_target_paise: goalPaise,
      goal_target_date: goal_target_date || '',
      start_date: start_date || toLocalDateString(),
      notes: String(notes || '').trim(),
    });

    // Seed initial investment cashflow for XIRR if invested > 0
    if (invPaise > 0) {
      await this.txRepo.create({
        investment_id: record.id,
        date_key: record.start_date,
        tx_type: 'buy',
        amount_paise: invPaise,
        notes: 'Initial investment',
      });
    }

    return record;
  }

  async addCashflow(investmentId, { date_key = toLocalDateString(), tx_type = 'buy', amount_rupees, amount_paise = null, new_current_value_rupees = null, notes = '' }) {
    const inv = await this.getById(investmentId);
    if (!inv) throw new Error('Investment not found.');

    const amtPaise =
      amount_paise !== null
        ? Number(amount_paise)
        : parseRupeesToPaise(amount_rupees || '0', { allowZero: tx_type === 'valuation', allowNegative: false });

    const tx = await this.txRepo.create({
      investment_id: investmentId,
      date_key,
      tx_type,
      amount_paise: amtPaise,
      notes: String(notes || '').trim(),
    });

    let nextInvested = inv.invested_paise || 0;
    let nextCurrent = inv.current_value_paise || 0;

    if (tx_type === 'buy' || tx_type === 'sip') {
      nextInvested += amtPaise;
      nextCurrent += amtPaise;
    } else if (tx_type === 'sell') {
      nextInvested = Math.max(0, nextInvested - amtPaise);
      nextCurrent = Math.max(0, nextCurrent - amtPaise);
    }

    if (new_current_value_rupees !== null && String(new_current_value_rupees).trim() !== '') {
      nextCurrent = parseRupeesToPaise(new_current_value_rupees, { allowZero: true, allowNegative: false });
    } else if (tx_type === 'valuation') {
      nextCurrent = amtPaise;
    }

    const updated = await this.update(investmentId, {
      invested_paise: nextInvested,
      current_value_paise: nextCurrent,
    });

    return { investment: updated, cashflow: tx };
  }
}

import { BaseRepository } from './baseRepository.js';
import { parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';

export const LOAN_TYPES = [
  { key: 'home_loan', label: 'Home Loan', icon: '🏡' },
  { key: 'car_loan', label: 'Car / Vehicle Loan', icon: '🚗' },
  { key: 'personal_loan', label: 'Personal Loan', icon: '💳' },
  { key: 'education_loan', label: 'Education Loan', icon: '🎓' },
  { key: 'gold_loan', label: 'Gold Loan', icon: '🪙' },
  { key: 'other', label: 'Other Loan', icon: '📄' },
];

export function computeStandardEmiPaise(principalPaise, annualRatePct, tenureMonths) {
  const P = Math.max(0, Number(principalPaise) || 0);
  const n = Math.max(1, Math.round(Number(tenureMonths) || 1));
  const r = Math.max(0, Number(annualRatePct) || 0) / 100 / 12;
  if (P === 0) return 0;
  if (r === 0) return Math.round(P / n);
  const factor = Math.pow(1 + r, n);
  return Math.round((P * r * factor) / (factor - 1));
}

export class LoanRepository extends BaseRepository {
  constructor(db) {
    super(db, 'loans');
  }

  async listAll() {
    const rows = await this.getAll({ includeDeleted: false });
    return rows.sort((a, b) => Number(b.is_active !== false) - Number(a.is_active !== false) || String(a.name || '').localeCompare(String(b.name || '')));
  }

  async createLoan({
    name,
    loan_type = 'home_loan',
    principal_rupees,
    principal_paise = null,
    outstanding_rupees = null,
    outstanding_paise = null,
    interest_rate_pct = 8.5,
    tenure_months = 240,
    remaining_months = null,
    emi_rupees = null,
    emi_paise = null,
    start_date = toLocalDateString(),
    notes = '',
  }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Loan name is required.');

    const pPaise =
      principal_paise !== null
        ? Number(principal_paise)
        : parseRupeesToPaise(principal_rupees || '0', { allowZero: false, allowNegative: false });

    const outPaise =
      outstanding_paise !== null
        ? Number(outstanding_paise)
        : outstanding_rupees !== null && String(outstanding_rupees).trim() !== ''
          ? parseRupeesToPaise(outstanding_rupees, { allowZero: true, allowNegative: false })
          : pPaise;

    const rate = Math.max(0, Number(interest_rate_pct) || 0);
    const tenure = Math.max(1, Math.round(Number(tenure_months) || 12));
    const remMonths = remaining_months !== null && String(remaining_months).trim() !== ''
      ? Math.max(1, Math.round(Number(remaining_months)))
      : tenure;

    const computedEmi =
      emi_paise !== null
        ? Number(emi_paise)
        : emi_rupees !== null && String(emi_rupees).trim() !== ''
          ? parseRupeesToPaise(emi_rupees, { allowZero: false, allowNegative: false })
          : computeStandardEmiPaise(outPaise, rate, remMonths);

    return this.create({
      name: cleanName,
      loan_type,
      principal_paise: pPaise,
      outstanding_paise: outPaise,
      interest_rate_pct: rate,
      tenure_months: tenure,
      remaining_months: remMonths,
      emi_paise: computedEmi,
      start_date: start_date || toLocalDateString(),
      is_active: outPaise > 0,
      notes: String(notes || '').trim(),
    });
  }
}

export class NetWorthSnapshotRepository extends BaseRepository {
  constructor(db) {
    super(db, 'net_worth_snapshots');
  }

  async listAll() {
    const rows = await this.getAll({ includeDeleted: false });
    return rows.sort((a, b) => String(a.snapshot_date || '').localeCompare(String(b.snapshot_date || '')));
  }

  async upsertSnapshot({ snapshot_date = toLocalDateString(), assets_paise, investments_paise, liabilities_paise, net_worth_paise }) {
    const all = await this.listAll();
    const monthKey = String(snapshot_date).slice(0, 7);
    const existing = all.find((s) => String(s.snapshot_date || '').startsWith(monthKey));
    if (existing) {
      return this.update(existing.id, {
        snapshot_date,
        assets_paise,
        investments_paise,
        liabilities_paise,
        net_worth_paise,
      });
    }
    return this.create({
      snapshot_date,
      assets_paise,
      investments_paise,
      liabilities_paise,
      net_worth_paise,
    });
  }
}

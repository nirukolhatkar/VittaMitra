import { BaseRepository } from './baseRepository.js';
import { parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';

export class RecurringRepository extends BaseRepository {
  constructor(db) {
    super(db, 'recurring_rules', { syncable: true });
  }

  async listAll() {
    const all = await this.getAll({ includeDeleted: false });
    return all.sort((a, b) => String(a.next_due_date || '').localeCompare(String(b.next_due_date || '')));
  }

  async createRule({
    name,
    type = 'expense',
    amount_paise = undefined,
    amount_rupees = undefined,
    category_id = null,
    account_id,
    to_account_id = null,
    frequency = 'monthly', // 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'half_yearly' | 'yearly' | 'custom_days'
    interval_value = 1,
    start_date = toLocalDateString(),
    end_date = null,
    next_due_date = null,
    auto_post = false, // Review-and-confirm by default per spec Section 7.3
    is_active = true,
    notes = '',
  }) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('Recurring rule name is required');
    if (!['expense', 'income', 'transfer'].includes(type)) throw new Error('Invalid recurring type');
    if (!account_id) throw new Error('Account is required');
    if (type === 'transfer' && (!to_account_id || to_account_id === account_id)) {
      throw new Error('Select a different destination account for recurring transfers');
    }

    const amountPaise =
      amount_rupees !== undefined ? parseRupeesToPaise(amount_rupees, { allowNegative: false }) : amount_paise;
    if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) {
      throw new Error('Recurring amount must be greater than ₹0.00');
    }

    const start = start_date || toLocalDateString();
    return this.create({
      name: cleanName,
      type,
      amount_paise: amountPaise,
      category_id: type === 'transfer' ? null : category_id || null,
      account_id,
      to_account_id: type === 'transfer' ? to_account_id : null,
      frequency: frequency || 'monthly',
      interval_value: Math.max(1, Number(interval_value) || 1),
      start_date: start,
      end_date: end_date || null,
      next_due_date: next_due_date || start,
      auto_post: Boolean(auto_post),
      is_active: Boolean(is_active),
      last_generated_date: null,
      notes: String(notes || '').trim(),
    });
  }

  async updateRule(id, patch) {
    const nextPatch = { ...patch };
    if (patch.amount_rupees !== undefined) {
      nextPatch.amount_paise = parseRupeesToPaise(patch.amount_rupees, { allowNegative: false });
      delete nextPatch.amount_rupees;
    }
    return this.update(id, nextPatch);
  }
}

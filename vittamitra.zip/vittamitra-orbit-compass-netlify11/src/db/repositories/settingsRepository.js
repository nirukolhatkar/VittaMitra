import { BaseRepository } from './baseRepository.js';
import { DEFAULT_SETTINGS } from '../../constants/defaultSeeds.js';

export class SettingsRepository extends BaseRepository {
  constructor(db) {
    super(db, 'settings', { syncable: true });
  }

  async getSettings() {
    const existing = await this.getById(DEFAULT_SETTINGS.id);
    if (existing) return existing;
    return this.create({ ...DEFAULT_SETTINGS });
  }

  async updateSettings(patch) {
    const existing = await this.getSettings();
    return this.update(existing.id, patch);
  }
}

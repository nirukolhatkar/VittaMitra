import { BaseRepository } from './baseRepository.js';
import { generateUUID } from '../../utils/uuid.js';
import { nowIsoUtc } from '../../utils/date.js';

/**
 * Complete field and index contracts for Smart Statement Import (Schema v8).
 * Defined upfront so Modules 2-7 share a stable, additive IndexedDB contract.
 */
export const V8_SCHEMA_CONTRACTS = Object.freeze({
  import_batches_statement_fields: [
    'id',
    'user_id',
    'source_type', // 'statement' | 'upi_screenshot' | 'spreadsheet'
    'source_files', // array of { source_index, filename, file_ext, mime_type, file_size, file_hash }
    'filename',
    'file_ext',
    'mime_type',
    'file_size',
    'file_hash', // SHA-256 hex digest
    'institution',
    'account_id',
    'masked_account_ref', // e.g. XXXX1234 (never full account/card number)
    'account_confirmed',
    'period_start',
    'period_end',
    'opening_balance_paise',
    'closing_balance_paise',
    'is_password_protected',
    'duplicate_of_batch_id',
    'status', // 'uploaded' | 'extracting' | 'review_ready' | 'partially_imported' | 'imported' | 'failed'
    'row_count',
    'imported_count',
    'skipped_count',
    'summary_json',
    'imported_at',
    'rolled_back_at',
    'created_at',
    'updated_at',
    'version',
    'deleted_at',
  ],
  staged_transactions: {
    indexes:
      'id, user_id, batch_id, status, date_key, account_id, ledger_transaction_id, idempotency_key, row_fingerprint, deleted_at, updated_at',
    fields: [
      'id',
      'user_id',
      'batch_id',
      'source_row_index',
      'source_page',
      'raw_narration',
      'date_key',
      'value_date_key',
      'description',
      'merchant',
      'normalized_merchant',
      'debit_paise',
      'credit_paise',
      'amount_paise',
      'transaction_reference',
      'tx_type',
      'account_id',
      'to_account_id',
      'category_id',
      'subcategory_id',
      'confidence_score',
      'categorisation_source',
      'splits_json',
      'status', // 'new' | 'needs_attention' | 'duplicate' | 'approved' | 'excluded' | 'imported' | 'failed'
      'ledger_transaction_id',
      'idempotency_key',
      'row_fingerprint',
      'notes',
      'created_at',
      'updated_at',
      'version',
      'deleted_at',
    ],
  },
  personal_learning_rules: {
    indexes: 'id, user_id, rule_type, match_key, priority, is_active, deleted_at, updated_at',
    fields: [
      'id',
      'user_id',
      'rule_type', // 'exact_merchant' | 'narration_pattern' | 'confirmed_preference'
      'match_key',
      'match_pattern',
      'category_id',
      'subcategory_id',
      'tx_type',
      'account_id',
      'priority',
      'hit_count',
      'last_confirmed_at',
      'is_active',
      'created_at',
      'updated_at',
      'version',
      'deleted_at',
    ],
  },
  merchant_dictionary: {
    indexes: 'id, user_id, normalized_merchant, category_hint, is_builtin, priority, deleted_at, updated_at',
    fields: [
      'id',
      'user_id',
      'normalized_merchant',
      'display_name',
      'aliases',
      'category_hint',
      'subcategory_hint',
      'tx_type_hint',
      'is_builtin', // false = personal override (always takes precedence over true = built-in)
      'priority',
      'created_at',
      'updated_at',
      'version',
      'deleted_at',
    ],
  },
  reconciliation_matches: {
    indexes:
      'id, user_id, batch_id, staged_tx_id, matched_tx_id, matched_staged_tx_id, match_type, confidence_score, resolution, deleted_at, updated_at',
    fields: [
      'id',
      'user_id',
      'batch_id',
      'staged_tx_id',
      'matched_tx_id',
      'matched_staged_tx_id',
      'match_type', // 'exact_duplicate' | 'probable_duplicate' | 'internal_transfer' | 'cc_settlement' | 'refund_link' | 'recurring'
      'confidence_score',
      'match_reasons',
      'resolution', // 'pending' | 'confirmed' | 'rejected'
      'resolved_at',
      'created_at',
      'updated_at',
      'version',
      'deleted_at',
    ],
  },
});

export function normalizeMerchantKey(raw) {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export class StatementImportRepository {
  constructor(db) {
    this.db = db;
    this.batches = new BaseRepository(db, 'import_batches');
    this.stagedTransactions = new BaseRepository(db, 'staged_transactions');
    this.learningRules = new BaseRepository(db, 'personal_learning_rules');
    this.merchantDictionary = new BaseRepository(db, 'merchant_dictionary');
    this.reconciliationMatches = new BaseRepository(db, 'reconciliation_matches');
  }

  // ---------- Import Batches (Statement-scoped; preserves legacy import_batches) ----------

  async createStatementBatch(meta) {
    const now = nowIsoUtc();
    const record = {
      id: meta.id || generateUUID(),
      user_id: null,
      source_type: meta.source_type || 'statement',
      source_files: Array.isArray(meta.source_files) ? meta.source_files : null,
      filename: String(meta.filename || '').trim(),
      file_ext: String(meta.file_ext || '').toLowerCase(),
      mime_type: String(meta.mime_type || ''),
      file_size: Number(meta.file_size) || 0,
      file_hash: String(meta.file_hash || ''),
      institution: String(meta.institution || '').trim(),
      account_id: meta.account_id || null,
      masked_account_ref: String(meta.masked_account_ref || '').trim(),
      account_confirmed: Boolean(meta.account_confirmed),
      period_start: meta.period_start || null,
      period_end: meta.period_end || null,
      opening_balance_paise: meta.opening_balance_paise ?? null,
      closing_balance_paise: meta.closing_balance_paise ?? null,
      is_password_protected: Boolean(meta.is_password_protected),
      duplicate_of_batch_id: meta.duplicate_of_batch_id || null,
      status: meta.status || 'uploaded',
      row_count: Number(meta.row_count) || 0,
      imported_count: Number(meta.imported_count) || 0,
      skipped_count: Number(meta.skipped_count) || 0,
      summary_json: meta.summary_json || null,
      imported_at: meta.imported_at || now,
      rolled_back_at: null,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    };
    await this.db.table('import_batches').add(record);
    return record;
  }

  async listStatementBatches({ includeDeleted = false } = {}) {
    const all = await this.db.table('import_batches').toArray();
    return all
      .filter((b) => (b.source_type === 'statement' || b.source_type === 'upi_screenshot') && (includeDeleted || !b.deleted_at))
      .sort((a, b) => String(b.imported_at || b.created_at || '').localeCompare(String(a.imported_at || a.created_at || '')));
  }

  async getBatchById(batchId) {
    return this.db.table('import_batches').get(batchId);
  }

  async findActiveBatchByHash(fileHash) {
    if (!fileHash) return null;
    const batches = await this.listStatementBatches({ includeDeleted: false });
    return (
      batches.find((b) => {
        if (b.rolled_back_at) return false;
        if (b.file_hash === fileHash) return true;
        if (Array.isArray(b.source_files)) {
          return b.source_files.some((f) => f.file_hash === fileHash);
        }
        return false;
      }) || null
    );
  }

  async updateStatementBatchMetadata(batchId, patch) {
    const existing = await this.db.table('import_batches').get(batchId);
    if (!existing || existing.deleted_at) {
      throw new Error('Statement import batch not found.');
    }
    const allowed = {
      institution: patch.institution !== undefined ? String(patch.institution).trim() : existing.institution,
      account_id: patch.account_id !== undefined ? patch.account_id : existing.account_id,
      masked_account_ref:
        patch.masked_account_ref !== undefined ? String(patch.masked_account_ref).trim() : existing.masked_account_ref,
      account_confirmed:
        patch.account_confirmed !== undefined ? Boolean(patch.account_confirmed) : existing.account_confirmed,
      period_start: patch.period_start !== undefined ? patch.period_start || null : existing.period_start,
      period_end: patch.period_end !== undefined ? patch.period_end || null : existing.period_end,
      status: patch.status !== undefined ? patch.status : existing.status,
    };
    const updated = {
      ...existing,
      ...allowed,
      updated_at: nowIsoUtc(),
      version: (existing.version || 1) + 1,
    };
    await this.db.table('import_batches').put(updated);
    return updated;
  }

  async softDeleteStatementBatch(batchId) {
    const existing = await this.db.table('import_batches').get(batchId);
    if (!existing || (existing.source_type !== 'statement' && existing.source_type !== 'upi_screenshot')) {
      throw new Error('Statement batch not found.');
    }
    if ((existing.imported_count || 0) > 0 && !existing.rolled_back_at) {
      throw new Error('Cannot delete a batch with imported ledger transactions. Roll back the batch first.');
    }
    const now = nowIsoUtc();
    await this.db.table('import_batches').put({
      ...existing,
      deleted_at: now,
      updated_at: now,
      version: (existing.version || 1) + 1,
    });
    // Also soft-delete any staged rows / reconciliation matches belonging to this unimported batch
    const staged = (await this.db.table('staged_transactions').toArray()).filter((r) => r.batch_id === batchId);
    for (const row of staged) {
      if (!row.deleted_at) {
        await this.db.table('staged_transactions').put({ ...row, deleted_at: now, updated_at: now });
      }
    }
    const matches = (await this.db.table('reconciliation_matches').toArray()).filter((m) => m.batch_id === batchId);
    for (const m of matches) {
      if (!m.deleted_at) {
        await this.db.table('reconciliation_matches').put({ ...m, deleted_at: now, updated_at: now });
      }
    }
    return { deletedBatchId: batchId };
  }

  // ---------- Merchant Dictionary (Personal overrides ALWAYS beat built-in) ----------

  async upsertMerchantEntry({
    id = null,
    normalized_merchant,
    display_name,
    aliases = [],
    category_hint = null,
    subcategory_hint = null,
    tx_type_hint = null,
    is_builtin = false,
    priority = null,
  }) {
    const norm = normalizeMerchantKey(normalized_merchant || display_name);
    if (!norm) throw new Error('Merchant name is required.');
    const resolvedPriority = priority !== null ? Number(priority) : is_builtin ? 10 : 100;
    const payload = {
      normalized_merchant: norm,
      display_name: String(display_name || normalized_merchant).trim(),
      aliases: Array.isArray(aliases) ? aliases : [],
      category_hint: category_hint || null,
      subcategory_hint: subcategory_hint || null,
      tx_type_hint: tx_type_hint || null,
      is_builtin: Boolean(is_builtin),
      priority: resolvedPriority,
    };

    if (id) {
      return this.merchantDictionary.update(id, payload);
    }

    const existing = (await this.db.table('merchant_dictionary').toArray()).filter(
      (e) => e.normalized_merchant === norm
    );
    const sameScope = existing.find((e) => !e.deleted_at && Boolean(e.is_builtin) === Boolean(is_builtin));
    if (sameScope) {
      return this.merchantDictionary.update(sameScope.id, payload);
    }
    return this.merchantDictionary.create(payload);
  }

  /**
   * Resolves a merchant entry from merchant_dictionary.
   * Mandatory rule: personal entries (is_builtin === false) ALWAYS take precedence
   * over built-in dictionary entries (is_builtin === true).
   */
  async resolveMerchant(rawName) {
    const norm = normalizeMerchantKey(rawName);
    if (!norm) return null;
    const matches = (await this.db.table('merchant_dictionary').toArray()).filter(
      (m) => m.normalized_merchant === norm
    );
    const active = matches.filter((m) => !m.deleted_at);
    if (active.length === 0) return null;

    active.sort((a, b) => {
      const aPersonal = a.is_builtin === false ? 1 : 0;
      const bPersonal = b.is_builtin === false ? 1 : 0;
      if (aPersonal !== bPersonal) return bPersonal - aPersonal;
      const pDiff = (Number(b.priority) || 0) - (Number(a.priority) || 0);
      if (pDiff !== 0) return pDiff;
      return String(b.updated_at || '').localeCompare(String(a.updated_at || ''));
    });
    return active[0];
  }

  // ---------- Personal Learning Rules (Storage & Backup CRUD) ----------

  async createLearningRule({
    rule_type,
    match_key,
    match_pattern = '',
    category_id = null,
    subcategory_id = null,
    tx_type = null,
    account_id = null,
    priority = 100,
    is_active = true,
  }) {
    const cleanKey = normalizeMerchantKey(match_key);
    if (!cleanKey) throw new Error('Learning rule match_key is required.');
    return this.learningRules.create({
      rule_type: rule_type || 'exact_merchant',
      match_key: cleanKey,
      match_pattern: String(match_pattern || ''),
      category_id,
      subcategory_id,
      tx_type,
      account_id,
      priority: Number(priority) || 100,
      hit_count: 0,
      last_confirmed_at: nowIsoUtc(),
      is_active: Boolean(is_active),
    });
  }

  async listActiveLearningRules() {
    const all = await this.learningRules.getAll({ includeDeleted: false });
    return all
      .filter((r) => r.is_active !== false)
      .sort((a, b) => (Number(b.priority) || 0) - (Number(a.priority) || 0));
  }
}

import { BaseRepository } from './baseRepository.js';
import { normalizeTagInput } from '../../utils/normalize.js';

export class TagRepository extends BaseRepository {
  constructor(db) {
    super(db, 'tags', { syncable: true });
  }

  async list({ includeArchived = false } = {}) {
    const all = await this.getAll({ includeDeleted: false });
    return all
      .filter((t) => (includeArchived ? true : !t.is_archived))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  async findByNormalizedKey(rawTag) {
    const norm = normalizeTagInput(rawTag);
    if (!norm) return null;
    const all = await this.getAll({ includeDeleted: false });
    return all.find((t) => t.normalized_key === norm.normalized_key) || null;
  }

  async createTag({ name, color = '#2563eb' }) {
    const norm = normalizeTagInput(name);
    if (!norm) throw new Error('Tag name is required');

    // Prevent duplicates caused by whitespace, '#' prefix, or capitalization differences
    const allIncludingDeleted = await this.getAll({ includeDeleted: true });
    const existing = allIncludingDeleted.find((t) => t.normalized_key === norm.normalized_key);

    if (existing && !existing.deleted_at) {
      throw new Error(`Tag "${norm.display}" already exists`);
    }

    // If a soft-deleted tombstone exists with the same unique normalized_key, restore & update it
    if (existing && existing.deleted_at) {
      await this.restore(existing.id);
      return this.update(existing.id, {
        name: norm.name,
        color: color || existing.color,
        is_archived: false,
      });
    }

    return this.create({
      name: norm.name,
      normalized_key: norm.normalized_key,
      color: color || '#2563eb',
      is_archived: false,
    });
  }

  async updateTag(id, { name, color, is_archived }) {
    const current = await this.getById(id);
    if (!current) throw new Error('Tag not found');

    const patch = {};
    if (color !== undefined) patch.color = color;
    if (is_archived !== undefined) patch.is_archived = Boolean(is_archived);

    if (name !== undefined) {
      const norm = normalizeTagInput(name);
      if (!norm) throw new Error('Tag name cannot be empty');
      const all = await this.getAll({ includeDeleted: false });
      const duplicate = all.find((t) => t.id !== id && t.normalized_key === norm.normalized_key);
      if (duplicate) {
        throw new Error(`Tag "${norm.display}" already exists`);
      }
      patch.name = norm.name;
      patch.normalized_key = norm.normalized_key;
    }

    return this.update(id, patch);
  }
}

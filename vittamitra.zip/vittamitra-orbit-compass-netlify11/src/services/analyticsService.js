import { escapeHtml } from '../utils/dom.js';
import { formatINR } from '../utils/money.js';
import { getCategoryColor } from '../utils/colors.js';
import { getFinancialYearInfo, getMonthLabel, shiftMonth } from '../utils/date.js';

function pad2(n) {
  return String(n).padStart(2, '0');
}

function toKey(dateObj) {
  return `${dateObj.getFullYear()}-${pad2(dateObj.getMonth() + 1)}-${pad2(dateObj.getDate())}`;
}

export class AnalyticsService {
  constructor(repos, services) {
    this.repos = repos;
    this.services = services;
  }

  resolvePeriod({ mode = 'month', year, month, weekOffset = 0, customStart = '', customEnd = '', weekStartDay = 1, fyStartMonth = 4 }) {
    if (mode === 'all') {
      return {
        mode: 'all',
        label: 'All Time',
        prevLabel: '',
        startDate: null,
        endDate: null,
        prevStartDate: '1900-01-01',
        prevEndDate: '1900-01-01',
        granularity: 'month',
        totalSlots: 12,
      };
    }
    const now = new Date();

    if (mode === 'week') {
      const ref = new Date(now.getFullYear(), now.getMonth(), now.getDate() + weekOffset * 7);
      const diffToStart = (ref.getDay() - weekStartDay + 7) % 7;
      const start = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate() - diffToStart);
      const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 6);
      const prevStart = new Date(start.getFullYear(), start.getMonth(), start.getDate() - 7);
      const prevEnd = new Date(start.getFullYear(), start.getMonth(), start.getDate() - 1);
      return {
        mode,
        label: `${toKey(start)} to ${toKey(end)}`,
        prevLabel: `${toKey(prevStart)} to ${toKey(prevEnd)}`,
        startDate: toKey(start),
        endDate: toKey(end),
        prevStartDate: toKey(prevStart),
        prevEndDate: toKey(prevEnd),
        granularity: 'day',
        totalSlots: 7,
      };
    }

    if (mode === 'year') {
      const y = year || now.getFullYear();
      return {
        mode,
        label: `${y}`,
        prevLabel: `${y - 1}`,
        startDate: `${y}-01-01`,
        endDate: `${y}-12-31`,
        prevStartDate: `${y - 1}-01-01`,
        prevEndDate: `${y - 1}-12-31`,
        granularity: 'month',
        totalSlots: 12,
      };
    }

    if (mode === 'fy') {
      const fy = getFinancialYearInfo(year ?? now.getFullYear(), month ?? now.getMonth(), fyStartMonth);
      const prevFy = getFinancialYearInfo((year ?? now.getFullYear()) - 1, month ?? now.getMonth(), fyStartMonth);
      return {
        mode,
        label: fy.label,
        prevLabel: prevFy.label,
        startDate: fy.startDate,
        endDate: fy.endDate,
        prevStartDate: prevFy.startDate,
        prevEndDate: prevFy.endDate,
        granularity: 'month',
        totalSlots: 12,
      };
    }

    if (mode === 'custom') {
      const s = customStart || `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-01`;
      const e = customEnd || toKey(now);
      const sDate = new Date(`${s}T00:00:00`);
      const eDate = new Date(`${e}T00:00:00`);
      const spanDays = Math.max(1, Math.round((eDate - sDate) / 86400000) + 1);
      const prevEnd = new Date(sDate.getTime() - 86400000);
      const prevStart = new Date(prevEnd.getTime() - (spanDays - 1) * 86400000);
      return {
        mode,
        label: `${s} to ${e}`,
        prevLabel: `${toKey(prevStart)} to ${toKey(prevEnd)}`,
        startDate: s,
        endDate: e,
        prevStartDate: toKey(prevStart),
        prevEndDate: toKey(prevEnd),
        granularity: spanDays > 62 ? 'month' : 'day',
        totalSlots: spanDays,
      };
    }

    const y = year ?? now.getFullYear();
    const m = month ?? now.getMonth();
    const days = new Date(y, m + 1, 0).getDate();
    const prev = shiftMonth(y, m, -1);
    const prevDays = new Date(prev.year, prev.month + 1, 0).getDate();
    return {
      mode: 'month',
      label: getMonthLabel(y, m),
      prevLabel: getMonthLabel(prev.year, prev.month),
      startDate: `${y}-${pad2(m + 1)}-01`,
      endDate: `${y}-${pad2(m + 1)}-${pad2(days)}`,
      prevStartDate: `${prev.year}-${pad2(prev.month + 1)}-01`,
      prevEndDate: `${prev.year}-${pad2(prev.month + 1)}-${pad2(prevDays)}`,
      granularity: 'day',
      totalSlots: days,
    };
  }

  async buildAnalysisReport({
    mode = 'month',
    year,
    month,
    weekOffset = 0,
    customStart = '',
    customEnd = '',
    accountIds = [],
    accountMode = 'include',
    familyIds = [],
    familyMode = 'include',
    categoryIds = [],
    categoryMode = 'include',
    tagIds = [],
    tagMode = 'any',
    type = 'all',
    search = '',
    years = [],
    months = [],
  } = {}) {
    const settings = await this.repos.settings.getSettings();
    const period = this.resolvePeriod({
      mode,
      year,
      month,
      weekOffset,
      customStart,
      customEnd,
      weekStartDay: Number(settings.week_start_day ?? 1),
      fyStartMonth: Number(settings.financial_year_start_month ?? 4),
    });

    const [currTxs, prevTxs, categories, accounts, tags, family] = await Promise.all([
      this.services.transactions.listTransactions({
        startDate: period.startDate,
        endDate: period.endDate,
        years,
        months,
        type,
        search,
        accountIds,
        accountMode,
        familyIds,
        familyMode,
        categoryIds,
        categoryMode,
        tagIds,
        tagMode,
      }),
      mode === 'all'
        ? Promise.resolve([])
        : this.services.transactions.listTransactions({
            startDate: period.prevStartDate,
            endDate: period.prevEndDate,
            type,
            search,
            accountIds,
            accountMode,
            familyIds,
            familyMode,
            categoryIds,
            categoryMode,
            tagIds,
            tagMode,
          }),
      this.repos.categories.list({ includeArchived: true }),
      this.repos.accounts.list({ includeArchived: true }),
      this.repos.tags.list({ includeArchived: true }),
      this.repos.family.list({ includeInactive: true }),
    ]);

    const catMap = new Map(categories.map((c) => [c.id, { ...c, color: getCategoryColor(c) }]));
    const accMap = new Map(accounts.map((a) => [a.id, a]));
    const tagMap = new Map(tags.map((t) => [t.id, t]));
    const famMap = new Map(family.map((f) => [f.id, f]));

    const summarize = (txList) => {
      let spending = 0;
      let income = 0;
      let spendCount = 0;
      let incomeCount = 0;
      const catSpend = new Map();
      const catIncome = new Map();
      const modeSpend = new Map();
      const modeIncome = new Map();
      const transferPairs = new Map(); // "srcId->dstId" => { sourceAccount, destinationAccount, total, count }
      const tagSpend = new Map();
      const famSpend = new Map();
      const byBucketSpend = new Map();
      const byBucketIncome = new Map();
      const weekdaySpend = [0, 0, 0, 0, 0, 0, 0]; // Mon..Sun
      const expensesList = [];

      for (const tx of txList) {
        const bucket = period.granularity === 'month' ? String(tx.date_key || '').slice(0, 7) : String(tx.date_key || '');
        if (tx.type === 'expense') {
          spending += tx.amount_paise;
          spendCount += 1;
          expensesList.push(tx);
          if (tx.date_key) {
            const d = new Date(`${tx.date_key}T00:00:00`);
            const monIdx = (d.getDay() + 6) % 7; // 0=Mon..6=Sun
            weekdaySpend[monIdx] += tx.amount_paise;
          }
          if (tx.category_id) {
            const entry = catSpend.get(tx.category_id) || { total: 0, count: 0, max: 0, min: Infinity };
            entry.total += tx.amount_paise;
            entry.count += 1;
            entry.max = Math.max(entry.max, tx.amount_paise);
            entry.min = Math.min(entry.min, tx.amount_paise);
            catSpend.set(tx.category_id, entry);
          }
          modeSpend.set(tx.account_id, (modeSpend.get(tx.account_id) || 0) + tx.amount_paise);
          if (tx.family_member_id) {
            famSpend.set(tx.family_member_id, (famSpend.get(tx.family_member_id) || 0) + tx.amount_paise);
          }
          for (const tid of tx.tag_ids || []) {
            tagSpend.set(tid, (tagSpend.get(tid) || 0) + tx.amount_paise);
          }
          byBucketSpend.set(bucket, (byBucketSpend.get(bucket) || 0) + tx.amount_paise);
        } else if (tx.type === 'income') {
          income += tx.amount_paise;
          incomeCount += 1;
          if (tx.category_id) {
            const entry = catIncome.get(tx.category_id) || { total: 0, count: 0, max: 0, min: Infinity };
            entry.total += tx.amount_paise;
            entry.count += 1;
            entry.max = Math.max(entry.max, tx.amount_paise);
            entry.min = Math.min(entry.min, tx.amount_paise);
            catIncome.set(tx.category_id, entry);
          }
          modeIncome.set(tx.account_id, (modeIncome.get(tx.account_id) || 0) + tx.amount_paise);
          for (const tid of tx.tag_ids || []) {
            if (!tagSpend.has(tid)) tagSpend.set(tid, 0);
          }
          byBucketIncome.set(bucket, (byBucketIncome.get(bucket) || 0) + tx.amount_paise);
        } else if (tx.type === 'transfer') {
          const pairKey = `${tx.account_id || ''}->${tx.to_account_id || ''}`;
          const prevPair = transferPairs.get(pairKey) || {
            sourceAccount: accMap.get(tx.account_id) || { name: 'Account', icon: '🏛️' },
            destinationAccount: accMap.get(tx.to_account_id) || { name: 'Account', icon: '🏛️' },
            total: 0,
            count: 0,
          };
          prevPair.total += tx.amount_paise;
          prevPair.count += 1;
          transferPairs.set(pairKey, prevPair);
        }
      }

      expensesList.sort((a, b) => b.amount_paise - a.amount_paise);

      return {
        spending,
        income,
        netBalance: income - spending,
        spendCount,
        incomeCount,
        catSpend,
        catIncome,
        modeSpend,
        modeIncome,
        transferPairs,
        tagSpend,
        famSpend,
        byBucketSpend,
        byBucketIncome,
        weekdaySpend,
        topExpenses: expensesList.slice(0, 5),
      };
    };

    const curr = summarize(currTxs);
    const prev = summarize(prevTxs);

    const buildSeries = (startStr, endStr, granularity, bucketMap) => {
      const keys = [];
      const labels = [];
      const values = [];
      const cumulative = [];
      let running = 0;

      if (granularity === 'month') {
        const sY = Number(startStr.slice(0, 4));
        const sM = Number(startStr.slice(5, 7)) - 1;
        const eY = Number(endStr.slice(0, 4));
        const eM = Number(endStr.slice(5, 7)) - 1;
        let cy = sY;
        let cm = sM;
        while (cy < eY || (cy === eY && cm <= eM)) {
          const k = `${cy}-${pad2(cm + 1)}`;
          keys.push(k);
          labels.push(getMonthLabel(cy, cm).slice(0, 3));
          const val = bucketMap.get(k) || 0;
          values.push(val);
          running += val;
          cumulative.push(running);
          const next = shiftMonth(cy, cm, 1);
          cy = next.year;
          cm = next.month;
          if (keys.length > 36) break;
        }
      } else {
        const sDate = new Date(`${startStr}T00:00:00`);
        const eDate = new Date(`${endStr}T00:00:00`);
        for (let d = new Date(sDate); d <= eDate; d.setDate(d.getDate() + 1)) {
          const k = toKey(d);
          keys.push(k);
          labels.push(String(d.getDate()));
          const val = bucketMap.get(k) || 0;
          values.push(val);
          running += val;
          cumulative.push(running);
          if (keys.length > 65) break;
        }
      }
      return { keys, labels, values, cumulative };
    };

    const todayKey = toKey(new Date());
    let effStart = period.startDate;
    let effEnd = period.endDate;
    if (!effStart || !effEnd) {
      const validDates = currTxs.map((t) => String(t.date_key || '')).filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)).sort();
      if (validDates.length > 0) {
        effStart = validDates[0];
        effEnd = validDates[validDates.length - 1];
      } else {
        effStart = `${todayKey.slice(0, 7)}-01`;
        effEnd = todayKey;
      }
    }

    const spendTrend = buildSeries(effStart, effEnd, period.granularity, curr.byBucketSpend);
    const prevSpendTrend = period.mode === 'all'
      ? { keys: [], labels: [], values: [], cumulative: [] }
      : buildSeries(period.prevStartDate, period.prevEndDate, period.granularity, prev.byBucketSpend);
    const incomeTrend = buildSeries(effStart, effEnd, period.granularity, curr.byBucketIncome);
    const prevIncomeTrend = period.mode === 'all'
      ? { keys: [], labels: [], values: [], cumulative: [] }
      : buildSeries(period.prevStartDate, period.prevEndDate, period.granularity, prev.byBucketIncome);

    let elapsedDays = Math.max(1, spendTrend.keys.length);
    if (period.granularity === 'day' && effStart && effEnd && todayKey >= effStart && todayKey <= effEnd) {
      elapsedDays = Math.max(1, spendTrend.keys.indexOf(todayKey) + 1);
    }
    const prevSamePointSpend =
      prevSpendTrend.cumulative[Math.min(elapsedDays - 1, Math.max(0, prevSpendTrend.cumulative.length - 1))] || 0;
    const projectedSpend =
      period.mode === 'month' && elapsedDays < spendTrend.keys.length && elapsedDays > 0
        ? Math.round((curr.spending / elapsedDays) * spendTrend.keys.length)
        : curr.spending;

    const buildCatRows = (currMap, prevMap, totalSum) =>
      Array.from(currMap.entries())
        .map(([id, info]) => {
          const prevInfo = prevMap.get(id);
          const prevTotal = prevInfo ? prevInfo.total : 0;
          const deltaPct = prevTotal > 0 ? ((info.total - prevTotal) / prevTotal) * 100 : null;
          return {
            id,
            category: catMap.get(id) || { name: 'Uncategorised', icon: '🏷️', color: '#64748b' },
            total: info.total,
            count: info.count,
            avg: Math.round(info.total / info.count),
            max: info.max,
            min: info.min === Infinity ? 0 : info.min,
            sharePct: totalSum > 0 ? (info.total / totalSum) * 100 : 0,
            prevTotal,
            deltaPct,
          };
        })
        .sort((a, b) => b.total - a.total);

    const buildModeRows = (m) =>
      Array.from(m.entries())
        .map(([id, total]) => ({
          id,
          account: accMap.get(id) || { name: 'Account', icon: '🏛️' },
          total,
        }))
        .sort((a, b) => b.total - a.total);

    // Transfer pairs sorted by highest total: Source -> Destination
    const transferRows = Array.from(curr.transferPairs.values()).sort((a, b) => b.total - a.total);

    const tagRows = Array.from(curr.tagSpend.entries())
      .map(([id, total]) => ({ id, tag: tagMap.get(id), total }))
      .filter((r) => r.tag)
      .sort((a, b) => b.total - a.total);

    const familyRows = Array.from(curr.famSpend.entries())
      .map(([id, total]) => ({ id, member: famMap.get(id), total }))
      .filter((r) => r.member)
      .sort((a, b) => b.total - a.total);

    const activeDaysForAvg = Math.max(1, period.granularity === 'day' ? elapsedDays : Math.round(period.totalSlots * 30.4));
    const avgSpendPerDay = Math.round(curr.spending / activeDaysForAvg);
    const avgSpendPerTx = curr.spendCount > 0 ? Math.round(curr.spending / curr.spendCount) : 0;
    const avgIncomePerDay = Math.round(curr.income / activeDaysForAvg);
    const avgIncomePerTx = curr.incomeCount > 0 ? Math.round(curr.income / curr.incomeCount) : 0;

    let highestBucket = null;
    for (let i = 0; i < spendTrend.keys.length; i += 1) {
      if (spendTrend.values[i] > 0 && (!highestBucket || spendTrend.values[i] > highestBucket.amount)) {
        highestBucket = { key: spendTrend.keys[i], label: spendTrend.labels[i], amount: spendTrend.values[i] };
      }
    }

    const top5Sum = curr.topExpenses.reduce((s, tx) => s + tx.amount_paise, 0);
    const top5SharePct = curr.spending > 0 ? (top5Sum / curr.spending) * 100 : 0;

    return {
      period,
      transactionCount: currTxs.length,
      spending: curr.spending,
      income: curr.income,
      netBalance: curr.netBalance,
      prevSpending: prev.spending,
      prevIncome: prev.income,
      prevSamePointSpend,
      projectedSpend,
      elapsedDays,
      categories: {
        expense: buildCatRows(curr.catSpend, prev.catSpend, curr.spending),
        income: buildCatRows(curr.catIncome, prev.catIncome, curr.income),
      },
      trends: {
        expense: { current: spendTrend, previous: prevSpendTrend },
        income: { current: incomeTrend, previous: prevIncomeTrend },
      },
      paymentModes: {
        expense: buildModeRows(curr.modeSpend),
        income: buildModeRows(curr.modeIncome),
        transfer: transferRows,
      },
      weekdaySpend: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        values: curr.weekdaySpend,
      },
      topExpenses: curr.topExpenses,
      top5SharePct,
      tags: tagRows,
      family: familyRows,
      stats: {
        avgSpendPerDay,
        avgSpendPerTx,
        avgIncomePerDay,
        avgIncomePerTx,
        highestBucket,
      },
      transactions: currTxs,
      lookups: { catMap, accMap },
    };
  }

  buildPrintableReportHtml(report, { titleOverride = null } = {}) {
    const { period, income, spending, netBalance, transactions, categories, lookups } = report;
    const heading = titleOverride || `Statement — ${period.label}`;

    const txRowsHtml = transactions
      .map((tx) => {
        const cat = tx.category_id ? lookups.catMap.get(tx.category_id) : null;
        const srcAcc = lookups.accMap.get(tx.account_id);
        const dstAcc = tx.to_account_id ? lookups.accMap.get(tx.to_account_id) : null;
        const amtPrefix = tx.type === 'income' ? '+' : tx.type === 'expense' ? '-' : '';
        const amtColor = tx.type === 'income' ? '#15803d' : tx.type === 'expense' ? '#111827' : '#475569';
        const modeHtml =
          tx.type === 'transfer'
            ? `From: ${escapeHtml(srcAcc?.name || '')}<br>To: ${escapeHtml(dstAcc?.name || '')}`
            : escapeHtml(srcAcc?.name || '');
        return `
          <tr>
            <td><strong>${escapeHtml(tx.date_key)}</strong><br><span class="muted">${escapeHtml((tx.occurred_at_local || '').slice(11, 16))}</span></td>
            <td style="color:${amtColor}; font-weight:600; white-space:nowrap;">${amtPrefix}${formatINR(tx.amount_paise)}</td>
            <td><strong>${escapeHtml(tx.description || (tx.type === 'transfer' ? 'Transfer' : cat?.name || 'Transaction'))}</strong><br><span class="muted">${escapeHtml(tx.type === 'transfer' ? 'Transfer' : cat?.name || '')}</span></td>
            <td>${modeHtml}</td>
          </tr>
        `;
      })
      .join('');

    const spendStatsHtml = categories.expense
      .map((r) => `<tr><td>${escapeHtml(r.category.name)}</td><td style="text-align:right; font-weight:600;">${formatINR(r.total)}</td></tr>`)
      .join('');
    const incStatsHtml = categories.income
      .map((r) => `<tr><td>${escapeHtml(r.category.name)}</td><td style="text-align:right; font-weight:600;">${formatINR(r.total)}</td></tr>`)
      .join('');

    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Personal Finance Manager — ${escapeHtml(heading)}</title>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #111827; margin: 0; padding: 24px; }
  .header { display: flex; justify-content: space-between; align-items: center; background: #111827; color: #fff; padding: 16px 20px; border-radius: 8px; margin-bottom: 18px; }
  .header h1 { margin: 0; font-size: 18px; }
  .summary-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-bottom: 20px; }
  .summary-box { border: 1px solid #cbd5e1; border-radius: 6px; padding: 12px 14px; }
  .summary-val { font-size: 18px; font-weight: 700; }
  .summary-lbl { font-size: 12px; color: #64748b; margin-top: 4px; }
  table { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-bottom: 24px; }
  th { text-align: left; border-bottom: 2px solid #111827; padding: 8px 6px; font-size: 11px; text-transform: uppercase; color: #475569; }
  td { border-bottom: 1px solid #e2e8f0; padding: 8px 6px; vertical-align: top; }
  .muted { color: #64748b; font-size: 11px; }
  .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; page-break-before: auto; }
  .section-bar { padding: 6px 10px; font-weight: 700; font-size: 12px; display: flex; justify-content: space-between; border-radius: 4px; margin-bottom: 6px; }
  .bar-red { background: #fee2e2; color: #991b1b; }
  .bar-green { background: #dcfce7; color: #166534; }
  @media print { body { padding: 0; } .no-print { display: none; } }
</style>
</head>
<body>
  <div class="no-print" style="margin-bottom:14px; display:flex; gap:10px;">
    <button onclick="window.print()" style="padding:8px 16px; background:#0f766e; color:#fff; border:none; border-radius:6px; font-weight:600; cursor:pointer;">Print / Save as PDF</button>
    <button onclick="window.close()" style="padding:8px 16px; background:#e2e8f0; border:none; border-radius:6px; cursor:pointer;">Close</button>
  </div>
  <div class="header">
    <h1>Personal Finance Manager</h1>
    <div>${escapeHtml(heading)}</div>
  </div>
  <div class="summary-grid">
    <div class="summary-box">
      <div class="summary-val" style="color:#15803d;">${formatINR(income)}</div>
      <div class="summary-lbl">Income</div>
    </div>
    <div class="summary-box">
      <div class="summary-val">${formatINR(spending)}</div>
      <div class="summary-lbl">Spending</div>
    </div>
    <div class="summary-box">
      <div class="summary-val" style="color:${netBalance < 0 ? '#dc2626' : '#15803d'};">${formatINR(netBalance)}</div>
      <div class="summary-lbl">Net Balance</div>
    </div>
  </div>
  <table>
    <thead><tr><th>Date</th><th>Amount</th><th>Details</th><th>Payment Mode</th></tr></thead>
    <tbody>${txRowsHtml || '<tr><td colspan="4" class="muted">No transactions in this period.</td></tr>'}</tbody>
  </table>
  <h2 style="font-size:15px; margin-bottom:10px;">Stats — ${escapeHtml(period.label)} (${transactions.length} transactions)</h2>
  <div class="stats-grid">
    <div>
      <div class="section-bar bar-red"><span>SPENDING</span><span>${formatINR(spending)}</span></div>
      <table><tbody>${spendStatsHtml || '<tr><td class="muted">None</td></tr>'}</tbody></table>
    </div>
    <div>
      <div class="section-bar bar-green"><span>INCOME</span><span>${formatINR(income)}</span></div>
      <table><tbody>${incStatsHtml || '<tr><td class="muted">None</td></tr>'}</tbody></table>
    </div>
  </div>
</body>
</html>`;
  }
}

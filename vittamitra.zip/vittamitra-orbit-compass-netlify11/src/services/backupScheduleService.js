import { nowIsoUtc } from '../utils/date.js';

/**
 * Scheduled Backup Checker & One-Tap Auto Google Drive Backup / Recovery Service.
 *
 * - Evaluates whether a scheduled backup (daily / weekly / monthly) is due.
 * - Connects once via Google Identity Services (OAuth 2.0 `drive.file` least-privilege scope).
 * - Automatically attempts silent token refresh + upload on app launch whenever a scheduled
 *   backup is due and `gdrive_auto_upload` is enabled (updates a single rolling backup file
 *   in Google Drive so Drive manages version history automatically).
 * - Supports one-tap "Restore Latest from Google Drive" for disaster recovery on a new phone.
 */

export function isScheduledBackupDue(settings, nowDate = new Date()) {
  const schedule = settings?.backup_schedule || 'off';
  if (schedule === 'off') return false;
  if (!settings?.last_backup_at) return true;

  const lastMs = new Date(settings.last_backup_at).getTime();
  if (Number.isNaN(lastMs)) return true;
  const elapsedDays = (nowDate.getTime() - lastMs) / 86400000;

  if (schedule === 'daily') return elapsedDays >= 1;
  if (schedule === 'weekly') return elapsedDays >= 7;
  if (schedule === 'monthly') return elapsedDays >= 30;
  return false;
}

export class GoogleDriveBackupService {
  constructor() {
    this.accessToken = null;
    this.tokenExpiresAt = 0;
  }

  hasValidToken() {
    return Boolean(this.accessToken && Date.now() < this.tokenExpiresAt - 60000);
  }

  async _ensureGisLoaded() {
    if (window.google?.accounts?.oauth2) return true;
    if (!navigator.onLine) {
      throw new Error('Google Drive backup requires an internet connection.');
    }
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client';
      s.async = true;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('Could not load Google Sign-In script.'));
      document.head.appendChild(s);
    });
    return true;
  }

  async authorize(clientId, { silent = false } = {}) {
    const cleanId = String(clientId || '').trim();
    if (!cleanId) {
      throw new Error('Add your Google OAuth Web Client ID in One-Time Setup first.');
    }
    if (this.hasValidToken()) return this.accessToken;

    await this._ensureGisLoaded();
    return new Promise((resolve, reject) => {
      const tokenClient = window.google.accounts.oauth2.initTokenClient({
        client_id: cleanId,
        scope: 'https://www.googleapis.com/auth/drive.file',
        callback: (resp) => {
          if (resp.error) {
            reject(new Error(resp.error_description || resp.error));
          } else {
            this.accessToken = resp.access_token;
            const expiresInSec = Number(resp.expires_in) || 3500;
            this.tokenExpiresAt = Date.now() + expiresInSec * 1000;
            resolve(this.accessToken);
          }
        },
        error_callback: (err) => {
          reject(new Error(err?.message || 'Google authorization was cancelled or blocked.'));
        },
      });
      tokenClient.requestAccessToken({ prompt: silent ? '' : 'consent' });
    });
  }

  async uploadBackupToDrive(clientId, backupObject, { silent = false, existingFileId = null } = {}) {
    const token = await this.authorize(clientId, { silent });
    const fileName = 'Personal_Finance_Manager_AutoBackup.json';

    const buildBody = (includeName) => {
      const metadata = includeName
        ? { name: fileName, mimeType: 'application/json' }
        : { mimeType: 'application/json' };
      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', new Blob([JSON.stringify(backupObject, null, 2)], { type: 'application/json' }));
      return form;
    };

    // If we already created a rolling backup file, update it in place (Drive keeps version history)
    if (existingFileId) {
      const patchRes = await fetch(
        `https://www.googleapis.com/upload/drive/v3/files/${encodeURIComponent(existingFileId)}?uploadType=multipart`,
        {
          method: 'PATCH',
          headers: { Authorization: `Bearer ${token}` },
          body: buildBody(false),
        }
      );
      if (patchRes.ok) {
        const data = await patchRes.json();
        return { fileId: data.id || existingFileId, fileName, uploadedAt: nowIsoUtc(), updatedInPlace: true };
      }
      if (patchRes.status === 401) {
        this.accessToken = null;
        throw new Error('Google Drive session expired. Tap Re-sync to reconnect.');
      }
      // Fall through to POST create if file was deleted (404)
    }

    const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: buildBody(true),
    });
    if (!res.ok) {
      if (res.status === 401) this.accessToken = null;
      throw new Error(`Google Drive upload failed (HTTP ${res.status})`);
    }
    const data = await res.json();
    return { fileId: data.id, fileName, uploadedAt: nowIsoUtc(), updatedInPlace: false };
  }

  async downloadLatestBackupFromDrive(clientId, existingFileId = null) {
    const token = await this.authorize(clientId, { silent: false });
    let targetId = existingFileId;

    if (!targetId) {
      const q = encodeURIComponent("name contains 'Personal_Finance_Manager' and mimeType='application/json' and trashed=false");
      const listRes = await fetch(
        `https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=modifiedTime desc&pageSize=1&fields=files(id,name,modifiedTime)`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (!listRes.ok) throw new Error(`Could not list Drive backups (HTTP ${listRes.status})`);
      const listData = await listRes.json();
      targetId = listData.files?.[0]?.id;
      if (!targetId) throw new Error('No Personal Finance Manager backup found in your Google Drive.');
    }

    const dlRes = await fetch(
      `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(targetId)}?alt=media`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!dlRes.ok) throw new Error(`Failed to download Drive backup (HTTP ${dlRes.status})`);
    const parsed = await dlRes.json();
    if (!parsed || parsed.format !== 'personal-finance-manager-backup') {
      throw new Error('The file on Google Drive is not a valid Personal Finance Manager backup.');
    }
    return { fileId: targetId, backup: parsed };
  }

  /**
   * Automatic startup check: if Drive is connected, auto-upload is enabled, online, and
   * a scheduled backup is due, attempts a silent background upload without interrupting the user.
   */
  async tryAutoBackupIfDue(settings, repos, importExportService, { nowDate = new Date() } = {}) {
    if (!settings?.gdrive_connected || !settings?.gdrive_auto_upload || !settings?.gdrive_client_id) {
      return { status: 'disabled' };
    }
    if (!isScheduledBackupDue(settings, nowDate)) {
      return { status: 'not_due' };
    }
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return { status: 'offline' };
    }
    try {
      const backup = await importExportService.exportCompleteJsonBackup();
      const res = await this.uploadBackupToDrive(settings.gdrive_client_id, backup, {
        silent: true,
        existingFileId: settings.gdrive_backup_file_id || null,
      });
      await repos.settings.updateSettings({
        last_backup_at: res.uploadedAt,
        gdrive_last_backup_at: res.uploadedAt,
        gdrive_backup_file_id: res.fileId,
      });
      return { status: 'uploaded', fileName: res.fileName, uploadedAt: res.uploadedAt };
    } catch (err) {
      return { status: 'needs_reconnect', reason: err?.message || 'Authorization needed' };
    }
  }
}

import { nowIsoUtc, toLocalDateString } from '../utils/date.js';

function pad2(n) {
  return String(n).padStart(2, '0');
}

/**
 * Advance a YYYY-MM-DD date string by a recurrence frequency.
 */
export function advanceDateByFrequency(dateStr, frequency, intervalValue = 1) {
  const step = Math.max(1, Number(intervalValue) || 1);
  const d = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(d.getTime())) return toLocalDateString();

  if (frequency === 'daily') d.setDate(d.getDate() + step);
  else if (frequency === 'weekly') d.setDate(d.getDate() + 7 * step);
  else if (frequency === 'custom_days') d.setDate(d.getDate() + step);
  else if (frequency === 'monthly') d.setMonth(d.getMonth() + step);
  else if (frequency === 'quarterly') d.setMonth(d.getMonth() + 3 * step);
  else if (frequency === 'half_yearly') d.setMonth(d.getMonth() + 6 * step);
  else if (frequency === 'yearly') d.setFullYear(d.getFullYear() + step);
  else return null; // 'once'

  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

/**
 * Phase 4 Bills, Reminders & Recurring Transactions Service.
 * - Prevents duplicate generated transactions via `last_generated_date` guard
 * - Review-and-confirm by default; auto-post runs only when explicitly enabled on a rule
 * - Paying a recurring bill logs the ledger transaction and schedules the next cycle's bill
 */
export class BillsRecurringService {
  constructor(repos, services) {
    this.repos = repos;
    this.services = services;
    this._inFlightBillPays = new Map();
  }

  async getBillsCategorized(todayKey = toLocalDateString()) {
    const all = await this.repos.bills.listAll();
    const upcoming = [];
    const overdue = [];
    const paid = [];
    const activeReminders = [];

    for (const b of all) {
      if (b.status === 'paid') {
        paid.push(b);
      } else {
        if (b.due_date < todayKey) overdue.push(b);
        else upcoming.push(b);

        const remindOn = b.snoozed_until || b.reminder_date || b.due_date;
        if (!b.reminder_dismissed && remindOn <= todayKey) {
          activeReminders.push(b);
        }
      }
    }

    paid.sort((a, b) => String(b.paid_at || b.due_date).localeCompare(String(a.paid_at || a.due_date)));
    return { all, upcoming, overdue, paid, activeReminders };
  }

  /**
   * Mark a bill paid: creates the expense transaction (if account & category exist),
   * marks the bill paid, and schedules the next recurring bill if frequency != 'once'.
   */
  async markBillPaid(billId, { paidDate = toLocalDateString(), accountIdOverride = null } = {}) {
    const lockKey = String(billId || '');
    // Synchronous in-flight coalescing before any await prevents concurrent double-tap payment
    if (lockKey && this._inFlightBillPays.has(lockKey)) {
      return this._inFlightBillPays.get(lockKey);
    }

    const workPromise = (async () => {
      const bill = await this.repos.bills.getById(billId);
      if (!bill) throw new Error('Bill not found');
      if (bill.status === 'paid') return { bill, transaction: null, nextBill: null };

      const accountId = accountIdOverride || bill.account_id;
      let tx = null;
      if (accountId && bill.category_id) {
        tx = await this.services.transactions.createTransaction({
          type: 'expense',
          amount_paise: bill.amount_paise,
          date: paidDate,
          category_id: bill.category_id,
          account_id: accountId,
          description: bill.name,
          notes: bill.notes || 'Bill payment',
          // Deterministic bill-scoped idempotency_key prevents duplicate ledger posting across crashes & restarts
          idempotency_key: `bill-pay:${bill.id}`,
        });
      }

      const updatedBill = await this.repos.bills.update(bill.id, {
        status: 'paid',
        paid_transaction_id: tx ? tx.id : null,
        paid_at: nowIsoUtc(),
        reminder_dismissed: true,
      });

      let nextBill = null;
      if (bill.frequency && bill.frequency !== 'once') {
        const nextDue = advanceDateByFrequency(bill.due_date, bill.frequency, 1);
        const existingAll = await this.repos.bills.listAll();
        const dupNext = existingAll.find(
          (b) => b.status === 'unpaid' && b.name.toLowerCase() === bill.name.toLowerCase() && b.due_date === nextDue
        );
        if (nextDue && !dupNext) {
          nextBill = await this.repos.bills.createBill({
            name: bill.name,
            category_id: bill.category_id,
            amount_paise: bill.amount_paise,
            due_date: nextDue,
            account_id: bill.account_id,
            frequency: bill.frequency,
            reminder_date: nextDue,
            notes: bill.notes,
          });
        }
      }

      return { bill: updatedBill, transaction: tx, nextBill };
    })();

    if (lockKey) this._inFlightBillPays.set(lockKey, workPromise);
    try {
      return await workPromise;
    } finally {
      if (lockKey) this._inFlightBillPays.delete(lockKey);
    }
  }

  async snoozeBillReminder(billId, days = 3) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    const snoozedUntil = `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    return this.repos.bills.update(billId, { snoozed_until: snoozedUntil });
  }

  async dismissBillReminder(billId) {
    return this.repos.bills.update(billId, { reminder_dismissed: true });
  }

  async getDueRecurringRules(todayKey = toLocalDateString()) {
    const all = await this.repos.recurring.listAll();
    return all.filter(
      (r) =>
        r.is_active &&
        r.next_due_date &&
        r.next_due_date <= todayKey &&
        (!r.end_date || r.next_due_date <= r.end_date) &&
        r.last_generated_date !== r.next_due_date
    );
  }

  /**
   * Post one due occurrence of a recurring rule and advance `next_due_date`.
   * Strictly prevents duplicate posting for the same `next_due_date`.
   */
  async postRecurringOccurrence(ruleId) {
    const rule = await this.repos.recurring.getById(ruleId);
    if (!rule || !rule.is_active) throw new Error('Recurring rule is inactive or not found');
    if (rule.last_generated_date === rule.next_due_date) {
      throw new Error(`Occurrence for ${rule.next_due_date} was already posted (duplicate prevented).`);
    }

    const dueDate = rule.next_due_date;
    const tx = await this.services.transactions.createTransaction({
      type: rule.type,
      amount_paise: rule.amount_paise,
      date: dueDate,
      time: '09:00',
      category_id: rule.category_id,
      account_id: rule.account_id,
      to_account_id: rule.to_account_id,
      description: rule.name,
      notes: rule.notes || 'Recurring transaction',
    });

    const nextDue = advanceDateByFrequency(dueDate, rule.frequency, rule.interval_value);
    const stillActive = !rule.end_date || (nextDue && nextDue <= rule.end_date);

    const updatedRule = await this.repos.recurring.update(rule.id, {
      last_generated_date: dueDate,
      next_due_date: nextDue || dueDate,
      is_active: stillActive,
    });

    return { transaction: tx, rule: updatedRule };
  }

  async skipRecurringOccurrence(ruleId) {
    const rule = await this.repos.recurring.getById(ruleId);
    if (!rule) return null;
    const nextDue = advanceDateByFrequency(rule.next_due_date, rule.frequency, rule.interval_value);
    const stillActive = !rule.end_date || (nextDue && nextDue <= rule.end_date);
    return this.repos.recurring.update(rule.id, {
      next_due_date: nextDue || rule.next_due_date,
      is_active: stillActive,
    });
  }

  /**
   * Process ONLY rules where the user explicitly enabled `auto_post = true`.
   */
  async processAutoPostRules(todayKey = toLocalDateString()) {
    const due = await this.getDueRecurringRules(todayKey);
    const autoRules = due.filter((r) => r.auto_post === true);
    let postedCount = 0;

    for (const rule of autoRules) {
      let guard = 0;
      let current = rule;
      while (
        guard < 12 &&
        current.is_active &&
        current.auto_post &&
        current.next_due_date <= todayKey &&
        (!current.end_date || current.next_due_date <= current.end_date) &&
        current.last_generated_date !== current.next_due_date
      ) {
        const res = await this.postRecurringOccurrence(current.id);
        current = res.rule;
        postedCount += 1;
        guard += 1;
      }
    }
    return postedCount;
  }
}

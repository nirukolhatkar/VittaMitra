import { shiftMonth } from '../utils/date.js';

/**
 * Budget Evaluation, Carry-Forward, Projection & Alert Service (Phase 3).
 *
 * - Supports Overall Monthly, Category (including subcategories under a parent!), and Tag budgets
 * - Calculates exact spent, remaining, % used, days remaining, average daily spend, and projected month-end spend
 * - Computes unused carry-forward from previous month when carry_forward=true
 * - Evaluates configurable alert thresholds (50%, 75%, 90%, 100%, custom) without repeating alerts
 * - Supports Copy Previous Month's Budgets into a target month
 */
export class BudgetService {
  constructor(repos, services) {
    this.repos = repos;
    this.services = services;
  }

  static monthKey(year, monthIndex0) {
    return `${year}-${String(monthIndex0 + 1).padStart(2, '0')}`;
  }

  _matchesBudget(tx, budget, childCatIdsByParent) {
    if (tx.type !== 'expense') return false;
    if (budget.scope_type === 'overall') return true;
    if (budget.scope_type === 'category') {
      if (tx.category_id === budget.scope_id) return true;
      const children = childCatIdsByParent.get(budget.scope_id);
      return Boolean(children && children.has(tx.category_id));
    }
    if (budget.scope_type === 'tag') {
      return Array.isArray(tx.tag_ids) && tx.tag_ids.includes(budget.scope_id);
    }
    return false;
  }

  async evaluateMonthBudgets(year, monthIndex0) {
    const targetKey = BudgetService.monthKey(year, monthIndex0);
    const prev = shiftMonth(year, monthIndex0, -1);
    const prevKey = BudgetService.monthKey(prev.year, prev.month);

    const [allBudgets, categories, monthTxs, prevMonthTxs] = await Promise.all([
      this.repos.budgets.listAll(),
      this.repos.categories.list({ includeArchived: true }),
      this.services.transactions.listTransactions({ monthYear: { year, month: monthIndex0 }, type: 'expense' }),
      this.services.transactions.listTransactions({ monthYear: { year: prev.year, month: prev.month }, type: 'expense' }),
    ]);

    const childCatIdsByParent = new Map();
    for (const c of categories) {
      if (c.parent_id) {
        if (!childCatIdsByParent.has(c.parent_id)) childCatIdsByParent.set(c.parent_id, new Set());
        childCatIdsByParent.get(c.parent_id).add(c.id);
      }
    }

    // Active budgets for targetKey: exact match for period_month OR recurring budgets started on/before targetKey
    const applicable = allBudgets.filter(
      (b) => b.period_month === targetKey || (b.is_recurring && b.period_month <= targetKey)
    );

    // Deduplicate by (scope_type, scope_id) preferring an explicit month override over a recurring rule
    const dedupMap = new Map();
    for (const b of applicable) {
      const sig = `${b.scope_type}|${b.scope_id || ''}`;
      const prevEntry = dedupMap.get(sig);
      if (!prevEntry || b.period_month === targetKey) {
        dedupMap.set(sig, b);
      }
    }
    const activeBudgets = Array.from(dedupMap.values());

    const daysInMonth = new Date(year, monthIndex0 + 1, 0).getDate();
    const today = new Date();
    const isCurrentMonth = today.getFullYear() === year && today.getMonth() === monthIndex0;
    const isPastMonth = year < today.getFullYear() || (year === today.getFullYear() && monthIndex0 < today.getMonth());
    const daysElapsed = isPastMonth ? daysInMonth : isCurrentMonth ? Math.max(1, today.getDate()) : 0;
    const daysRemaining = isPastMonth ? 0 : isCurrentMonth ? Math.max(0, daysInMonth - today.getDate()) : daysInMonth;

    const evaluated = [];
    const newAlerts = [];

    for (const b of activeBudgets) {
      let carryForwardPaise = 0;
      if (b.carry_forward && b.period_month <= prevKey) {
        let prevSpent = 0;
        for (const tx of prevMonthTxs) {
          if (this._matchesBudget(tx, b, childCatIdsByParent)) prevSpent += tx.amount_paise;
        }
        carryForwardPaise = Math.max(0, b.amount_paise - prevSpent);
      }

      const effectiveBudgetPaise = b.amount_paise + carryForwardPaise;

      let spentPaise = 0;
      for (const tx of monthTxs) {
        if (this._matchesBudget(tx, b, childCatIdsByParent)) spentPaise += tx.amount_paise;
      }

      const remainingPaise = effectiveBudgetPaise - spentPaise;
      const percentUsed = effectiveBudgetPaise > 0 ? (spentPaise / effectiveBudgetPaise) * 100 : 0;
      const avgDailySpendPaise = daysElapsed > 0 ? Math.round(spentPaise / daysElapsed) : 0;
      const projectedMonthEndPaise = isPastMonth
        ? spentPaise
        : daysElapsed > 0
          ? Math.round((spentPaise / daysElapsed) * daysInMonth)
          : 0;

      // Check alert thresholds without repeating already-triggered thresholds for this month
      const alreadyTriggered = new Set((b.triggered_alerts && b.triggered_alerts[targetKey]) || []);
      const thresholds = Array.isArray(b.alert_thresholds) ? b.alert_thresholds : [50, 75, 90, 100];
      const newlyCrossed = thresholds.filter((th) => percentUsed >= th && !alreadyTriggered.has(th));

      if (newlyCrossed.length > 0) {
        const highestNew = Math.max(...newlyCrossed);
        newAlerts.push({
          budgetId: b.id,
          budgetName: b.name,
          threshold: highestNew,
          percentUsed,
          spentPaise,
          effectiveBudgetPaise,
        });
        const nextTriggered = {
          ...(b.triggered_alerts || {}),
          [targetKey]: Array.from(new Set([...alreadyTriggered, ...newlyCrossed])).sort((a, c) => a - c),
        };
        await this.repos.budgets.update(b.id, { triggered_alerts: nextTriggered }).catch(() => {});
      }

      evaluated.push({
        budget: b,
        baseBudgetPaise: b.amount_paise,
        carryForwardPaise,
        effectiveBudgetPaise,
        spentPaise,
        remainingPaise,
        percentUsed,
        daysInMonth,
        daysElapsed,
        daysRemaining,
        avgDailySpendPaise,
        projectedMonthEndPaise,
        status: percentUsed >= 100 ? 'exceeded' : percentUsed >= 75 ? 'warning' : 'healthy',
      });
    }

    return {
      periodKey: targetKey,
      daysInMonth,
      daysElapsed,
      daysRemaining,
      budgets: evaluated,
      newAlerts,
    };
  }

  /**
   * Copy all non-recurring (or specific) budgets from the previous month into target month.
   */
  async copyPreviousMonthBudgets(targetYear, targetMonthIndex0) {
    const targetKey = BudgetService.monthKey(targetYear, targetMonthIndex0);
    const prev = shiftMonth(targetYear, targetMonthIndex0, -1);
    const prevKey = BudgetService.monthKey(prev.year, prev.month);

    const all = await this.repos.budgets.listAll();
    const prevBudgets = all.filter((b) => b.period_month === prevKey);
    const existingTargetSigs = new Set(
      all
        .filter((b) => b.period_month === targetKey)
        .map((b) => `${b.scope_type}|${b.scope_id || ''}`)
    );

    let copiedCount = 0;
    for (const pb of prevBudgets) {
      const sig = `${pb.scope_type}|${pb.scope_id || ''}`;
      if (existingTargetSigs.has(sig)) continue;
      await this.repos.budgets.createBudget({
        name: pb.name,
        scope_type: pb.scope_type,
        scope_id: pb.scope_id,
        amount_paise: pb.amount_paise,
        period_month: targetKey,
        is_recurring: pb.is_recurring,
        carry_forward: pb.carry_forward,
        alert_thresholds: pb.alert_thresholds,
      });
      copiedCount += 1;
    }

    return { copiedCount, fromMonth: prevKey, toMonth: targetKey };
  }
}

import { isLiabilityAccount } from '../constants/accountTypes.js';

/**
 * Explicit Asset vs Liability Ledger Posting Rules (Expense, Income, Transfer).
 */
export function buildLedgerPostings({ transactionId, type, amountPaise, sourceAccount, destinationAccount = null }) {
  if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) {
    throw new Error('Transaction amount must be a positive integer in paise');
  }
  if (!sourceAccount) {
    throw new Error('Source account is required');
  }

  const srcIsLiability = isLiabilityAccount(sourceAccount);

  if (type === 'expense') {
    return [
      {
        transaction_id: transactionId,
        account_id: sourceAccount.id,
        account_class: srcIsLiability ? 'liability' : 'asset',
        posting_role: 'expense_payment',
        entry_side: 'credit',
        balance_delta_paise: srcIsLiability ? amountPaise : -amountPaise,
        amount_paise: amountPaise,
      },
    ];
  }

  if (type === 'income') {
    return [
      {
        transaction_id: transactionId,
        account_id: sourceAccount.id,
        account_class: srcIsLiability ? 'liability' : 'asset',
        posting_role: 'income_receipt',
        entry_side: 'debit',
        balance_delta_paise: srcIsLiability ? -amountPaise : amountPaise,
        amount_paise: amountPaise,
      },
    ];
  }

  if (type === 'transfer') {
    if (!destinationAccount) {
      throw new Error('Destination account is required for transfers');
    }
    if (destinationAccount.id === sourceAccount.id) {
      throw new Error('Source and destination accounts must be different');
    }
    const dstIsLiability = isLiabilityAccount(destinationAccount);

    return [
      {
        transaction_id: transactionId,
        account_id: sourceAccount.id,
        account_class: srcIsLiability ? 'liability' : 'asset',
        posting_role: 'transfer_out',
        entry_side: 'credit',
        balance_delta_paise: srcIsLiability ? amountPaise : -amountPaise,
        amount_paise: amountPaise,
      },
      {
        transaction_id: transactionId,
        account_id: destinationAccount.id,
        account_class: dstIsLiability ? 'liability' : 'asset',
        posting_role: 'transfer_in',
        entry_side: 'debit',
        balance_delta_paise: dstIsLiability ? -amountPaise : amountPaise,
        amount_paise: amountPaise,
      },
    ];
  }

  throw new Error(`Unsupported transaction type: "${type}"`);
}

/**
 * Balanced Double-Entry Journal Postings for Personal Debt Tracker Events.
 * Every returned posting set has sum(debit amounts) === sum(credit amounts).
 * Bank/Cash/Wallet accounts use their real account.id so computeReconciledAccountBalance
 * reconciles them automatically without any parallel balance logic.
 */
export function buildDebtLedgerPostings({
  transactionId,
  debtId,
  debtType, // 'RECEIVABLE' | 'PAYABLE'
  eventType,
  amountPaise,
  account = null,
}) {
  if (!Number.isSafeInteger(amountPaise) || amountPaise === 0) {
    throw new Error('Debt posting amount must be a non-zero integer in paise');
  }

  const absAmt = Math.abs(amountPaise);
  const debtAccountId = debtType === 'RECEIVABLE' ? `debt_receivable:${debtId}` : `debt_payable:${debtId}`;
  const debtAccountClass = debtType === 'RECEIVABLE' ? 'receivable' : 'payable';

  const requireAccount = () => {
    if (!account) throw new Error('A valid bank, cash, or wallet account is required for this debt event');
    return isLiabilityAccount(account);
  };

  if (eventType === 'LENT') {
    const isLiab = requireAccount();
    return [
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: 'receivable',
        posting_role: 'debt_lent_receivable',
        entry_side: 'debit',
        balance_delta_paise: absAmt,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: account.id,
        account_class: isLiab ? 'liability' : 'asset',
        posting_role: 'debt_lent_outflow',
        entry_side: 'credit',
        balance_delta_paise: isLiab ? absAmt : -absAmt,
        amount_paise: absAmt,
      },
    ];
  }

  if (eventType === 'PRINCIPAL_RECEIVED') {
    const isLiab = requireAccount();
    return [
      {
        transaction_id: transactionId,
        account_id: account.id,
        account_class: isLiab ? 'liability' : 'asset',
        posting_role: 'debt_principal_received',
        entry_side: 'debit',
        balance_delta_paise: isLiab ? -absAmt : absAmt,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: 'receivable',
        posting_role: 'debt_receivable_reduction',
        entry_side: 'credit',
        balance_delta_paise: -absAmt,
        amount_paise: absAmt,
      },
    ];
  }

  if (eventType === 'BORROWED') {
    const isLiab = requireAccount();
    return [
      {
        transaction_id: transactionId,
        account_id: account.id,
        account_class: isLiab ? 'liability' : 'asset',
        posting_role: 'debt_borrowed_inflow',
        entry_side: 'debit',
        balance_delta_paise: isLiab ? -absAmt : absAmt,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: 'payable',
        posting_role: 'debt_borrowed_payable',
        entry_side: 'credit',
        balance_delta_paise: absAmt,
        amount_paise: absAmt,
      },
    ];
  }

  if (eventType === 'PRINCIPAL_PAID') {
    const isLiab = requireAccount();
    return [
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: 'payable',
        posting_role: 'debt_payable_reduction',
        entry_side: 'debit',
        balance_delta_paise: -absAmt,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: account.id,
        account_class: isLiab ? 'liability' : 'asset',
        posting_role: 'debt_principal_paid',
        entry_side: 'credit',
        balance_delta_paise: isLiab ? absAmt : -absAmt,
        amount_paise: absAmt,
      },
    ];
  }

  if (eventType === 'DEBT_WRITTEN_OFF') {
    return [
      {
        transaction_id: transactionId,
        account_id: 'system:debt_writeoff_expense',
        account_class: 'expense',
        posting_role: 'debt_writeoff_loss',
        entry_side: 'debit',
        balance_delta_paise: absAmt,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: 'receivable',
        posting_role: 'debt_receivable_written_off',
        entry_side: 'credit',
        balance_delta_paise: -absAmt,
        amount_paise: absAmt,
      },
    ];
  }

  if (eventType === 'DEBT_FORGIVEN') {
    return [
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: 'payable',
        posting_role: 'debt_payable_forgiven',
        entry_side: 'debit',
        balance_delta_paise: -absAmt,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: 'system:debt_forgiveness_income',
        account_class: 'income',
        posting_role: 'debt_forgiveness_gain',
        entry_side: 'credit',
        balance_delta_paise: absAmt,
        amount_paise: absAmt,
      },
    ];
  }

  if (eventType === 'PRINCIPAL_ADJUSTMENT') {
    const isIncrease = amountPaise > 0;
    if (debtType === 'RECEIVABLE') {
      return [
        {
          transaction_id: transactionId,
          account_id: debtAccountId,
          account_class: debtAccountClass,
          posting_role: 'debt_principal_adjustment',
          entry_side: isIncrease ? 'debit' : 'credit',
          balance_delta_paise: amountPaise,
          amount_paise: absAmt,
        },
        {
          transaction_id: transactionId,
          account_id: 'system:debt_adjustment_equity',
          account_class: 'equity',
          posting_role: 'debt_adjustment_offset',
          entry_side: isIncrease ? 'credit' : 'debit',
          balance_delta_paise: -amountPaise,
          amount_paise: absAmt,
        },
      ];
    }
    return [
      {
        transaction_id: transactionId,
        account_id: debtAccountId,
        account_class: debtAccountClass,
        posting_role: 'debt_principal_adjustment',
        entry_side: isIncrease ? 'credit' : 'debit',
        balance_delta_paise: amountPaise,
        amount_paise: absAmt,
      },
      {
        transaction_id: transactionId,
        account_id: 'system:debt_adjustment_equity',
        account_class: 'equity',
        posting_role: 'debt_adjustment_offset',
        entry_side: isIncrease ? 'debit' : 'credit',
        balance_delta_paise: -amountPaise,
        amount_paise: absAmt,
      },
    ];
  }

  throw new Error(`Unsupported debt event type for ledger posting: "${eventType}"`);
}

/**
 * Reconcile an account's balance from opening balance + active postings.
 * If `asOfDateKey` ("YYYY-MM-DD") is provided, strictly excludes all future postings after that date.
 */
export function computeReconciledAccountBalance(account, postings, asOfDateKey = null) {
  let balance = account.opening_balance_paise || 0;
  for (const p of postings) {
    if (p.deleted_at) continue;
    if (p.account_id !== account.id) continue;
    if (asOfDateKey) {
      const pDate = String(p.occurred_at_local || '').slice(0, 10);
      if (pDate && pDate > asOfDateKey) continue;
    }
    balance += p.balance_delta_paise;
  }
  return balance;
}

/**
 * Validate that split transaction lines reconcile exactly with the parent amount.
 */
export function validateSplitReconciliation(parentAmountPaise, splits) {
  if (!Array.isArray(splits) || splits.length === 0) {
    throw new Error('Split transactions require at least one split line');
  }
  let sum = 0;
  for (const s of splits) {
    if (!Number.isSafeInteger(s.amount_paise) || s.amount_paise <= 0) {
      throw new Error('Each split amount must be a positive integer in paise');
    }
    sum += s.amount_paise;
  }
  if (sum !== parentAmountPaise) {
    throw new Error(
      `Split total (${sum} paise) does not match parent transaction amount (${parentAmountPaise} paise)`
    );
  }
  return true;
}


/**
 * Balanced Double-Entry Ledger Postings for Account Balance Adjustments (As-On-Date).
 * - Preserves account sign conventions (Asset vs Credit Card Liability).
 * - `deltaPaise` is the signed change to apply to the account's reconciled balance
 *   (actualBalancePaise - calculatedBalanceAsOfDatePaise).
 * - Offset leg posts to `system:balance_adjustment_equity` so adjustments are never
 *   counted as Income, Expense, or Transfers.
 */
export function buildBalanceAdjustmentPostings({ transactionId, account, deltaPaise }) {
  if (!account) {
    throw new Error('A valid account is required for balance adjustment');
  }
  if (!Number.isSafeInteger(deltaPaise) || deltaPaise === 0) {
    throw new Error('Balance adjustment difference must be a non-zero integer in paise');
  }

  const isLiab = isLiabilityAccount(account);
  const absAmt = Math.abs(deltaPaise);
  // For assets: positive delta = debit (+balance); negative delta = credit (-balance)
  // For liabilities (credit cards): positive delta = credit (+outstanding); negative delta = debit (-outstanding)
  const accountSide = isLiab ? (deltaPaise > 0 ? 'credit' : 'debit') : (deltaPaise > 0 ? 'debit' : 'credit');
  const offsetSide = accountSide === 'debit' ? 'credit' : 'debit';

  return [
    {
      transaction_id: transactionId,
      account_id: account.id,
      account_class: isLiab ? 'liability' : 'asset',
      posting_role: 'balance_adjustment',
      entry_side: accountSide,
      balance_delta_paise: deltaPaise,
      amount_paise: absAmt,
    },
    {
      transaction_id: transactionId,
      account_id: 'system:balance_adjustment_equity',
      account_class: 'equity',
      posting_role: 'balance_adjustment_offset',
      entry_side: offsetSide,
      balance_delta_paise: -deltaPaise,
      amount_paise: absAmt,
    },
  ];
}

/**
 * Local-only On-Device OCR Service & Replaceable Adapter (Zero External APIs, Zero CDN).
 *
 * Primary Engine: `tesseract-wasm` v0.11.0 (BSD-2-Clause, Robert Knight)
 * Bundled locally under `./vendor/ocr/tesseract-wasm/`:
 *   - dist/lib.js                      (ES module entry point, Comlink bundled)
 *   - dist/tesseract-worker.js         (Dedicated Web Worker script)
 *   - dist/tesseract-core.wasm         (SIMD-accelerated WASM binary)
 *   - dist/tesseract-core-fallback.wasm (Non-SIMD fallback WASM binary)
 *   - eng.traineddata                  (English LSTM traineddata model)
 *
 * Design guarantees:
 * - Lazy-loaded ONLY when the user initiates OCR (never at normal app startup).
 * - Runs strictly inside a dedicated Web Worker in browser environments.
 * - Processes multiple images sequentially with explicit ImageBitmap, Canvas,
 *   ArrayBuffer, and Worker cleanup (`clearImage()` per image + `destroy()` in `finally`).
 * - Isolates per-image and worker crashes without aborting the rest of a batch.
 * - Returns structured OCR output (text, word-level text, confidence, bounding boxes,
 *   processingMs, status, error) — completely decoupled from UPI/financial parsing.
 * - Never writes to the VittaMitra ledger (`transactions` / `ledger_postings`).
 */

export const LOCAL_OCR_ENGINE_INFO = Object.freeze({
  packageName: 'tesseract-wasm',
  version: '0.11.0',
  license: 'BSD-2-Clause',
  basePath: './vendor/ocr/tesseract-wasm',
});

export const LOCAL_OCR_ASSET_PATHS = Object.freeze({
  libModule: './vendor/ocr/tesseract-wasm/dist/lib.js',
  worker: './vendor/ocr/tesseract-wasm/dist/tesseract-worker.js',
  wasmFast: './vendor/ocr/tesseract-wasm/dist/tesseract-core.wasm',
  wasmFallback: './vendor/ocr/tesseract-wasm/dist/tesseract-core-fallback.wasm',
  model: './vendor/ocr/tesseract-wasm/eng.traineddata',
});

let _cachedLibModule = null;

function _resolveAssetUrl(relPath) {
  if (typeof window !== 'undefined' && window.location?.href) {
    try {
      return new URL(relPath, window.location.href).href;
    } catch {
      return relPath;
    }
  }
  return relPath;
}

function _isRestrictedStandaloneContext() {
  if (typeof window === 'undefined' || !window.location) return false;
  const proto = String(window.location.protocol || '').toLowerCase();
  return proto === 'file:' || proto === 'content:' || proto === 'data:' || proto === 'about:';
}

/**
 * Lazily imports `./vendor/ocr/tesseract-wasm/dist/lib.js` on demand.
 */
export async function lazyLoadTesseractWasm() {
  if (_cachedLibModule) return _cachedLibModule;
  if (_isRestrictedStandaloneContext()) {
    const err = new Error(
      'Local WASM/Worker OCR requires the hosted PWA (HTTPS/localhost). Browser security blocks Web Worker and WASM asset loading inside standalone file:// or content:// HTML previews.'
    );
    err.code = 'LOCAL_OCR_RESTRICTED_CONTEXT';
    throw err;
  }
  const url = _resolveAssetUrl(LOCAL_OCR_ASSET_PATHS.libModule);
  try {
    const mod = await import(url);
    if (!mod || typeof mod.OCRClient !== 'function') {
      throw new Error('Supplied tesseract-wasm module does not export OCRClient.');
    }
    _cachedLibModule = mod;
    return mod;
  } catch (err) {
    const wrapped = new Error(
      `Local tesseract-wasm runtime could not be loaded from ${LOCAL_OCR_ASSET_PATHS.libModule}: ${err?.message || 'unavailable'}. Your upload has been retained safely.`
    );
    wrapped.code = 'LOCAL_OCR_UNAVAILABLE';
    throw wrapped;
  }
}

export async function probeLocalOcrCapability() {
  if (typeof window === 'undefined' || typeof Worker === 'undefined') {
    return {
      available: false,
      engineName: `${LOCAL_OCR_ENGINE_INFO.packageName}@${LOCAL_OCR_ENGINE_INFO.version}`,
      reason: 'Browser Web Worker runtime is not available in this environment.',
    };
  }
  if (_isRestrictedStandaloneContext()) {
    return {
      available: false,
      engineName: `${LOCAL_OCR_ENGINE_INFO.packageName}@${LOCAL_OCR_ENGINE_INFO.version}`,
      reason:
        'Standalone HTML preview (file:// / content://) restricts Web Worker & WASM loading. Use the hosted Netlify PWA for on-device OCR.',
    };
  }
  try {
    const mod = await lazyLoadTesseractWasm();
    return {
      available: Boolean(mod && typeof mod.OCRClient === 'function'),
      engineName: `${LOCAL_OCR_ENGINE_INFO.packageName}@${LOCAL_OCR_ENGINE_INFO.version}`,
      fastSimdSupported: typeof mod.supportsFastBuild === 'function' ? Boolean(mod.supportsFastBuild()) : false,
      reason: 'Locally bundled tesseract-wasm v0.11.0 ready.',
    };
  } catch (err) {
    return {
      available: false,
      engineName: `${LOCAL_OCR_ENGINE_INFO.packageName}@${LOCAL_OCR_ENGINE_INFO.version}`,
      reason: err.message,
    };
  }
}

/**
 * Decodes JPG, JPEG, PNG, or WebP via browser-native `createImageBitmap()` + `<canvas>`,
 * applies dark-mode detection/inversion and contrast normalization for UPI screenshots,
 * caps dimensions at `maxDim` (1800px) for Android Chrome memory safety, and returns
 * `{ imageData, preprocessed, invertedDarkMode, width, height }`.
 * Releases `ImageBitmap` and `<canvas>` memory immediately in `finally`.
 */
export async function decodeAndPreprocessImage(arrayBuffer, mimeType = 'image/png', { maxDim = 1800 } = {}) {
  if (
    typeof document === 'undefined' ||
    typeof createImageBitmap !== 'function' ||
    !arrayBuffer ||
    arrayBuffer.byteLength === 0
  ) {
    return { imageData: null, preprocessed: false, invertedDarkMode: false, width: 0, height: 0 };
  }

  const srcBlob = new Blob([arrayBuffer], { type: mimeType || 'image/png' });
  let bitmap = null;
  const canvas = document.createElement('canvas');
  try {
    bitmap = await createImageBitmap(srcBlob);
    const longest = Math.max(bitmap.width, bitmap.height, 1);
    const scale = longest < 900 ? Math.min(2, maxDim / longest) : Math.min(1, maxDim / longest);
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(bitmap, 0, 0, w, h);

    const imgData = ctx.getImageData(0, 0, w, h);
    const d = imgData.data;

    // Detect dark-mode screenshot via sampled mean luminance
    let lumSum = 0;
    let samples = 0;
    for (let i = 0; i < d.length; i += 16) {
      lumSum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      samples += 1;
    }
    const meanLum = samples > 0 ? lumSum / samples : 255;
    const invertedDarkMode = meanLum < 115;

    // High-contrast grayscale (and invert dark-mode to crisp dark-on-light for Tesseract LSTM)
    const contrast = 1.3;
    for (let i = 0; i < d.length; i += 4) {
      let lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      if (invertedDarkMode) lum = 255 - lum;
      lum = Math.max(0, Math.min(255, (lum - 128) * contrast + 128));
      d[i] = lum;
      d[i + 1] = lum;
      d[i + 2] = lum;
    }

    return { imageData: imgData, preprocessed: true, invertedDarkMode, width: w, height: h };
  } finally {
    if (bitmap && typeof bitmap.close === 'function') bitmap.close();
    canvas.width = 0;
    canvas.height = 0;
  }
}

function _normalizeWords(rawItems) {
  if (!Array.isArray(rawItems)) return [];
  return rawItems
    .map((item) => {
      const rawConf = Number(item.confidence);
      // tesseract-wasm returns confidence in [0, 1]; normalize to 0..100 percentage
      const confPct = Number.isFinite(rawConf)
        ? Number((rawConf <= 1 ? rawConf * 100 : rawConf).toFixed(1))
        : null;
      const r = item.rect || item.bbox || null;
      const bbox = r
        ? {
            x0: Number(r.left ?? r.x0) || 0,
            y0: Number(r.top ?? r.y0) || 0,
            x1: Number(r.right ?? r.x1) || 0,
            y1: Number(r.bottom ?? r.y1) || 0,
          }
        : null;
      return {
        text: String(item.text || '').trim(),
        confidence: confPct,
        bbox,
        flags: Number(item.flags) || 0,
      };
    })
    .filter((w) => w.text.length > 0);
}

/**
 * Reconstructs visual horizontal rows from word bounding boxes (y-midpoint clustering,
 * sorted left-to-right by x0) so 2-column UPI Transaction History screenshots keep
 * the Merchant Name (left) and Amount (right) together on the same line.
 */
export function reconstructVisualLinesFromWords(words) {
  const withBox = (words || []).filter((w) => w && w.text && w.bbox);
  if (withBox.length === 0) return [];
  const heights = withBox.map((w) => Math.max(8, (w.bbox.y1 || 0) - (w.bbox.y0 || 0))).sort((a, b) => a - b);
  const medianH = heights[Math.floor(heights.length / 2)] || 18;
  const yTol = Math.max(12, Math.round(medianH * 0.85));

  const sorted = [...withBox].sort((a, b) => {
    const ay = ((a.bbox.y0 || 0) + (a.bbox.y1 || 0)) / 2;
    const by = ((b.bbox.y0 || 0) + (b.bbox.y1 || 0)) / 2;
    return ay - by || (a.bbox.x0 || 0) - (b.bbox.x0 || 0);
  });

  const rows = [];
  for (const w of sorted) {
    const cy = ((w.bbox.y0 || 0) + (w.bbox.y1 || 0)) / 2;
    const last = rows[rows.length - 1];
    if (!last || Math.abs(last.cy - cy) > yTol) {
      rows.push({ cy, words: [w] });
    } else {
      last.words.push(w);
      last.cy = (last.cy * (last.words.length - 1) + cy) / last.words.length;
    }
  }

  return rows.map((row) => {
    row.words.sort((a, b) => (a.bbox.x0 || 0) - (b.bbox.x0 || 0));
    const text = row.words.map((w) => w.text).join(' ').trim();
    const confs = row.words.map((w) => w.confidence).filter((c) => Number.isFinite(c));
    const avgConf = confs.length ? Number((confs.reduce((s, c) => s + c, 0) / confs.length).toFixed(1)) : null;
    const bbox = {
      x0: Math.min(...row.words.map((w) => w.bbox.x0)),
      y0: Math.min(...row.words.map((w) => w.bbox.y0)),
      x1: Math.max(...row.words.map((w) => w.bbox.x1)),
      y1: Math.max(...row.words.map((w) => w.bbox.y1)),
    };
    return { text, confidence: avgConf, bbox };
  });
}

function _groupWordsToLines(words, layoutFlags = { StartOfLine: 1, EndOfLine: 2 }) {
  if (!Array.isArray(words) || words.length === 0) return [];
  const lines = [];
  let current = [];

  for (const w of words) {
    const isStart = (w.flags & (layoutFlags.StartOfLine || 1)) !== 0;
    const isEnd = (w.flags & (layoutFlags.EndOfLine || 2)) !== 0;
    if (isStart && current.length > 0) {
      lines.push(current);
      current = [];
    }
    current.push(w);
    if (isEnd) {
      lines.push(current);
      current = [];
    }
  }
  if (current.length > 0) lines.push(current);

  return lines.map((lineWords) => {
    const text = lineWords.map((w) => w.text).join(' ').trim();
    const confs = lineWords.map((w) => w.confidence).filter((c) => Number.isFinite(c));
    const avgConf = confs.length ? Number((confs.reduce((s, c) => s + c, 0) / confs.length).toFixed(1)) : null;
    const boxes = lineWords.map((w) => w.bbox).filter(Boolean);
    const bbox = boxes.length
      ? {
          x0: Math.min(...boxes.map((b) => b.x0)),
          y0: Math.min(...boxes.map((b) => b.y0)),
          x1: Math.max(...boxes.map((b) => b.x1)),
          y1: Math.max(...boxes.map((b) => b.y1)),
        }
      : null;
    return { text, confidence: avgConf, bbox };
  });
}

/**
 * Reusable sequential OCR session backed by a single dedicated Web Worker (`OCRClient`).
 * Reuses the loaded `eng.traineddata` model across a multi-image batch, calls `clearImage()`
 * after every image, recovers from worker crashes per image, and releases all WASM + Worker
 * memory in `destroy()`.
 */
export class LocalOcrSession {
  constructor({ customOcrProvider = null } = {}) {
    this._customOcrProvider = customOcrProvider;
    this._client = null;
    this._layoutFlags = { StartOfLine: 1, EndOfLine: 2 };
    this._engineLabel = `${LOCAL_OCR_ENGINE_INFO.packageName}@${LOCAL_OCR_ENGINE_INFO.version}`;
    this._destroyed = false;
  }

  async _ensureWorkerClient() {
    if (this._client) return this._client;
    const mod = await lazyLoadTesseractWasm();
    this._layoutFlags = mod.layoutFlags || { StartOfLine: 1, EndOfLine: 2 };
    const useFast = typeof mod.supportsFastBuild === 'function' ? Boolean(mod.supportsFastBuild()) : false;
    const wasmUrl = _resolveAssetUrl(useFast ? LOCAL_OCR_ASSET_PATHS.wasmFast : LOCAL_OCR_ASSET_PATHS.wasmFallback);
    const workerURL = _resolveAssetUrl(LOCAL_OCR_ASSET_PATHS.worker);
    const modelUrl = _resolveAssetUrl(LOCAL_OCR_ASSET_PATHS.model);

    const wasmResp = await fetch(wasmUrl);
    if (!wasmResp.ok) {
      const err = new Error(`Failed to load local OCR WASM binary (${wasmResp.status}).`);
      err.code = 'LOCAL_OCR_UNAVAILABLE';
      throw err;
    }
    const wasmBinary = await wasmResp.arrayBuffer();

    const client = new mod.OCRClient({ workerURL, wasmBinary });
    try {
      await client.loadModel(modelUrl);
    } catch (modelErr) {
      await client.destroy().catch(() => {});
      const err = new Error(`Failed to load local English OCR model: ${modelErr?.message || 'load error'}`);
      err.code = 'LOCAL_OCR_UNAVAILABLE';
      throw err;
    }
    this._client = client;
    return client;
  }

  async recognizeImage({ arrayBuffer, mimeType = 'image/png', signal = null, onProgress = null }) {
    if (signal?.aborted) {
      const err = new Error('OCR cancelled by user.');
      err.code = 'OCR_CANCELLED';
      throw err;
    }

    const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();

    if (typeof this._customOcrProvider === 'function') {
      const out = await this._customOcrProvider({ arrayBuffer, mimeType, signal });
      if (signal?.aborted) {
        const err = new Error('OCR cancelled by user.');
        err.code = 'OCR_CANCELLED';
        throw err;
      }
      const elapsedMs = Math.round((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0);
      if (out && typeof out === 'object' && !Array.isArray(out)) {
        const words = _normalizeWords(out.words || out.blocks || out.lines || []);
        return {
          ok: true,
          status: 'completed',
          text: String(out.text || '').trim(),
          words,
          blocks: _normalizeWords(out.blocks || out.lines || out.words || []),
          confidence: Number.isFinite(Number(out.confidence)) ? Number(out.confidence) : null,
          processingMs: elapsedMs,
          preprocessed: Boolean(out.preprocessed),
          invertedDarkMode: Boolean(out.invertedDarkMode),
          engine: out.engine || 'custom-local-ocr',
          error: null,
        };
      }
      const text = Array.isArray(out) ? out.join('\n') : String(out || '');
      return {
        ok: true,
        status: 'completed',
        text: text.trim(),
        words: [],
        blocks: [],
        confidence: null,
        processingMs: elapsedMs,
        preprocessed: false,
        invertedDarkMode: false,
        engine: 'custom-local-ocr',
        error: null,
      };
    }

    let client = await this._ensureWorkerClient();
    const prep = await decodeAndPreprocessImage(arrayBuffer, mimeType);
    if (!prep.imageData) {
      throw new Error('Could not decode image via browser createImageBitmap/Canvas.');
    }

    try {
      await client.loadImage(prep.imageData);
      if (signal?.aborted) {
        const err = new Error('OCR cancelled by user.');
        err.code = 'OCR_CANCELLED';
        throw err;
      }
      const rawWords = await client.getTextBoxes('word', (progress) => {
        if (typeof onProgress === 'function') {
          const pct = Math.min(100, Math.max(0, Math.round(Number(progress) || 0)));
          onProgress({
            stage: 'ocr',
            status: 'recognizing',
            progressPct: pct,
            message: `Recognizing text (${pct}%)…`,
          });
        }
      });
      const text = await client.getText();
      await client.clearImage();

      const words = _normalizeWords(rawWords);
      const visualBlocks = reconstructVisualLinesFromWords(words);
      const blocks = visualBlocks.length > 0 ? visualBlocks : _groupWordsToLines(words, this._layoutFlags);
      const visualText = visualBlocks.length > 0 ? visualBlocks.map((b) => b.text).join('\n') : String(text || '').trim();
      const confs = words.map((w) => w.confidence).filter((c) => Number.isFinite(c));
      const avgConf = confs.length ? Number((confs.reduce((s, c) => s + c, 0) / confs.length).toFixed(1)) : null;
      const elapsedMs = Math.round((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0);

      return {
        ok: true,
        status: 'completed',
        text: visualText || String(text || '').trim(),
        words,
        blocks,
        confidence: avgConf,
        processingMs: elapsedMs,
        preprocessed: prep.preprocessed,
        invertedDarkMode: prep.invertedDarkMode,
        engine: this._engineLabel,
        error: null,
      };
    } catch (err) {
      // If worker crashed or was cancelled, destroy it so subsequent images in batch get a clean worker
      if (this._client) {
        await this._client.destroy().catch(() => {});
        this._client = null;
      }
      throw err;
    }
  }

  async destroy() {
    this._destroyed = true;
    if (this._client) {
      const c = this._client;
      this._client = null;
      await c.destroy().catch(() => {});
    }
  }
}

export function createLocalOcrSession(options = {}) {
  return new LocalOcrSession(options);
}

/**
 * Convenience single-image OCR call (creates a session, recognizes one image, and destroys the worker).
 */
export async function runLocalImageOcr({
  arrayBuffer,
  mimeType = 'image/png',
  customOcrProvider = null,
  signal = null,
  onProgress = null,
}) {
  const session = createLocalOcrSession({ customOcrProvider });
  try {
    return await session.recognizeImage({ arrayBuffer, mimeType, signal, onProgress });
  } finally {
    await session.destroy();
  }
}

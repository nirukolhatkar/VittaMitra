import { runLocalImageOcr } from './localOcrEngine.js';

/**
 * Local-only PDF.js Adapter (Zero External APIs, Zero Runtime CDN Dependencies).
 *
 * - Lazily loads locally bundled PDF.js (`./vendor/pdfjs/pdf.min.mjs` + `pdf.worker.min.mjs`).
 * - Extracts embedded text directly from digital PDFs (preserving X/Y coordinates & page numbers).
 * - For scanned/image-only PDF pages, renders each page locally onto a temporary Canvas,
 *   converts to PNG bytes, immediately releases Canvas memory, and routes the image through
 *   the EXACT SAME `runLocalImageOcr` engine (never a separate PDF OCR engine).
 */

export const LOCAL_PDFJS_ASSET_PATHS = Object.freeze({
  library: './vendor/pdfjs/pdf.min.mjs',
  worker: './vendor/pdfjs/pdf.worker.min.mjs',
});

let _pdfjsLibPromise = null;

export async function lazyLoadLocalPdfJs() {
  if (typeof window === 'undefined') return null;
  if (window.pdfjsLib && typeof window.pdfjsLib.getDocument === 'function') {
    return window.pdfjsLib;
  }
  if (_pdfjsLibPromise) return _pdfjsLibPromise;

  _pdfjsLibPromise = (async () => {
    try {
      const mod = await import(LOCAL_PDFJS_ASSET_PATHS.library);
      const lib = mod?.default || mod;
      if (lib && typeof lib.getDocument === 'function') {
        if (lib.GlobalWorkerOptions) {
          lib.GlobalWorkerOptions.workerSrc = new URL(LOCAL_PDFJS_ASSET_PATHS.worker, window.location.href).href;
        }
        return lib;
      }
    } catch {
      // Local PDF.js bundle not installed yet; caller falls back gracefully to built-in pure-JS PDF extractor
    }
    _pdfjsLibPromise = null;
    return null;
  })();

  return _pdfjsLibPromise;
}

/**
 * Renders a single PDF.js page to PNG ArrayBuffer locally and releases canvas memory immediately.
 */
async function _renderPdfPageToPngBuffer(page, scale = 1.75) {
  if (typeof document === 'undefined') {
    throw new Error('Canvas rendering is unavailable in this environment.');
  }
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(viewport.width));
  canvas.height = Math.max(1, Math.round(viewport.height));
  const ctx = canvas.getContext('2d');
  try {
    await page.render({ canvasContext: ctx, viewport }).promise;
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('Failed to encode rendered PDF page to PNG.');
    return await blob.arrayBuffer();
  } finally {
    canvas.width = 0;
    canvas.height = 0;
  }
}

/**
 * Groups PDF.js getTextContent() items into coordinate-sorted visual lines and columns.
 */
function _groupPdfJsTextItems(items) {
  const positioned = [];
  for (const it of items || []) {
    const str = String(it.str || '').trim();
    if (!str) continue;
    const tr = Array.isArray(it.transform) ? it.transform : [1, 0, 0, 1, 0, 0];
    positioned.push({ x: Number(tr[4]) || 0, y: Number(tr[5]) || 0, text: str });
  }
  if (positioned.length === 0) return [];

  positioned.sort((a, b) => (Math.abs(b.y - a.y) > 3.5 ? b.y - a.y : a.x - b.x));
  const lines = [];
  for (const item of positioned) {
    const last = lines[lines.length - 1];
    if (!last || Math.abs(last.y - item.y) > 3.5) {
      lines.push({ y: item.y, segs: [item] });
    } else {
      last.segs.push(item);
    }
  }

  return lines.map((line) => {
    line.segs.sort((a, b) => a.x - b.x);
    const cells = [];
    let cur = '';
    let prevX = null;
    for (const seg of line.segs) {
      if (prevX !== null && seg.x - prevX > 18 && cur) {
        cells.push(cur.trim());
        cur = seg.text;
      } else {
        cur = cur ? `${cur} ${seg.text}` : seg.text;
      }
      prevX = seg.x + seg.text.length * 4.5;
    }
    if (cur.trim()) cells.push(cur.trim());
    return cells;
  });
}

/**
 * Extracts multi-page PDF rows using locally bundled PDF.js, routing any scanned/image-only
 * pages through the unified `runLocalImageOcr` engine.
 * Returns `null` if local PDF.js is not bundled (signaling caller to use pure-JS fallback).
 */
export async function extractPdfWithLocalPdfJs(
  arrayBuffer,
  {
    password = '',
    pdfjsLibOverride = null,
    customOcrProvider = null,
    signal = null,
    onProgress = null,
  } = {}
) {
  const pdfjsLib = pdfjsLibOverride || (await lazyLoadLocalPdfJs());
  if (!pdfjsLib) return null;

  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(arrayBuffer),
    password: password || undefined,
    isEvalSupported: false,
    useSystemFonts: true,
  });

  let pdfDoc = null;
  try {
    pdfDoc = await loadingTask.promise;
  } catch (err) {
    if (err?.name === 'PasswordException' || /password/i.test(String(err?.message || ''))) {
      const pwdErr = new Error('This PDF is password-protected or the password is incorrect.');
      pwdErr.code = 'PDF_PASSWORD_REQUIRED';
      throw pwdErr;
    }
    throw err;
  }

  const rows = [];
  const scannedPages = [];
  const warnings = [];
  const ocrMetadataByPage = {};
  let rowCounter = 0;

  try {
    const numPages = pdfDoc.numPages || 0;
    for (let pageNum = 1; pageNum <= numPages; pageNum += 1) {
      if (signal?.aborted) {
        const err = new Error('PDF extraction cancelled by user.');
        err.code = 'OCR_CANCELLED';
        throw err;
      }
      if (typeof onProgress === 'function') {
        onProgress({
          stage: 'extracting',
          current: pageNum,
          total: numPages,
          message: `Reading PDF page ${pageNum} of ${numPages}…`,
        });
      }

      const page = await pdfDoc.getPage(pageNum);
      try {
        const textContent = await page.getTextContent();
        const pageLines = _groupPdfJsTextItems(textContent?.items || []);
        const totalChars = pageLines.reduce((s, cells) => s + cells.join(' ').length, 0);

        if (totalChars >= 20) {
          for (const cells of pageLines) {
            rowCounter += 1;
            rows.push({ cells, sourcePage: pageNum, sourceRowIndex: rowCounter });
          }
        } else {
          // Scanned / image-only PDF page -> render locally & route to the unified local OCR engine
          scannedPages.push(pageNum);
          try {
            const pagePngBuf =
              typeof page._mockRenderPng === 'function'
                ? await page._mockRenderPng()
                : await _renderPdfPageToPngBuffer(page, 1.75);
            const ocrRes = await runLocalImageOcr({
              arrayBuffer: pagePngBuf,
              mimeType: 'image/png',
              customOcrProvider,
              signal,
              onProgress,
            });
            ocrMetadataByPage[pageNum] = {
              confidence: ocrRes.confidence,
              blocks: ocrRes.blocks,
              processingMs: ocrRes.processingMs,
              engine: ocrRes.engine,
            };
            const ocrLines = String(ocrRes.text || '')
              .split(/\r?\n/)
              .map((l) => l.trim())
              .filter(Boolean);
            for (const line of ocrLines) {
              rowCounter += 1;
              rows.push({
                cells: [line],
                sourcePage: pageNum,
                sourceRowIndex: rowCounter,
                fromOcr: true,
                ocrConfidence: ocrRes.confidence,
                ocrBlocks: ocrRes.blocks,
              });
            }
          } catch (ocrErr) {
            if (ocrErr.code === 'OCR_CANCELLED') throw ocrErr;
            warnings.push(
              `Page ${pageNum} is scanned/image-only and local OCR could not run: ${ocrErr.message || 'OCR unavailable'}. Remaining pages preserved.`
            );
          }
        }
      } finally {
        if (typeof page.cleanup === 'function') page.cleanup();
      }
    }
  } finally {
    if (pdfDoc && typeof pdfDoc.destroy === 'function') {
      await pdfDoc.destroy();
    }
  }

  return {
    rows,
    pageCount: Math.max(1, pdfDoc?.numPages || 1),
    warnings,
    scannedPages,
    ocrMetadataByPage,
    sheetNames: ['PDF (PDF.js)'],
    selectedSheet: 'PDF (PDF.js)',
  };
}

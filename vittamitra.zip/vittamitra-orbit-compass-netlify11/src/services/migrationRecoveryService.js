import { createDatabase, initializeDatabase } from '../db/database.js';
import { SettingsRepository } from '../db/repositories/settingsRepository.js';
import { CategoryRepository } from '../db/repositories/categoryRepository.js';
import { AccountRepository } from '../db/repositories/accountRepository.js';
import { FamilyRepository } from '../db/repositories/familyRepository.js';
import { TagRepository } from '../db/repositories/tagRepository.js';
import { FavoriteRepository } from '../db/repositories/favoriteRepository.js';
import { AttachmentRepository } from '../db/repositories/attachmentRepository.js';
import { BudgetRepository } from '../db/repositories/budgetRepository.js';
import { BillRepository } from '../db/repositories/billRepository.js';
import { RecurringRepository } from '../db/repositories/recurringRepository.js';
import { InvestmentRepository } from '../db/repositories/investmentRepository.js';
import { LoanRepository, NetWorthSnapshotRepository } from '../db/repositories/loanRepository.js';
import { TransactionService } from './transactionService.js';
import { ImportExportService } from './importExportService.js';
import { sumPaise } from '../utils/money.js';

/**
 * Phase 8 — Data Integrity Audit & Non-Destructive Real-Data Migration / Recovery Verification.
 */

export async function runIntegrityAudit(db, repos) {
  const [txs, postings, accounts, tags] = await Promise.all([
    db.table('transactions').toArray(),
    db.table('ledger_postings').toArray(),
    repos.accounts.list({ includeArchived: true }),
    repos.tags.list({ includeArchived: true }),
  ]);

  const activeTxs = txs.filter((t) => !t.deleted_at);
  const activeTxIds = new Set(activeTxs.map((t) => t.id));
  const activePostings = postings.filter((p) => !p.deleted_at);

  const orphanPostings = activePostings.filter((p) => !activeTxIds.has(p.transaction_id));
  const invalidAmounts = activeTxs.filter((t) => !Number.isSafeInteger(t.amount_paise) || t.amount_paise <= 0);
  const negativeCc = accounts.filter((a) => a.type === 'credit_card' && (a.current_balance_paise || 0) < 0);

  const checks = [
    {
      name: 'Integer-paise transaction amounts',
      passed: invalidAmounts.length === 0,
      detail: invalidAmounts.length === 0
        ? `All ${activeTxs.length.toLocaleString('en-IN')} active transactions use valid integer paise`
        : `${invalidAmounts.length} invalid amount(s) found`,
    },
    {
      name: 'Ledger posting referential integrity',
      passed: orphanPostings.length === 0,
      detail: orphanPostings.length === 0
        ? `${activePostings.length.toLocaleString('en-IN')} active postings matched cleanly`
        : `${orphanPostings.length} orphan posting(s) detected`,
    },
    {
      name: 'Credit Card non-negative outstanding rule',
      passed: negativeCc.length === 0,
      detail: negativeCc.length === 0
        ? 'All credit card outstanding balances are strictly ≥ ₹0.00'
        : `${negativeCc.length} credit card(s) had negative outstanding`,
    },
  ];

  return {
    passed: checks.every((c) => c.passed),
    checks,
    stats: {
      transactions: activeTxs.length,
      postings: activePostings.length,
      accounts: accounts.length,
      tags: tags.length,
    },
  };
}

function buildScopedEnv(tempDb) {
  const repos = {
    settings: new SettingsRepository(tempDb),
    categories: new CategoryRepository(tempDb),
    accounts: new AccountRepository(tempDb),
    family: new FamilyRepository(tempDb),
    tags: new TagRepository(tempDb),
    favorites: new FavoriteRepository(tempDb),
    attachments: new AttachmentRepository(tempDb),
    budgets: new BudgetRepository(tempDb),
    bills: new BillRepository(tempDb),
    recurring: new RecurringRepository(tempDb),
    investments: new InvestmentRepository(tempDb),
    loans: new LoanRepository(tempDb),
    netWorthSnapshots: new NetWorthSnapshotRepository(tempDb),
  };
  const services = { transactions: new TransactionService(tempDb, repos) };
  services.importExport = new ImportExportService(tempDb, repos, services);
  return { repos, services };
}

function summarizeLedger(txs, accounts) {
  const incomePaise = sumPaise(txs.filter((t) => t.type === 'income').map((t) => t.amount_paise));
  const expensePaise = sumPaise(txs.filter((t) => t.type === 'expense').map((t) => t.amount_paise));
  const transferPaise = sumPaise(txs.filter((t) => t.type === 'transfer').map((t) => t.amount_paise));
  const balanceMap = {};
  for (const a of accounts) {
    balanceMap[a.name] = a.current_balance_paise;
  }
  return { count: txs.length, incomePaise, expensePaise, transferPaise, balanceMap };
}

/**
 * Non-destructive Migration & Disaster-Recovery Verification using the user's real
 * historical Excel/CSV file inside an isolated temporary database (deleted after test).
 */
export async function runIsolatedMigrationAndRecoveryTest({
  sheetRows,
  filename = 'HistoricalData.xlsx',
  sheetName = 'Sheet1',
  createTempDbFn = null,
  onProgress = null,
}) {
  const tStart = Date.now();
  const dbName = `PFM_Migration_Test_${Date.now()}`;
  const tempDb = createTempDbFn ? createTempDbFn() : createDatabase(dbName);
  const steps = [];

  try {
    await initializeDatabase(tempDb);
    const { repos, services } = buildScopedEnv(tempDb);

    // 1. Real Historical Import
    if (onProgress) onProgress({ phase: 'Step 1/4: Importing historical file', done: 10, total: 100 });
    const preview = await services.importExport.buildImportPreview({
      sheetRows,
      filename,
      sheetName,
    });
    const commitRes = await services.importExport.commitImport(preview, {
      createUnknownCategories: true,
      createUnknownAccounts: true,
    });

    const baseTxs = await services.transactions.listTransactions();
    const baseAccs = await repos.accounts.list({ includeArchived: true });
    const baseTags = await repos.tags.list({ includeArchived: true });
    const baseSummary = summarizeLedger(baseTxs, baseAccs);

    steps.push({
      name: '1. Real historical data import',
      passed: commitRes.importedCount > 0 && baseSummary.count === commitRes.importedCount,
      detail: `Imported ${commitRes.importedCount.toLocaleString('en-IN')} rows across ${baseAccs.length} accounts and ${baseTags.length} tags`,
    });

    // 2. Full v6 JSON Backup -> Wipe -> Restore Reconciliation
    if (onProgress) onProgress({ phase: 'Step 2/4: Testing JSON backup & disaster recovery', done: 45, total: 100 });
    const jsonBackup = await services.importExport.exportCompleteJsonBackup();
    await services.importExport.clearTransactionsOnly();
    await services.importExport.restoreCompleteJsonBackup(jsonBackup);

    const restoredTxs = await services.transactions.listTransactions();
    const restoredAccs = await repos.accounts.list({ includeArchived: true });
    const restoredSummary = summarizeLedger(restoredTxs, restoredAccs);

    const jsonExactMatch =
      restoredSummary.count === baseSummary.count &&
      restoredSummary.incomePaise === baseSummary.incomePaise &&
      restoredSummary.expensePaise === baseSummary.expensePaise &&
      restoredSummary.transferPaise === baseSummary.transferPaise &&
      JSON.stringify(restoredSummary.balanceMap) === JSON.stringify(baseSummary.balanceMap);

    steps.push({
      name: '2. Complete JSON backup → wipe → restore',
      passed: jsonExactMatch,
      detail: jsonExactMatch
        ? `100% paise-for-paise match on ${restoredSummary.count.toLocaleString('en-IN')} rows & ${restoredAccs.length} account balances`
        : 'Mismatch detected after JSON restore',
    });

    // 3. 8-Column Sheet1 XLSX Export -> Clean Re-Import Reconciliation
    if (onProgress) onProgress({ phase: 'Step 3/4: Verifying 8-col XLSX round-trip', done: 75, total: 100 });
    const exportedXlsx = await services.importExport.exportStandardXlsx();
    const reparsedWb = await services.importExport.parseWorkbookBuffer(exportedXlsx.bytes);
    const reimportRows = reparsedWb.sheets[reparsedWb.sheetNames[0]];

    const tempDb2 = createTempDbFn ? createTempDbFn() : createDatabase(`${dbName}_reimport`);
    let xlsxExactMatch = false;
    try {
      await initializeDatabase(tempDb2);
      const env2 = buildScopedEnv(tempDb2);
      const p2 = await env2.services.importExport.buildImportPreview({
        sheetRows: reimportRows,
        filename: 'roundtrip.xlsx',
        sheetName: 'Sheet1',
      });
      await env2.services.importExport.commitImport(p2, {
        createUnknownCategories: true,
        createUnknownAccounts: true,
      });
      const rtTxs = await env2.services.transactions.listTransactions();
      const rtAccs = await env2.repos.accounts.list({ includeArchived: true });
      const rtSummary = summarizeLedger(rtTxs, rtAccs);
      xlsxExactMatch =
        rtSummary.count === baseSummary.count &&
        rtSummary.incomePaise === baseSummary.incomePaise &&
        rtSummary.expensePaise === baseSummary.expensePaise &&
        rtSummary.transferPaise === baseSummary.transferPaise &&
        JSON.stringify(rtSummary.balanceMap) === JSON.stringify(baseSummary.balanceMap);
    } finally {
      if (typeof tempDb2.delete === 'function') {
        try { await tempDb2.delete(); } catch { /* ignore */ }
      }
    }

    steps.push({
      name: '3. Standard 8-column Sheet1 XLSX round-trip',
      passed: xlsxExactMatch,
      detail: xlsxExactMatch
        ? `Re-imported ${exportedXlsx.rowCount.toLocaleString('en-IN')} rows with zero balance drift`
        : 'Balance or count drift detected in XLSX round-trip',
    });

    // 4. Integrity Audit
    if (onProgress) onProgress({ phase: 'Step 4/4: Running ledger integrity audit', done: 95, total: 100 });
    const audit = await runIntegrityAudit(tempDb, repos);
    steps.push({
      name: '4. Ledger & credit card integrity audit',
      passed: audit.passed,
      detail: audit.passed
        ? 'Zero orphan postings, valid integer paise, non-negative CC balances'
        : audit.checks.filter((c) => !c.passed).map((c) => c.detail).join('; '),
    });

    return {
      passed: steps.every((s) => s.passed),
      durationMs: Date.now() - tStart,
      importedRows: commitRes.importedCount,
      accountsChecked: baseAccs.length,
      tagsCreated: baseTags.length,
      steps,
    };
  } finally {
    if (typeof tempDb.delete === 'function') {
      try { await tempDb.delete(); } catch { /* ignore */ }
    }
  }
}

import { nowIsoUtc } from '../utils/date.js';
import { normalizeMerchantKey } from '../db/repositories/statementImportRepository.js';

/**
 * Smart Statement Import — Module 3: Personal Intelligence & Categorisation Engine.
 *
 * 100% local on-device. Strictly enforces the 7-tier categorisation precedence:
 *   1. Explicit user correction (`user_correction`, confidence 1.00)
 *   2. Personal exact merchant rule (`exact_merchant`, confidence 0.96)
 *   3. Personal narration pattern rule (`narration_pattern`, confidence 0.92)
 *   4. Previously confirmed merchant preference / ledger history (`confirmed_preference`, confidence 0.85)
 *   5. General merchant dictionary — personal overrides ALWAYS beat built-in (`merchant_dictionary`, 0.78 / 0.72)
 *   6. Transaction description / narration analysis (`description_analysis`, confidence 0.60)
 *   7. Uncategorized fallback (`uncategorized`, confidence 0.10)
 *
 * Learns ONLY from explicit user-confirmed corrections.
 * Never writes directly to the ledger (`transactions` / `ledger_postings`).
 */

export const BUILTIN_INDIAN_MERCHANTS = Object.freeze([
  // Food & Dining
  { merchant: 'swiggy', display: 'Swiggy', categoryHint: 'Eating Out', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'zomato', display: 'Zomato', categoryHint: 'Eating Out', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'dominos', display: "Domino's Pizza", categoryHint: 'Eating Out', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'starbucks', display: 'Starbucks', categoryHint: 'Eating Out', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'paakashaala', display: 'Paakashaala', categoryHint: 'Eating Out', txTypeHint: 'expense', accountingClass: 'expense' },
  // Groceries
  { merchant: 'swiggy instamart', display: 'Swiggy Instamart', categoryHint: 'Groceries', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'blinkit', display: 'Blinkit', categoryHint: 'Groceries', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'zepto', display: 'Zepto', categoryHint: 'Groceries', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'bigbasket', display: 'BigBasket', categoryHint: 'Groceries', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'dmart', display: 'DMart', categoryHint: 'Groceries', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'reliance fresh', display: 'Reliance Fresh', categoryHint: 'Groceries', txTypeHint: 'expense', accountingClass: 'expense' },
  // Transport & Fuel
  { merchant: 'uber', display: 'Uber', categoryHint: 'Transport', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'ola', display: 'Ola', categoryHint: 'Transport', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'ola auto', display: 'Ola Auto', categoryHint: 'Transport', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'rapido', display: 'Rapido', categoryHint: 'Transport', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'irctc', display: 'IRCTC', categoryHint: 'Travel', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'bmrcl', display: 'Namma Metro', categoryHint: 'Transport', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'metro rail', display: 'Metro Rail', categoryHint: 'Transport', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'indianoil', display: 'IndianOil', categoryHint: 'Fuel', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'hpcl', display: 'HPCL Fuel', categoryHint: 'Fuel', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'bpcl', display: 'BPCL Fuel', categoryHint: 'Fuel', txTypeHint: 'expense', accountingClass: 'expense' },
  // Shopping
  { merchant: 'amazon', display: 'Amazon', categoryHint: 'Shopping', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'amazon pay india', display: 'Amazon Pay India', categoryHint: 'Shopping', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'flipkart', display: 'Flipkart', categoryHint: 'Shopping', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'myntra', display: 'Myntra', categoryHint: 'Shopping', txTypeHint: 'expense', accountingClass: 'expense' },
  // Medical & Health
  { merchant: 'apollo pharmacy', display: 'Apollo Pharmacy', categoryHint: 'Medical', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: '1mg', display: 'Tata 1mg', categoryHint: 'Medical', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'pharmeasy', display: 'PharmEasy', categoryHint: 'Medical', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'manipal hospital', display: 'Manipal Hospital', categoryHint: 'Medical', txTypeHint: 'expense', accountingClass: 'expense' },
  // Utilities & Telecom
  { merchant: 'airtel', display: 'Airtel', categoryHint: 'Bills & Utilities', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'jio', display: 'Jio', categoryHint: 'Bills & Utilities', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'bescom', display: 'BESCOM Electricity', categoryHint: 'Bills & Utilities', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'act fibernet', display: 'ACT Fibernet', categoryHint: 'Bills & Utilities', txTypeHint: 'expense', accountingClass: 'expense' },
  // Subscriptions & Entertainment
  { merchant: 'netflix', display: 'Netflix', categoryHint: 'Entertainment', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'spotify', display: 'Spotify', categoryHint: 'Entertainment', txTypeHint: 'expense', accountingClass: 'expense' },
  { merchant: 'bookmyshow', display: 'BookMyShow', categoryHint: 'Entertainment', txTypeHint: 'expense', accountingClass: 'expense' },
  // Investments (not ordinary consumption)
  { merchant: 'zerodha', display: 'Zerodha', categoryHint: 'Investments', txTypeHint: 'transfer', accountingClass: 'investment' },
  { merchant: 'groww', display: 'Groww', categoryHint: 'Investments', txTypeHint: 'transfer', accountingClass: 'investment' },
  { merchant: 'kuvera', display: 'Kuvera', categoryHint: 'Investments', txTypeHint: 'transfer', accountingClass: 'investment' },
  { merchant: 'bse star mf', display: 'BSE StAR MF', categoryHint: 'Investments', txTypeHint: 'transfer', accountingClass: 'investment' },
  { merchant: 'iccl', display: 'ICCL Mutual Fund', categoryHint: 'Investments', txTypeHint: 'transfer', accountingClass: 'investment' },
  // Credit Card Bill Settlements (liability settlement, not a second expense)
  { merchant: 'cred', display: 'CRED CC Payment', categoryHint: null, txTypeHint: 'transfer', accountingClass: 'cc_settlement' },
  { merchant: 'cred club', display: 'CRED CC Payment', categoryHint: null, txTypeHint: 'transfer', accountingClass: 'cc_settlement' },
]);

const _SC_DESCRIPTION_RULES = [
  // Credit Card settlements & liability payments
  {
    re: /\b(credit\s*card\s*(bill|payment)|cc\s*bill|cred\s*club|bbps\s*credit\s*card|card\s*bill\s*pay)\b/i,
    txType: 'transfer',
    accountingClass: 'cc_settlement',
    categoryHint: null,
    confidence: 0.68,
  },
  // Cash withdrawals -> transfer to cash account
  {
    re: /\b(atm\s*(wdl|cash|withdrawal)|cash\s*withdrawal|nfs\s*cash)\b/i,
    txType: 'transfer',
    accountingClass: 'cash_withdrawal',
    categoryHint: null,
    confidence: 0.7,
  },
  // Internal / self transfers
  {
    re: /\b(self\s*transfer|own\s*account|internal\s*transfer|sweep\s*in|sweep\s*out)\b/i,
    txType: 'transfer',
    accountingClass: 'internal_transfer',
    categoryHint: null,
    confidence: 0.65,
  },
  // Investments / SIPs
  {
    re: /\b(mutual\s*fund|sip\b|nifty|midcap|smallcap|index\s*fund|zerodha|groww|kuvera|iccl|nsdl|cdsl|ppf\s*deposit|nps\b)\b/i,
    txType: 'transfer',
    accountingClass: 'investment',
    categoryHint: 'Investments',
    confidence: 0.66,
  },
  // Loan EMI (never invents principal/interest breakdown unless explicitly present)
  {
    re: /\b(emi\b|loan\s*repayment|home\s*loan|car\s*loan|personal\s*loan|nach\s*emi|ach\s*dr.*loan)\b/i,
    txType: 'expense',
    accountingClass: 'loan_emi',
    categoryHint: 'EMI & Loans',
    confidence: 0.65,
  },
  // Bank charges & fees -> expenses
  {
    re: /\b(sms\s*alert|annual\s*fee|joining\s*fee|service\s*charge|bank\s*charge|late\s*fee|markup\s*fee|cheque\s*bounce|folio\s*charge|gst\s*on)\b/i,
    txType: 'expense',
    accountingClass: 'bank_charge',
    categoryHint: 'Bank Charges',
    confidence: 0.68,
  },
  // Refunds & reversals
  {
    re: /\b(refund|reversal|chargeback|cashback|rev[-/\s])\b/i,
    txType: 'income',
    accountingClass: 'refund',
    categoryHint: 'Refund',
    confidence: 0.66,
    creditOnly: true,
  },
  // Income (Salary, Interest, Dividend)
  {
    re: /\b(salary|payroll|stipend|bonus|wages)\b/i,
    txType: 'income',
    accountingClass: 'income',
    categoryHint: 'Salary',
    confidence: 0.68,
    creditOnly: true,
  },
  {
    re: /\b(int\.?\s*pd|bank\s*interest|sb\s*interest|fd\s*interest|interest\s*credit|dividend)\b/i,
    txType: 'income',
    accountingClass: 'income',
    categoryHint: 'Interest',
    confidence: 0.66,
    creditOnly: true,
  },
  // Common expense keywords
  { re: /\b(hospital|clinic|pharmacy|medical|diagnostic|doctor|apollo|health)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Medical', confidence: 0.6 },
  { re: /\b(grocery|groceries|supermarket|mart|vegetables|fruits|milk|dairy|kirana)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Groceries', confidence: 0.6 },
  { re: /\b(restaurant|cafe|coffee|tea|bakery|hotel|biryani|pizza|food|dining|sweet)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Eating Out', confidence: 0.6 },
  { re: /\b(petrol|diesel|fuel|hpcl|bpcl|iocl|shell|fastag|toll|parking)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Fuel', confidence: 0.6 },
  { re: /\b(auto|cab|taxi|metro|bus|flight|airline|indigo|train|rail|uber|ola|rapido)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Transport', confidence: 0.6 },
  { re: /\b(electricity|water\s*bill|gas\s*bill|broadband|wifi|fiber|recharge|postpaid|prepaid|dth)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Bills & Utilities', confidence: 0.6 },
  { re: /\b(rent|house\s*rent|maintenance|society)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Rent', confidence: 0.6 },
  { re: /\b(school|tuition|college|books|course|education|exam\s*fee)\b/i, txType: 'expense', accountingClass: 'expense', categoryHint: 'Education', confidence: 0.6 },
];

function _scResolveCategoryFromHint(hint, txType, categories) {
  if (!hint || !Array.isArray(categories) || categories.length === 0) {
    return { categoryId: null, subcategoryId: null };
  }
  const target = String(hint).trim().toLowerCase();
  const active = categories.filter((c) => !c.deleted_at && !c.is_archived);
  const scoped = txType === 'income' || txType === 'expense'
    ? active.filter((c) => c.type === txType)
    : active;
  const pool = scoped.length > 0 ? scoped : active;

  // Exact name match first, then substring/keyword match
  let match = pool.find((c) => String(c.name || '').trim().toLowerCase() === target);
  if (!match) {
    match = pool.find((c) => {
      const n = String(c.name || '').trim().toLowerCase();
      return n.includes(target) || target.includes(n);
    });
  }
  if (!match) {
    // Keyword overlap (e.g. 'Eating Out' <-> 'Food & Dining', 'Medical' <-> 'Health')
    const aliases = {
      'eating out': ['food', 'dining', 'restaurant'],
      groceries: ['grocery', 'supermarket'],
      medical: ['health', 'healthcare', 'pharmacy'],
      'bills & utilities': ['utilities', 'bills', 'recharge', 'telecom'],
      transport: ['commute', 'travel', 'cab', 'fuel'],
      fuel: ['transport', 'petrol', 'vehicle'],
      entertainment: ['movies', 'subscriptions', 'ott'],
      rent: ['housing', 'home'],
      investments: ['investment', 'savings'],
    };
    const altWords = aliases[target] || [];
    match = pool.find((c) => {
      const n = String(c.name || '').trim().toLowerCase();
      return altWords.some((w) => n.includes(w));
    });
  }
  if (!match) return { categoryId: null, subcategoryId: null };

  if (match.parent_id) {
    return { categoryId: match.parent_id, subcategoryId: match.id };
  }
  return { categoryId: match.id, subcategoryId: null };
}

export class StatementCategorisationService {
  constructor(db, repos) {
    this.db = db;
    this.repos = repos;
  }

  /**
   * Idempotently seeds built-in Indian merchants into `merchant_dictionary` (`is_builtin: true`)
   * without ever overwriting personal overrides (`is_builtin: false`).
   */
  async ensureBuiltInMerchantDictionary() {
    const existing = await this.db.table('merchant_dictionary').toArray();
    const existingBuiltins = new Set(
      existing.filter((e) => !e.deleted_at && e.is_builtin === true).map((e) => e.normalized_merchant)
    );
    const toAdd = [];
    const now = nowIsoUtc();
    for (const item of BUILTIN_INDIAN_MERCHANTS) {
      const norm = normalizeMerchantKey(item.merchant);
      if (!norm || existingBuiltins.has(norm)) continue;
      toAdd.push({
        id: `builtin_merch_${norm.replace(/\s+/g, '_')}`,
        user_id: null,
        normalized_merchant: norm,
        display_name: item.display,
        aliases: [],
        category_hint: item.categoryHint || null,
        subcategory_hint: null,
        tx_type_hint: item.txTypeHint || null,
        accounting_class: item.accountingClass || 'expense',
        is_builtin: true,
        priority: 10,
        created_at: now,
        updated_at: now,
        version: 1,
        deleted_at: null,
      });
    }
    if (toAdd.length > 0) {
      await this.db.table('merchant_dictionary').bulkPut(toAdd);
    }
    return toAdd.length;
  }

  /**
   * Builds a map of normalized_merchant -> most frequent (tie-break: most recent) category
   * from the user's existing confirmed ledger `transactions` (Tier 4).
   */
  async _buildHistoricalMerchantPreferences() {
    const allTxs = await this.db.table('transactions').toArray();
    const statsByMerchant = new Map();

    for (const tx of allTxs) {
      if (tx.deleted_at || !tx.category_id) continue;
      if (tx.type !== 'expense' && tx.type !== 'income') continue;
      const key = normalizeMerchantKey(tx.description || '');
      if (!key || key.length < 2) continue;

      if (!statsByMerchant.has(key)) statsByMerchant.set(key, new Map());
      const bucketKey = `${tx.type}|${tx.category_id}`;
      const bucket = statsByMerchant.get(key).get(bucketKey) || {
        count: 0,
        lastDate: '',
        type: tx.type,
        category_id: tx.category_id,
      };
      bucket.count += 1;
      if (String(tx.date_key || '') > bucket.lastDate) bucket.lastDate = String(tx.date_key || '');
      statsByMerchant.get(key).set(bucketKey, bucket);
    }

    const bestMap = new Map();
    for (const [mKey, bucketMap] of statsByMerchant.entries()) {
      const ranked = [...bucketMap.values()].sort(
        (a, b) => b.count - a.count || b.lastDate.localeCompare(a.lastDate)
      );
      if (ranked[0]) bestMap.set(mKey, ranked[0]);
    }
    return bestMap;
  }

  /**
   * Categorises a single staged transaction strictly following the 7-tier precedence hierarchy.
   */
  classifyStagedRow(row, { rules, merchantMap, historyMap, categories }) {
    // Tier 1: Explicit user correction (NEVER overwritten)
    if (row.categorisation_source === 'user_correction' || row.user_corrected === true) {
      return {
        category_id: row.category_id || null,
        subcategory_id: row.subcategory_id || null,
        tx_type: row.tx_type || 'expense',
        accounting_class: row.accounting_class || row.tx_type || 'expense',
        confidence_score: 1.0,
        categorisation_source: 'user_correction',
      };
    }

    const normMerchant = normalizeMerchantKey(row.normalized_merchant || row.merchant || row.description || '');
    const rawNarrLower = String(row.raw_narration || row.description || '').toLowerCase();
    const isCredit = (row.credit_paise || 0) > 0 && (row.debit_paise || 0) === 0;

    // Tier 2: Personal exact merchant rule
    if (normMerchant) {
      const exactRule = rules.find(
        (r) => r.rule_type === 'exact_merchant' && r.is_active !== false && r.match_key === normMerchant
      );
      if (exactRule) {
        return {
          category_id: exactRule.category_id || null,
          subcategory_id: exactRule.subcategory_id || null,
          tx_type: exactRule.tx_type || row.tx_type || (isCredit ? 'income' : 'expense'),
          accounting_class: exactRule.accounting_class || exactRule.tx_type || row.tx_type || 'expense',
          confidence_score: 0.96,
          categorisation_source: 'exact_merchant',
          matched_rule_id: exactRule.id,
        };
      }
    }

    // Tier 3: Personal narration pattern rule (substring/keyword match against raw_narration)
    const patternRules = rules.filter((r) => r.rule_type === 'narration_pattern' && r.is_active !== false);
    for (const pr of patternRules) {
      const needle = String(pr.match_pattern || pr.match_key || '').trim().toLowerCase();
      if (needle && rawNarrLower.includes(needle)) {
        return {
          category_id: pr.category_id || null,
          subcategory_id: pr.subcategory_id || null,
          tx_type: pr.tx_type || row.tx_type || (isCredit ? 'income' : 'expense'),
          accounting_class: pr.accounting_class || pr.tx_type || row.tx_type || 'expense',
          confidence_score: 0.92,
          categorisation_source: 'narration_pattern',
          matched_rule_id: pr.id,
        };
      }
    }

    // Tier 4: Previously confirmed merchant preference (learning rules OR historical ledger transactions)
    if (normMerchant) {
      const prefRule = rules.find(
        (r) => r.rule_type === 'confirmed_preference' && r.is_active !== false && r.match_key === normMerchant
      );
      if (prefRule) {
        return {
          category_id: prefRule.category_id || null,
          subcategory_id: prefRule.subcategory_id || null,
          tx_type: prefRule.tx_type || row.tx_type || (isCredit ? 'income' : 'expense'),
          accounting_class: prefRule.accounting_class || prefRule.tx_type || row.tx_type || 'expense',
          confidence_score: 0.85,
          categorisation_source: 'confirmed_preference',
          matched_rule_id: prefRule.id,
        };
      }

      const histPref = historyMap.get(normMerchant);
      if (histPref) {
        const catObj = categories.find((c) => c.id === histPref.category_id);
        const categoryId = catObj?.parent_id ? catObj.parent_id : histPref.category_id;
        const subcategoryId = catObj?.parent_id ? catObj.id : null;
        return {
          category_id: categoryId,
          subcategory_id: subcategoryId,
          tx_type: histPref.type || row.tx_type || (isCredit ? 'income' : 'expense'),
          accounting_class: histPref.type || row.tx_type || 'expense',
          confidence_score: 0.85,
          categorisation_source: 'confirmed_preference',
        };
      }
    }

    // Tier 5: General merchant dictionary (personal override is_builtin===false ALWAYS beats is_builtin===true)
    if (normMerchant) {
      let dictEntry = merchantMap.get(normMerchant) || null;
      if (!dictEntry) {
        // Also check partial merchant key containment (e.g. "swiggy bangalore" -> "swiggy")
        for (const [k, entry] of merchantMap.entries()) {
          if (k.length >= 3 && (normMerchant.includes(k) || rawNarrLower.includes(k))) {
            dictEntry = entry;
            break;
          }
        }
      }
      if (dictEntry) {
        const txType = dictEntry.tx_type_hint || row.tx_type || (isCredit ? 'income' : 'expense');
        const resolved = _scResolveCategoryFromHint(dictEntry.category_hint, txType, categories);
        return {
          category_id: resolved.categoryId,
          subcategory_id: resolved.subcategoryId,
          tx_type: txType,
          accounting_class: dictEntry.accounting_class || txType,
          confidence_score: dictEntry.is_builtin === false ? 0.78 : 0.72,
          categorisation_source: 'merchant_dictionary',
        };
      }
    }

    // Tier 6: Transaction description / narration analysis
    for (const rule of _SC_DESCRIPTION_RULES) {
      if (rule.creditOnly && !isCredit) continue;
      if (rule.re.test(rawNarrLower)) {
        const resolved = _scResolveCategoryFromHint(rule.categoryHint, rule.txType, categories);
        return {
          category_id: resolved.categoryId,
          subcategory_id: resolved.subcategoryId,
          tx_type: rule.txType,
          accounting_class: rule.accountingClass,
          confidence_score: rule.confidence,
          categorisation_source: 'description_analysis',
        };
      }
    }

    // Tier 7: Uncategorized fallback
    return {
      category_id: null,
      subcategory_id: null,
      tx_type: row.tx_type || (isCredit ? 'income' : 'expense'),
      accounting_class: isCredit ? 'income' : 'expense',
      confidence_score: 0.1,
      categorisation_source: 'uncategorized',
    };
  }

  /**
   * Runs the 7-tier Personal Intelligence Engine across all staged rows in a batch.
   */
  async categoriseBatch(batchId) {
    await this.ensureBuiltInMerchantDictionary();

    const [rules, dictEntries, categories, historyMap, allStaged] = await Promise.all([
      this.repos.statementImport.listActiveLearningRules(),
      this.db.table('merchant_dictionary').toArray(),
      this.repos.categories.list({ includeArchived: false }),
      this._buildHistoricalMerchantPreferences(),
      this.db.table('staged_transactions').toArray(),
    ]);

    // Build personal-precedence merchant map (personal override ALWAYS beats built-in)
    const activeDict = dictEntries
      .filter((e) => !e.deleted_at)
      .sort((a, b) => {
        const aPers = a.is_builtin === false ? 1 : 0;
        const bPers = b.is_builtin === false ? 1 : 0;
        if (aPers !== bPers) return bPers - aPers;
        return (Number(b.priority) || 0) - (Number(a.priority) || 0);
      });
    const merchantMap = new Map();
    for (const entry of activeDict) {
      if (!merchantMap.has(entry.normalized_merchant)) {
        merchantMap.set(entry.normalized_merchant, entry);
      }
    }

    const batchRows = allStaged.filter((r) => r.batch_id === batchId && !r.deleted_at);
    const updatedRows = [];
    const now = nowIsoUtc();

    for (const row of batchRows) {
      const cls = this.classifyStagedRow(row, { rules, merchantMap, historyMap, categories });
      const nextStatus =
        row.status === 'duplicate' || row.status === 'excluded' || row.status === 'imported'
          ? row.status
          : row.requires_confirmation || cls.categorisation_source === 'uncategorized'
            ? 'needs_attention'
            : row.status || 'new';

      const updated = {
        ...row,
        category_id: cls.category_id,
        subcategory_id: cls.subcategory_id,
        tx_type: cls.tx_type,
        accounting_class: cls.accounting_class,
        confidence_score: cls.confidence_score,
        categorisation_source: cls.categorisation_source,
        status: nextStatus,
        updated_at: now,
      };
      updatedRows.push(updated);
    }

    if (updatedRows.length > 0) {
      await this.db.table('staged_transactions').bulkPut(updatedRows);
    }

    return {
      batchId,
      totalCategorised: updatedRows.length,
      highConfidenceCount: updatedRows.filter((r) => r.confidence_score >= 0.85).length,
      uncategorizedCount: updatedRows.filter((r) => r.categorisation_source === 'uncategorized').length,
      rows: updatedRows,
    };
  }

  /**
   * Applies an explicit user-confirmed correction to a staged transaction AND learns a personal rule
   * (ONLY called on explicit user confirmation — never auto-learned from unconfirmed guesses).
   */
  async applyUserCorrectionAndLearn({
    stagedTxId,
    categoryId = null,
    subcategoryId = null,
    txType = null,
    saveRule = true,
    ruleType = 'exact_merchant', // 'exact_merchant' | 'narration_pattern' | 'confirmed_preference'
    patternText = '',
  }) {
    const existing = await this.db.table('staged_transactions').get(stagedTxId);
    if (!existing || existing.deleted_at) {
      throw new Error('Staged transaction not found.');
    }

    const now = nowIsoUtc();
    const resolvedType = txType || existing.tx_type || 'expense';
    const updatedStaged = {
      ...existing,
      category_id: categoryId || null,
      subcategory_id: subcategoryId || null,
      tx_type: resolvedType,
      confidence_score: 1.0,
      categorisation_source: 'user_correction',
      user_corrected: true,
      requires_confirmation: false,
      status: existing.status === 'duplicate' ? 'duplicate' : 'new',
      updated_at: now,
      version: (existing.version || 1) + 1,
    };
    await this.db.table('staged_transactions').put(updatedStaged);

    let learnedRule = null;
    if (saveRule) {
      const matchKey =
        ruleType === 'narration_pattern'
          ? normalizeMerchantKey(patternText || existing.merchant || existing.raw_narration)
          : normalizeMerchantKey(existing.normalized_merchant || existing.merchant || existing.description);

      if (matchKey) {
        const allRules = await this.db.table('personal_learning_rules').toArray();
        const prevRule = allRules.find(
          (r) => !r.deleted_at && r.rule_type === ruleType && r.match_key === matchKey
        );
        if (prevRule) {
          learnedRule = await this.repos.statementImport.learningRules.update(prevRule.id, {
            match_pattern: ruleType === 'narration_pattern' ? String(patternText || matchKey).trim() : prevRule.match_pattern || '',
            category_id: categoryId || null,
            subcategory_id: subcategoryId || null,
            tx_type: resolvedType,
            hit_count: (Number(prevRule.hit_count) || 0) + 1,
            last_confirmed_at: now,
            is_active: true,
          });
        } else {
          learnedRule = await this.repos.statementImport.createLearningRule({
            rule_type: ruleType,
            match_key: matchKey,
            match_pattern: ruleType === 'narration_pattern' ? String(patternText || matchKey).trim() : '',
            category_id: categoryId || null,
            subcategory_id: subcategoryId || null,
            tx_type: resolvedType,
            priority: ruleType === 'exact_merchant' ? 200 : ruleType === 'narration_pattern' ? 150 : 100,
            is_active: true,
          });
        }
      }
    }

    return { stagedTx: updatedStaged, learnedRule };
  }
}

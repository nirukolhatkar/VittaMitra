import { readXlsxWorkbook } from '../../vendor/xlsx-lite.js';
import { parseCsvText } from './importExportService.js';
import { extractPdfWithLocalPdfJs } from './localPdfEngine.js';

/**
 * Smart Statement Import — Module 2: Local Extraction Engine.
 *
 * 100% on-device inside the PWA:
 * - CSV (auto-detect delimiter , ; \t |, BOM, quoted fields)
 * - XLSX (reuses vendored xlsx-lite.js, multi-sheet support)
 * - XLS (HTML table / TSV bank exports + lightweight pure-JS OLE2/BIFF8 reader)
 * - PDF (multi-page text stream extractor, FlateDecode, ToUnicode CMap, coordinate-sorted rows,
 *        in-memory password check/RC4 decryption without storing passwords, scanned-page detection
 *        with pluggable local OCR hook that isolates per-page errors)
 * - Automatic column mapping + manual column mapping override support
 * - Opening / closing balance extraction where reliably present
 */

function _seYield() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

function _seDecodeHtmlEntities(str) {
  return String(str || '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(parseInt(dec, 10)));
}

/**
 * Decompress zlib/deflate stream using native browser DecompressionStream or Node zlib fallback.
 */
async function _seInflateBytes(compressed) {
  const u8 = compressed instanceof Uint8Array ? compressed : new Uint8Array(compressed);
  if (typeof DecompressionStream !== 'undefined') {
    for (const fmt of ['deflate', 'deflate-raw']) {
      try {
        const ds = new DecompressionStream(fmt);
        const writer = ds.writable.getWriter();
        writer.write(u8);
        writer.close();
        const chunks = [];
        const reader = ds.readable.getReader();
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          if (value) chunks.push(value);
        }
        const total = chunks.reduce((s, c) => s + c.length, 0);
        const out = new Uint8Array(total);
        let pos = 0;
        for (const c of chunks) {
          out.set(c, pos);
          pos += c.length;
        }
        return out;
      } catch {
        // try next format
      }
    }
  }
  if (typeof process !== 'undefined' && process.versions?.node) {
    const zlib = await import('node:zlib');
    try {
      return new Uint8Array(zlib.inflateSync(u8));
    } catch {
      return new Uint8Array(zlib.inflateRawSync(u8));
    }
  }
  throw new Error('Deflate decompression is not supported in this runtime.');
}

// ---------- CSV Extraction ----------

function _seDetectDelimiter(text) {
  const firstLines = text.split(/\r?\n/).filter((l) => l.trim()).slice(0, 10);
  const candidates = [',', '\t', ';', '|'];
  let best = ',';
  let bestScore = -1;
  for (const delim of candidates) {
    const counts = firstLines.map((line) => line.split(delim).length - 1);
    const nonZero = counts.filter((c) => c >= 2);
    const score = nonZero.length * 10 + counts.reduce((s, c) => s + c, 0);
    if (score > bestScore) {
      bestScore = score;
      best = delim;
    }
  }
  return best;
}

function _seParseDelimited(text, delimiter) {
  if (delimiter === ',') return parseCsvText(text);
  const rows = [];
  let row = [];
  let cell = '';
  let inQuotes = false;
  const clean = String(text || '').replace(/^\uFEFF/, '');
  for (let i = 0; i < clean.length; i += 1) {
    const ch = clean[i];
    if (inQuotes) {
      if (ch === '"' && clean[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        cell += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === delimiter) {
      row.push(cell.trim());
      cell = '';
    } else if (ch === '\r') {
      // ignore
    } else if (ch === '\n') {
      row.push(cell.trim());
      if (row.some((c) => c !== '')) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += ch;
    }
  }
  row.push(cell.trim());
  if (row.some((c) => c !== '')) rows.push(row);
  return rows;
}

export function extractCsvRows(arrayBuffer) {
  const text = new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(arrayBuffer)).replace(/^\uFEFF/, '');
  const delimiter = _seDetectDelimiter(text);
  const rawRows = _seParseDelimited(text, delimiter);
  return {
    rows: rawRows.map((cells, idx) => ({ cells, sourcePage: 1, sourceRowIndex: idx + 1 })),
    pageCount: 1,
    warnings: [],
    scannedPages: [],
    sheetNames: ['CSV'],
    selectedSheet: 'CSV',
  };
}

// ---------- XLSX Extraction (Reuses vendored xlsx-lite.js) ----------

export async function extractXlsxRows(arrayBuffer, { sheetName = null } = {}) {
  const wb = await readXlsxWorkbook(arrayBuffer);
  const names = wb.sheetNames || Object.keys(wb.sheets || {});
  if (names.length === 0) {
    throw new Error('No worksheets found inside XLSX file.');
  }
  let chosen = sheetName && wb.sheets[sheetName] ? sheetName : names[0];
  if (!sheetName && names.length > 1) {
    let bestLen = -1;
    for (const n of names) {
      const len = (wb.sheets[n] || []).length;
      if (len > bestLen) {
        bestLen = len;
        chosen = n;
      }
    }
  }
  const sheetIdx = names.indexOf(chosen) + 1;
  const rawRows = wb.sheets[chosen] || [];
  return {
    rows: rawRows.map((cells, idx) => ({
      cells: Array.isArray(cells) ? cells.map((c) => (c === null || c === undefined ? '' : String(c).trim())) : [],
      sourcePage: sheetIdx,
      sourceRowIndex: idx + 1,
    })),
    pageCount: names.length,
    warnings: [],
    scannedPages: [],
    sheetNames: names,
    selectedSheet: chosen,
  };
}

// ---------- XLS Extraction (HTML/TSV Indian Bank Exports + Pure-JS OLE2/BIFF8 Reader) ----------

function _seParseHtmlTableRows(html) {
  const rows = [];
  const trRe = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let trMatch;
  let rowIdx = 0;
  while ((trMatch = trRe.exec(html)) !== null) {
    rowIdx += 1;
    const trBody = trMatch[1];
    const cells = [];
    const tdRe = /<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi;
    let tdMatch;
    while ((tdMatch = tdRe.exec(trBody)) !== null) {
      const text = _seDecodeHtmlEntities(tdMatch[1].replace(/<[^>]+>/g, ' '))
        .replace(/\s+/g, ' ')
        .trim();
      cells.push(text);
    }
    if (cells.some((c) => c !== '')) {
      rows.push({ cells, sourcePage: 1, sourceRowIndex: rowIdx });
    }
  }
  return rows;
}

function _seDecodeBiffRk(rk) {
  const isDiv100 = (rk & 0x01) !== 0;
  const isInt = (rk & 0x02) !== 0;
  let val;
  if (isInt) {
    val = rk >> 2;
  } else {
    const buf = new ArrayBuffer(8);
    const dv = new DataView(buf);
    dv.setUint32(4, rk & 0xfffffffc, true);
    dv.setUint32(0, 0, true);
    val = dv.getFloat64(0, true);
  }
  return isDiv100 ? val / 100 : val;
}

/**
 * Minimal pure-JS OLE2 + BIFF8 Workbook stream extractor for standard unencrypted .xls files.
 */
function _seParseBiff8Xls(arrayBuffer) {
  const u8 = new Uint8Array(arrayBuffer);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  const sectorShift = dv.getUint16(30, true);
  const sectorSize = 1 << sectorShift;
  const dirStartSec = dv.getInt32(48, true);

  // Build FAT from DIFAT header entries (first 109 FAT sectors)
  const fat = [];
  for (let i = 0; i < 109; i += 1) {
    const sec = dv.getInt32(76 + i * 4, true);
    if (sec < 0) break;
    const base = (sec + 1) * sectorSize;
    if (base + sectorSize > u8.length) break;
    for (let j = 0; j < sectorSize; j += 4) {
      fat.push(dv.getInt32(base + j, true));
    }
  }

  const readChain = (startSec, expectedSize) => {
    const chunks = [];
    let sec = startSec;
    const seen = new Set();
    while (sec >= 0 && !seen.has(sec)) {
      seen.add(sec);
      const off = (sec + 1) * sectorSize;
      if (off >= u8.length) break;
      chunks.push(u8.slice(off, Math.min(off + sectorSize, u8.length)));
      sec = sec < fat.length ? fat[sec] : -2;
    }
    const total = chunks.reduce((s, c) => s + c.length, 0);
    const out = new Uint8Array(expectedSize > 0 ? Math.min(expectedSize, total) : total);
    let pos = 0;
    for (const c of chunks) {
      const n = Math.min(c.length, out.length - pos);
      if (n <= 0) break;
      out.set(c.subarray(0, n), pos);
      pos += n;
    }
    return out;
  };

  const dirBytes = readChain(dirStartSec, 0);
  const dirDv = new DataView(dirBytes.buffer, dirBytes.byteOffset, dirBytes.byteLength);
  let wbBytes = null;
  for (let off = 0; off + 128 <= dirBytes.length; off += 128) {
    const nameLen = dirDv.getUint16(off + 64, true);
    if (nameLen <= 2 || nameLen > 64) continue;
    let name = '';
    for (let k = 0; k < nameLen - 2; k += 2) {
      name += String.fromCharCode(dirDv.getUint16(off + k, true));
    }
    if (name === 'Workbook' || name === 'Book') {
      const startSec = dirDv.getInt32(off + 116, true);
      const size = dirDv.getUint32(off + 120, true);
      wbBytes = readChain(startSec, size);
      break;
    }
  }
  if (!wbBytes || wbBytes.length < 16) {
    throw new Error('Could not locate BIFF8 Workbook stream inside .xls file. Please re-save as .xlsx or .csv.');
  }

  const wbDv = new DataView(wbBytes.buffer, wbBytes.byteOffset, wbBytes.byteLength);
  const sst = [];
  const grid = new Map(); // row -> Map(col -> value)
  const setCell = (r, c, v) => {
    if (!grid.has(r)) grid.set(r, new Map());
    grid.get(r).set(c, String(v ?? '').trim());
  };

  let pos = 0;
  let inFirstSheet = false;
  let bofCount = 0;
  while (pos + 4 <= wbBytes.length) {
    const recType = wbDv.getUint16(pos, true);
    const recLen = wbDv.getUint16(pos + 2, true);
    const dataStart = pos + 4;
    if (dataStart + recLen > wbBytes.length) break;

    if (recType === 0x002f) {
      throw new Error('Encrypted legacy .xls workbooks are not supported locally. Please re-save as .xlsx or .csv.');
    }
    if (recType === 0x0809) {
      bofCount += 1;
      const subType = recLen >= 4 ? wbDv.getUint16(dataStart + 2, true) : 0;
      if (subType === 0x0010) {
        if (bofCount > 2) break; // stop after first worksheet
        inFirstSheet = true;
      }
    } else if (recType === 0x00fc && recLen >= 8) {
      // SST (Shared String Table)
      const uniqueCount = wbDv.getUint32(dataStart + 4, true);
      let sPos = dataStart + 8;
      const end = dataStart + recLen;
      for (let i = 0; i < uniqueCount && sPos + 3 <= end; i += 1) {
        const charCount = wbDv.getUint16(sPos, true);
        const flags = wbBytes[sPos + 2];
        sPos += 3;
        const isUtf16 = (flags & 0x01) !== 0;
        const hasExt = (flags & 0x04) !== 0;
        const hasRich = (flags & 0x08) !== 0;
        let richRuns = 0;
        let extLen = 0;
        if (hasRich && sPos + 2 <= end) {
          richRuns = wbDv.getUint16(sPos, true);
          sPos += 2;
        }
        if (hasExt && sPos + 4 <= end) {
          extLen = wbDv.getUint32(sPos, true);
          sPos += 4;
        }
        let str = '';
        if (isUtf16) {
          for (let c = 0; c < charCount && sPos + 2 <= end; c += 1) {
            str += String.fromCharCode(wbDv.getUint16(sPos, true));
            sPos += 2;
          }
        } else {
          for (let c = 0; c < charCount && sPos < end; c += 1) {
            str += String.fromCharCode(wbBytes[sPos]);
            sPos += 1;
          }
        }
        sPos += richRuns * 4 + extLen;
        sst.push(str);
      }
    } else if (inFirstSheet && recType === 0x00fd && recLen >= 10) {
      // LABELSST
      const r = wbDv.getUint16(dataStart, true);
      const c = wbDv.getUint16(dataStart + 2, true);
      const idx = wbDv.getUint32(dataStart + 6, true);
      setCell(r, c, sst[idx] ?? '');
    } else if (inFirstSheet && recType === 0x0204 && recLen >= 8) {
      // LABEL
      const r = wbDv.getUint16(dataStart, true);
      const c = wbDv.getUint16(dataStart + 2, true);
      const strLen = wbDv.getUint16(dataStart + 6, true);
      const flags = recLen > 8 ? wbBytes[dataStart + 8] : 0;
      const isUtf16 = (flags & 0x01) !== 0;
      let str = '';
      let sPos = dataStart + 9;
      if (isUtf16) {
        for (let k = 0; k < strLen && sPos + 2 <= dataStart + recLen; k += 1) {
          str += String.fromCharCode(wbDv.getUint16(sPos, true));
          sPos += 2;
        }
      } else {
        for (let k = 0; k < strLen && sPos < dataStart + recLen; k += 1) {
          str += String.fromCharCode(wbBytes[sPos]);
          sPos += 1;
        }
      }
      setCell(r, c, str);
    } else if (inFirstSheet && recType === 0x0203 && recLen >= 14) {
      // NUMBER (IEEE-754 float64)
      const r = wbDv.getUint16(dataStart, true);
      const c = wbDv.getUint16(dataStart + 2, true);
      const val = wbDv.getFloat64(dataStart + 6, true);
      setCell(r, c, Number.isFinite(val) ? String(val) : '');
    } else if (inFirstSheet && recType === 0x027e && recLen >= 10) {
      // RK
      const r = wbDv.getUint16(dataStart, true);
      const c = wbDv.getUint16(dataStart + 2, true);
      const val = _seDecodeBiffRk(wbDv.getInt32(dataStart + 6, true));
      setCell(r, c, String(val));
    } else if (inFirstSheet && recType === 0x00bd && recLen >= 10) {
      // MULRK
      const r = wbDv.getUint16(dataStart, true);
      const firstCol = wbDv.getUint16(dataStart + 2, true);
      const lastCol = wbDv.getUint16(dataStart + recLen - 2, true);
      let off = dataStart + 4;
      for (let c = firstCol; c <= lastCol && off + 6 <= dataStart + recLen - 2; c += 1) {
        const val = _seDecodeBiffRk(wbDv.getInt32(off + 2, true));
        setCell(r, c, String(val));
        off += 6;
      }
    }

    pos = dataStart + recLen;
  }

  const sortedRowNums = [...grid.keys()].sort((a, b) => a - b);
  const rows = [];
  for (const rNum of sortedRowNums) {
    const colMap = grid.get(rNum);
    const maxCol = Math.max(...colMap.keys());
    const cells = [];
    for (let c = 0; c <= maxCol; c += 1) {
      cells.push(colMap.get(c) ?? '');
    }
    if (cells.some((x) => x !== '')) {
      rows.push({ cells, sourcePage: 1, sourceRowIndex: rNum + 1 });
    }
  }
  return rows;
}

export function extractXlsRows(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const isOle2 =
    bytes.length >= 8 &&
    bytes[0] === 0xd0 &&
    bytes[1] === 0xcf &&
    bytes[2] === 0x11 &&
    bytes[3] === 0xe0;

  if (!isOle2) {
    const text = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    if (/<tr\b/i.test(text) && /<t[dh]\b/i.test(text)) {
      const rows = _seParseHtmlTableRows(text);
      return {
        rows,
        pageCount: 1,
        warnings: [],
        scannedPages: [],
        sheetNames: ['HTML Table'],
        selectedSheet: 'HTML Table',
      };
    }
    return extractCsvRows(arrayBuffer);
  }

  const rows = _seParseBiff8Xls(arrayBuffer);
  return {
    rows,
    pageCount: 1,
    warnings: rows.length === 0 ? ['No readable rows found in legacy .xls workbook. Try saving as .xlsx or .csv.'] : [],
    scannedPages: [],
    sheetNames: ['Sheet1'],
    selectedSheet: 'Sheet1',
  };
}

// ---------- PDF Extraction (Multi-page, FlateDecode, Coordinate Row Reconstruction, Password & Scanned Detection) ----------

function _seDecodePdfLiteralString(str) {
  let out = '';
  for (let i = 0; i < str.length; i += 1) {
    const ch = str[i];
    if (ch === '\\' && i + 1 < str.length) {
      const next = str[i + 1];
      if (next === 'n') { out += '\n'; i += 1; }
      else if (next === 'r') { out += '\r'; i += 1; }
      else if (next === 't') { out += '\t'; i += 1; }
      else if (next === 'b') { out += '\b'; i += 1; }
      else if (next === 'f') { out += '\f'; i += 1; }
      else if (next === '(' || next === ')' || next === '\\') { out += next; i += 1; }
      else if (/[0-7]/.test(next)) {
        const oct = str.slice(i + 1, i + 4).match(/^[0-7]{1,3}/)[0];
        out += String.fromCharCode(parseInt(oct, 8));
        i += oct.length;
      } else {
        i += 1;
      }
    } else {
      out += ch;
    }
  }
  return out;
}

function _seDecodePdfHexString(hex, cmap = null) {
  const clean = hex.replace(/\s+/g, '');
  if (!clean) return '';
  if (cmap && cmap.size > 0) {
    // Try 4-hex-digit (2-byte CID) lookup first, then 2-hex-digit
    let mapped = '';
    let matchedAny = false;
    for (let i = 0; i < clean.length; ) {
      const h4 = clean.slice(i, i + 4).toUpperCase();
      if (h4.length === 4 && cmap.has(h4)) {
        mapped += cmap.get(h4);
        matchedAny = true;
        i += 4;
        continue;
      }
      const h2 = clean.slice(i, i + 2).toUpperCase();
      if (cmap.has(h2)) {
        mapped += cmap.get(h2);
        matchedAny = true;
        i += 2;
        continue;
      }
      if (h2.length === 2) {
        const code = parseInt(h2, 16);
        if (code >= 32 && code <= 126) mapped += String.fromCharCode(code);
      }
      i += 2;
    }
    if (matchedAny) return mapped;
  }
  // Standard UTF-16BE with BOM FEFF or Latin1 hex bytes
  if (clean.toUpperCase().startsWith('FEFF')) {
    let s = '';
    for (let i = 4; i + 4 <= clean.length; i += 4) {
      s += String.fromCharCode(parseInt(clean.slice(i, i + 4), 16));
    }
    return s;
  }
  let out = '';
  for (let i = 0; i + 2 <= clean.length; i += 2) {
    const code = parseInt(clean.slice(i, i + 2), 16);
    if (code >= 32 || code === 9 || code === 10) out += String.fromCharCode(code);
  }
  return out;
}

function _seParseToUnicodeCMap(text) {
  const map = new Map();
  const bfCharRe = /beginbfchar([\s\S]*?)endbfchar/g;
  let m;
  while ((m = bfCharRe.exec(text)) !== null) {
    const pairRe = /<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/g;
    let pm;
    while ((pm = pairRe.exec(m[1])) !== null) {
      const src = pm[1].toUpperCase();
      const dstHex = pm[2];
      let ch = '';
      for (let i = 0; i + 4 <= dstHex.length; i += 4) {
        ch += String.fromCharCode(parseInt(dstHex.slice(i, i + 4), 16));
      }
      if (!ch && dstHex.length === 2) ch = String.fromCharCode(parseInt(dstHex, 16));
      if (ch) map.set(src, ch);
    }
  }
  const bfRangeRe = /beginbfrange([\s\S]*?)endbfrange/g;
  while ((m = bfRangeRe.exec(text)) !== null) {
    const lineRe = /<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/g;
    let lm;
    while ((lm = lineRe.exec(m[1])) !== null) {
      const start = parseInt(lm[1], 16);
      const end = parseInt(lm[2], 16);
      let dst = parseInt(lm[3], 16);
      const width = lm[1].length;
      for (let code = start; code <= end && code - start < 256; code += 1) {
        map.set(code.toString(16).toUpperCase().padStart(width, '0'), String.fromCharCode(dst));
        dst += 1;
      }
    }
  }
  return map;
}

/**
 * Extracts positioned text tokens from a single decompressed PDF content stream
 * and groups them into coordinate-sorted visual lines / column cells.
 */
function _seExtractLinesFromPdfContent(contentText, cmap) {
  const items = [];
  let curX = 0;
  let curY = 0;
  let inText = false;

  const btRe = /BT([\s\S]*?)ET/g;
  let btMatch;
  while ((btMatch = btRe.exec(contentText)) !== null) {
    inText = true;
    curX = 0;
    curY = 0;
    const block = btMatch[1];
    // Tokenize positioning and text-show operators
    const opRe =
      /(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+Tm|(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+T[dD]|\bT\*|(\((?:\\.|[^\\()])*\)|<[0-9a-fA-F\s]+>)\s*(?:Tj|'|")|\[((?:\\.|[^\]])*)\]\s*TJ/g;
    let om;
    while ((om = opRe.exec(block)) !== null) {
      if (om[5] !== undefined && om[6] !== undefined) {
        curX = parseFloat(om[5]);
        curY = parseFloat(om[6]);
      } else if (om[7] !== undefined && om[8] !== undefined) {
        curX += parseFloat(om[7]);
        curY += parseFloat(om[8]);
      } else if (om[0] === 'T*') {
        curY -= 12;
      } else if (om[9] !== undefined) {
        const rawTok = om[9];
        const decoded = rawTok.startsWith('(')
          ? _seDecodePdfLiteralString(rawTok.slice(1, -1))
          : _seDecodePdfHexString(rawTok.slice(1, -1), cmap);
        if (decoded.trim()) {
          items.push({ x: curX, y: curY, text: decoded });
        }
      } else if (om[10] !== undefined) {
        const arrBody = om[10];
        let joined = '';
        const partRe = /\((?:\\.|[^\\()])*\)|<[0-9a-fA-F\s]+>|-?\d+(?:\.\d+)?/g;
        let pm;
        while ((pm = partRe.exec(arrBody)) !== null) {
          const tok = pm[0];
          if (tok.startsWith('(')) joined += _seDecodePdfLiteralString(tok.slice(1, -1));
          else if (tok.startsWith('<')) joined += _seDecodePdfHexString(tok.slice(1, -1), cmap);
          else {
            const kern = parseFloat(tok);
            if (kern < -180) joined += ' ';
          }
        }
        if (joined.trim()) {
          items.push({ x: curX, y: curY, text: joined });
        }
      }
    }
    inText = false;
  }

  if (items.length === 0) return [];

  // Group items by Y coordinate (tolerance 3.5pt), top-to-bottom (higher Y first in PDF coordinates)
  items.sort((a, b) => (Math.abs(b.y - a.y) > 3.5 ? b.y - a.y : a.x - b.x));
  const lines = [];
  for (const it of items) {
    const last = lines[lines.length - 1];
    if (!last || Math.abs(last.y - it.y) > 3.5) {
      lines.push({ y: it.y, segments: [it] });
    } else {
      last.segments.push(it);
    }
  }

  return lines.map((line) => {
    line.segments.sort((a, b) => a.x - b.x);
    // Split into column cells when horizontal gap > 14pt, else join with space
    const cells = [];
    let curCell = '';
    let prevX = null;
    for (const seg of line.segments) {
      const txt = seg.text.trim();
      if (!txt) continue;
      if (prevX !== null && seg.x - prevX > 18 && curCell) {
        cells.push(curCell.trim());
        curCell = txt;
      } else {
        curCell = curCell ? `${curCell} ${txt}` : txt;
      }
      prevX = seg.x + txt.length * 4.5;
    }
    if (curCell.trim()) cells.push(curCell.trim());
    return cells;
  });
}

/**
 * Extracts multi-page text rows from a local PDF ArrayBuffer.
 * Supports optional in-memory password (never stored/logged) and optional local OCR adapter for scanned pages.
 */
export async function extractPdfRows(
  arrayBuffer,
  { password = '', localOcrFn = null, onProgress = null } = {}
) {
  const bytes = new Uint8Array(arrayBuffer);
  // Decode as Latin-1 so byte offsets stay 1:1 with character indices
  let rawLatin1 = '';
  const CHUNK = 32768;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    rawLatin1 += String.fromCharCode(...bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
  }

  const isEncrypted = /\/Encrypt\b/.test(rawLatin1);
  if (isEncrypted && !password) {
    const err = new Error('This PDF is password-protected. Please enter the PDF password to unlock it in memory.');
    err.code = 'PDF_PASSWORD_REQUIRED';
    throw err;
  }

  // Parse all indirect objects (N G obj ... endobj)
  const objects = new Map();
  const objRe = /(\d+)\s+(\d+)\s+obj\b([\s\S]*?)endobj/g;
  let om;
  while ((om = objRe.exec(rawLatin1)) !== null) {
    const objNum = Number(om[1]);
    objects.set(objNum, { body: om[3], bodyStart: om.index + om[0].indexOf(om[3]) });
  }

  const warnings = [];
  if (isEncrypted && password) {
    warnings.push('Password was verified in memory and immediately cleared (never saved).');
  }

  // Decode stream helper
  const decodeObjectStream = async (objRec) => {
    const stIdx = objRec.body.indexOf('stream');
    if (stIdx < 0) return null;
    const dictPart = objRec.body.slice(0, stIdx);
    let dataStart = stIdx + 6;
    if (objRec.body[dataStart] === '\r' && objRec.body[dataStart + 1] === '\n') dataStart += 2;
    else if (objRec.body[dataStart] === '\n') dataStart += 1;
    const endIdx = objRec.body.lastIndexOf('endstream');
    if (endIdx <= dataStart) return null;

    const absStart = objRec.bodyStart + dataStart;
    const absEnd = objRec.bodyStart + endIdx;
    let streamBytes = bytes.subarray(absStart, absEnd);
    // Trim trailing EOL before endstream
    while (streamBytes.length > 0 && (streamBytes[streamBytes.length - 1] === 10 || streamBytes[streamBytes.length - 1] === 13)) {
      streamBytes = streamBytes.subarray(0, streamBytes.length - 1);
    }

    if (/\/FlateDecode\b/.test(dictPart)) {
      try {
        streamBytes = await _seInflateBytes(streamBytes);
      } catch {
        return null;
      }
    }
    return new TextDecoder('latin1').decode(streamBytes);
  };

  // Collect any ToUnicode CMap tables first
  const globalCmap = new Map();
  for (const [, objRec] of objects) {
    if (/beginbfchar|beginbfrange/.test(objRec.body) || /\/ToUnicode\b/.test(objRec.body)) {
      const txt = await decodeObjectStream(objRec);
      if (txt && /beginbfchar|beginbfrange/.test(txt)) {
        const parsed = _seParseToUnicodeCMap(txt);
        for (const [k, v] of parsed) globalCmap.set(k, v);
      }
    }
  }

  // Locate Page objects (/Type /Page, excluding /Pages)
  const pageObjects = [];
  for (const [objNum, objRec] of objects) {
    if (/\/Type\s*\/Page\b(?!s)/.test(objRec.body)) {
      pageObjects.push({ objNum, objRec });
    }
  }

  // Fallback: if no explicit /Type /Page found (e.g. minimal PDF), inspect all streams with BT..ET
  const rows = [];
  const scannedPages = [];
  let rowCounter = 0;

  if (pageObjects.length > 0) {
    for (let pIdx = 0; pIdx < pageObjects.length; pIdx += 1) {
      const pageNum = pIdx + 1;
      if (typeof onProgress === 'function') {
        onProgress({ stage: 'extracting', current: pageNum, total: pageObjects.length, message: `Extracting PDF page ${pageNum} of ${pageObjects.length}…` });
      }
      const { objRec } = pageObjects[pIdx];
      const contentRefs = [];
      const arrMatch = objRec.body.match(/\/Contents\s*\[([\s\S]*?)\]/);
      if (arrMatch) {
        const refRe = /(\d+)\s+\d+\s+R/g;
        let rm;
        while ((rm = refRe.exec(arrMatch[1])) !== null) contentRefs.push(Number(rm[1]));
      } else {
        const singleMatch = objRec.body.match(/\/Contents\s+(\d+)\s+\d+\s+R/);
        if (singleMatch) contentRefs.push(Number(singleMatch[1]));
      }

      let pageTextLen = 0;
      const pageLines = [];
      for (const refId of contentRefs) {
        const streamObj = objects.get(refId);
        if (!streamObj) continue;
        const decoded = await decodeObjectStream(streamObj);
        if (!decoded) continue;
        const lines = _seExtractLinesFromPdfContent(decoded, globalCmap);
        for (const cells of lines) {
          pageLines.push(cells);
          pageTextLen += cells.join(' ').length;
        }
      }

      const hasImages = /\/XObject\b|\/Image\b/.test(objRec.body);
      if (pageTextLen < 20 && (hasImages || contentRefs.length === 0)) {
        scannedPages.push(pageNum);
        if (typeof localOcrFn === 'function') {
          try {
            const ocrLines = await localOcrFn({ pageNum, arrayBuffer });
            for (const line of ocrLines || []) {
              const cells = Array.isArray(line) ? line : [String(line)];
              if (cells.some((c) => c.trim())) {
                rowCounter += 1;
                rows.push({ cells, sourcePage: pageNum, sourceRowIndex: rowCounter, fromOcr: true });
              }
            }
          } catch (ocrErr) {
            warnings.push(`Local OCR failed on page ${pageNum}: ${ocrErr.message || 'device limit reached'}. Remaining pages preserved.`);
          }
        }
      } else {
        for (const cells of pageLines) {
          rowCounter += 1;
          rows.push({ cells, sourcePage: pageNum, sourceRowIndex: rowCounter });
        }
      }

      if (pIdx % 3 === 2) await _seYield();
    }
  } else {
    // Direct stream scan fallback
    for (const [, objRec] of objects) {
      const decoded = await decodeObjectStream(objRec);
      if (!decoded || !decoded.includes('BT')) continue;
      const lines = _seExtractLinesFromPdfContent(decoded, globalCmap);
      for (const cells of lines) {
        rowCounter += 1;
        rows.push({ cells, sourcePage: 1, sourceRowIndex: rowCounter });
      }
    }
  }

  if (scannedPages.length > 0 && typeof localOcrFn !== 'function') {
    warnings.push(
      `Scanned/image-only content detected on page(s) ${scannedPages.join(', ')}. Local OCR is unavailable on this browser — download a text-based PDF, CSV, or XLSX from netbanking for complete extraction.`
    );
  }
  if (isEncrypted && rows.length === 0) {
    warnings.push(
      'Encrypted PDF streams could not be decoded locally (AES-256/strong encryption). Please export an unlocked PDF, CSV, or XLSX from your bank portal.'
    );
  }

  return {
    rows,
    pageCount: Math.max(1, pageObjects.length),
    warnings,
    scannedPages,
    sheetNames: ['PDF'],
    selectedSheet: 'PDF',
  };
}

// ---------- Automatic Column Mapping & Opening/Closing Balance Detection ----------

const COLUMN_PATTERNS = {
  date: [/^(txn|transaction|tran|posting|post|book)?\s*date$/i, /^date\b/i, /^dt$/i],
  value_date: [/^val(ue)?\s*date$/i, /^value\s*dt$/i],
  description: [
    /^(narration|description|particulars|remarks|details|transaction\s*details|txn\s*details|memo|merchant)$/i,
    /narration|particulars|description|remarks/i,
  ],
  reference: [
    /^(chq\.?\/?ref\.?\s*no\.?|ref\.?\s*no\.?|reference|utr|cheque\s*no\.?|txn\s*id|transaction\s*id|rrn|inst\.?\s*no\.?)$/i,
    /ref|utr|chq|cheque/i,
  ],
  debit: [/^(withdrawal(\s*amt\.?)?|debit(\s*amt\.?)?|dr\.?|withdrawals|spent|outflow|paid\s*out)$/i, /withdrawal|debit/i],
  credit: [/^(deposit(\s*amt\.?)?|credit(\s*amt\.?)?|cr\.?|deposits|received|inflow|paid\s*in)$/i, /deposit|credit/i],
  amount: [/^(amount|amt\.?|txn\s*amount|transaction\s*amount|value|inr)$/i, /\bamount\b/i],
  dr_cr: [/^(dr\s*\/?\s*cr|cr\s*\/?\s*dr|type|indicator|txn\s*type|d\/c)$/i],
  balance: [/^(closing\s*balance|balance|running\s*balance|avail(able)?\s*balance|bal\.?)$/i, /balance/i],
};

function _seMatchColumnField(headerCell) {
  const clean = String(headerCell || '').replace(/\s+/g, ' ').trim();
  if (!clean) return null;
  for (const [field, patterns] of Object.entries(COLUMN_PATTERNS)) {
    for (const re of patterns) {
      if (re.test(clean)) return field;
    }
  }
  return null;
}

/**
 * Finds the best header row in the first 35 rows and builds an automatic column mapping.
 */
export function detectColumnMapping(extractedRows) {
  let bestRowIdx = -1;
  let bestScore = 0;
  let bestMapping = {};

  const scanLimit = Math.min(extractedRows.length, 35);
  for (let i = 0; i < scanLimit; i += 1) {
    const cells = extractedRows[i].cells || [];
    if (cells.length < 2) continue;
    const mapping = {};
    let score = 0;
    for (let c = 0; c < cells.length; c += 1) {
      const field = _seMatchColumnField(cells[c]);
      if (field && mapping[field] === undefined) {
        mapping[field] = c;
        score += field === 'date' || field === 'description' ? 3 : 2;
      }
    }
    const hasAmount = mapping.debit !== undefined || mapping.credit !== undefined || mapping.amount !== undefined;
    if (mapping.date !== undefined && hasAmount && score > bestScore) {
      bestScore = score;
      bestRowIdx = i;
      bestMapping = mapping;
    }
  }

  const headerCells = bestRowIdx >= 0 ? extractedRows[bestRowIdx].cells : extractedRows[0]?.cells || [];
  const dataStartIndex = bestRowIdx >= 0 ? bestRowIdx + 1 : 0;
  const needsManualMapping = bestRowIdx < 0 || bestMapping.date === undefined || (
    bestMapping.debit === undefined && bestMapping.credit === undefined && bestMapping.amount === undefined
  );

  return {
    headerRowIndex: bestRowIdx,
    headerCells,
    dataStartIndex,
    columnMapping: bestMapping,
    needsManualMapping,
  };
}

/**
 * Detects statement opening and closing balances from preamble/footer rows if explicitly labelled.
 * Never invents values when absent.
 */
export function extractStatementBalances(extractedRows) {
  let openingBalanceRaw = null;
  let closingBalanceRaw = null;
  const amtRe = /(?:₹|rs\.?|inr)?\s*(-?\d[\d,]*\.\d{1,2}|-?\d[\d,]+)\s*(cr|dr)?/i;

  for (const row of extractedRows) {
    const line = (row.cells || []).join(' ').trim();
    if (!line) continue;
    if (openingBalanceRaw === null && /\b(opening|brought\s*forward|b\/f)\s*bal(ance)?\b/i.test(line)) {
      const after = line.split(/bal(?:ance)?/i).slice(1).join(' ');
      const m = after.match(amtRe);
      if (m) openingBalanceRaw = { amountStr: m[1], indicator: (m[2] || '').toLowerCase() };
    }
    if (/\b(closing|carried\s*forward|ending)\s*bal(ance)?\b/i.test(line)) {
      const after = line.split(/bal(?:ance)?/i).slice(1).join(' ');
      const m = after.match(amtRe);
      if (m) closingBalanceRaw = { amountStr: m[1], indicator: (m[2] || '').toLowerCase() };
    }
  }

  return { openingBalanceRaw, closingBalanceRaw };
}

/**
 * Main Module 2 Extraction Entrypoint.
 */

// ---------- Screenshot Image Extraction (JPG / PNG — Local OCR Hook or Pasted Device Text) ----------

export async function extractImageScreenshotRows(
  arrayBuffer,
  { fileExt = 'png', localOcrFn = null, manualOcrText = '', onProgress = null } = {}
) {
  if (typeof onProgress === 'function') {
    onProgress({ stage: 'extracting', current: 0, total: 1, message: `Inspecting ${fileExt.toUpperCase()} screenshot locally…` });
  }
  const rows = [];
  const warnings = [];
  let ocrText = String(manualOcrText || '').trim();

  if (!ocrText && typeof localOcrFn === 'function') {
    try {
      const ocrLines = await localOcrFn({ pageNum: 1, arrayBuffer, fileExt });
      if (typeof ocrLines === 'string') {
        ocrText = ocrLines.trim();
      } else if (Array.isArray(ocrLines)) {
        ocrText = ocrLines
          .map((l) => (Array.isArray(l) ? l.join(' ') : String(l || '')))
          .filter((s) => s.trim())
          .join('\n');
      }
    } catch (ocrErr) {
      warnings.push(`Local OCR failed on screenshot: ${ocrErr.message || 'device limit reached'}. You can still paste text from your phone below.`);
    }
  }

  if (ocrText) {
    const lines = ocrText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
    lines.forEach((line, idx) => {
      rows.push({ cells: [line], sourcePage: 1, sourceRowIndex: idx + 1, fromOcr: true });
    });
  } else {
    warnings.push(
      'Screenshot uploaded locally. Because offline browsers do not include built-in OCR, copy text from the screenshot on your phone (e.g. Google Lens / Select Text) and paste it below to extract transactions.'
    );
  }

  return {
    rows,
    pageCount: 1,
    warnings,
    scannedPages: ocrText ? [] : [1],
    sheetNames: ['Screenshot'],
    selectedSheet: 'Screenshot',
    isImageScreenshot: true,
    rawOcrText: ocrText,
  };
}

export async function extractStatementFile({
  fileExt,
  arrayBuffer,
  password = '',
  sheetName = null,
  localOcrFn = null,
  customOcrProvider = null,
  pdfjsLibOverride = null,
  signal = null,
  manualOcrText = '',
  onProgress = null,
}) {
  if (typeof onProgress === 'function') {
    onProgress({ stage: 'extracting', current: 0, total: 1, message: `Reading ${String(fileExt || '').toUpperCase()} statement…` });
  }

  let extracted;
  const ext = String(fileExt || '').toLowerCase();
  if (ext === 'csv') {
    extracted = extractCsvRows(arrayBuffer);
  } else if (ext === 'xlsx') {
    extracted = await extractXlsxRows(arrayBuffer, { sheetName });
  } else if (ext === 'xls') {
    extracted = extractXlsRows(arrayBuffer);
  } else if (ext === 'pdf') {
    const pdfJsResult = await extractPdfWithLocalPdfJs(arrayBuffer, {
      password,
      pdfjsLibOverride,
      customOcrProvider,
      signal,
      onProgress,
    });
    extracted = pdfJsResult || (await extractPdfRows(arrayBuffer, { password, localOcrFn, onProgress }));
  } else if (ext === 'jpg' || ext === 'jpeg' || ext === 'png') {
    extracted = await extractImageScreenshotRows(arrayBuffer, { fileExt: ext, localOcrFn, manualOcrText, onProgress });
  } else {
    throw new Error(`Unsupported statement extension ".${ext}".`);
  }

  const mappingInfo = detectColumnMapping(extracted.rows);
  const balances = extractStatementBalances(extracted.rows);

  return {
    ...extracted,
    ...mappingInfo,
    ...balances,
  };
}

import { nowIsoUtc } from '../utils/date.js';
import { scoreDuplicateCandidate } from './statementReconciliationService.js';

/**
 * Smart Statement Import — Module 6: Idempotent Ledger Integration Service.
 *
 * Strictly commits ONLY user-approved (`status === 'approved'`) staged transactions
 * through the existing `TransactionService.createTransaction` — never bypassing
 * validation, split reconciliation, or double-entry ledger postings, and never
 * creating a separate ledger.
 *
 * Guarantees:
 * - Pre-commit duplicate recheck against live `transactions` before each commit.
 * - Idempotency via `staged_transactions.ledger_transaction_id` AND `transactions.idempotency_key`.
 * - Partial failure isolation & safe retry without duplicating already-committed rows.
 * - Preserves original statement narration in `notes` and UTR in `reference_no`.
 * - Maintains bidirectional import-to-ledger links (`import_batch_id`, `ledger_transaction_id`).
 */

export class StatementLedgerCommitService {
  constructor(db, repos, services) {
    this.db = db;
    this.repos = repos;
    this.services = services;
    this._commitInFlight = false;
  }

  get isCommitting() {
    return this._commitInFlight;
  }

  /**
   * Commits all `approved` (or explicitly specified `retryFailed`) staged rows in a batch
   * into the existing VittaMitra ledger via `TransactionService.createTransaction`.
   */
  async commitApprovedBatch(batchId, { includeFailedRetry = false, onProgress = null } = {}) {
    if (this._commitInFlight) {
      throw new Error('A statement import commit is already in progress.');
    }
    this._commitInFlight = true;

    try {
      const batch = await this.repos.statementImport.getBatchById(batchId);
      if (!batch || batch.deleted_at) {
        throw new Error('Statement import batch not found.');
      }

      const [allStaged, existingLedger, batchMatches] = await Promise.all([
        this.db.table('staged_transactions').toArray(),
        this.db.table('transactions').toArray(),
        this.db.table('reconciliation_matches').toArray(),
      ]);

      const targetRows = allStaged
        .filter((r) => {
          if (r.batch_id !== batchId || r.deleted_at) return false;
          if (r.status === 'approved') return true;
          if (includeFailedRetry && r.status === 'failed') return true;
          return false;
        })
        .sort((a, b) => (a.source_page - b.source_page) || (a.source_row_index - b.source_row_index));

      if (targetRows.length === 0) {
        throw new Error('No approved transactions found to import. Approve at least one row first.');
      }

      const activeLedger = existingLedger.filter((tx) => !tx.deleted_at);
      const ledgerByIdempotency = new Map();
      for (const tx of activeLedger) {
        if (tx.idempotency_key) ledgerByIdempotency.set(tx.idempotency_key, tx.id);
      }

      // Rows where user explicitly rejected a duplicate match during review bypass pre-commit duplicate block
      const userRejectedDupStagedIds = new Set(
        batchMatches
          .filter(
            (m) =>
              m.batch_id === batchId &&
              !m.deleted_at &&
              m.resolution === 'rejected' &&
              (m.match_type === 'exact_duplicate' ||
                m.match_type === 'probable_duplicate' ||
                m.match_type === 'cross_screenshot_duplicate')
          )
          .map((m) => m.staged_tx_id)
      );

      let importedCount = 0;
      let skippedAlreadyImported = 0;
      let skippedDuplicateRecheck = 0;
      const failedRows = [];
      const importedTxIds = [];
      const consumedLedgerIds = new Set();

      for (let i = 0; i < targetRows.length; i += 1) {
        const row = targetRows[i];
        if (typeof onProgress === 'function') {
          onProgress({
            current: i + 1,
            total: targetRows.length,
            message: `Importing transaction ${i + 1} of ${targetRows.length}…`,
          });
        }

        // 1. Idempotency guard: already linked or idempotency_key already present in live ledger
        if (row.ledger_transaction_id || (row.idempotency_key && ledgerByIdempotency.has(row.idempotency_key))) {
          const existingId = row.ledger_transaction_id || ledgerByIdempotency.get(row.idempotency_key);
          skippedAlreadyImported += 1;
          if (row.status !== 'imported' || !row.ledger_transaction_id) {
            await this.db.table('staged_transactions').put({
              ...row,
              status: 'imported',
              ledger_transaction_id: existingId,
              import_error: null,
              updated_at: nowIsoUtc(),
              version: (row.version || 1) + 1,
            });
          }
          continue;
        }

        // 2. Pre-commit duplicate recheck against live ledger (unless user explicitly rejected match)
        if (!userRejectedDupStagedIds.has(row.id)) {
          const liveDup = activeLedger.find((tx) => {
            if (consumedLedgerIds.has(tx.id) || tx.type === 'BALANCE_ADJUSTMENT') return false;
            const scored = scoreDuplicateCandidate(row, tx, { isLedger: true });
            return scored.matchType === 'exact_duplicate';
          });
          if (liveDup) {
            consumedLedgerIds.add(liveDup.id);
            skippedDuplicateRecheck += 1;
            await this.db.table('staged_transactions').put({
              ...row,
              status: 'duplicate',
              duplicate_reason: `Pre-commit check found exact duplicate in ledger (${liveDup.date_key})`,
              updated_at: nowIsoUtc(),
              version: (row.version || 1) + 1,
            });
            continue;
          }
        }

        // 3. Commit exclusively through existing TransactionService.createTransaction
        try {
          const parsedSplits = row.splits_json
            ? (() => {
                try {
                  const arr = JSON.parse(row.splits_json);
                  return Array.isArray(arr) ? arr : [];
                } catch {
                  return [];
                }
              })()
            : [];

          const noteParts = [];
          if (row.notes) noteParts.push(row.notes);
          if (row.raw_narration) noteParts.push(`Statement: ${row.raw_narration}`);
          if (row.upi_id) noteParts.push(`UPI: ${row.upi_id}`);

          const createdTx = await this.services.transactions.createTransaction({
            type: row.tx_type || 'expense',
            amount_paise: Number(row.amount_paise),
            date: row.date_key,
            category_id:
              row.tx_type === 'transfer' || parsedSplits.length > 0
                ? null
                : row.subcategory_id || row.category_id || null,
            account_id: row.account_id,
            to_account_id: row.tx_type === 'transfer' ? row.to_account_id || null : null,
            description: row.description || row.merchant || row.raw_narration?.slice(0, 80) || 'Statement Transaction',
            notes: noteParts.join(' · '),
            reference_no: row.transaction_reference || '',
            splits: parsedSplits,
          });

          // Stamp non-accounting provenance fields (`import_batch_id`, `idempotency_key`, `staged_tx_id`)
          const liveCreated = await this.db.table('transactions').get(createdTx.id);
          if (liveCreated) {
            await this.db.table('transactions').put({
              ...liveCreated,
              import_batch_id: batchId,
              idempotency_key: row.idempotency_key,
              staged_tx_id: row.id,
            });
            activeLedger.push({
              ...liveCreated,
              import_batch_id: batchId,
              idempotency_key: row.idempotency_key,
            });
          }

          if (row.idempotency_key) {
            ledgerByIdempotency.set(row.idempotency_key, createdTx.id);
          }

          await this.db.table('staged_transactions').put({
            ...row,
            status: 'imported',
            ledger_transaction_id: createdTx.id,
            import_error: null,
            updated_at: nowIsoUtc(),
            version: (row.version || 1) + 1,
          });

          importedCount += 1;
          importedTxIds.push(createdTx.id);
        } catch (err) {
          const errMsg = err?.message || 'Failed to create ledger transaction';
          failedRows.push({
            stagedTxId: row.id,
            description: row.description || row.merchant || row.raw_narration,
            amountPaise: row.amount_paise,
            error: errMsg,
          });
          await this.db.table('staged_transactions').put({
            ...row,
            status: 'failed',
            import_error: errMsg,
            updated_at: nowIsoUtc(),
            version: (row.version || 1) + 1,
          });
        }
      }

      // Compute updated batch status & counts
      const refreshedStaged = (await this.db.table('staged_transactions').toArray()).filter(
        (r) => r.batch_id === batchId && !r.deleted_at
      );
      const totalImportedInBatch = refreshedStaged.filter((r) => r.status === 'imported').length;
      const totalFailedInBatch = refreshedStaged.filter((r) => r.status === 'failed').length;
      const totalExcludedInBatch = refreshedStaged.filter((r) => r.status === 'excluded').length;

      let nextBatchStatus = batch.status;
      if (totalFailedInBatch > 0) nextBatchStatus = 'partially_imported';
      else if (totalImportedInBatch > 0) nextBatchStatus = 'imported';

      let prevSummary = {};
      if (batch.summary_json) {
        try {
          prevSummary = JSON.parse(batch.summary_json);
        } catch {
          prevSummary = {};
        }
      }
      const completionReport = {
        committedAt: nowIsoUtc(),
        importedCount,
        totalImportedInBatch,
        skippedAlreadyImported,
        skippedDuplicateRecheck,
        failedCount: failedRows.length,
        failedRows,
      };

      const updatedBatch = {
        ...batch,
        status: nextBatchStatus,
        imported_count: totalImportedInBatch,
        skipped_count: totalExcludedInBatch + skippedDuplicateRecheck,
        summary_json: JSON.stringify({ ...prevSummary, lastCommitReport: completionReport }),
        updated_at: nowIsoUtc(),
        version: (batch.version || 1) + 1,
      };
      await this.db.table('import_batches').put(updatedBatch);

      return {
        batch: updatedBatch,
        importedCount,
        totalImportedInBatch,
        skippedAlreadyImported,
        skippedDuplicateRecheck,
        failedCount: failedRows.length,
        failedRows,
        importedTxIds,
        completionReport,
      };
    } finally {
      this._commitInFlight = false;
    }
  }

  /**
   * Rolls back all ledger transactions created by a statement batch using the existing
   * `ImportExportService.rollbackImportBatch` and resets staged rows cleanly to `'approved'`
   * so the user can re-review or delete the batch.
   */
  async rollbackStatementBatch(batchId) {
    if (!this.services.importExport) {
      throw new Error('ImportExportService is required for batch rollback.');
    }
    const rbRes = await this.services.importExport.rollbackImportBatch(batchId);
    const staged = (await this.db.table('staged_transactions').toArray()).filter(
      (r) => r.batch_id === batchId && !r.deleted_at && r.status === 'imported'
    );
    const now = nowIsoUtc();
    for (const row of staged) {
      await this.db.table('staged_transactions').put({
        ...row,
        status: 'approved',
        ledger_transaction_id: null,
        updated_at: now,
        version: (row.version || 1) + 1,
      });
    }
    const batch = await this.db.table('import_batches').get(batchId);
    if (batch) {
      await this.db.table('import_batches').put({
        ...batch,
        status: 'review_ready',
        imported_count: 0,
        updated_at: now,
        version: (batch.version || 1) + 1,
      });
    }
    return { ...rbRes, resetStagedCount: staged.length };
  }
}

import { excelSerialToLocalDateTime } from '../../vendor/xlsx-lite.js';
import { generateUUID } from '../utils/uuid.js';
import { nowIsoUtc } from '../utils/date.js';
import { normalizeMerchantKey } from '../db/repositories/statementImportRepository.js';
import { computeSha256Hex } from './statementUploadService.js';
import { extractStatementFile } from './statementExtractionService.js';
import { createLocalOcrSession } from './localOcrEngine.js';
import { parseUpiScreenshotText } from './upiScreenshotParser.js';

/**
 * Smart Statement Import — Module 2: Normalisation & Staging Engine.
 *
 * Standardises extracted rows into `staged_transactions` records:
 * - Transaction date & Value date (Indian DD/MM/YYYY, DD-MMM-YYYY, ISO, Excel serial)
 * - Original narration ALWAYS preserved verbatim in `raw_narration`
 * - Cleaned description & extracted Merchant + normalized_merchant
 * - Integer-paise debit_paise, credit_paise, amount_paise (handles Indian commas, Cr/Dr, parentheses)
 * - Transaction reference / UTR / RRN / Cheque number
 * - Baseline transaction type (never invents missing accounting info)
 * - Source page & row references preserved
 * - Deterministic row_fingerprint (with per-occurrence index so identical same-day txns stay distinct)
 * - Idempotency key (`stmt:${batchId}:${rowFingerprint}`)
 *
 * Strictly NO Module 3 personal categorisation intelligence or Module 4 ledger reconciliation yet.
 */

const _SN_MONTHS = {
  jan: 1,
  feb: 2,
  mar: 3,
  apr: 4,
  may: 5,
  jun: 6,
  jul: 7,
  aug: 8,
  sep: 9,
  sept: 9,
  oct: 10,
  nov: 11,
  dec: 12,
};

function _snPad2(n) {
  return String(n).padStart(2, '0');
}

function _snYield() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

function _snValidYmd(y, m, d) {
  if (y < 1990 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) return null;
  const dt = new Date(y, m - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
  return `${y}-${_snPad2(m)}-${_snPad2(d)}`;
}

/**
 * Parses Indian bank/CC/UPI statement date strings or Excel serials into YYYY-MM-DD.
 */
export function parseStatementDate(raw) {
  if (raw === null || raw === undefined) return null;
  const str = String(raw).trim();
  if (!str) return null;

  // Excel serial number (e.g. 46113)
  if (/^\d{5}(?:\.\d+)?$/.test(str)) {
    const num = Number(str);
    if (num >= 30000 && num <= 80000) {
      const iso = excelSerialToLocalDateTime(num);
      if (iso && /^\d{4}-\d{2}-\d{2}/.test(iso)) return iso.slice(0, 10);
    }
  }

  // ISO YYYY-MM-DD or YYYY/MM/DD (with optional time)
  let m = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:\b|T|\s)/);
  if (m) return _snValidYmd(Number(m[1]), Number(m[2]), Number(m[3]));

  // DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY (Indian standard)
  m = str.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})(?:\b|\s)/);
  if (m) {
    const d = Number(m[1]);
    const mo = Number(m[2]);
    let y = Number(m[3]);
    if (y < 100) y += y >= 70 ? 1900 : 2000;
    return _snValidYmd(y, mo, d);
  }

  // DD-MMM-YYYY or DD MMM YYYY or DD-MMM-YY (e.g. 02-Apr-2026, 02 Apr 26)
  m = str.match(/^(\d{1,2})[\s/-]+([A-Za-z]{3,9})[\s,/-]+(\d{2,4})/);
  if (m) {
    const d = Number(m[1]);
    const mo = _SN_MONTHS[m[2].toLowerCase().slice(0, 3)];
    let y = Number(m[3]);
    if (y < 100) y += y >= 70 ? 1900 : 2000;
    if (mo) return _snValidYmd(y, mo, d);
  }

  // MMM DD, YYYY (e.g. Apr 02, 2026)
  m = str.match(/^([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})/);
  if (m) {
    const mo = _SN_MONTHS[m[1].toLowerCase().slice(0, 3)];
    if (mo) return _snValidYmd(Number(m[3]), mo, Number(m[2]));
  }

  return null;
}

/**
 * Parses monetary amounts in Indian comma format, currency prefixes, parentheses, and Cr/Dr suffixes.
 * Returns { paise (non-negative integer), sign ('debit'|'credit'|null) } or null if not a valid amount.
 */
export function parseStatementAmount(raw) {
  if (raw === null || raw === undefined) return null;
  let str = String(raw).trim();
  if (!str || str === '-' || str === '--' || /^n\/?a$/i.test(str)) return null;

  let sign = null;
  if (/\b(cr\.?|credit)\s*$/i.test(str)) {
    sign = 'credit';
    str = str.replace(/\b(cr\.?|credit)\s*$/i, '').trim();
  } else if (/\b(dr\.?|debit)\s*$/i.test(str)) {
    sign = 'debit';
    str = str.replace(/\b(dr\.?|debit)\s*$/i, '').trim();
  }

  const isParenNeg = /^\(.*\)$/.test(str);
  if (isParenNeg) {
    str = str.slice(1, -1).trim();
    if (!sign) sign = 'debit';
  }

  str = str.replace(/^(?:₹|rs\.?|inr)\s*/i, '').replace(/,/g, '').replace(/\s+/g, '');
  if (str.startsWith('-')) {
    if (!sign) sign = 'debit';
    str = str.slice(1);
  } else if (str.startsWith('+')) {
    if (!sign) sign = 'credit';
    str = str.slice(1);
  }

  if (!/^\d+(?:\.\d{1,4})?$/.test(str)) return null;
  const num = Number(str);
  if (!Number.isFinite(num)) return null;
  return { paise: Math.round(num * 100), sign };
}

/**
 * Extracts UTR / UPI RRN / NEFT / IMPS / Cheque reference from explicit column or narration.
 */
export function extractTransactionReference(explicitRef, narration) {
  const cleanExplicit = String(explicitRef || '').trim();
  if (cleanExplicit && cleanExplicit !== '-' && cleanExplicit !== '0' && cleanExplicit !== '000000000000') {
    return cleanExplicit.slice(0, 64);
  }
  const text = String(narration || '');
  // UPI 12-digit RRN (e.g. UPI/DR/409812345678/SWIGGY or UPI-SWIGGY-409812345678)
  const upiRrn = text.match(/(?:upi[/-](?:dr|cr|p2m|p2a|p2p)?[/-]?|rrn[:\s-]*|utr[:\s-]*|ref[:\s-]*)(\d{12})\b/i);
  if (upiRrn) return upiRrn[1];
  // NEFT / RTGS / IMPS alphanumeric reference
  const bankRef = text.match(/\b((?:HDFC|ICIC|SBIN|UTIB|KKBK|IDFB|YESB|INDB|CNRB)[A-Z0-9]{10,18})\b/);
  if (bankRef) return bankRef[1];
  const any12 = text.match(/\b(\d{12})\b/);
  if (any12) return any12[1];
  return '';
}

/**
 * Extracts a clean display description and merchant name from Indian bank/CC/UPI narrations
 * while NEVER discarding `raw_narration`.
 */
export function extractMerchantAndDescription(rawNarration) {
  const raw = String(rawNarration || '').replace(/\s+/g, ' ').trim();
  if (!raw) return { merchant: '', normalizedMerchant: '', description: '' };

  let merchant = '';

  // Pattern 1: UPI/DR/123456789012/MERCHANT NAME/BANK/vpa...  OR UPI/P2M/123.../MERCHANT
  const upiSlash = raw.match(/^UPI\/(?:DR|CR|P2M|P2A|P2P)\/\d+\/([^/]+)/i);
  if (upiSlash) {
    merchant = upiSlash[1].trim();
  }

  // Pattern 2: UPI-MERCHANT NAME-vpa@bank-ref...
  if (!merchant) {
    const upiDash = raw.match(/^UPI-([^-]+)-/i);
    if (upiDash && !/^\d{6,}$/.test(upiDash[1].trim())) {
      merchant = upiDash[1].trim();
    }
  }

  // Pattern 3: NEFT / IMPS / RTGS (e.g. NEFT CR-HDFC0001234-ACME TECHNOLOGIES-REF)
  if (!merchant) {
    const neft = raw.match(/^(?:NEFT|IMPS|RTGS)[\s/-]+(?:CR|DR|IN|OUT)?[\s/-]*(?:[A-Z0-9]{6,18}[\s/-]+)?([A-Za-z][A-Za-z0-9 &.'-]{2,40})/i);
    if (neft) merchant = neft[1].trim();
  }

  // Pattern 4: POS / ECOM / CARD (e.g. POS 4321XXXXXX1234 SWIGGY BANGALORE)
  if (!merchant) {
    const pos = raw.match(/^(?:POS|ECOM|DEBIT\s*CARD|CARD)\s+[0-9X*]{4,20}\s+([A-Za-z][A-Za-z0-9 &.'-]{2,40})/i);
    if (pos) merchant = pos[1].trim();
  }

  // Fallback: strip leading transaction prefixes and trailing numeric refs
  if (!merchant) {
    merchant = raw
      .replace(/^(?:UPI|IMPS|NEFT|RTGS|POS|ATM|BIL|ACH|ECS|NACH|MMT)[/\s-]+/i, '')
      .replace(/\b\d{9,}\b/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 48);
  }

  // Clean trailing punctuation
  merchant = merchant.replace(/[-/:*]+$/, '').trim();
  const normalizedMerchant = normalizeMerchantKey(merchant);
  const description = merchant || raw.slice(0, 80);

  return { merchant, normalizedMerchant, description };
}

/**
 * Determines baseline transaction type from debit/credit direction, account type, and explicit narration markers.
 * Never invents missing accounting details.
 */
function _snInferBaselineTxType({ debitPaise, creditPaise, accountType, rawNarration }) {
  const narr = String(rawNarration || '').toLowerCase();
  const isCreditCard = accountType === 'credit_card';

  if (/\b(atm\s*(wdl|cash|withdrawal)|cash\s*withdrawal)\b/i.test(narr) && debitPaise > 0) {
    return 'transfer';
  }
  if (/\b(sms\s*alert|annual\s*fee|joining\s*fee|service\s*charge|bank\s*charge|late\s*fee|markup\s*fee|gst\s*on)\b/i.test(narr) && debitPaise > 0) {
    return 'expense';
  }
  if (/\b(refund|reversal|cashback|chargeback)\b/i.test(narr) && creditPaise > 0) {
    return 'income';
  }
  if (isCreditCard) {
    if (creditPaise > 0 && /\b(payment|bbps|neft|imps|upi|billdesk|autopay|thank\s*you)\b/i.test(narr)) {
      return 'transfer';
    }
    return debitPaise > 0 ? 'expense' : 'income';
  }
  if (debitPaise > 0 && /\b(credit\s*card\s*(bill|payment)|cred\s*club|cc\s*bill)\b/i.test(narr)) {
    return 'transfer';
  }
  if (debitPaise > 0) return 'expense';
  if (creditPaise > 0) return 'income';
  return 'expense';
}

/**
 * Fallback parser for unstructured PDF lines where columnMapping wasn't tabular
 * (e.g. a line starting with a date and ending with 1-2 numeric amounts).
 */
const _SN_NON_TX_HEADER_RE =
  /\b(credit\s*limit|available\s*credit|cash\s*limit|statement\s*period|statement\s*date|payment\s*due|total\s*amount\s*due|minimum\s*amount\s*due|opening\s*balance|closing\s*balance|reward\s*points|account\s*summary|credit\s*summary|billing\s*cycle)\b/i;

function _snParseUnstructuredPdfRow(cells) {
  const joined = (cells || []).join(' ').trim();
  if (!joined || _SN_NON_TX_HEADER_RE.test(joined)) return null;
  const dateMatch = joined.match(/^(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}|\d{1,2}[\s/-]+[A-Za-z]{3,9}[\s,/-]+\d{2,4}|\d{4}[-/]\d{1,2}[-/]\d{1,2})\b/);
  if (!dateMatch) return null;
  const afterDate = joined.slice(dateMatch[0].length).trim();
  // Skip statement date-range header lines like "13/10/2026 To 12/11/2026 ... 4,00,000.00"
  if (/^(?:to|–|-)\s*\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}/i.test(afterDate)) return null;
  const dateKey = parseStatementDate(dateMatch[1]);
  if (!dateKey) return null;

  const rest = joined.slice(dateMatch[0].length).trim();
  // Match monetary tokens (must contain decimal or comma, or follow Dr/Cr)
  const amtMatches = [...rest.matchAll(/(?:₹|rs\.?|inr)?\s*(\d{1,3}(?:,\d{2,3})*\.\d{2}|\d+\.\d{2})\s*(cr|dr)?\b/gi)];
  if (amtMatches.length === 0) return null;

  // If 2+ amounts on line, usually last is running balance and preceding is txn amount (or debit/credit)
  const txnMatch = amtMatches.length >= 2 ? amtMatches[amtMatches.length - 2] : amtMatches[0];
  const parsedAmt = parseStatementAmount(`${txnMatch[1]} ${txnMatch[2] || ''}`);
  if (!parsedAmt || parsedAmt.paise <= 0) return null;

  const narrEnd = txnMatch.index ?? rest.length;
  const rawNarration = rest.slice(0, narrEnd).trim() || rest;
  const isCredit = parsedAmt.sign === 'credit' || /\b(cr|credit|salary|interest|refund|deposit)\b/i.test(rawNarration);

  return {
    dateKey,
    valueDateKey: null,
    rawNarration,
    explicitRef: '',
    debitPaise: isCredit ? 0 : parsedAmt.paise,
    creditPaise: isCredit ? parsedAmt.paise : 0,
  };
}

/**
 * Normalises extracted rows using either the auto-detected or user-overridden column mapping.
 */

/**
 * Parses a single-transaction UPI / payment confirmation screenshot where Merchant,
 * Amount, Date, and UPI Transaction ID appear across separate lines.
 */
function _snParseSingleTransactionScreenshot(extractedRows) {
  const lines = (extractedRows || [])
    .map((r) => (r.cells || []).join(' ').trim())
    .filter(Boolean);
  if (lines.length === 0) return null;
  const fullText = lines.join(' | ');

  // Extract amount (prefer explicit ₹ / Rs. / INR amount)
  let parsedAmt = null;
  for (const line of lines) {
    const m = line.match(/(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)/i);
    if (m) {
      parsedAmt = parseStatementAmount(m[1]);
      if (parsedAmt && parsedAmt.paise > 0) break;
    }
  }
  if (!parsedAmt) {
    for (const line of lines) {
      if (/^\d{1,3}(?:,\d{2,3})*(?:\.\d{2})?$/.test(line)) {
        parsedAmt = parseStatementAmount(line);
        if (parsedAmt && parsedAmt.paise > 0) break;
      }
    }
  }
  if (!parsedAmt || parsedAmt.paise <= 0) return null;

  // Extract date from any line
  let dateKey = null;
  for (const line of lines) {
    const dm = line.match(/(\d{1,2}[\s/-]+[A-Za-z]{3,9}[\s,/-]+\d{2,4}|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}|\d{4}[-/]\d{1,2}[-/]\d{1,2}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})/);
    if (dm) {
      dateKey = parseStatementDate(dm[1]);
      if (dateKey) break;
    }
  }
  if (!dateKey) {
    dateKey = nowIsoUtc().slice(0, 10);
  }

  // Extract merchant (look for "Paid to X", "Received from X", "To: X", or first clean text line)
  let merchantLine = '';
  for (let i = 0; i < lines.length; i += 1) {
    const paidM = lines[i].match(/^(?:paid\s+to|sent\s+to|received\s+from|from|to)\s*[:\-]?\s*(.+)$/i);
    if (paidM && paidM[1].trim().length >= 2) {
      merchantLine = paidM[1].trim();
      break;
    }
    if (/^(?:paid\s+to|sent\s+to|received\s+from)$/i.test(lines[i]) && lines[i + 1]) {
      merchantLine = lines[i + 1].trim();
      break;
    }
  }
  if (!merchantLine) {
    merchantLine = lines.find((l) => !/^(?:₹|rs\.?|inr|\d|completed|success|upi\s*transaction|debited|credited)/i.test(l)) || lines[0];
  }

  const isCredit = /\b(received\s+from|credited|refund|cashback)\b/i.test(fullText);
  const explicitRef = extractTransactionReference('', fullText);

  return {
    dateKey,
    valueDateKey: null,
    rawNarration: fullText,
    merchantOverride: merchantLine.slice(0, 64),
    explicitRef,
    debitPaise: isCredit ? 0 : parsedAmt.paise,
    creditPaise: isCredit ? parsedAmt.paise : 0,
  };
}

export async function normaliseExtractedRows({
  batchId,
  account,
  extractedRows,
  dataStartIndex = 0,
  columnMapping = {},
  fileExt = '',
  onProgress = null,
}) {
  const stagedRows = [];
  const occurrenceCounter = new Map();
  const now = nowIsoUtc();
  let minDate = null;
  let maxDate = null;
  let skippedNonTxRows = 0;

  const useTabular =
    columnMapping.date !== undefined &&
    (columnMapping.debit !== undefined || columnMapping.credit !== undefined || columnMapping.amount !== undefined);

  const total = extractedRows.length;
  for (let i = dataStartIndex; i < total; i += 1) {
    const row = extractedRows[i];
    const cells = row.cells || [];
    if (cells.length === 0 || cells.every((c) => !String(c || '').trim())) continue;

    let dateKey = null;
    let valueDateKey = null;
    let rawNarration = '';
    let explicitRef = '';
    let debitPaise = 0;
    let creditPaise = 0;

    if (useTabular) {
      dateKey = parseStatementDate(cells[columnMapping.date]);
      if (!dateKey) {
        skippedNonTxRows += 1;
        continue;
      }
      if (columnMapping.value_date !== undefined) {
        valueDateKey = parseStatementDate(cells[columnMapping.value_date]);
      }
      rawNarration =
        columnMapping.description !== undefined
          ? String(cells[columnMapping.description] || '').trim()
          : cells
              .filter((_, idx) => idx !== columnMapping.date && idx !== columnMapping.debit && idx !== columnMapping.credit && idx !== columnMapping.amount && idx !== columnMapping.balance)
              .join(' ')
              .trim();
      explicitRef = columnMapping.reference !== undefined ? String(cells[columnMapping.reference] || '').trim() : '';

      if (columnMapping.debit !== undefined || columnMapping.credit !== undefined) {
        const dParsed = columnMapping.debit !== undefined ? parseStatementAmount(cells[columnMapping.debit]) : null;
        const cParsed = columnMapping.credit !== undefined ? parseStatementAmount(cells[columnMapping.credit]) : null;
        debitPaise = dParsed ? dParsed.paise : 0;
        creditPaise = cParsed ? cParsed.paise : 0;
      } else if (columnMapping.amount !== undefined) {
        const aParsed = parseStatementAmount(cells[columnMapping.amount]);
        if (aParsed && aParsed.paise > 0) {
          const drCrCell = columnMapping.dr_cr !== undefined ? String(cells[columnMapping.dr_cr] || '').trim().toLowerCase() : '';
          let dir = aParsed.sign;
          if (!dir && drCrCell) {
            if (/^(cr|credit|c|in|deposit|\+)/i.test(drCrCell)) dir = 'credit';
            else if (/^(dr|debit|d|out|withdrawal|-)/i.test(drCrCell)) dir = 'debit';
          }
          if (dir === 'credit') creditPaise = aParsed.paise;
          else debitPaise = aParsed.paise;
        }
      }
    } else if (fileExt === 'pdf' || fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png') {
      const parsed = _snParseUnstructuredPdfRow(cells);
      if (!parsed) {
        skippedNonTxRows += 1;
        continue;
      }
      ({ dateKey, valueDateKey, rawNarration, explicitRef, debitPaise, creditPaise } = parsed);
    } else {
      skippedNonTxRows += 1;
      continue;
    }

    const amountPaise = Math.max(debitPaise, creditPaise);
    if (amountPaise <= 0) {
      skippedNonTxRows += 1;
      continue;
    }

    if (!minDate || dateKey < minDate) minDate = dateKey;
    if (!maxDate || dateKey > maxDate) maxDate = dateKey;

    const transactionReference = extractTransactionReference(explicitRef, rawNarration);
    const { merchant, normalizedMerchant, description } = extractMerchantAndDescription(rawNarration);
    const txType = _snInferBaselineTxType({
      debitPaise,
      creditPaise,
      accountType: account?.type || 'bank_account',
      rawNarration,
    });

    // Disambiguate multiple legitimate identical transactions on the same date via occurrence index
    const baseKey = `${account?.id || ''}|${dateKey}|${debitPaise}|${creditPaise}|${transactionReference}|${rawNarration.toLowerCase()}`;
    const occIdx = (occurrenceCounter.get(baseKey) || 0) + 1;
    occurrenceCounter.set(baseKey, occIdx);

    const rowFingerprint = (await computeSha256Hex(new TextEncoder().encode(`${baseKey}|#${occIdx}`))).slice(0, 32);
    const idempotencyKey = `stmt:${batchId}:${rowFingerprint}`;

    stagedRows.push({
      id: generateUUID(),
      user_id: null,
      batch_id: batchId,
      source_row_index: row.sourceRowIndex || i + 1,
      source_page: row.sourcePage || 1,
      raw_narration: rawNarration, // NEVER discarded
      date_key: dateKey,
      value_date_key: valueDateKey || null,
      description,
      merchant,
      normalized_merchant: normalizedMerchant,
      debit_paise: debitPaise,
      credit_paise: creditPaise,
      amount_paise: amountPaise,
      transaction_reference: transactionReference,
      tx_type: txType,
      account_id: account?.id || null,
      to_account_id: null,
      category_id: null,
      subcategory_id: null,
      confidence_score: 0,
      categorisation_source: 'unclassified',
      splits_json: null,
      status: 'new',
      ledger_transaction_id: null,
      idempotency_key: idempotencyKey,
      row_fingerprint: rowFingerprint,
      notes: row.fromOcr ? 'Extracted via local OCR' : '',
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    });

    if (stagedRows.length % 200 === 0) {
      if (typeof onProgress === 'function') {
        onProgress({ stage: 'normalising', current: i, total, message: `Normalised ${stagedRows.length} transactions…` });
      }
      await _snYield();
    }
  }

  // Single-transaction payment screenshot fallback (when merchant/amount/date are on separate lines)
  if (stagedRows.length === 0 && (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png') && extractedRows.length > 0) {
    const single = _snParseSingleTransactionScreenshot(extractedRows);
    if (single) {
      const amountPaise = Math.max(single.debitPaise, single.creditPaise);
      const baseKey = `${account?.id || ''}|${single.dateKey}|${single.debitPaise}|${single.creditPaise}|${single.explicitRef}|${single.rawNarration.toLowerCase()}|#1`;
      const rowFingerprint = (await computeSha256Hex(new TextEncoder().encode(baseKey))).slice(0, 32);
      minDate = single.dateKey;
      maxDate = single.dateKey;
      stagedRows.push({
        id: generateUUID(),
        user_id: null,
        batch_id: batchId,
        source_row_index: 1,
        source_page: 1,
        raw_narration: single.rawNarration,
        date_key: single.dateKey,
        value_date_key: null,
        description: single.merchantOverride,
        merchant: single.merchantOverride,
        normalized_merchant: normalizeMerchantKey(single.merchantOverride),
        debit_paise: single.debitPaise,
        credit_paise: single.creditPaise,
        amount_paise: amountPaise,
        transaction_reference: single.explicitRef,
        tx_type: _snInferBaselineTxType({
          debitPaise: single.debitPaise,
          creditPaise: single.creditPaise,
          accountType: account?.type || 'bank_account',
          rawNarration: single.rawNarration,
        }),
        account_id: account?.id || null,
        to_account_id: null,
        category_id: null,
        subcategory_id: null,
        confidence_score: 0,
        categorisation_source: 'unclassified',
        splits_json: null,
        status: 'new',
        ledger_transaction_id: null,
        idempotency_key: `stmt:${batchId}:${rowFingerprint}`,
        row_fingerprint: rowFingerprint,
        notes: 'Extracted from transaction screenshot',
        created_at: now,
        updated_at: now,
        version: 1,
        deleted_at: null,
      });
    }
  }

  return {
    stagedRows,
    skippedNonTxRows,
    detectedPeriodStart: minDate,
    detectedPeriodEnd: maxDate,
  };
}

export class StatementNormalisationService {
  constructor(db, repos) {
    this.db = db;
    this.repos = repos;
  }

  /**
   * Runs full Module 2 extraction + normalisation for a confirmed batch and persists `staged_transactions`.
   */
  async extractAndStageBatch({
    batchId,
    arrayBuffer,
    password = '',
    sheetName = null,
    overrideMapping = null,
    overrideDataStartIndex = null,
    localOcrFn = null,
    manualOcrText = '',
    onProgress = null,
  }) {
    const batch = await this.repos.statementImport.getBatchById(batchId);
    if (!batch || batch.deleted_at) {
      throw new Error('Statement import batch not found.');
    }
    const account = batch.account_id ? await this.repos.accounts.getById(batch.account_id) : null;

    const extracted = await extractStatementFile({
      fileExt: batch.file_ext,
      arrayBuffer,
      password,
      sheetName,
      localOcrFn,
      manualOcrText,
      onProgress,
    });

    const activeMapping = overrideMapping || extracted.columnMapping;
    const activeDataStart = overrideDataStartIndex !== null ? overrideDataStartIndex : extracted.dataStartIndex;

    if (typeof onProgress === 'function') {
      onProgress({ stage: 'normalising', current: 0, total: extracted.rows.length, message: 'Normalising extracted rows…' });
    }

    const norm = await normaliseExtractedRows({
      batchId,
      account,
      extractedRows: extracted.rows,
      dataStartIndex: activeDataStart,
      columnMapping: activeMapping,
      fileExt: batch.file_ext,
      onProgress,
    });

    // Replace any previously staged (unimported) rows for this batch (e.g. after manual column remapping)
    const existingStaged = (await this.db.table('staged_transactions').toArray()).filter(
      (r) => r.batch_id === batchId && !r.deleted_at && !r.ledger_transaction_id
    );
    const now = nowIsoUtc();
    for (const oldRow of existingStaged) {
      await this.db.table('staged_transactions').put({ ...oldRow, deleted_at: now, updated_at: now });
    }

    // Chunked staging write to protect Android IndexedDB transactions
    const CHUNK = 250;
    for (let i = 0; i < norm.stagedRows.length; i += CHUNK) {
      await this.db.table('staged_transactions').bulkPut(norm.stagedRows.slice(i, i + CHUNK));
      await _snYield();
    }

    const openingPaise = extracted.openingBalanceRaw ? parseStatementAmount(extracted.openingBalanceRaw.amountStr)?.paise ?? null : null;
    const closingPaise = extracted.closingBalanceRaw ? parseStatementAmount(extracted.closingBalanceRaw.amountStr)?.paise ?? null : null;

    const summary = {
      pageCount: extracted.pageCount,
      rawRowCount: extracted.rows.length,
      extractedCount: norm.stagedRows.length,
      skippedNonTxRows: norm.skippedNonTxRows,
      scannedPages: extracted.scannedPages || [],
      warnings: extracted.warnings || [],
      headerCells: extracted.headerCells || [],
      columnMapping: activeMapping,
      needsManualMapping: Boolean(extracted.needsManualMapping && !overrideMapping),
      sheetNames: extracted.sheetNames || [],
      selectedSheet: extracted.selectedSheet || '',
    };

    const updatedBatch = {
      ...batch,
      status: norm.stagedRows.length > 0 ? 'extracted' : 'needs_mapping',
      row_count: norm.stagedRows.length,
      period_start: batch.period_start || norm.detectedPeriodStart || null,
      period_end: batch.period_end || norm.detectedPeriodEnd || null,
      opening_balance_paise: openingPaise ?? batch.opening_balance_paise ?? null,
      closing_balance_paise: closingPaise ?? batch.closing_balance_paise ?? null,
      summary_json: JSON.stringify(summary),
      updated_at: nowIsoUtc(),
      version: (batch.version || 1) + 1,
    };
    await this.db.table('import_batches').put(updatedBatch);

    return {
      batch: updatedBatch,
      stagedRows: norm.stagedRows,
      extracted,
      summary,
    };
  }


  /**
   * Module 2 First-Class UPI Screenshot Extraction, Parsing & Cross-Screenshot Deduplication.
   *
   * - Runs strictly local OCR (via localOcrEngine) or optional user-pasted text.
   * - If local OCR is unavailable, RETAINS the batch cleanly with status='ocr_unavailable'
   *   and explicit unsupported-processing message (never silently ignores the image).
   * - Parses Google Pay, PhonePe, Paytm & BHIM detail and history screenshots.
   * - Preserves uncertainty (ambiguous_fields, requires_confirmation, failed/pending status).
   * - Deduplicates the same payment appearing across multiple screenshots (by UTR or date+amount+direction+merchant).
   */
  async extractAndStageUpiScreenshotBatch({
    batchId,
    imageInputs = [],
    customOcrProvider = null,
    manualOcrTexts = null,
    signal = null,
    onProgress = null,
  }) {
    const batch = await this.repos.statementImport.getBatchById(batchId);
    if (!batch || batch.deleted_at) {
      throw new Error('UPI screenshot import batch not found.');
    }
    const account = batch.account_id ? await this.repos.accounts.getById(batch.account_id) : null;
    const now = nowIsoUtc();

    // Load previously staged UPI screenshot rows from OTHER active batches for cross-batch screenshot dedup
    const allExistingStaged = (await this.db.table('staged_transactions').toArray()).filter(
      (r) => !r.deleted_at && r.batch_id !== batchId
    );
    const seenUtrMap = new Map();
    const seenCompositeMap = new Map();
    for (const prev of allExistingStaged) {
      if (prev.transaction_reference) seenUtrMap.set(prev.transaction_reference.toLowerCase(), prev.id);
      if (prev.date_key && prev.amount_paise && prev.normalized_merchant) {
        const dir = (prev.credit_paise || 0) > 0 && (prev.debit_paise || 0) === 0 ? 'credit' : 'debit';
        seenCompositeMap.set(`${prev.date_key}|${prev.amount_paise}|${dir}|${prev.normalized_merchant}`, prev.id);
      }
    }

    const stagedRows = [];
    const reconciliationRows = [];
    const warnings = [];
    let ocrUnavailableCount = 0;
    let detectedApps = new Set();
    const rawOcrSamples = [];
    let minDate = null;
    let maxDate = null;

    const totalImgs = Math.max(1, imageInputs.length);
    const ocrSession = createLocalOcrSession({ customOcrProvider });
    try {
    for (let idx = 0; idx < imageInputs.length; idx += 1) {
      const img = imageInputs[idx];
      const sourceIndex = idx + 1;
      if (typeof onProgress === 'function') {
        onProgress({
          stage: 'extracting',
          current: sourceIndex,
          total: totalImgs,
          message: `Running local OCR on screenshot ${sourceIndex} of ${totalImgs}…`,
        });
      }

      if (signal?.aborted) {
        warnings.push(`Processing cancelled after ${idx} of ${imageInputs.length} screenshot(s).`);
        break;
      }

      let ocrText = Array.isArray(manualOcrTexts) ? String(manualOcrTexts[idx] || '').trim() : '';
      let ocrMeta = { confidence: null, blocks: [], processingMs: 0, preprocessed: false, invertedDarkMode: false, engine: 'manual_text' };
      if (!ocrText) {
        try {
          const ocrRes = await ocrSession.recognizeImage({
            arrayBuffer: img.arrayBuffer,
            mimeType: img.mimeType || 'image/png',
            signal,
            onProgress,
          });
          ocrText = ocrRes.text || '';
          ocrMeta = {
            confidence: ocrRes.confidence ?? null,
            words: ocrRes.words || [],
            blocks: ocrRes.blocks || [],
            processingMs: ocrRes.processingMs || 0,
            preprocessed: Boolean(ocrRes.preprocessed),
            invertedDarkMode: Boolean(ocrRes.invertedDarkMode),
            engine: ocrRes.engine || 'tesseract-wasm@0.11.0',
          };
        } catch (err) {
          if (err.code === 'OCR_CANCELLED') {
            warnings.push(`Processing cancelled on screenshot ${sourceIndex} of ${imageInputs.length}.`);
            break;
          }
          if (err.code === 'LOCAL_OCR_UNAVAILABLE' || err.code === 'LOCAL_OCR_RESTRICTED_CONTEXT') {
            ocrUnavailableCount += 1;
            warnings.push(err.message);
          } else {
            warnings.push(`OCR failed on "${img.filename || `image_${sourceIndex}`}": ${err.message || 'unknown error'}`);
          }
          continue;
        } finally {
          // Release raw ArrayBuffer reference after processing each image
          img.arrayBuffer = null;
        }
      }

      if (!ocrText) {
        warnings.push(`No readable text detected in "${img.filename || `image_${sourceIndex}`}".`);
        continue;
      }
      rawOcrSamples.push({
        filename: img.filename || `screenshot_${sourceIndex}`,
        engine: ocrMeta.engine,
        confidence: ocrMeta.confidence,
        processingMs: ocrMeta.processingMs,
        text: ocrText.slice(0, 1200),
      });

      const parsed = parseUpiScreenshotText(ocrText);
      if (parsed.upiApp) detectedApps.add(parsed.upiApp);

      for (const tx of parsed.transactions) {
        const dateKey = tx.dateKey || null;
        if (dateKey) {
          if (!minDate || dateKey < minDate) minDate = dateKey;
          if (!maxDate || dateKey > maxDate) maxDate = dateKey;
        }

        // Cross-screenshot duplicate detection (UTR first, then date+amount+direction+merchant)
        let matchedStagedId = null;
        let dupReason = '';
        const utrKey = tx.utr ? tx.utr.toLowerCase() : '';
        const compKey =
          dateKey && tx.amountPaise && tx.normalizedMerchant
            ? `${dateKey}|${tx.amountPaise}|${tx.direction}|${tx.normalizedMerchant}`
            : '';

        if (utrKey && seenUtrMap.has(utrKey)) {
          matchedStagedId = seenUtrMap.get(utrKey);
          dupReason = `Duplicate UPI payment (UTR ${tx.utr} already captured in another screenshot)`;
        } else if (compKey && seenCompositeMap.has(compKey)) {
          matchedStagedId = seenCompositeMap.get(compKey);
          dupReason = 'Duplicate UPI payment (same date, amount, direction & counterparty in another screenshot)';
        }

        const stagedId = generateUUID();
        const baseKey = `${account?.id || ''}|${dateKey || 'nodate'}|${tx.debitPaise}|${tx.creditPaise}|${tx.utr}|${tx.rawNarration.toLowerCase()}|img${sourceIndex}`;
        const rowFingerprint = (await computeSha256Hex(new TextEncoder().encode(baseKey))).slice(0, 32);

        const rowStatus = matchedStagedId
          ? 'duplicate'
          : tx.requiresConfirmation || tx.txStatus !== 'completed'
            ? 'needs_attention'
            : 'new';

        stagedRows.push({
          id: stagedId,
          user_id: null,
          batch_id: batchId,
          source_row_index: tx.sourceRowIndex || 1,
          source_page: sourceIndex,
          source_filename: img.filename || `screenshot_${sourceIndex}`,
          raw_narration: tx.rawNarration,
          date_key: dateKey,
          value_date_key: null,
          description: tx.counterparty,
          merchant: tx.counterparty,
          normalized_merchant: tx.normalizedMerchant,
          upi_id: tx.upiId || '',
          upi_app: tx.upiApp || 'generic_upi',
          upi_layout: tx.layoutType || 'detail',
          tx_status: tx.txStatus || 'unknown',
          ambiguous_fields: tx.ambiguousFields || [],
          requires_confirmation: Boolean(tx.requiresConfirmation),
          ocr_confidence: ocrMeta.confidence,
          ocr_words: ocrMeta.words || [],
          ocr_blocks: ocrMeta.blocks,
          ocr_processing_ms: ocrMeta.processingMs,
          ocr_preprocessed: ocrMeta.preprocessed,
          ocr_engine: ocrMeta.engine,
          debit_paise: tx.debitPaise,
          credit_paise: tx.creditPaise,
          amount_paise: tx.amountPaise,
          transaction_reference: tx.utr || '',
          tx_type: _snInferBaselineTxType({
            debitPaise: tx.debitPaise,
            creditPaise: tx.creditPaise,
            accountType: account?.type || 'bank_account',
            rawNarration: tx.rawNarration,
          }),
          account_id: account?.id || null,
          to_account_id: null,
          category_id: null,
          subcategory_id: null,
          confidence_score: 0,
          categorisation_source: 'unclassified',
          splits_json: null,
          status: rowStatus,
          duplicate_reason: dupReason || null,
          ledger_transaction_id: null,
          idempotency_key: `stmt:${batchId}:${rowFingerprint}`,
          row_fingerprint: rowFingerprint,
          notes: dupReason || (tx.txStatus !== 'completed' ? `UPI status: ${tx.txStatus}` : ''),
          created_at: now,
          updated_at: now,
          version: 1,
          deleted_at: null,
        });

        if (matchedStagedId) {
          reconciliationRows.push({
            id: generateUUID(),
            user_id: null,
            batch_id: batchId,
            staged_tx_id: stagedId,
            matched_tx_id: null,
            matched_staged_tx_id: matchedStagedId,
            match_type: 'cross_screenshot_duplicate',
            confidence_score: utrKey ? 0.99 : 0.9,
            match_reasons: [dupReason],
            resolution: 'pending',
            resolved_at: null,
            created_at: now,
            updated_at: now,
            version: 1,
            deleted_at: null,
          });
        } else {
          if (utrKey) seenUtrMap.set(utrKey, stagedId);
          if (compKey) seenCompositeMap.set(compKey, stagedId);
        }
      }
      await _snYield();
    }
    } finally {
      await ocrSession.destroy();
    }

    // Soft-delete previous unimported staged rows for this batch
    const prevBatchRows = (await this.db.table('staged_transactions').toArray()).filter(
      (r) => r.batch_id === batchId && !r.deleted_at && !r.ledger_transaction_id
    );
    for (const oldRow of prevBatchRows) {
      await this.db.table('staged_transactions').put({ ...oldRow, deleted_at: now, updated_at: now });
    }

    if (stagedRows.length > 0) {
      await this.db.table('staged_transactions').bulkPut(stagedRows);
    }
    if (reconciliationRows.length > 0) {
      await this.db.table('reconciliation_matches').bulkPut(reconciliationRows);
    }

    const batchStatus =
      stagedRows.length > 0
        ? 'extracted'
        : ocrUnavailableCount > 0
          ? 'ocr_unavailable'
          : 'needs_attention';

    const dedupWarnings = [...new Set(warnings)];
    const summary = {
      sourceType: 'upi_screenshot',
      pageCount: imageInputs.length,
      extractedCount: stagedRows.length,
      duplicateCount: reconciliationRows.length,
      needsAttentionCount: stagedRows.filter((r) => r.status === 'needs_attention').length,
      ocrUnavailable: ocrUnavailableCount > 0 && stagedRows.length === 0,
      detectedApps: [...detectedApps],
      rawOcrSamples,
      warnings: dedupWarnings,
    };

    const updatedBatch = {
      ...batch,
      status: batchStatus,
      row_count: stagedRows.length,
      period_start: batch.period_start || minDate || null,
      period_end: batch.period_end || maxDate || null,
      summary_json: JSON.stringify(summary),
      updated_at: nowIsoUtc(),
      version: (batch.version || 1) + 1,
    };
    await this.db.table('import_batches').put(updatedBatch);

    return {
      batch: updatedBatch,
      stagedRows,
      reconciliationMatches: reconciliationRows,
      summary,
    };
  }

  async listStagedByBatch(batchId) {
    const all = await this.db.table('staged_transactions').toArray();
    return all
      .filter((r) => r.batch_id === batchId && !r.deleted_at)
      .sort((a, b) => (a.source_page - b.source_page) || (a.source_row_index - b.source_row_index));
  }
}

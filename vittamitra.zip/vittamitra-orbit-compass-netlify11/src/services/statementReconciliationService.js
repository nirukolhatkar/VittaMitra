import { generateUUID } from '../utils/uuid.js';
import { nowIsoUtc } from '../utils/date.js';
import { normalizeMerchantKey } from '../db/repositories/statementImportRepository.js';

/**
 * Smart Statement Import — Module 4: Duplicate Detection & Reconciliation Engine.
 *
 * 100% local on-device. Incorporates:
 * - Multi-factor duplicate matching (Account, UTR/Reference, Amount, Date window, Merchant, Narration similarity)
 * - Comparison against BOTH existing ledger (`transactions`) AND previously staged/imported batches
 * - 1-to-1 match consumption so two legitimate same-day same-merchant transactions are NEVER auto-merged
 * - Internal transfer pairing across accounts
 * - Credit card bill settlement detection (liability settlement, not a second expense)
 * - Refund-to-original-purchase matching (within 30 days)
 * - Recurring transaction detection (against `recurring_rules` and historical ledger cadence)
 * - Statement opening vs. closing balance verification (when both balances exist)
 * - Never auto-discards possible duplicates — records `reconciliation_matches` for user confirm/reject
 */

function _srDaysBetween(dateA, dateB) {
  if (!dateA || !dateB) return 999;
  const a = new Date(`${String(dateA).slice(0, 10)}T00:00:00Z`).getTime();
  const b = new Date(`${String(dateB).slice(0, 10)}T00:00:00Z`).getTime();
  if (Number.isNaN(a) || Number.isNaN(b)) return 999;
  return Math.round(Math.abs(a - b) / 86400000);
}

function _srSignedDaysDiff(laterDate, earlierDate) {
  if (!laterDate || !earlierDate) return -999;
  const a = new Date(`${String(laterDate).slice(0, 10)}T00:00:00Z`).getTime();
  const b = new Date(`${String(earlierDate).slice(0, 10)}T00:00:00Z`).getTime();
  if (Number.isNaN(a) || Number.isNaN(b)) return -999;
  return Math.round((a - b) / 86400000);
}

function _srTokenize(text) {
  const clean = String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 2 && !/^(upi|dr|cr|neft|imps|rtgs|pos|p2m|p2a|p2p|the|and|for|to|from)$/.test(w));
  return new Set(clean);
}

export function computeNarrationSimilarity(textA, textB) {
  const setA = _srTokenize(textA);
  const setB = _srTokenize(textB);
  if (setA.size === 0 || setB.size === 0) return 0;
  let inter = 0;
  for (const tok of setA) {
    if (setB.has(tok)) inter += 1;
  }
  const union = new Set([...setA, ...setB]).size;
  return union > 0 ? Number((inter / union).toFixed(3)) : 0;
}

function _srStagedDirection(row) {
  return (row.credit_paise || 0) > 0 && (row.debit_paise || 0) === 0 ? 'credit' : 'debit';
}

function _srLedgerDirection(tx, accountId) {
  if (tx.type === 'income') return 'credit';
  if (tx.type === 'expense') return 'debit';
  if (tx.type === 'transfer') {
    return tx.to_account_id === accountId ? 'credit' : 'debit';
  }
  return 'debit';
}

/**
 * Multi-factor duplicate scoring between a staged row and a candidate (ledger tx or prior staged row).
 * Returns { matchType: 'exact_duplicate'|'probable_duplicate'|null, score, reasons }.
 */
export function scoreDuplicateCandidate(staged, candidate, { isLedger = true } = {}) {
  const stagedAmt = Number(staged.amount_paise) || 0;
  const candAmt = Number(candidate.amount_paise) || 0;
  if (stagedAmt <= 0 || stagedAmt !== candAmt) {
    return { matchType: null, score: 0, reasons: [] };
  }

  const stagedAcc = staged.account_id || null;
  const candAcc = isLedger
    ? candidate.account_id === stagedAcc || candidate.to_account_id === stagedAcc
      ? stagedAcc
      : candidate.account_id
    : candidate.account_id;
  if (stagedAcc && candAcc && stagedAcc !== candAcc) {
    return { matchType: null, score: 0, reasons: [] };
  }

  const stagedDir = _srStagedDirection(staged);
  const candDir = isLedger ? _srLedgerDirection(candidate, stagedAcc) : _srStagedDirection(candidate);
  if (stagedDir !== candDir) {
    return { matchType: null, score: 0, reasons: [] };
  }

  const reasons = ['Same account, amount & direction'];
  const stagedRef = String(staged.transaction_reference || '').trim().toLowerCase();
  const candRef = String(
    isLedger ? candidate.transaction_reference || '' : candidate.transaction_reference || ''
  )
    .trim()
    .toLowerCase();
  const candText = isLedger
    ? `${candidate.description || ''} ${candidate.notes || ''}`
    : `${candidate.merchant || ''} ${candidate.raw_narration || ''}`;
  const stagedText = `${staged.merchant || ''} ${staged.raw_narration || ''}`;

  // Factor 1: Exact UTR / Reference match (either in explicit field or inside ledger description/notes)
  if (stagedRef && stagedRef.length >= 6) {
    if ((candRef && candRef === stagedRef) || candText.toLowerCase().includes(stagedRef)) {
      reasons.push(`Matching reference / UTR (${staged.transaction_reference})`);
      return { matchType: 'exact_duplicate', score: 0.99, reasons };
    }
    // If BOTH have distinct non-empty UTRs, they are two different real transactions (never duplicates!)
    if (candRef && candRef.length >= 6 && candRef !== stagedRef) {
      return { matchType: null, score: 0, reasons: [] };
    }
  }

  const daysDiff = _srDaysBetween(staged.date_key, candidate.date_key);
  if (daysDiff > 3) {
    return { matchType: null, score: 0, reasons: [] };
  }

  const stagedMerch = normalizeMerchantKey(staged.normalized_merchant || staged.merchant || staged.description);
  const candMerch = normalizeMerchantKey(
    isLedger ? candidate.description || '' : candidate.normalized_merchant || candidate.merchant || candidate.description
  );
  const exactMerchant = Boolean(stagedMerch && candMerch && stagedMerch === candMerch);
  const sim = computeNarrationSimilarity(stagedText, candText);

  let score = 0.45;
  if (daysDiff === 0) {
    score += 0.25;
    reasons.push(`Exact date (${staged.date_key})`);
  } else {
    score += Math.max(0.08, 0.2 - daysDiff * 0.04);
    reasons.push(`Date within ${daysDiff} day${daysDiff === 1 ? '' : 's'}`);
  }

  if (exactMerchant) {
    score += 0.28;
    reasons.push(`Matching merchant (${staged.merchant || stagedMerch})`);
  } else if (sim >= 0.45) {
    score += Number((sim * 0.28).toFixed(2));
    reasons.push(`Narration similarity ${Math.round(sim * 100)}%`);
  }

  score = Math.min(0.98, Number(score.toFixed(2)));

  if (daysDiff === 0 && (exactMerchant || sim >= 0.8)) {
    return { matchType: 'exact_duplicate', score: Math.max(score, 0.95), reasons };
  }
  if (score >= 0.7) {
    return { matchType: 'probable_duplicate', score, reasons };
  }
  return { matchType: null, score, reasons: [] };
}

/**
 * Verifies statement Opening + Credits - Debits === Closing Balance (where both are available).
 */
export function verifyStatementBalances(batch, stagedRows) {
  if (batch.opening_balance_paise === null || batch.opening_balance_paise === undefined ||
      batch.closing_balance_paise === null || batch.closing_balance_paise === undefined) {
    return { available: false, verified: null, discrepancyPaise: null };
  }
  const active = stagedRows.filter((r) => !r.deleted_at);
  const totalCredits = active.reduce((s, r) => s + (Number(r.credit_paise) || 0), 0);
  const totalDebits = active.reduce((s, r) => s + (Number(r.debit_paise) || 0), 0);
  const calculatedClosingPaise = Number(batch.opening_balance_paise) + totalCredits - totalDebits;
  const discrepancyPaise = calculatedClosingPaise - Number(batch.closing_balance_paise);
  return {
    available: true,
    verified: Math.abs(discrepancyPaise) <= 100, // within ₹1 rounding tolerance
    openingBalancePaise: Number(batch.opening_balance_paise),
    closingBalancePaise: Number(batch.closing_balance_paise),
    calculatedClosingPaise,
    discrepancyPaise,
  };
}

export class StatementReconciliationService {
  constructor(db, repos) {
    this.db = db;
    this.repos = repos;
  }

  /**
   * Runs full Module 4 reconciliation on all active staged rows in a batch.
   * Never auto-discards possible duplicates; persists `reconciliation_matches` for user review.
   */
  async reconcileBatch(batchId) {
    const batch = await this.repos.statementImport.getBatchById(batchId);
    if (!batch || batch.deleted_at) {
      throw new Error('Statement import batch not found.');
    }

    const [allStaged, allLedgerTxs, allAccounts, allRecurring, existingMatches] = await Promise.all([
      this.db.table('staged_transactions').toArray(),
      this.db.table('transactions').toArray(),
      this.repos.accounts.list({ includeArchived: false }),
      this.db.table('recurring_rules').toArray().catch(() => []),
      this.db.table('reconciliation_matches').toArray(),
    ]);

    const accMap = new Map(allAccounts.map((a) => [a.id, a]));
    const batchRows = allStaged
      .filter((r) => r.batch_id === batchId && !r.deleted_at)
      .sort((a, b) => (a.source_page - b.source_page) || (a.source_row_index - b.source_row_index));
    const otherBatchStaged = allStaged.filter(
      (r) => r.batch_id !== batchId && !r.deleted_at && r.status !== 'excluded'
    );
    const activeLedger = allLedgerTxs.filter((tx) => !tx.deleted_at && tx.type !== 'BALANCE_ADJUSTMENT');
    const activeRecurring = allRecurring.filter((r) => !r.deleted_at && r.is_active !== false);

    const now = nowIsoUtc();

    // Preserve any user-resolved matches (confirmed/rejected) and cross-screenshot matches from Module 2
    const preservedMatches = existingMatches.filter(
      (m) =>
        m.batch_id === batchId &&
        !m.deleted_at &&
        (m.resolution !== 'pending' || m.match_type === 'cross_screenshot_duplicate')
    );
    const resolvedByStaged = new Set(preservedMatches.map((m) => `${m.staged_tx_id}|${m.match_type}`));

    // Soft-delete stale pending reconciliation matches for this batch before regenerating
    for (const m of existingMatches) {
      if (
        m.batch_id === batchId &&
        !m.deleted_at &&
        m.resolution === 'pending' &&
        m.match_type !== 'cross_screenshot_duplicate'
      ) {
        await this.db.table('reconciliation_matches').put({ ...m, deleted_at: now, updated_at: now });
      }
    }

    // 1-to-1 consumption sets so two legitimate identical same-day transactions are NEVER both flagged against 1 ledger row
    const usedLedgerDupIds = new Set();
    const usedStagedDupIds = new Set();

    const newMatches = [];
    const updatedStagedRows = [];

    // Precompute merchant month counts in ledger for recurring detection
    const merchantMonths = new Map();
    for (const tx of activeLedger) {
      const mKey = normalizeMerchantKey(tx.description || '');
      if (!mKey || mKey.length < 3 || !tx.date_key) continue;
      if (!merchantMonths.has(mKey)) merchantMonths.set(mKey, new Map());
      merchantMonths.get(mKey).set(tx.date_key.slice(0, 7), Number(tx.amount_paise) || 0);
    }

    for (const row of batchRows) {
      let rowMutated = { ...row };
      const rowAcc = accMap.get(row.account_id);
      const rowDir = _srStagedDirection(row);

      // --- 1. Duplicate Detection against Existing Ledger ---
      let bestDup = null;
      for (const tx of activeLedger) {
        if (usedLedgerDupIds.has(tx.id)) continue;
        const scored = scoreDuplicateCandidate(row, tx, { isLedger: true });
        if (scored.matchType && (!bestDup || scored.score > bestDup.score)) {
          bestDup = { ...scored, matchedTxId: tx.id, matchedStagedTxId: null };
        }
      }

      // --- 2. Duplicate Detection against Previously Imported / Staged Batches ---
      if (!bestDup || bestDup.matchType !== 'exact_duplicate') {
        for (const other of otherBatchStaged) {
          if (usedStagedDupIds.has(other.id)) continue;
          const scored = scoreDuplicateCandidate(row, other, { isLedger: false });
          if (scored.matchType && (!bestDup || scored.score > bestDup.score)) {
            bestDup = { ...scored, matchedTxId: other.ledger_transaction_id || null, matchedStagedTxId: other.id };
          }
        }
      }

      if (bestDup && !resolvedByStaged.has(`${row.id}|${bestDup.matchType}`)) {
        if (bestDup.matchedTxId) usedLedgerDupIds.add(bestDup.matchedTxId);
        if (bestDup.matchedStagedTxId) usedStagedDupIds.add(bestDup.matchedStagedTxId);
        newMatches.push({
          id: generateUUID(),
          user_id: null,
          batch_id: batchId,
          staged_tx_id: row.id,
          matched_tx_id: bestDup.matchedTxId,
          matched_staged_tx_id: bestDup.matchedStagedTxId,
          match_type: bestDup.matchType,
          confidence_score: bestDup.score,
          match_reasons: bestDup.reasons,
          resolution: 'pending',
          resolved_at: null,
          created_at: now,
          updated_at: now,
          version: 1,
          deleted_at: null,
        });
        if (rowMutated.status !== 'excluded' && rowMutated.status !== 'imported') {
          rowMutated.status = 'duplicate';
          rowMutated.duplicate_reason = bestDup.reasons.join(' · ');
        }
      }

      // --- 3. Credit Card Bill Settlement & Internal Transfer Detection across Accounts ---
      if (!bestDup && row.account_id) {
        const counterpartCandidates = [
          ...activeLedger.map((tx) => ({ rec: tx, isLedger: true })),
          ...otherBatchStaged.map((st) => ({ rec: st, isLedger: false })),
        ];
        for (const { rec, isLedger } of counterpartCandidates) {
          const recAccId = rec.account_id;
          if (!recAccId || recAccId === row.account_id) continue;
          if (Number(rec.amount_paise) !== Number(row.amount_paise)) continue;
          const recDir = isLedger ? _srLedgerDirection(rec, recAccId) : _srStagedDirection(rec);
          if (recDir === rowDir) continue; // must be opposite direction
          const days = _srDaysBetween(row.date_key, rec.date_key);
          const recAcc = accMap.get(recAccId);
          const involvesCc = rowAcc?.type === 'credit_card' || recAcc?.type === 'credit_card';
          if (days > (involvesCc ? 5 : 3)) continue;

          const matchType = involvesCc ? 'cc_settlement' : 'internal_transfer';
          if (!resolvedByStaged.has(`${row.id}|${matchType}`)) {
            newMatches.push({
              id: generateUUID(),
              user_id: null,
              batch_id: batchId,
              staged_tx_id: row.id,
              matched_tx_id: isLedger ? rec.id : rec.ledger_transaction_id || null,
              matched_staged_tx_id: isLedger ? null : rec.id,
              match_type: matchType,
              confidence_score: days === 0 ? 0.94 : 0.86,
              match_reasons: [
                involvesCc
                  ? `Credit card bill settlement paired with ${recAcc?.name || 'other account'} (${days}d diff)`
                  : `Internal transfer paired with ${recAcc?.name || 'other account'} (${days}d diff)`,
              ],
              resolution: 'pending',
              resolved_at: null,
              created_at: now,
              updated_at: now,
              version: 1,
              deleted_at: null,
            });
            if (rowMutated.categorisation_source !== 'user_correction') {
              rowMutated.tx_type = 'transfer';
              rowMutated.accounting_class = matchType;
              rowMutated.to_account_id = recAccId;
            }
          }
          break;
        }
      }

      // --- 4. Refund Matching against Original Purchase (within preceding 30 days) ---
      if (rowDir === 'credit' && (row.accounting_class === 'refund' || /\b(refund|reversal|chargeback)\b/i.test(row.raw_narration || ''))) {
        const rowMerch = normalizeMerchantKey(row.normalized_merchant || row.merchant || '');
        const priorDebits = [
          ...activeLedger
            .filter((tx) => tx.type === 'expense' && tx.account_id === row.account_id)
            .map((tx) => ({ rec: tx, isLedger: true })),
          ...batchRows
            .filter((r) => r.id !== row.id && (r.debit_paise || 0) > 0)
            .map((r) => ({ rec: r, isLedger: false })),
        ];
        for (const { rec, isLedger } of priorDebits) {
          const diffDays = _srSignedDaysDiff(row.date_key, rec.date_key);
          if (diffDays < 0 || diffDays > 30) continue;
          if (Number(row.amount_paise) > Number(rec.amount_paise)) continue;
          const recMerch = normalizeMerchantKey(isLedger ? rec.description || '' : rec.normalized_merchant || rec.merchant || '');
          const sim = computeNarrationSimilarity(row.raw_narration, isLedger ? rec.description : rec.raw_narration);
          if ((rowMerch && recMerch && (rowMerch === recMerch || recMerch.includes(rowMerch) || rowMerch.includes(recMerch))) || sim >= 0.4) {
            if (!resolvedByStaged.has(`${row.id}|refund_link`)) {
              newMatches.push({
                id: generateUUID(),
                user_id: null,
                batch_id: batchId,
                staged_tx_id: row.id,
                matched_tx_id: isLedger ? rec.id : null,
                matched_staged_tx_id: isLedger ? null : rec.id,
                match_type: 'refund_link',
                confidence_score: Number(row.amount_paise) === Number(rec.amount_paise) ? 0.92 : 0.8,
                match_reasons: [
                  `Refund matches purchase on ${rec.date_key} (${diffDays}d earlier)`,
                ],
                resolution: 'pending',
                resolved_at: null,
                created_at: now,
                updated_at: now,
                version: 1,
                deleted_at: null,
              });
              rowMutated.accounting_class = 'refund';
            }
            break;
          }
        }
      }

      // --- 5. Recurring Transaction Detection ---
      const normM = normalizeMerchantKey(row.normalized_merchant || row.merchant || '');
      if (normM) {
        const matchedRule = activeRecurring.find((rr) => {
          const rKey = normalizeMerchantKey(rr.description || rr.name || '');
          if (!rKey || !(rKey.includes(normM) || normM.includes(rKey))) return false;
          const rAmt = Number(rr.amount_paise) || 0;
          return rAmt <= 0 || Math.abs(rAmt - row.amount_paise) / rAmt <= 0.12;
        });
        let histMonths = merchantMonths.get(normM);
        if (!histMonths) {
          for (const [mKey, monthsMap] of merchantMonths.entries()) {
            if (mKey.length >= 4 && (normM.includes(mKey) || mKey.includes(normM))) {
              histMonths = monthsMap;
              break;
            }
          }
        }
        const isHistRecurring =
          histMonths &&
          histMonths.size >= 2 &&
          [...histMonths.values()].some((amt) => amt > 0 && Math.abs(amt - row.amount_paise) / amt <= 0.1);

        if ((matchedRule || isHistRecurring) && !resolvedByStaged.has(`${row.id}|recurring`)) {
          newMatches.push({
            id: generateUUID(),
            user_id: null,
            batch_id: batchId,
            staged_tx_id: row.id,
            matched_tx_id: null,
            matched_staged_tx_id: null,
            match_type: 'recurring',
            confidence_score: matchedRule ? 0.9 : 0.78,
            match_reasons: [
              matchedRule
                ? `Matches active recurring rule "${matchedRule.name || matchedRule.description}"`
                : `Recurring cadence detected across ${histMonths.size} prior months`,
            ],
            resolution: 'pending',
            resolved_at: null,
            created_at: now,
            updated_at: now,
            version: 1,
            deleted_at: null,
          });
          rowMutated.is_recurring_candidate = true;
        }
      }

      updatedStagedRows.push({ ...rowMutated, updated_at: now });
    }

    if (newMatches.length > 0) {
      await this.db.table('reconciliation_matches').bulkPut(newMatches);
    }
    if (updatedStagedRows.length > 0) {
      await this.db.table('staged_transactions').bulkPut(updatedStagedRows);
    }

    const allBatchMatches = [...preservedMatches, ...newMatches];
    const balanceCheck = verifyStatementBalances(batch, updatedStagedRows);

    let prevSummary = {};
    if (batch.summary_json) {
      try {
        prevSummary = JSON.parse(batch.summary_json);
      } catch {
        prevSummary = {};
      }
    }
    const nextSummary = {
      ...prevSummary,
      reconciliation: {
        exactDuplicates: allBatchMatches.filter((m) => m.match_type === 'exact_duplicate').length,
        probableDuplicates: allBatchMatches.filter((m) => m.match_type === 'probable_duplicate').length,
        crossScreenshotDuplicates: allBatchMatches.filter((m) => m.match_type === 'cross_screenshot_duplicate').length,
        internalTransfers: allBatchMatches.filter((m) => m.match_type === 'internal_transfer').length,
        ccSettlements: allBatchMatches.filter((m) => m.match_type === 'cc_settlement').length,
        refundLinks: allBatchMatches.filter((m) => m.match_type === 'refund_link').length,
        recurringCandidates: allBatchMatches.filter((m) => m.match_type === 'recurring').length,
        balanceCheck,
      },
    };

    const updatedBatch = {
      ...batch,
      status: batch.status === 'imported' ? 'imported' : 'review_ready',
      summary_json: JSON.stringify(nextSummary),
      updated_at: now,
      version: (batch.version || 1) + 1,
    };
    await this.db.table('import_batches').put(updatedBatch);

    return {
      batch: updatedBatch,
      stagedRows: updatedStagedRows,
      matches: allBatchMatches,
      balanceCheck,
      summary: nextSummary.reconciliation,
    };
  }

  /**
   * User confirms or rejects a reconciliation match (especially duplicate matches).
   */
  async resolveMatch(matchId, resolution) {
    if (resolution !== 'confirmed' && resolution !== 'rejected') {
      throw new Error('Resolution must be "confirmed" or "rejected".');
    }
    const match = await this.db.table('reconciliation_matches').get(matchId);
    if (!match || match.deleted_at) {
      throw new Error('Reconciliation match not found.');
    }
    const now = nowIsoUtc();
    const updatedMatch = {
      ...match,
      resolution,
      resolved_at: now,
      updated_at: now,
      version: (match.version || 1) + 1,
    };
    await this.db.table('reconciliation_matches').put(updatedMatch);

    const staged = await this.db.table('staged_transactions').get(match.staged_tx_id);
    if (staged && !staged.deleted_at && !staged.ledger_transaction_id) {
      const isDupType =
        match.match_type === 'exact_duplicate' ||
        match.match_type === 'probable_duplicate' ||
        match.match_type === 'cross_screenshot_duplicate';
      if (isDupType) {
        await this.db.table('staged_transactions').put({
          ...staged,
          status: resolution === 'confirmed' ? 'excluded' : 'new',
          duplicate_reason: resolution === 'confirmed' ? staged.duplicate_reason || 'Confirmed duplicate' : null,
          updated_at: now,
          version: (staged.version || 1) + 1,
        });
      }
    }

    return updatedMatch;
  }

  async listMatchesByBatch(batchId) {
    const all = await this.db.table('reconciliation_matches').toArray();
    return all.filter((m) => m.batch_id === batchId && !m.deleted_at);
  }
}

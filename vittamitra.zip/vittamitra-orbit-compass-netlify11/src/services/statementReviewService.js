import { nowIsoUtc } from '../utils/date.js';
import { validateSplitReconciliation } from './ledgerRules.js';
import { normalizeMerchantKey } from '../db/repositories/statementImportRepository.js';

/**
 * Smart Statement Import — Module 5: Review Workspace Service.
 *
 * Manages all transaction-level edits, split-transaction validation, bulk categorisation,
 * bulk account assignment, selective approval/exclusion, and review filtering on
 * `staged_transactions` — NEVER modifying `raw_narration` and NEVER writing to the ledger.
 */

export const REVIEW_FILTERS = Object.freeze([
  'all',
  'new',
  'duplicates',
  'needs_attention',
  'approved',
  'excluded',
]);

export function getReviewFilterCounts(rows) {
  const active = (rows || []).filter((r) => !r.deleted_at);
  return {
    all: active.length,
    new: active.filter((r) => r.status === 'new').length,
    duplicates: active.filter((r) => r.status === 'duplicate').length,
    needs_attention: active.filter((r) => r.status === 'needs_attention').length,
    approved: active.filter((r) => r.status === 'approved').length,
    excluded: active.filter((r) => r.status === 'excluded').length,
    imported: active.filter((r) => r.status === 'imported').length,
  };
}

export function filterStagedRows(rows, { filter = 'all', search = '' } = {}) {
  let list = (rows || []).filter((r) => !r.deleted_at);
  if (filter === 'new') list = list.filter((r) => r.status === 'new');
  else if (filter === 'duplicates') list = list.filter((r) => r.status === 'duplicate');
  else if (filter === 'needs_attention') list = list.filter((r) => r.status === 'needs_attention');
  else if (filter === 'approved') list = list.filter((r) => r.status === 'approved');
  else if (filter === 'excluded') list = list.filter((r) => r.status === 'excluded');

  const q = String(search || '').trim().toLowerCase();
  if (q) {
    list = list.filter((r) => {
      const hay = `${r.merchant || ''} ${r.description || ''} ${r.raw_narration || ''} ${r.transaction_reference || ''} ${r.upi_id || ''} ${r.date_key || ''}`.toLowerCase();
      return hay.includes(q);
    });
  }
  return list;
}

export class StatementReviewService {
  constructor(db, repos, services = {}) {
    this.db = db;
    this.repos = repos;
    this.services = services;
  }

  /**
   * Edits any reviewable field on a staged transaction (date, description, account,
   * to_account, type, category, subcategory, splits, notes) while strictly preserving
   * `raw_narration` verbatim.
   */
  async updateStagedTransaction(stagedTxId, patch = {}, { learnRule = false, ruleType = 'exact_merchant' } = {}) {
    const existing = await this.db.table('staged_transactions').get(stagedTxId);
    if (!existing || existing.deleted_at) {
      throw new Error('Staged transaction not found.');
    }
    if (existing.status === 'imported' || existing.ledger_transaction_id) {
      throw new Error('Cannot edit a staged row that has already been imported into the ledger.');
    }

    const nextDate = patch.date_key !== undefined ? String(patch.date_key || '').trim() : existing.date_key;
    if (nextDate && !/^\d{4}-\d{2}-\d{2}$/.test(nextDate)) {
      throw new Error('Date must be in YYYY-MM-DD format.');
    }

    const nextType = patch.tx_type || existing.tx_type || 'expense';
    if (!['expense', 'income', 'transfer'].includes(nextType)) {
      throw new Error(`Invalid transaction type "${nextType}".`);
    }

    const nextAmountPaise =
      patch.amount_paise !== undefined
        ? Math.round(Number(patch.amount_paise))
        : existing.amount_paise;
    if (!Number.isFinite(nextAmountPaise) || nextAmountPaise <= 0) {
      throw new Error('Transaction amount must be greater than zero.');
    }
    const amountChanged = nextAmountPaise !== existing.amount_paise;

    const nextDesc =
      patch.description !== undefined ? String(patch.description || '').trim() : existing.description;
    const nextMerchant =
      patch.merchant !== undefined ? String(patch.merchant || '').trim() : nextDesc || existing.merchant;

    // Validate split legs if provided (or if amount changed with existing splits)
    let nextSplitsJson = existing.splits_json || null;
    if (patch.splits !== undefined) {
      if (!patch.splits || patch.splits.length === 0) {
        nextSplitsJson = null;
      } else {
        const cleanSplits = patch.splits.map((s) => ({
          category_id: s.category_id,
          amount_paise: Math.round(Number(s.amount_paise) || 0),
          note: String(s.note || '').trim(),
        }));
        validateSplitReconciliation(nextAmountPaise, cleanSplits);
        nextSplitsJson = JSON.stringify(cleanSplits);
      }
    } else if (amountChanged && nextSplitsJson) {
      const existingSplits = JSON.parse(nextSplitsJson);
      validateSplitReconciliation(nextAmountPaise, existingSplits);
    }

    const nextCategoryId = patch.category_id !== undefined ? patch.category_id || null : existing.category_id;
    const nextSubcategoryId = patch.subcategory_id !== undefined ? patch.subcategory_id || null : existing.subcategory_id;
    const categoryChanged =
      nextCategoryId !== existing.category_id ||
      nextSubcategoryId !== existing.subcategory_id ||
      nextType !== existing.tx_type;

    const now = nowIsoUtc();
    const updated = {
      ...existing,
      // raw_narration is NEVER overwritten
      raw_narration: existing.raw_narration,
      date_key: nextDate || null,
      description: nextDesc || existing.description,
      merchant: nextMerchant || existing.merchant,
      normalized_merchant: normalizeMerchantKey(nextMerchant || existing.merchant),
      account_id: patch.account_id !== undefined ? patch.account_id || null : existing.account_id,
      to_account_id:
        nextType === 'transfer'
          ? patch.to_account_id !== undefined
            ? patch.to_account_id || null
            : existing.to_account_id
          : null,
      amount_paise: nextAmountPaise,
      debit_paise: nextType === 'income' ? 0 : nextAmountPaise,
      credit_paise: nextType === 'income' ? nextAmountPaise : 0,
      direction: nextType === 'income' ? 'credit' : 'debit',
      tx_type: nextType,
      category_id: nextSplitsJson ? null : nextCategoryId,
      subcategory_id: nextSplitsJson ? null : nextSubcategoryId,
      splits_json: nextSplitsJson,
      notes: patch.notes !== undefined ? String(patch.notes || '').trim() : existing.notes,
      categorisation_source: categoryChanged ? 'user_correction' : existing.categorisation_source,
      confidence_score: categoryChanged ? 1.0 : existing.confidence_score,
      user_corrected: categoryChanged || amountChanged ? true : existing.user_corrected,
      requires_confirmation: nextDate && nextAmountPaise > 0 ? false : existing.requires_confirmation,
      ambiguous_fields: (existing.ambiguous_fields || []).filter((f) => {
        if (nextDate && f === 'date_key') return false;
        if (nextAmountPaise > 0 && (f === 'amount' || f === 'amount_paise')) return false;
        return true;
      }),
      status: patch.status || (existing.status === 'needs_attention' && nextDate && nextAmountPaise > 0 ? 'new' : existing.status),
      updated_at: now,
      version: (existing.version || 1) + 1,
    };

    await this.db.table('staged_transactions').put(updated);

    if (learnRule && this.services.statementCategorisation && !nextSplitsJson) {
      await this.services.statementCategorisation.applyUserCorrectionAndLearn({
        stagedTxId: updated.id,
        categoryId: updated.category_id,
        subcategoryId: updated.subcategory_id,
        txType: updated.tx_type,
        saveRule: true,
        ruleType,
      });
    }

    return updated;
  }

  async setStagedStatus(stagedTxId, status) {
    if (!['new', 'approved', 'excluded', 'needs_attention'].includes(status)) {
      throw new Error(`Unsupported staged status "${status}".`);
    }
    const existing = await this.db.table('staged_transactions').get(stagedTxId);
    if (!existing || existing.deleted_at) throw new Error('Staged transaction not found.');
    if (existing.status === 'imported') throw new Error('Already imported into the ledger.');
    if (status === 'approved') {
      if (!existing.date_key) throw new Error('Cannot approve a row without a valid date.');
      if (!existing.account_id) throw new Error('Cannot approve a row without a confirmed account.');
      if ((Number(existing.amount_paise) || 0) <= 0) throw new Error('Cannot approve a row with zero amount.');
    }
    const updated = {
      ...existing,
      status,
      requires_confirmation: status === 'approved' ? false : existing.requires_confirmation,
      updated_at: nowIsoUtc(),
      version: (existing.version || 1) + 1,
    };
    await this.db.table('staged_transactions').put(updated);
    return updated;
  }

  async bulkUpdateCategory(stagedTxIds, { categoryId = null, subcategoryId = null, txType = null, learnRules = false } = {}) {
    const ids = [...new Set(stagedTxIds || [])];
    let updatedCount = 0;
    for (const id of ids) {
      const existing = await this.db.table('staged_transactions').get(id);
      if (!existing || existing.deleted_at || existing.status === 'imported') continue;
      await this.updateStagedTransaction(
        id,
        {
          category_id: categoryId,
          subcategory_id: subcategoryId,
          tx_type: txType || existing.tx_type,
        },
        { learnRule: learnRules }
      );
      updatedCount += 1;
    }
    return { updatedCount };
  }

  async bulkAssignAccount(stagedTxIds, accountId) {
    if (!accountId) throw new Error('Target account is required for bulk assignment.');
    const ids = [...new Set(stagedTxIds || [])];
    const now = nowIsoUtc();
    let updatedCount = 0;
    for (const id of ids) {
      const existing = await this.db.table('staged_transactions').get(id);
      if (!existing || existing.deleted_at || existing.status === 'imported') continue;
      await this.db.table('staged_transactions').put({
        ...existing,
        account_id: accountId,
        updated_at: now,
        version: (existing.version || 1) + 1,
      });
      updatedCount += 1;
    }
    return { updatedCount };
  }

  async bulkSetStatus(stagedTxIds, status) {
    const ids = [...new Set(stagedTxIds || [])];
    let updatedCount = 0;
    const skipped = [];
    for (const id of ids) {
      try {
        await this.setStagedStatus(id, status);
        updatedCount += 1;
      } catch (err) {
        skipped.push({ id, reason: err.message });
      }
    }
    return { updatedCount, skipped };
  }

  /**
   * Approves all clean `'new'` rows in a batch that have valid date, account, and amount.
   * Never auto-approves `'duplicate'` or `'needs_attention'` rows.
   */
  async approveAllReady(batchId) {
    const all = await this.db.table('staged_transactions').toArray();
    const eligible = all.filter(
      (r) =>
        r.batch_id === batchId &&
        !r.deleted_at &&
        r.status === 'new' &&
        Boolean(r.date_key) &&
        Boolean(r.account_id) &&
        (Number(r.amount_paise) || 0) > 0
    );
    const now = nowIsoUtc();
    const updated = eligible.map((r) => ({
      ...r,
      status: 'approved',
      updated_at: now,
      version: (r.version || 1) + 1,
    }));
    if (updated.length > 0) {
      await this.db.table('staged_transactions').bulkPut(updated);
    }
    return { approvedCount: updated.length };
  }
}

/**
 * Smart Statement Import — Module 1: Upload, Validation, SHA-256 Fingerprinting & Metadata Detection.
 *
 * Strictly local within the PWA. No external APIs, no PDF text extraction, no OCR,
 * no XLS parsing, and no categorisation intelligence in Module 1.
 */

export const UPI_SCREENSHOT_EXTENSIONS = Object.freeze(['jpg', 'jpeg', 'png', 'webp']);
export const DOCUMENT_STATEMENT_EXTENSIONS = Object.freeze(['pdf', 'csv', 'xls', 'xlsx']);
export const SUPPORTED_STATEMENT_EXTENSIONS = Object.freeze([...DOCUMENT_STATEMENT_EXTENSIONS, ...UPI_SCREENSHOT_EXTENSIONS]);

export function isUpiScreenshotExtension(ext) {
  return UPI_SCREENSHOT_EXTENSIONS.includes(String(ext || '').toLowerCase());
}
export const MAX_STATEMENT_FILE_BYTES = 50 * 1024 * 1024; // 50 MB safety cap for mobile devices

const INSTITUTION_PATTERNS = [
  { name: 'HDFC Bank', re: /\bhdfc\b/i },
  { name: 'ICICI Bank', re: /\bicici\b/i },
  { name: 'State Bank of India', re: /\b(sbi|state\s*bank)\b/i },
  { name: 'Axis Bank', re: /\baxis\b/i },
  { name: 'Kotak Mahindra Bank', re: /\bkotak\b/i },
  { name: 'IDFC First Bank', re: /\bidfc\b/i },
  { name: 'Yes Bank', re: /\b(yes\s*bank|kiwi)\b/i },
  { name: 'IndusInd Bank', re: /\bindusind\b/i },
  { name: 'Canara Bank', re: /\bcanara\b/i },
  { name: 'Bank of Baroda', re: /\b(bob|baroda)\b/i },
  { name: 'Punjab National Bank', re: /\b(pnb|punjab\s*national)\b/i },
  { name: 'Federal Bank', re: /\bfederal\b/i },
  { name: 'RBL Bank', re: /\brbl\b/i },
  { name: 'American Express', re: /\b(amex|american\s*express)\b/i },
  { name: 'HSBC', re: /\bhsbc\b/i },
  { name: 'Standard Chartered', re: /\b(scb|standard\s*chartered)\b/i },
  { name: 'Paytm', re: /\bpaytm\b/i },
  { name: 'PhonePe', re: /\bphonepe\b/i },
  { name: 'Google Pay', re: /\b(gpay|google\s*pay)\b/i },
  { name: 'Amazon Pay', re: /\bamazon\s*pay\b/i },
];

const MONTH_NAME_MAP = {
  jan: 1,
  feb: 2,
  mar: 3,
  apr: 4,
  may: 5,
  jun: 6,
  jul: 7,
  aug: 8,
  sep: 9,
  sept: 9,
  oct: 10,
  nov: 11,
  dec: 12,
};

/**
 * Pure-JS SHA-256 fallback for environments where crypto.subtle is unavailable
 * (e.g., insecure HTTP / constrained WebViews).
 */
function sha256FallbackHex(uint8) {
  const K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  const H = new Uint32Array([
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ]);

  const bitLenHi = Math.floor((uint8.length * 8) / 0x100000000);
  const bitLenLo = (uint8.length * 8) >>> 0;
  const paddedLen = Math.ceil((uint8.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLen);
  padded.set(uint8);
  padded[uint8.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLen - 8, bitLenHi, false);
  view.setUint32(paddedLen - 4, bitLenLo, false);

  const W = new Uint32Array(64);
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));

  for (let offset = 0; offset < paddedLen; offset += 64) {
    for (let i = 0; i < 16; i += 1) {
      W[i] = view.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i += 1) {
      const s0 = rotr(W[i - 15], 7) ^ rotr(W[i - 15], 18) ^ (W[i - 15] >>> 3);
      const s1 = rotr(W[i - 2], 17) ^ rotr(W[i - 2], 19) ^ (W[i - 2] >>> 10);
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) >>> 0;
    }

    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i += 1) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[i] + W[i]) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    H[0] = (H[0] + a) >>> 0;
    H[1] = (H[1] + b) >>> 0;
    H[2] = (H[2] + c) >>> 0;
    H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0;
    H[5] = (H[5] + f) >>> 0;
    H[6] = (H[6] + g) >>> 0;
    H[7] = (H[7] + h) >>> 0;
  }

  return Array.from(H)
    .map((v) => v.toString(16).padStart(8, '0'))
    .join('');
}

export async function computeSha256Hex(arrayBuffer) {
  const bytes = arrayBuffer instanceof Uint8Array ? arrayBuffer : new Uint8Array(arrayBuffer);
  if (typeof globalThis.crypto !== 'undefined' && globalThis.crypto?.subtle?.digest) {
    try {
      const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(digest))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    } catch {
      // Fallback for non-secure origins
    }
  }
  return sha256FallbackHex(bytes);
}

export function extractFileExtension(filename) {
  const clean = String(filename || '').trim();
  const idx = clean.lastIndexOf('.');
  if (idx < 0 || idx === clean.length - 1) return '';
  return clean.slice(idx + 1).toLowerCase();
}

export function maskAccountNumber(raw) {
  const digits = String(raw || '').replace(/\D/g, '');
  if (digits.length < 4) return '';
  return `XXXX${digits.slice(-4)}`;
}

/**
 * Validates file type, non-empty size, and binary/text magic-byte integrity.
 * Does NOT perform PDF extraction, OCR, or XLS parsing.
 */
export function validateStatementFile({ name, size, type = '', arrayBuffer }) {
  const errors = [];
  const warnings = [];
  const fileExt = extractFileExtension(name);
  const byteLength = arrayBuffer ? arrayBuffer.byteLength : Number(size) || 0;

  if (!name || !String(name).trim()) {
    errors.push('File name is missing.');
  }
  if (!SUPPORTED_STATEMENT_EXTENSIONS.includes(fileExt)) {
    errors.push(`Unsupported file type ".${fileExt || 'unknown'}". Allowed: PDF, CSV, XLS, XLSX, JPG, JPEG, PNG, WebP.`);
  }
  if (byteLength <= 0) {
    errors.push('File is empty (0 bytes).');
  } else if (byteLength > MAX_STATEMENT_FILE_BYTES) {
    errors.push('File exceeds the 50 MB mobile safety limit.');
  }

  let isPasswordProtected = false;
  let formatNote = '';

  if (errors.length === 0 && arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);

    if (fileExt === 'pdf') {
      // Check %PDF- magic bytes within first 1024 bytes (per PDF spec)
      const headAscii = String.fromCharCode(...bytes.slice(0, Math.min(1024, bytes.length)));
      if (!headAscii.includes('%PDF-')) {
        errors.push('File header is not a valid PDF document (missing %PDF- signature).');
      } else {
        // Lightweight metadata-only encryption flag check (never stores passwords)
        const scanLen = Math.min(bytes.length, 65536);
        const tailStart = Math.max(0, bytes.length - scanLen);
        let tailText = '';
        for (let i = tailStart; i < bytes.length; i += 1) {
          tailText += String.fromCharCode(bytes[i]);
        }
        if (/\/Encrypt\b/.test(tailText) || /\/Encrypt\b/.test(headAscii)) {
          isPasswordProtected = true;
          warnings.push('Password-protected PDF detected. Password will be requested in memory during extraction and never stored.');
        }
      }
    } else if (fileExt === 'xlsx') {
      const isZip =
        bytes.length >= 4 &&
        bytes[0] === 0x50 &&
        bytes[1] === 0x4b &&
        bytes[2] === 0x03 &&
        bytes[3] === 0x04;
      if (!isZip) {
        errors.push('File header is not a valid XLSX OpenXML archive.');
      }
    } else if (fileExt === 'xls') {
      const isOle2 =
        bytes.length >= 8 &&
        bytes[0] === 0xd0 &&
        bytes[1] === 0xcf &&
        bytes[2] === 0x11 &&
        bytes[3] === 0xe0 &&
        bytes[4] === 0xa1 &&
        bytes[5] === 0xb1 &&
        bytes[6] === 0x1a &&
        bytes[7] === 0xe1;
      if (!isOle2) {
        const sample = new TextDecoder('utf-8', { fatal: false }).decode(bytes.slice(0, Math.min(2048, bytes.length)));
        const looksHtmlOrText = /<html|<table|<\?xml|\t|,/i.test(sample) && !bytes.slice(0, 512).includes(0);
        if (looksHtmlOrText) {
          formatNote = 'Bank HTML/delimited export with .xls extension';
        } else {
          errors.push('File header is not a valid XLS workbook.');
        }
      }
    } else if (fileExt === 'csv') {
      const probe = bytes.slice(0, Math.min(4096, bytes.length));
      if (probe.includes(0)) {
        errors.push('CSV file appears to contain binary data.');
      } else {
        const textSample = new TextDecoder('utf-8', { fatal: false }).decode(probe).trim();
        if (!textSample) {
          errors.push('CSV file contains no readable text.');
        }
      }
    } else if (fileExt === 'png') {
      const isPng =
        bytes.length >= 8 &&
        bytes[0] === 0x89 &&
        bytes[1] === 0x50 &&
        bytes[2] === 0x4e &&
        bytes[3] === 0x47 &&
        bytes[4] === 0x0d &&
        bytes[5] === 0x0a &&
        bytes[6] === 0x1a &&
        bytes[7] === 0x0a;
      if (!isPng) {
        errors.push('File header is not a valid PNG image.');
      } else {
        formatNote = 'Transaction screenshot (PNG)';
      }
    } else if (fileExt === 'jpg' || fileExt === 'jpeg') {
      const isJpg = bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
      if (!isJpg) {
        errors.push('File header is not a valid JPEG/JPG image.');
      } else {
        formatNote = 'Transaction screenshot (JPG)';
      }
    } else if (fileExt === 'webp') {
      const isWebp =
        bytes.length >= 12 &&
        bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
        bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50;
      if (!isWebp) {
        errors.push('File header is not a valid WebP image.');
      } else {
        formatNote = 'UPI Screenshot (WebP)';
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    fileExt,
    mimeType: type || guessMimeType(fileExt),
    byteLength,
    isPasswordProtected,
    formatNote,
  };
}

function guessMimeType(ext) {
  switch (ext) {
    case 'pdf':
      return 'application/pdf';
    case 'csv':
      return 'text/csv';
    case 'xls':
      return 'application/vnd.ms-excel';
    case 'xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'webp':
      return 'image/webp';
    default:
      return 'application/octet-stream';
  }
}

function _stmtPad2(n) {
  return String(n).padStart(2, '0');
}

function lastDayOfMonth(year, month1Based) {
  return new Date(year, month1Based, 0).getDate();
}

/**
 * Lightweight metadata-only detection from filename (and first 2 KB of CSV text if CSV).
 * Never extracts PDF text, never runs OCR, never parses XLS.
 */
export function detectStatementMetadata({ name = '', fileExt = '', arrayBuffer = null, accounts = [] }) {
  let probeText = String(name || '');
  if (fileExt === 'csv' && arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    const snippet = new TextDecoder('utf-8', { fatal: false }).decode(bytes.slice(0, Math.min(2048, bytes.length)));
    probeText = `${probeText}\n${snippet}`;
  }

  // 1. Institution detection (treat _, -, . as word separators in filenames)
  const wordProbe = probeText.replace(/[_./-]+/g, ' ');
  let institution = '';
  for (const inst of INSTITUTION_PATTERNS) {
    if (inst.re.test(wordProbe)) {
      institution = inst.name;
      break;
    }
  }

  // 2. Masked account reference detection (always masked to XXXX1234)
  let maskedAccountRef = '';
  const maskedMatch = probeText.match(/(?:x{2,}|\*{2,}|a\/c\s*(?:no\.?)?\s*[:#-]?\s*|acct\s*[:#-]?\s*)(\d{4,16})/i);
  if (maskedMatch) {
    maskedAccountRef = maskAccountNumber(maskedMatch[1]);
  } else {
    const longDigits = String(name || '').match(/\d{8,16}/);
    if (longDigits) maskedAccountRef = maskAccountNumber(longDigits[0]);
  }

  // 3. Statement period detection from filename / CSV header
  let periodStart = '';
  let periodEnd = '';
  const isoRange = probeText.match(/(\d{4}-\d{2}-\d{2})\s*(?:to|_|–|-)\s*(\d{4}-\d{2}-\d{2})/i);
  if (isoRange) {
    periodStart = isoRange[1];
    periodEnd = isoRange[2];
  } else {
    const dmyRange = probeText.match(/(\d{2})[-/](\d{2})[-/](\d{4})\s*(?:to|_|–|-)\s*(\d{2})[-/](\d{2})[-/](\d{4})/i);
    if (dmyRange) {
      periodStart = `${dmyRange[3]}-${dmyRange[2]}-${dmyRange[1]}`;
      periodEnd = `${dmyRange[6]}-${dmyRange[5]}-${dmyRange[4]}`;
    } else {
      const monthYr = String(name || '').replace(/[_./-]+/g, ' ').match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\s?(20\d{2})\b/i);
      if (monthYr) {
        const m = MONTH_NAME_MAP[monthYr[1].toLowerCase().slice(0, 3)];
        const y = Number(monthYr[2]);
        if (m && y) {
          periodStart = `${y}-${_stmtPad2(m)}-01`;
          periodEnd = `${y}-${_stmtPad2(m)}-${_stmtPad2(lastDayOfMonth(y, m))}`;
        }
      }
    }
  }

  // 4. Suggested VittaMitra Account (always requires explicit user confirmation)
  const activeAccounts = (accounts || []).filter((a) => !a.deleted_at && !a.is_archived);
  let suggestedAccountId = '';
  let matchReason = '';
  const last4 = maskedAccountRef ? maskedAccountRef.slice(-4) : '';

  if (last4) {
    const byDigits = activeAccounts.find((a) => String(a.name || '').includes(last4));
    if (byDigits) {
      suggestedAccountId = byDigits.id;
      matchReason = `Matched digits ${maskedAccountRef}`;
    }
  }
  if (!suggestedAccountId && institution) {
    const instFirstWord = institution.split(' ')[0].toLowerCase();
    const byInst = activeAccounts.find((a) => String(a.name || '').toLowerCase().includes(instFirstWord));
    if (byInst) {
      suggestedAccountId = byInst.id;
      matchReason = `Matched institution ${institution}`;
    }
  }

  return {
    institution,
    periodStart,
    periodEnd,
    maskedAccountRef,
    suggestedAccountId,
    matchReason,
  };
}

export class StatementUploadService {
  constructor(repos) {
    this.repos = repos;
  }

  /**
   * Validates multiple uploaded files, computes SHA-256 fingerprints, checks duplicate batches,
   * and returns reviewable upload drafts (releasing raw buffers once inspected).
   */
  async inspectUploadedFiles(fileInputs) {
    const accounts = await this.repos.accounts.list({ includeArchived: false });
    const drafts = [];
    const seenHashesInUpload = new Map();

    for (let i = 0; i < fileInputs.length; i += 1) {
      const item = fileInputs[i];
      const arrayBuffer = item.arrayBuffer || (typeof item.file?.arrayBuffer === 'function' ? await item.file.arrayBuffer() : null);
      const name = item.name || item.file?.name || `statement_${i + 1}`;
      const size = item.size ?? item.file?.size ?? (arrayBuffer ? arrayBuffer.byteLength : 0);
      const type = item.type || item.file?.type || '';

      const validation = validateStatementFile({ name, size, type, arrayBuffer });
      let fileHash = '';
      let duplicateBatch = null;
      let metadata = {
        institution: '',
        periodStart: '',
        periodEnd: '',
        maskedAccountRef: '',
        suggestedAccountId: '',
        matchReason: '',
      };

      const isImg = isUpiScreenshotExtension(validation.fileExt);
      let intraUploadDupName = null;
      if (validation.valid && arrayBuffer) {
        fileHash = await computeSha256Hex(arrayBuffer);
        duplicateBatch = await this.repos.statementImport.findActiveBatchByHash(fileHash);
        if (!duplicateBatch && seenHashesInUpload.has(fileHash)) {
          intraUploadDupName = seenHashesInUpload.get(fileHash);
        } else {
          seenHashesInUpload.set(fileHash, name);
        }
        metadata = detectStatementMetadata({
          name,
          fileExt: validation.fileExt,
          arrayBuffer,
          accounts,
        });
      }

      const isDup = Boolean(duplicateBatch || intraUploadDupName);
      drafts.push({
        draftId: `draft_${Date.now()}_${i}`,
        filename: name,
        fileExt: validation.fileExt,
        fileCategory: isImg ? 'upi_screenshot' : 'statement',
        sourceType: isImg ? 'upi_screenshot' : 'statement',
        mimeType: validation.mimeType,
        fileSize: validation.byteLength,
        valid: validation.valid,
        errors: validation.errors,
        warnings: validation.warnings,
        formatNote: validation.formatNote,
        isPasswordProtected: validation.isPasswordProtected,
        fileHash,
        isDuplicateFile: isDup,
        duplicateOfBatch: duplicateBatch
          ? {
              id: duplicateBatch.id,
              filename: duplicateBatch.filename,
              imported_at: duplicateBatch.imported_at,
              status: duplicateBatch.status,
            }
          : intraUploadDupName
            ? {
                id: null,
                filename: intraUploadDupName,
                imported_at: 'current upload',
                status: 'duplicate_in_selection',
              }
            : null,
        include: validation.valid && !isDup,
        institution: metadata.institution,
        periodStart: metadata.periodStart,
        periodEnd: metadata.periodEnd,
        maskedAccountRef: metadata.maskedAccountRef,
        accountId: metadata.suggestedAccountId,
        matchReason: metadata.matchReason,
        accountConfirmed: false,
      });
    }

    return drafts;
  }

  /**
   * Creates statement import batches after mandatory user confirmation of account and metadata.
   */
  async createConfirmedBatches(confirmedDrafts) {
    const created = [];
    const skipped = [];
    const screenshotGroups = new Map(); // accountId -> Array<draft>

    for (const draft of confirmedDrafts) {
      if (!draft.include) {
        skipped.push({ filename: draft.filename, reason: 'Excluded by user' });
        continue;
      }
      if (!draft.valid) {
        throw new Error(`Cannot create batch for invalid file "${draft.filename}".`);
      }
      if (!draft.accountId) {
        throw new Error(`Please select and confirm an account for "${draft.filename}".`);
      }
      if (draft.isDuplicateFile && !draft.allowDuplicateUpload) {
        skipped.push({ filename: draft.filename, reason: 'Duplicate file fingerprint (SHA-256)' });
        continue;
      }

      if (draft.sourceType === 'upi_screenshot' || isUpiScreenshotExtension(draft.fileExt)) {
        if (!screenshotGroups.has(draft.accountId)) screenshotGroups.set(draft.accountId, []);
        screenshotGroups.get(draft.accountId).push(draft);
        continue;
      }

      const batch = await this.repos.statementImport.createStatementBatch({
        source_type: 'statement',
        filename: draft.filename,
        file_ext: draft.fileExt,
        mime_type: draft.mimeType,
        file_size: draft.fileSize,
        file_hash: draft.fileHash,
        institution: draft.institution || '',
        account_id: draft.accountId,
        masked_account_ref: draft.maskedAccountRef ? maskAccountNumber(draft.maskedAccountRef) || draft.maskedAccountRef : '',
        account_confirmed: true,
        period_start: draft.periodStart || null,
        period_end: draft.periodEnd || null,
        is_password_protected: Boolean(draft.isPasswordProtected),
        duplicate_of_batch_id: draft.duplicateOfBatch?.id || null,
        status: 'uploaded',
      });
      created.push(batch);
    }

    // Create one consolidated upi_screenshot batch per confirmed account (supports multiple screenshots in one batch)
    for (const [accountId, imgDrafts] of screenshotGroups.entries()) {
      const first = imgDrafts[0];
      const totalSize = imgDrafts.reduce((s, d) => s + (Number(d.fileSize) || 0), 0);
      const sourceFiles = imgDrafts.map((d, idx) => ({
        source_index: idx + 1,
        draftId: d.draftId,
        filename: d.filename,
        file_ext: d.fileExt,
        mime_type: d.mimeType,
        file_size: d.fileSize,
        file_hash: d.fileHash,
        duplicate_of_batch_id: d.duplicateOfBatch?.id || null,
      }));
      const combinedHash =
        imgDrafts.length === 1
          ? first.fileHash
          : await computeSha256Hex(new TextEncoder().encode(sourceFiles.map((f) => f.file_hash).join('|')));

      const batch = await this.repos.statementImport.createStatementBatch({
        source_type: 'upi_screenshot',
        source_files: sourceFiles,
        filename:
          imgDrafts.length === 1
            ? first.filename
            : `${imgDrafts.length} UPI Screenshots (${first.filename} + ${imgDrafts.length - 1} more)`,
        file_ext: first.fileExt,
        mime_type: first.mimeType,
        file_size: totalSize,
        file_hash: combinedHash,
        institution: first.institution || 'UPI Screenshot',
        account_id: accountId,
        masked_account_ref: first.maskedAccountRef ? maskAccountNumber(first.maskedAccountRef) || first.maskedAccountRef : '',
        account_confirmed: true,
        period_start: first.periodStart || null,
        period_end: first.periodEnd || null,
        is_password_protected: false,
        duplicate_of_batch_id: first.duplicateOfBatch?.id || null,
        status: 'uploaded',
      });
      created.push(batch);
    }

    return { created, skipped };
  }
}

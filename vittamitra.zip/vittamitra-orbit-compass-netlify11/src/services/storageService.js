/**
 * Storage persistence, quota inspection, and offline status helpers.
 */

export async function requestPersistentStorage() {
  if (typeof navigator === 'undefined' || !navigator.storage?.persist) {
    return { supported: false, persisted: false };
  }
  try {
    const already = await navigator.storage.persisted();
    if (already) return { supported: true, persisted: true };
    const granted = await navigator.storage.persist();
    return { supported: true, persisted: granted };
  } catch {
    return { supported: true, persisted: false };
  }
}

export async function getStorageDiagnostics(db) {
  let persisted = false;
  let usageBytes = null;
  let quotaBytes = null;

  if (typeof navigator !== 'undefined' && navigator.storage) {
    try {
      if (navigator.storage.persisted) persisted = await navigator.storage.persisted();
      if (navigator.storage.estimate) {
        const est = await navigator.storage.estimate();
        usageBytes = est.usage ?? null;
        quotaBytes = est.quota ?? null;
      }
    } catch {
      // Ignore browser quota restrictions
    }
  }

  let swControlled = false;
  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    swControlled = Boolean(navigator.serviceWorker.controller);
  }

  const syncQueueCount = db ? await db.sync_queue.count() : 0;

  return {
    online: typeof navigator !== 'undefined' ? navigator.onLine : true,
    persisted,
    usageBytes,
    quotaBytes,
    swControlled,
    syncQueueCount,
  };
}

export function formatBytes(bytes) {
  if (bytes === null || bytes === undefined) return 'Unavailable';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

/**
 * Theme management supporting Light, Dark, and System preference.
 */

let mediaQueryListenerBound = false;

export function applyTheme(theme = 'system') {
  const root = document.documentElement;
  if (theme === 'light' || theme === 'dark') {
    root.dataset.theme = theme;
  } else {
    const prefersDark =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.dataset.theme = prefersDark ? 'dark' : 'light';
  }
  root.dataset.themePreference = theme;

  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    metaTheme.setAttribute('content', root.dataset.theme === 'dark' ? '#0B0E11' : '#F8FAFC');
  }

  if (!mediaQueryListenerBound && typeof window !== 'undefined' && window.matchMedia) {
    mediaQueryListenerBound = true;
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (document.documentElement.dataset.themePreference === 'system') {
        applyTheme('system');
      }
    });
  }
}

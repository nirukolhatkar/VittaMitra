import { escapeHtml } from '../utils/dom.js';
import { formatINR } from '../utils/money.js';
import { formatRelativeDate, toLocalDateString, toLocalDateTimeString } from '../utils/date.js';
import { formatTagDisplay } from '../utils/normalize.js';
import { openModal } from '../ui/components/modal.js';
import { showToast } from '../ui/components/toast.js';

/**
 * Centralised Transaction Context Engine, Context-Aware Copy/Paste Clipboard,
 * and Global Search Modal.
 *
 * Context Resolution Hierarchy (strictly enforced):
 *   1. Explicit user selections inside the Add Transaction form
 *   2. Context inherited from the current page (Calendar date, Account, Tag, Category, Budget, Debt, Family, Ledger filters)
 *   3. Existing application defaults (default account, remembered category)
 *   4. System defaults (today's date, current time, expense)
 *
 * Copy & Paste Rules:
 *   - Never modifies the original transaction
 *   - Never duplicates transaction IDs or reference numbers
 *   - Always opens the Add Transaction form pre-populated with copied attributes +
 *     destination page context overrides so the user can review/edit before saving
 *   - Never saves automatically on paste
 */

export function formatShortContextDate(dateKey) {
  if (!dateKey || !/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return dateKey || '';
  const [y, m, d] = dateKey.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  const mon = dt.toLocaleDateString('en-IN', { month: 'short' });
  return `${d} ${mon}`;
}

/**
 * Pure, testable 4-level context resolver for Add Transaction & Paste.
 * Level 1: explicitFormValues (highest precedence)
 * Level 2: pageContextOverrides (inherited from active screen)
 * Level 3: appDefaults (settings defaults)
 * Level 4: systemDefaults (today's date, current time, 'expense')
 */
export function resolveTransactionContext({
  explicit = {},
  pageContext = null,
  copiedTx = null,
  appDefaults = {},
  systemDefaults = {},
} = {}) {
  const nowTs = toLocalDateTimeString();
  const sys = {
    type: 'expense',
    date: toLocalDateString(),
    time: nowTs.slice(11, 16),
    ...systemDefaults,
  };

  const ov = pageContext?.overrides || {};
  const copied = copiedTx || {};

  // Type resolution: explicit > pageContext.type > copied.type > appDefaults > system
  let resolvedType =
    explicit.type ||
    ov.type ||
    (copied.type && copied.type !== 'debt' ? copied.type : null) ||
    appDefaults.type ||
    sys.type;

  // Date resolution: explicit > pageContext.date > system (NOTE: pasting uses destination context date or today, NOT old copied date unless no context and explicitly requested)
  const resolvedDate = explicit.date || ov.date || sys.date;
  const resolvedTime = explicit.time || ov.time || sys.time;

  // Account resolution: explicit > pageContext.account_id/source_account_id > copied.account_id > appDefaults
  const resolvedAccountId =
    explicit.account_id ||
    ov.account_id ||
    ov.source_account_id ||
    copied.account_id ||
    appDefaults.account_id ||
    null;

  let resolvedToAccountId =
    resolvedType === 'transfer'
      ? explicit.to_account_id ||
        ov.to_account_id ||
        ov.destination_account_id ||
        copied.to_account_id ||
        appDefaults.to_account_id ||
        null
      : null;

  // Guard against self-transfer when destination account context matches original to_account_id
  if (resolvedType === 'transfer' && resolvedAccountId && resolvedToAccountId === resolvedAccountId) {
    resolvedToAccountId = copied.account_id && copied.account_id !== resolvedAccountId ? copied.account_id : null;
  }

  // Category resolution: explicit > pageContext.category_id > copied.category_id > appDefaults
  const resolvedCategoryId =
    resolvedType === 'transfer'
      ? null
      : explicit.category_id ||
        ov.category_id ||
        copied.category_id ||
        (resolvedType === 'income' ? appDefaults.income_category_id : appDefaults.expense_category_id) ||
        null;

  // Tag resolution: merge copied tags + pageContext inherited tags (preserving both, deduplicated), overridden if explicit.tag_ids provided
  let resolvedTagIds;
  if (Array.isArray(explicit.tag_ids)) {
    resolvedTagIds = [...new Set(explicit.tag_ids.filter(Boolean))];
  } else {
    const merged = new Set();
    if (Array.isArray(copied.tag_ids)) {
      copied.tag_ids.forEach((id) => id && merged.add(id));
    }
    if (ov.add_tag_id) merged.add(ov.add_tag_id);
    if (Array.isArray(ov.add_tag_ids)) {
      ov.add_tag_ids.forEach((id) => id && merged.add(id));
    }
    resolvedTagIds = Array.from(merged);
  }

  // Family member resolution
  const resolvedFamilyId =
    explicit.family_member_id !== undefined
      ? explicit.family_member_id
      : ov.family_member_id !== undefined
        ? ov.family_member_id
        : copied.family_member_id || null;

  // Inherited context metadata badges (for display in Add Transaction header)
  const inheritedBadges = [];
  if (ov.date) inheritedBadges.push(`📅 ${formatShortContextDate(ov.date)}`);
  if (ov.account_id || ov.source_account_id) inheritedBadges.push(`🏛️ ${pageContext?.accountName || 'Account'}`);
  if (ov.category_id) inheritedBadges.push(`🏷️ ${pageContext?.categoryName || 'Category'}`);
  if (ov.add_tag_id || (Array.isArray(ov.add_tag_ids) && ov.add_tag_ids.length)) {
    inheritedBadges.push(`${pageContext?.tagName || '#Tag'}`);
  }
  if (ov.family_member_id) inheritedBadges.push(`👤 ${pageContext?.familyName || 'Family'}`);
  if (ov.budget_id) inheritedBadges.push(`🎯 ${pageContext?.budgetName || 'Budget'}`);
  if (ov.debt_id) inheritedBadges.push(`🤝 ${pageContext?.debtName || 'Debt'}`);

  return {
    type: resolvedType,
    amount_paise: explicit.amount_paise ?? copied.amount_paise ?? null,
    date: resolvedDate,
    time: resolvedTime,
    account_id: resolvedAccountId,
    to_account_id: resolvedToAccountId,
    category_id: resolvedCategoryId,
    description: explicit.description ?? copied.description ?? '',
    notes: explicit.notes ?? copied.notes ?? '',
    // Never duplicate reference_no or original transaction id when pasting
    reference_no: explicit.reference_no ?? '',
    family_member_id: resolvedFamilyId,
    tag_ids: resolvedTagIds,
    budget_id: explicit.budget_id ?? ov.budget_id ?? null,
    debt_id: explicit.debt_id ?? ov.debt_id ?? null,
    inheritedBadges,
    fromClipboard: Boolean(copiedTx),
    copiedSourceTitle: copiedTx ? copiedTx.description || copiedTx.title || 'Copied entry' : null,
  };
}

export function setPageContext(ctx, context = null) {
  if (!ctx?.state) return;
  ctx.state.pageContext = context || null;
  updateContextualActionButtons(ctx);
  renderClipboardBar(ctx);
}

export function updateContextualActionButtons(ctx) {
  const pc = ctx?.state?.pageContext;
  const label = pc?.shortLabel || pc?.label || '';

  const compassAddBtn = document.getElementById('compass-add-btn');
  if (compassAddBtn) {
    const textEl = compassAddBtn.querySelector('.compass-add-label');
    if (textEl) {
      textEl.textContent = label ? `Add · ${label}` : 'Add';
    }
    compassAddBtn.setAttribute('aria-label', label ? `Add transaction for ${label}` : 'Add transaction');
  }

  const topbarAddBtn = document.getElementById('topbar-add-btn');
  if (topbarAddBtn) {
    topbarAddBtn.setAttribute('title', label ? `Add transaction (${label})` : 'Add transaction');
  }
}

export function buildContextDraft(ctx, extra = {}) {
  const pc = ctx?.state?.pageContext || null;
  const rawRoute = window.location.hash.replace(/^#\/?/, '').split('?')[0] || 'home';
  const route = rawRoute === 'add-transaction' ? 'home' : rawRoute;
  const resolved = resolveTransactionContext({
    explicit: extra,
    pageContext: pc,
  });

  return {
    ...resolved,
    returnRoute: extra.returnRoute || route,
    sourcePageLabel: pc?.label || '',
  };
}

export function openAddTransactionWithContext(ctx, extra = {}) {
  ctx.state.txDraft = buildContextDraft(ctx, extra);
  if (window.location.hash === '#/add-transaction') {
    if (typeof ctx.refreshCurrentView === 'function') ctx.refreshCurrentView();
  } else {
    window.location.hash = '#/add-transaction';
  }
}

export async function copyTransactionToClipboard(ctx, txId) {
  const tx = await ctx.services.transactions.getTransactionById(txId);
  if (!tx) {
    showToast('Transaction not found', { type: 'error' });
    return null;
  }

  const [cat, acc] = await Promise.all([
    tx.category_id ? ctx.repos.categories.getById(tx.category_id) : Promise.resolve(null),
    tx.account_id ? ctx.repos.accounts.getById(tx.account_id) : Promise.resolve(null),
  ]);

  // Store a clean snapshot (strictly excluding original id & reference_no from paste payload)
  ctx.state.clipboardTx = {
    sourceId: tx.id,
    type: tx.type,
    amount_paise: tx.amount_paise,
    category_id: tx.category_id,
    account_id: tx.account_id,
    to_account_id: tx.to_account_id,
    description: tx.description || '',
    notes: tx.notes || '',
    family_member_id: tx.family_member_id || null,
    tag_ids: [...(tx.tag_ids || [])],
    title: tx.description || (tx.type === 'transfer' ? 'Transfer' : cat?.name || 'Transaction'),
    subtitle: acc?.name || '',
    icon: tx.type === 'transfer' ? '⇄' : tx.type === 'debt' ? '🤝' : cat?.icon || '🧾',
  };

  renderClipboardBar(ctx);

  const pc = ctx.state.pageContext;
  const targetHint = pc?.label ? `Paste to ${pc.label}` : 'Paste & Edit';
  showToast(`Copied "${ctx.state.clipboardTx.title}" (${formatINR(tx.amount_paise)})`, {
    durationMs: 4500,
    actionLabel: targetHint,
    onAction: () => pasteClipboardToContext(ctx),
  });
  return ctx.state.clipboardTx;
}

export function clearClipboard(ctx) {
  if (ctx?.state) ctx.state.clipboardTx = null;
  renderClipboardBar(ctx);
}

/**
 * Context-Aware Paste:
 * Resolves the copied transaction against the destination page's active context
 * and opens the Add Transaction screen for review & editing (NEVER auto-saves!).
 */
export async function pasteClipboardToContext(ctx, { txId = null, onRefresh = null } = {}) {
  const sourceId = txId || ctx?.state?.clipboardTx?.sourceId || ctx?.state?.clipboardTx?.id;
  if (!sourceId) {
    showToast('No copied transaction in clipboard', { type: 'warning' });
    return null;
  }

  const pc = ctx.state.pageContext || {};
  const overrides = { ...(pc.overrides || {}) };

  try {
    const cloned = await ctx.services.transactions.cloneTransaction(sourceId, overrides);
    const refresh = async () => {
      if (typeof onRefresh === 'function') await onRefresh(cloned);
      else if (typeof pc.onPasteRefresh === 'function') await pc.onPasteRefresh(cloned);
      else if (typeof ctx.refreshCurrentView === 'function') await ctx.refreshCurrentView();
    };
    await refresh();

    const appliedParts = [];
    if (overrides.date) appliedParts.push(formatShortContextDate(overrides.date));
    if (overrides.account_id && pc.accountName) appliedParts.push(pc.accountName);
    if (overrides.add_tag_id && pc.tagName) appliedParts.push(pc.tagName);
    if (overrides.category_id && pc.categoryName) appliedParts.push(pc.categoryName);
    if (overrides.family_member_id && pc.familyName) appliedParts.push(pc.familyName);
    const detail = appliedParts.length > 0 ? ` (${appliedParts.join(' · ')})` : '';

    showToast(`Transaction recorded${detail}`, {
      durationMs: 5000,
      actionLabel: 'Undo',
      onAction: async () => {
        await ctx.services.transactions.softDeleteTransaction(cloned.id);
        await refresh();
        showToast('Copy undone');
      },
    });
    return cloned;
  } catch (err) {
    showToast(err?.message || 'Unable to record copied transaction', { type: 'error' });
    return null;
  }
}

export function renderClipboardBar(ctx) {
  let bar = document.getElementById('tx-clipboard-bar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'tx-clipboard-bar';
    bar.className = 'clipboard-bar hidden';
    bar.setAttribute('role', 'region');
    bar.setAttribute('aria-label', 'Copied transaction clipboard');
    document.body.appendChild(bar);
  }

  const clip = ctx?.state?.clipboardTx;
  const rawRoute = window.location.hash.replace(/^#\/?/, '').split('?')[0] || 'home';
  const route = rawRoute === 'add-transaction' ? 'home' : rawRoute;
  if (!clip || route === 'add-transaction') {
    bar.classList.add('hidden');
    bar.innerHTML = '';
    return;
  }

  const pc = ctx?.state?.pageContext;
  const targetLabel = pc?.shortLabel || pc?.label || 'Today';

  bar.classList.remove('hidden');
  bar.innerHTML = `
    <div class="clipboard-bar-info">
      <span class="clipboard-bar-icon">${escapeHtml(clip.icon)}</span>
      <div style="min-width:0;">
        <div class="clipboard-bar-title">${escapeHtml(clip.title)} · ${escapeHtml(formatINR(clip.amount_paise))}</div>
        <div class="clipboard-bar-sub">Copied · Paste into <strong>${escapeHtml(targetLabel)}</strong></div>
      </div>
    </div>
    <div class="clipboard-bar-actions">
      <button type="button" class="btn btn-primary btn-sm" id="btn-clipboard-paste">📋 Paste</button>
      <button type="button" class="icon-btn" id="btn-clipboard-clear" style="width:34px; height:34px;" aria-label="Clear copied transaction">✕</button>
    </div>
  `;

  bar.querySelector('#btn-clipboard-paste')?.addEventListener('click', () => {
    pasteClipboardToContext(ctx);
  });

  bar.querySelector('#btn-clipboard-clear')?.addEventListener('click', () => {
    clearClipboard(ctx);
  });
}

export async function openGlobalSearchModal(ctx) {
  const { repos, services, state } = ctx;
  const [settings, accounts, categories, tags, allTxs] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.list({ includeArchived: true }),
    repos.categories.list({ includeArchived: true }),
    repos.tags.list({ includeArchived: true }),
    services.transactions.listTransactions({ sort: 'desc' }),
  ]);

  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const catMap = new Map(categories.map((c) => [c.id, c]));
  const tagMap = new Map(tags.map((t) => [t.id, t]));
  const showBalances = settings.show_balances !== false;
  const pc = state.pageContext;
  const pasteLabel = pc?.shortLabel || pc?.label || 'Today';

  openModal({
    title: 'Search Transactions',
    bodyHtml: `
      <div class="stack" style="gap:10px;">
        <div style="display:flex; gap:8px;">
          <input id="global-tx-search-input" class="form-control" type="search" autocomplete="off"
            placeholder="Search description, notes, category, account, #tag, or amount…">
          <button type="button" class="btn btn-primary btn-sm" id="global-search-add-btn" style="white-space:nowrap;">+ Add</button>
        </div>
        ${
          pc?.label
            ? `<div class="item-meta" style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                <span>Context: <strong>${escapeHtml(pc.label)}</strong></span>
                <span>Tap 📋 to paste &amp; edit here</span>
              </div>`
            : `<div class="item-meta">Tap a row to edit, ⧉ to copy, or 📋 to paste into Add Transaction.</div>`
        }
        <div id="global-tx-search-results" class="grouped-card" style="max-height:54vh; overflow-y:auto;"></div>
      </div>
    `,
    onMount: (panel, close) => {
      const input = panel.querySelector('#global-tx-search-input');
      const resultsEl = panel.querySelector('#global-tx-search-results');

      panel.querySelector('#global-search-add-btn')?.addEventListener('click', () => {
        close();
        openAddTransactionWithContext(ctx);
      });

      const renderResults = (query) => {
        const q = String(query || '').trim().toLowerCase();
        const matches = (
          q
            ? allTxs.filter((tx) => {
                const cat = tx.category_id ? catMap.get(tx.category_id) : null;
                const acc = accMap.get(tx.account_id);
                const toAcc = tx.to_account_id ? accMap.get(tx.to_account_id) : null;
                const tagStr = (tx.tag_ids || [])
                  .map((tid) => {
                    const t = tagMap.get(tid);
                    return t ? formatTagDisplay(t) : '';
                  })
                  .join(' ');
                const amtStr = String(Math.round((tx.amount_paise || 0) / 100));
                const amtDec = ((tx.amount_paise || 0) / 100).toFixed(2);
                const hay = `${tx.description || ''} ${tx.notes || ''} ${tx.reference_no || ''} ${cat?.name || ''} ${acc?.name || ''} ${toAcc?.name || ''} ${tagStr} ${amtStr} ${amtDec} ${tx.date_key || ''}`.toLowerCase();
                return hay.includes(q);
              })
            : allTxs
        ).slice(0, 30);

        if (matches.length === 0) {
          resultsEl.innerHTML = `<div class="grouped-row"><span class="item-meta">No transactions match "${escapeHtml(query)}".</span></div>`;
          return;
        }

        resultsEl.innerHTML = matches
          .map((tx) => {
            const cat = tx.category_id ? catMap.get(tx.category_id) : null;
            const acc = accMap.get(tx.account_id);
            const toAcc = tx.to_account_id ? accMap.get(tx.to_account_id) : null;
            const icon = tx.type === 'transfer' ? '⇄' : tx.type === 'debt' ? '🤝' : cat?.icon || '🧾';
            const prettyType = String(tx.type || '').toUpperCase() === 'BALANCE_ADJUSTMENT' ? 'Balance Adjustment' : tx.type;
            const title = tx.description || (tx.type === 'transfer' ? 'Transfer' : cat?.name || prettyType);
            const subLeft =
              tx.type === 'transfer'
                ? `${acc?.name || 'Account'} → ${toAcc?.name || 'Account'}`
                : `${cat?.name || prettyType}${acc?.name ? ` · ${acc.name}` : ''}`;
            const amtClass =
              tx.type === 'income' ? 'text-success' : tx.type === 'expense' ? 'text-danger' : 'text-muted';
            const prefix = tx.type === 'income' ? '+' : tx.type === 'expense' ? '−' : '';
            const amtText = showBalances ? `${prefix}${formatINR(tx.amount_paise)}` : '*****';

            return `
              <div class="search-tx-card">
                <div class="search-tx-top" data-gs-edit="${tx.id}">
                  <span class="avatar-badge search-tx-icon">${escapeHtml(icon)}</span>
                  <div class="search-tx-info">
                    <div class="search-tx-title">${escapeHtml(title)}</div>
                    <div class="search-tx-sub">${escapeHtml(subLeft)}</div>
                  </div>
                  <strong class="search-tx-amt ${amtClass}">${amtText}</strong>
                </div>
                <div class="search-tx-bottom">
                  <span class="search-tx-date">${escapeHtml(tx.date_key || '')}</span>
                  <div class="search-tx-actions">
                    <button type="button" class="btn btn-secondary btn-sm" data-gs-copy="${tx.id}" title="Copy to clipboard">Copy</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-gs-paste="${tx.id}" title="Paste into ${escapeHtml(pasteLabel)}">Paste · ${escapeHtml(pasteLabel)}</button>
                  </div>
                </div>
              </div>
            `;
          })
          .join('');

        resultsEl.querySelectorAll('[data-gs-edit]').forEach((row) => {
          row.addEventListener('click', () => {
            close();
            state.txDraft = { editId: row.getAttribute('data-gs-edit'), returnRoute: window.location.hash.replace(/^#\/?/, '').split('?')[0] || 'home' };
            window.location.hash = '#/add-transaction';
          });
        });

        resultsEl.querySelectorAll('[data-gs-copy]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            await copyTransactionToClipboard(ctx, btn.getAttribute('data-gs-copy'));
            close();
          });
        });

        resultsEl.querySelectorAll('[data-gs-paste]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const txId = btn.getAttribute('data-gs-paste');
            close();
            await pasteClipboardToContext(ctx, { txId });
          });
        });
      };

      renderResults('');
      input?.focus();
      let searchTimer = null;
      input?.addEventListener('input', (e) => {
        const val = e.target.value;
        if (searchTimer) clearTimeout(searchTimer);
        searchTimer = setTimeout(() => renderResults(val), 120);
      });
    },
  });
}


/**
 * Opens a clean Long-Press Action Sheet for any transaction:
 * Copy | Make Favourite | Delete | Cancel
 */
export async function openTransactionActionSheet(ctx, txId, { onRefresh = null, onBeforeAction = null } = {}) {
  const { repos, services } = ctx;
  const tx = await services.transactions.getTransactionById(txId);
  if (!tx) {
    showToast('Transaction not found', { type: 'error' });
    return;
  }

  const [cat, acc, settings] = await Promise.all([
    tx.category_id ? repos.categories.getById(tx.category_id) : Promise.resolve(null),
    tx.account_id ? repos.accounts.getById(tx.account_id) : Promise.resolve(null),
    repos.settings.getSettings(),
  ]);

  const showBalances = settings.show_balances !== false;
  const icon = tx.type === 'transfer' ? '⇄' : tx.type === 'debt' ? '🤝' : cat?.icon || '🧾';
  const title = tx.description || (tx.type === 'transfer' ? 'Transfer' : cat?.name || 'Transaction');
  const amtPrefix = tx.type === 'income' ? '+' : tx.type === 'expense' ? '−' : '';
  const amtClass = tx.type === 'income' ? 'text-success' : tx.type === 'expense' ? 'text-danger' : 'text-muted';
  const amtText = showBalances ? `${amtPrefix}${formatINR(tx.amount_paise)}` : '*****';

  openModal({
    title: 'Transaction Options',
    bodyHtml: `
      <div class="stack" style="gap:10px;">
        <div class="card" style="padding:12px 14px; display:flex; align-items:center; justify-content:space-between; gap:10px;">
          <div class="list-row-main" style="min-width:0; flex:1;">
            <span class="avatar-badge">${escapeHtml(icon)}</span>
            <div style="min-width:0;">
              <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(title)}</div>
              <div class="item-meta">${escapeHtml(acc?.name || '')} · ${escapeHtml(formatRelativeDate(tx.date_key))}</div>
            </div>
          </div>
          <strong class="${amtClass}" style="font-variant-numeric:tabular-nums;">${escapeHtml(amtText)}</strong>
        </div>

        <div class="stack" style="gap:8px;">
          <button type="button" class="btn btn-secondary" id="tx-act-copy" style="justify-content:flex-start; padding:12px 16px; gap:10px;">
            <span>⧉</span><span>Copy transaction</span>
          </button>
          <button type="button" class="btn btn-secondary" id="tx-act-fav" style="justify-content:flex-start; padding:12px 16px; gap:10px;">
            <span>★</span><span>Make Favourite</span>
          </button>
          <button type="button" class="btn btn-danger" id="tx-act-delete" style="justify-content:flex-start; padding:12px 16px; gap:10px;">
            <span>🗑</span><span>Delete transaction</span>
          </button>
          <button type="button" class="btn btn-secondary" data-modal-close style="justify-content:center; padding:11px 16px; margin-top:2px;">
            Cancel
          </button>
        </div>
      </div>
    `,
    onMount: (panel, close) => {
      panel.querySelector('#tx-act-copy')?.addEventListener('click', async () => {
        close();
        if (typeof onBeforeAction === 'function') onBeforeAction();
        await pasteClipboardToContext(ctx, { txId: tx.id, onRefresh });
      });

      panel.querySelector('#tx-act-fav')?.addEventListener('click', async () => {
        try {
          if (tx.type === 'debt') {
            showToast('Debt ledger events cannot be saved as favourites', { type: 'warning' });
            close();
            return;
          }
          const favName = (tx.description || '').trim() || cat?.name || (tx.type === 'transfer' ? 'Transfer' : 'Quick Entry');
          await repos.favorites.createFavorite({
            name: favName,
            type: tx.type,
            amount_paise: tx.amount_paise,
            category_id: tx.type === 'transfer' ? null : tx.category_id,
            account_id: tx.account_id,
            to_account_id: tx.type === 'transfer' ? tx.to_account_id : null,
            description: tx.description || '',
            family_member_id: tx.family_member_id || null,
            tag_ids: tx.tag_ids || [],
          });
          close();
          showToast(`Saved "${favName}" to Favourites`);
          if (typeof onRefresh === 'function') await onRefresh();
        } catch (err) {
          showToast(err?.message || 'Unable to save favourite', { type: 'error' });
        }
      });

      panel.querySelector('#tx-act-delete')?.addEventListener('click', async () => {
        close();
        const undoToken = await services.transactions.softDeleteTransaction(tx.id);
        if (typeof onRefresh === 'function') await onRefresh();
        else if (typeof ctx.refreshCurrentView === 'function') await ctx.refreshCurrentView();
        if (undoToken) {
          showToast('Transaction deleted', {
            actionLabel: 'Undo',
            onAction: async () => {
              await services.transactions.restoreTransaction(undoToken);
              if (typeof onRefresh === 'function') await onRefresh();
              else if (typeof ctx.refreshCurrentView === 'function') await ctx.refreshCurrentView();
              showToast('Transaction restored');
            },
          });
        }
      });
    },
  });
}

/**
 * Attaches touch long-press (~450ms) and desktop right-click (contextmenu) to
 * transaction rows so tapping opens Edit while long-pressing opens the Action Sheet.
 */
export function bindTransactionLongPress(rootEl, ctx, { selector, attr, onRefresh = null, onBeforeAction = null } = {}) {
  if (!rootEl || !selector || !attr) return;
  rootEl.querySelectorAll(selector).forEach((el) => {
    const txId = el.getAttribute(attr);
    if (!txId) return;
    el.classList.add('tx-pressable');

    let timer = null;
    let startX = 0;
    let startY = 0;
    let longPressed = false;

    const cancel = () => {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
    };

    const trigger = () => {
      cancel();
      longPressed = true;
      el.dataset.lpJustFired = '1';
      setTimeout(() => {
        delete el.dataset.lpJustFired;
      }, 450);
      if (navigator?.vibrate) {
        try { navigator.vibrate(18); } catch {}
      }
      openTransactionActionSheet(ctx, txId, { onRefresh, onBeforeAction });
    };

    el.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return;
      longPressed = false;
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      timer = setTimeout(trigger, 460);
    }, { passive: true });

    el.addEventListener('touchmove', (e) => {
      if (!timer || e.touches.length !== 1) return;
      const dx = Math.abs(e.touches[0].clientX - startX);
      const dy = Math.abs(e.touches[0].clientY - startY);
      if (dx > 10 || dy > 10) cancel();
    }, { passive: true });

    el.addEventListener('touchend', cancel, { passive: true });
    el.addEventListener('touchcancel', cancel, { passive: true });

    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      trigger();
    });

    // Block tap-to-edit if long-press just opened the sheet
    el.addEventListener('click', (e) => {
      if (longPressed || el.dataset.lpJustFired === '1') {
        e.preventDefault();
        e.stopImmediatePropagation();
        longPressed = false;
      }
    }, true);
  });
}

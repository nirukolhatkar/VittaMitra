import { normalizeMerchantKey } from '../db/repositories/statementImportRepository.js';

/**
 * First-Class UPI Screenshot Parser (Module 2)
 *
 * Supports Indian UPI payment apps where reliably identifiable:
 * - Google Pay (GPay)
 * - PhonePe
 * - Paytm
 * - BHIM
 *
 * Handles BOTH:
 * 1. Individual transaction-detail receipt screenshots
 * 2. Multi-row transaction-history list screenshots
 *
 * Extracts: date, amount, debit/credit direction, counterparty, UPI ID (VPA),
 * UTR/reference number, and transaction status — explicitly preserving uncertainty
 * in `ambiguousFields` and setting `requiresConfirmation: true` whenever any field
 * is missing, relative, failed/pending, or ambiguous.
 */

const _UP_MONTHS = {
  jan: 1,
  feb: 2,
  mar: 3,
  apr: 4,
  may: 5,
  jun: 6,
  jul: 7,
  aug: 8,
  sep: 9,
  sept: 9,
  oct: 10,
  nov: 11,
  dec: 12,
};

function _upPad2(n) {
  return String(n).padStart(2, '0');
}

function _upParseDateFromText(text, fallbackYear = new Date().getFullYear()) {
  const str = String(text || '');
  // DD MMM YYYY or DD-MMM-YYYY (e.g. 22 Nov 2026, 22 Nov, 2026)
  let m = str.match(/\b(\d{1,2})(?:st|nd|rd|th)?[\s/-]+(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*[\s,/-]+(20\d{2}|\d{2})\b/i);
  if (m) {
    const d = Number(m[1]);
    const mo = _UP_MONTHS[m[2].toLowerCase().slice(0, 3)];
    let y = Number(m[3]);
    if (y < 100) y += 2000;
    return { dateKey: `${y}-${_upPad2(mo)}-${_upPad2(d)}`, ambiguous: false };
  }
  // MMM DD, YYYY (e.g. Nov 22, 2026)
  m = str.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\s+(\d{1,2}),?\s+(20\d{2})\b/i);
  if (m) {
    const mo = _UP_MONTHS[m[1].toLowerCase().slice(0, 3)];
    const d = Number(m[2]);
    return { dateKey: `${Number(m[3])}-${_upPad2(mo)}-${_upPad2(d)}`, ambiguous: false };
  }
  // DD/MM/YYYY or DD-MM-YYYY
  m = str.match(/\b(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2}|\d{2})\b/);
  if (m) {
    const d = Number(m[1]);
    const mo = Number(m[2]);
    let y = Number(m[3]);
    if (y < 100) y += 2000;
    if (mo >= 1 && mo <= 12 && d >= 1 && d <= 31) {
      return { dateKey: `${y}-${_upPad2(mo)}-${_upPad2(d)}`, ambiguous: false };
    }
  }
  // DD MMM without year (common in GPay / PhonePe history lists — mark date year as ambiguous!)
  m = str.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\b/i);
  if (m) {
    const d = Number(m[1]);
    const mo = _UP_MONTHS[m[2].toLowerCase().slice(0, 3)];
    return { dateKey: `${fallbackYear}-${_upPad2(mo)}-${_upPad2(d)}`, ambiguous: true };
  }
  return { dateKey: null, ambiguous: true };
}

function _upParseAmountPaise(str) {
  const clean = String(str || '')
    .replace(/,/g, '')
    .replace(/\s+/g, '');
  if (!/^\d+(?:\.\d{1,2})?$/.test(clean)) return 0;
  const num = Number(clean);
  return Number.isFinite(num) ? Math.round(num * 100) : 0;
}

export function detectUpiApp(text) {
  const s = String(text || '');
  if (/google\s*pay|gpay|google\s*transaction\s*id|upi\s*transaction\s*id|@(?:okhdfcbank|okicici|okaxis|oksbi)\b/i.test(s)) {
    return 'google_pay';
  }
  if (/phonepe|transfer\s*details|transaction\s*id\s*[:\s]*t\d{10,}|@(?:ybl|ibl|axl)\b/i.test(s)) {
    return 'phonepe';
  }
  if (/paytm|paid\s*successfully|upi\s*ref\s*no|money\s*(?:sent|received)|@(?:paytm|ptsbi|pthdfc|ptaxis)\b/i.test(s)) {
    return 'paytm';
  }
  if (/\bbhim\b|to\s*vpa|from\s*account|@upi\b/i.test(s)) {
    return 'bhim';
  }
  return 'generic_upi';
}

function _upExtractUpiId(text) {
  // Normalize common Tesseract OCR pipe/1 misreads in Indian UPI handles (@ax| -> @axl, @yb| -> @ybl, @ib| -> @ibl)
  const cleaned = String(text || '').replace(/@(ax|yb|ib|okicic|okhd)[|1]/gi, (_, p) => `@${p}l`);
  const m = cleaned.match(/\b([a-zA-Z0-9._-]{2,}@[a-zA-Z0-9]{2,})\b/);
  return m ? m[1].toLowerCase() : '';
}

function _upExtractUtr(text) {
  const s = String(text || '');
  const labelled = s.match(
    /(?:utr(?:\s*no\.?)?|upi\s*(?:transaction|txn|ref(?:erence)?)\s*(?:id|no\.?)?|transaction\s*reference|ref(?:erence)?\s*(?:id|no\.?))\s*[:#-]?\s*([A-Z0-9]{10,24})/i
  );
  if (labelled) return labelled[1].trim();
  const twelve = s.match(/\b(\d{12})\b/);
  return twelve ? twelve[1] : '';
}

function _upExtractStatus(text) {
  const s = String(text || '');
  if (/\b(failed|declined|payment\s*declined|unsuccessful|rejected|cancelled|canceled|reversed)\b/i.test(s)) {
    return { status: 'failed', ambiguous: false };
  }
  if (/\b(pending|processing|in\s*progress|awaiting)\b/i.test(s)) {
    return { status: 'pending', ambiguous: false };
  }
  if (/\b(completed|paid\s*successfully|transaction\s*successful|payment\s*successful|success|sent\s*successfully|received\s*successfully|paid\s*to)\b/i.test(s)) {
    return { status: 'completed', ambiguous: false };
  }
  return { status: 'unknown', ambiguous: true };
}

/**
 * Parses a multi-row transaction-history screenshot (GPay / PhonePe / Paytm / BHIM history feed).
 */
function _upParseHistoryLines(lines, appName) {
  const results = [];
  const amtLineRe = /([+-])?\s*(?:₹|rs\.?|inr|[=¥€£])\s*([\d,]+(?:\.\d{1,2})?)/i;
  const signedFallbackRe = /(?:^|\s)([+-])\s*(\d{1,3}(?:,\d{2,3})*(?:\.\d{1,2})?|\d{2,6}(?:\.\d{1,2})?)(?:\s|$)/;
  let currentSectionDate = null;

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    let amtMatch = line.match(amtLineRe);
    let usedSignedFallback = false;
    if (!amtMatch) {
      // Check if this line is a section date header (e.g. "22nd November", "23rd November")
      const headerDate = _upParseDateFromText(line);
      if (headerDate.dateKey && line.length <= 28) {
        currentSectionDate = headerDate;
        continue;
      }
      const sm = line.match(signedFallbackRe);
      if (sm) {
        amtMatch = sm;
        usedSignedFallback = true;
      } else {
        continue;
      }
    }
    const paise = _upParseAmountPaise(amtMatch[2]);
    if (paise <= 0) continue;

    // Combine current line with up to 2 preceding non-amount lines (e.g. Counterparty -> Date -> ₹Amount)
    const prev1 = i > 0 && !amtLineRe.test(lines[i - 1]) ? lines[i - 1] : '';
    const prev2 = i > 1 && prev1 && !amtLineRe.test(lines[i - 2]) ? lines[i - 2] : '';
    const nextLine = i + 1 < lines.length && !amtLineRe.test(lines[i + 1]) ? lines[i + 1] : '';
    const windowText = [prev2, prev1, line, nextLine].filter(Boolean).join(' | ');

    const beforeAmt = line.slice(0, amtMatch.index).trim();
    const afterAmt = line.slice((amtMatch.index || 0) + amtMatch[0].length).trim();

    // Extract date from current line, adjacent lines, or active section date header (e.g. "22nd November")
    const inlineDate = _upParseDateFromText(`${beforeAmt} ${afterAmt} ${prev1} ${nextLine}`);
    const dateInfo = inlineDate.dateKey ? inlineDate : (currentSectionDate || inlineDate);

    const cleanCounterpartyCandidate = (s) =>
      String(s || '')
        .replace(/\b\d{1,2}[\s/-]+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*(?:[\s,/-]+\d{2,4})?\b/gi, '')
        .replace(/\b\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}\b/g, '')
        .replace(/^(?:paid\s*to|received\s*from|sent\s*to|money\s*sent\s*to|money\s*received\s*from)\s*[:\-]?\s*/i, '')
        .replace(/^(?:google\s*pay|phonepe|paytm|bhim)$/i, '')
        .trim();

    let counterparty = cleanCounterpartyCandidate(beforeAmt);
    if (!counterparty && prev1) counterparty = cleanCounterpartyCandidate(prev1);
    if (!counterparty && prev2) counterparty = cleanCounterpartyCandidate(prev2);

    const ambiguousFields = [];
    if (usedSignedFallback) ambiguousFields.push('amount');
    if (!dateInfo.dateKey || dateInfo.ambiguous) ambiguousFields.push('date_key');
    if (!counterparty) ambiguousFields.push('counterparty');

    // Direction detection
    let direction = null;
    if (amtMatch[1] === '+' || /\b(received\s*from|credited|money\s*received|refund|cashback)\b/i.test(windowText)) {
      direction = 'credit';
    } else if (amtMatch[1] === '-' || /\b(paid\s*to|debited|sent\s*to|money\s*sent|paid)\b/i.test(windowText)) {
      direction = 'debit';
    } else {
      direction = 'debit';
      ambiguousFields.push('direction');
    }

    const statusInfo = _upExtractStatus(windowText);
    if (statusInfo.ambiguous || statusInfo.status !== 'completed') {
      ambiguousFields.push('tx_status');
    }

    const upiId = _upExtractUpiId(windowText);
    const utr = _upExtractUtr(windowText);

    results.push({
      upiApp: appName,
      layoutType: 'history',
      dateKey: dateInfo.dateKey,
      amountPaise: paise,
      debitPaise: direction === 'debit' ? paise : 0,
      creditPaise: direction === 'credit' ? paise : 0,
      direction,
      counterparty: counterparty || 'Unknown UPI Counterparty',
      normalizedMerchant: normalizeMerchantKey(counterparty || 'unknown'),
      upiId,
      utr,
      txStatus: statusInfo.status,
      rawNarration: windowText,
      ambiguousFields,
      requiresConfirmation: ambiguousFields.length > 0 || statusInfo.status !== 'completed',
      sourceRowIndex: i + 1,
    });
  }

  return results;
}

/**
 * Parses an individual UPI transaction-detail receipt screenshot.
 */
function _upParseDetailScreenshot(lines, appName) {
  const fullText = lines.join(' | ');
  const ambiguousFields = [];

  // 1. Amount (supports ₹, Rs., INR, plus Tesseract eng.traineddata misreads of ₹ like '= 200', '¥ 450', or standalone amount line)
  let amountPaise = 0;
  let explicitSign = '';
  let amountFromFallback = false;
  for (const line of lines) {
    const m = line.match(/([+-])?\s*(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)/i);
    if (m) {
      const p = _upParseAmountPaise(m[2]);
      if (p > 0) {
        amountPaise = p;
        explicitSign = m[1] || '';
        break;
      }
    }
  }
  if (amountPaise <= 0) {
    // Check for Tesseract ₹ glyph misreads (e.g. "= 200", "¥ 450.00", "? 1,200")
    for (const line of lines) {
      const m = line.match(/(?:^|\s)([+-])?\s*[=¥€£?]\s*([\d,]+(?:\.\d{1,2})?)(?:\s|$)/);
      if (m) {
        const p = _upParseAmountPaise(m[2]);
        if (p > 0 && p <= 100000000) {
          amountPaise = p;
          explicitSign = m[1] || '';
          amountFromFallback = true;
          break;
        }
      }
    }
  }
  if (amountPaise <= 0) {
    // Check for standalone amount line (e.g. "450.00" or "1,250" — excluding 4-digit years, phone numbers & battery %)
    for (const line of lines) {
      const m = line.match(/^([+-])?\s*(\d{1,3}(?:,\d{2,3})+(?:\.\d{1,2})?|\d{1,6}\.\d{2})$/);
      if (m) {
        const p = _upParseAmountPaise(m[2]);
        if (p > 0) {
          amountPaise = p;
          explicitSign = m[1] || '';
          amountFromFallback = true;
          break;
        }
      }
    }
  }
  if (amountPaise <= 0) return [];
  if (amountFromFallback) ambiguousFields.push('amount');

  // 2. Date
  const dateInfo = _upParseDateFromText(fullText);
  if (!dateInfo.dateKey || dateInfo.ambiguous) ambiguousFields.push('date_key');

  // 3. Direction (debit vs credit)
  let direction = null;
  if (explicitSign === '+' || /\b(received\s*from|credited\s*to|money\s*received|refund\s*from)\b/i.test(fullText)) {
    direction = 'credit';
  } else if (explicitSign === '-' || /\b(paid\s*to|sent\s*to|debited\s*from|money\s*sent|paid\s*successfully|pay\s*again)\b/i.test(fullText)) {
    direction = 'debit';
  } else {
    direction = 'debit';
    ambiguousFields.push('direction');
  }

  // 4. Counterparty
  let counterparty = '';
  for (let i = 0; i < lines.length; i += 1) {
    const inline = lines[i].match(/^(?:paid\s+to|sent\s+to|received\s+from|to\s+vpa|to\s*[:\-]|from\s*[:\-])\s*(.+)$/i);
    if (inline && inline[1].trim().length >= 2 && !/^(?:bank|account|sbi|hdfc|icici|axis|kotak)/i.test(inline[1].trim())) {
      counterparty = inline[1].trim();
      break;
    }
    if (/^(?:paid\s*to|sent\s*to|received\s*from|to)$/i.test(lines[i]) && lines[i + 1]) {
      counterparty = lines[i + 1].trim();
      break;
    }
  }
  if (!counterparty) {
    counterparty =
      lines.find(
        (l) =>
          l.length >= 2 &&
          !/^(?:₹|rs\.?|inr|\d|completed|transaction|payment|upi|utr|ref|debited|credited|google\s*pay|phonepe|paytm|bhim|transfer\s*details|paid\s*successfully)/i.test(l)
      ) || '';
  }
  if (!counterparty) ambiguousFields.push('counterparty');

  // 5. UPI ID (VPA), UTR/Reference, Status
  const upiId = _upExtractUpiId(fullText);
  const utr = _upExtractUtr(fullText);
  const statusInfo = _upExtractStatus(fullText);
  if (statusInfo.ambiguous || statusInfo.status !== 'completed') {
    ambiguousFields.push('tx_status');
  }

  return [
    {
      upiApp: appName,
      layoutType: 'detail',
      dateKey: dateInfo.dateKey,
      amountPaise,
      debitPaise: direction === 'debit' ? amountPaise : 0,
      creditPaise: direction === 'credit' ? amountPaise : 0,
      direction,
      counterparty: counterparty || 'Unknown UPI Counterparty',
      normalizedMerchant: normalizeMerchantKey(counterparty || 'unknown'),
      upiId,
      utr,
      txStatus: statusInfo.status,
      rawNarration: fullText,
      ambiguousFields,
      requiresConfirmation: ambiguousFields.length > 0 || statusInfo.status !== 'completed',
      sourceRowIndex: 1,
    },
  ];
}

/**
 * Main entrypoint: parses OCR text from a UPI app screenshot (GPay, PhonePe, Paytm, BHIM)
 * into structured transaction candidates while preserving uncertainty.
 */
/**
 * Normalizes OCR misreads of the Indian Rupee symbol (₹ -> %, =, ¥) when placed BEFORE digits
 * (e.g. "-%250" -> "-₹250", "+%500" -> "+₹500", "%236" -> "₹236"), while never altering real
 * percentages where "%" follows a number (e.g. "61%", "78%").
 */
export function normalizeOcrRupeeSymbols(text) {
  return String(text || '').replace(/(^|[\s+-])%\s*(\d[\d,]*(?:\.\d{1,2})?)/gm, '$1₹$2');
}

export function parseUpiScreenshotText(rawText) {
  const normalizedInput = normalizeOcrRupeeSymbols(rawText);
  const lines = normalizedInput
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return { upiApp: 'generic_upi', layoutType: 'unknown', transactions: [] };

  const fullText = lines.join('\n');
  const upiApp = detectUpiApp(fullText);

  // Heuristic: if text has explicit detail-screen markers (UTR / UPI Transaction ID / Transfer Details / Paid Successfully)
  // AND only 1 distinct currency amount line, parse as an individual detail receipt.
  const amountLineCount = lines.filter((l) => /(?:₹|rs\.?|inr|[=¥€£])\s*[\d,]+(?:\.\d{1,2})?/i.test(l) || /(?:^|\s)[+-]\s*\d{2,6}(?:\.\d{1,2})?(?:\s|$)/.test(l)).length;
  const hasDetailMarkers = /\b(upi\s*transaction\s*id|google\s*transaction\s*id|utr|upi\s*ref\s*no|transfer\s*details|transaction\s*successful|paid\s*successfully|transaction\s*reference|payment\s*declined|payment\s*failed)\b/i.test(
    fullText
  );

  if (amountLineCount >= 2 && !hasDetailMarkers) {
    const historyTxns = _upParseHistoryLines(lines, upiApp);
    if (historyTxns.length > 0) {
      return { upiApp, layoutType: 'history', transactions: historyTxns };
    }
  }

  const detailTxns = _upParseDetailScreenshot(lines, upiApp);
  if (detailTxns.length > 0) {
    return { upiApp, layoutType: 'detail', transactions: detailTxns };
  }

  const fallbackHistory = _upParseHistoryLines(lines, upiApp);
  return {
    upiApp,
    layoutType: fallbackHistory.length > 0 ? 'history' : 'unknown',
    transactions: fallbackHistory,
  };
}

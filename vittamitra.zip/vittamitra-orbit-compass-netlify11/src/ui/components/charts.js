import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { getCategoryColor } from '../../utils/colors.js';

function compactInr(paise) {
  const r = Math.abs(paise) / 100;
  if (r >= 10000000) return `₹${(r / 10000000).toFixed(1)}Cr`;
  if (r >= 100000) return `₹${(r / 100000).toFixed(1)}L`;
  if (r >= 1000) return `₹${(r / 1000).toFixed(1)}k`;
  return `₹${Math.round(r)}`;
}

/**
 * Bind interactive tap/click/hover tooltips to all SVG chart elements within `rootEl`.
 * Every interactive element carries `data-tip-title` and `data-tip-value`.
 */
export function bindChartTooltips(rootEl) {
  if (!rootEl) return;
  rootEl.querySelectorAll('.chart-box').forEach((box) => {
    const tip = box.querySelector('.chart-tooltip');
    if (!tip) return;
    const targets = box.querySelectorAll('[data-tip-title]');
    const showTip = (el) => {
      const title = el.getAttribute('data-tip-title') || '';
      const value = el.getAttribute('data-tip-value') || '';
      const sub = el.getAttribute('data-tip-sub') || '';
      tip.innerHTML = `<strong>${escapeHtml(title)}</strong>: ${escapeHtml(value)}${sub ? ` <span class="item-meta">(${escapeHtml(sub)})</span>` : ''}`;
      tip.classList.remove('hidden');
      targets.forEach((t) => t.classList.remove('chart-active-mark'));
      el.classList.add('chart-active-mark');
    };
    targets.forEach((el) => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        showTip(el);
      });
      el.addEventListener('mouseenter', () => showTip(el));
    });
  });
}

/**
 * Offline, high-DPI SVG Doughnut Chart with uniform category colors and interactive tap tooltips.
 */
export function renderDoughnutChartSvg(rows, { totalPaise = 0, centerLabel = 'Total', showBalances = true } = {}) {
  if (!rows || rows.length === 0 || totalPaise <= 0) {
    return `<div class="item-meta" style="text-align:center; padding:24px 0;">No data to chart in this period.</div>`;
  }

  const size = 216;
  const cx = size / 2;
  const cy = size / 2;
  const radius = 78;
  const strokeWidth = 30;
  const circumference = 2 * Math.PI * radius;

  const top = rows.slice(0, 9).map((r) => ({
    label: r.category.name,
    value: r.total,
    color: getCategoryColor(r.category),
  }));
  if (rows.length > 9) {
    const restSum = rows.slice(9).reduce((s, r) => s + r.total, 0);
    if (restSum > 0) top.push({ label: 'Others', value: restSum, color: '#64748b' });
  }

  let offset = 0;
  const arcs = top.map((slice) => {
    const frac = slice.value / totalPaise;
    const len = Math.max(0, frac * circumference - 1.5);
    const dashArray = `${len.toFixed(2)} ${(circumference - len).toFixed(2)}`;
    const dashOffset = (-offset).toFixed(2);
    offset += frac * circumference;
    const valStr = showBalances ? formatINR(slice.value) : '*****';
    return `<circle cx="${cx}" cy="${cy}" r="${radius}" fill="none" stroke="${escapeHtml(slice.color)}"
      stroke-width="${strokeWidth}" stroke-dasharray="${dashArray}" stroke-dashoffset="${dashOffset}"
      transform="rotate(-90 ${cx} ${cy})" style="cursor:pointer;"
      data-tip-title="${escapeHtml(slice.label)}" data-tip-value="${escapeHtml(valStr)}" data-tip-sub="${(frac * 100).toFixed(1)}%">
      <title>${escapeHtml(slice.label)}: ${escapeHtml(valStr)} (${(frac * 100).toFixed(1)}%)</title>
    </circle>`;
  });

  return `
    <div class="chart-box">
      <div class="chart-tooltip hidden"></div>
      <div style="display:flex; justify-content:center; padding:4px 0 6px;">
        <svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img" aria-label="Category distribution chart">
          <circle cx="${cx}" cy="${cy}" r="${radius}" fill="none" stroke="var(--bg-surface-elevated)" stroke-width="${strokeWidth}"/>
          ${arcs.join('')}
          <text x="${cx}" y="${cy - 4}" text-anchor="middle" fill="var(--text-muted)" font-size="11" font-weight="600">${escapeHtml(centerLabel)}</text>
          <text x="${cx}" y="${cy + 16}" text-anchor="middle" fill="var(--text-primary)" font-size="15" font-weight="700">${showBalances ? escapeHtml(compactInr(totalPaise)) : '*****'}</text>
        </svg>
      </div>
      <div class="item-meta" style="text-align:center; font-size:0.72rem;">Tap any slice for exact value</div>
    </div>
  `;
}

/**
 * Offline SVG Cumulative Trend Line Chart with interactive tap/hover tooltips per date point.
 */
export function renderCumulativeTrendSvg({
  keys = [],
  labels = [],
  current = [],
  previous = [],
  elapsedCount = null,
  projectedEnd = null,
  showCompare = true,
  accentColor = '#f46978',
  showBalances = true,
}) {
  if (!labels.length) return '';
  const w = 340;
  const h = 154;
  const padL = 44;
  const padR = 12;
  const padT = 14;
  const padB = 24;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const maxVal = Math.max(100, ...current, ...(showCompare ? previous : []), projectedEnd || 0);
  const count = Math.max(1, labels.length);
  const xFor = (i) => padL + (count === 1 ? plotW / 2 : (i / (count - 1)) * plotW);
  const yFor = (v) => padT + plotH - (v / maxVal) * plotH;

  const validLen = elapsedCount ? Math.min(elapsedCount, current.length) : current.length;
  const currPoints = current.slice(0, validLen).map((v, i) => `${xFor(i).toFixed(1)},${yFor(v).toFixed(1)}`).join(' ');

  let prevPath = '';
  if (showCompare && previous.length > 0) {
    const prevPoints = previous.slice(0, count).map((v, i) => `${xFor(i).toFixed(1)},${yFor(v).toFixed(1)}`).join(' ');
    prevPath = `<polyline fill="none" stroke="#60a5fa" stroke-width="2" stroke-opacity="0.7" points="${prevPoints}" />`;
  }

  let projLine = '';
  if (projectedEnd && validLen > 0 && validLen < count) {
    const x1 = xFor(validLen - 1).toFixed(1);
    const y1 = yFor(current[validLen - 1]).toFixed(1);
    const x2 = xFor(count - 1).toFixed(1);
    const y2 = yFor(projectedEnd).toFixed(1);
    projLine = `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#fbbf24" stroke-width="2" stroke-dasharray="4 4" />
      <circle cx="${x2}" cy="${y2}" r="4" fill="#fbbf24" style="cursor:pointer;"
        data-tip-title="Projected Month-End" data-tip-value="${showBalances ? escapeHtml(formatINR(projectedEnd)) : '*****'}" />`;
  }

  // Interactive invisible vertical hit-columns + visible dot markers on tap/hover
  const slotW = plotW / count;
  const hitZones = current.slice(0, validLen).map((v, i) => {
    const cx = xFor(i);
    const cy = yFor(v);
    const dateLbl = keys[i] || labels[i];
    const valStr = showBalances ? formatINR(v) : '*****';
    const prevStr =
      showCompare && previous[i] !== undefined
        ? `Prev: ${showBalances ? formatINR(previous[i]) : '*****'}`
        : '';
    return `<g style="cursor:pointer;" data-tip-title="${escapeHtml(dateLbl)}" data-tip-value="${escapeHtml(valStr)}" data-tip-sub="${escapeHtml(prevStr)}">
      <rect x="${(cx - slotW / 2).toFixed(1)}" y="${padT}" width="${Math.max(8, slotW).toFixed(1)}" height="${plotH}" fill="transparent"/>
      <circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="2.8" fill="${escapeHtml(accentColor)}" opacity="0.85"/>
    </g>`;
  });

  const gridLines = [0, 0.5, 1].map((f) => {
    const y = (padT + plotH - f * plotH).toFixed(1);
    const val = Math.round(maxVal * f);
    return `<line x1="${padL}" y1="${y}" x2="${w - padR}" y2="${y}" stroke="var(--border-subtle)" stroke-width="1"/>
      <text x="${padL - 6}" y="${Number(y) + 3}" text-anchor="end" fill="var(--text-muted)" font-size="9">${showBalances ? escapeHtml(compactInr(val)) : '***'}</text>`;
  });

  const step = Math.max(1, Math.ceil(count / 6));
  const xLabels = [];
  for (let i = 0; i < count; i += step) {
    xLabels.push(`<text x="${xFor(i).toFixed(1)}" y="${h - 6}" text-anchor="middle" fill="var(--text-muted)" font-size="9">${escapeHtml(labels[i])}</text>`);
  }

  return `
    <div class="chart-box">
      <div class="chart-tooltip hidden"></div>
      <svg viewBox="0 0 ${w} ${h}" width="100%" style="max-height:180px; display:block;" role="img" aria-label="Cumulative trend chart">
        ${gridLines.join('')}
        ${prevPath}
        ${currPoints ? `<polyline fill="none" stroke="${escapeHtml(accentColor)}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" points="${currPoints}" />` : ''}
        ${projLine}
        ${hitZones.join('')}
        ${xLabels.join('')}
      </svg>
    </div>
  `;
}

/**
 * Offline SVG Bar Chart with dashed Average line and interactive tap/hover tooltips per bar.
 */
export function renderBarChartSvg({
  keys = [],
  labels = [],
  values = [],
  avgValue = 0,
  barColor = '#f46978',
  showBalances = true,
}) {
  if (!labels.length) return '';
  const w = 340;
  const h = 144;
  const padL = 44;
  const padR = 10;
  const padT = 14;
  const padB = 24;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const maxVal = Math.max(100, ...values, avgValue || 0);
  const count = labels.length;
  const slotW = plotW / count;
  const barW = Math.max(3, Math.min(22, slotW * 0.68));

  const bars = values.map((v, i) => {
    const bh = (v / maxVal) * plotH;
    const x = padL + i * slotW + (slotW - barW) / 2;
    const y = padT + plotH - bh;
    const tipTitle = keys[i] || labels[i];
    const tipVal = showBalances ? formatINR(v) : '*****';
    return `<g style="cursor:pointer;" data-tip-title="${escapeHtml(tipTitle)}" data-tip-value="${escapeHtml(tipVal)}">
      <rect x="${(padL + i * slotW).toFixed(1)}" y="${padT}" width="${slotW.toFixed(1)}" height="${plotH}" fill="transparent"/>
      <rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(0, bh).toFixed(1)}" rx="2.5" fill="${escapeHtml(barColor)}" opacity="0.9"/>
    </g>`;
  });

  const avgY = (padT + plotH - (avgValue / maxVal) * plotH).toFixed(1);
  const avgLine =
    avgValue > 0
      ? `<line x1="${padL}" y1="${avgY}" x2="${w - padR}" y2="${avgY}" stroke="#60a5fa" stroke-width="1.2" stroke-dasharray="3 3"/>
         <text x="${w - padR}" y="${Math.max(11, Number(avgY) - 4)}" text-anchor="end" fill="#60a5fa" font-size="9" font-weight="600">Avg ${showBalances ? escapeHtml(compactInr(avgValue)) : '***'}</text>`
      : '';

  const gridLines = [0, 0.5, 1].map((f) => {
    const y = (padT + plotH - f * plotH).toFixed(1);
    const val = Math.round(maxVal * f);
    return `<line x1="${padL}" y1="${y}" x2="${w - padR}" y2="${y}" stroke="var(--border-subtle)" stroke-width="1"/>
      <text x="${padL - 6}" y="${Number(y) + 3}" text-anchor="end" fill="var(--text-muted)" font-size="9">${showBalances ? escapeHtml(compactInr(val)) : '***'}</text>`;
  });

  const step = Math.max(1, Math.ceil(count / 7));
  const xLabels = [];
  for (let i = 0; i < count; i += step) {
    const x = padL + i * slotW + slotW / 2;
    xLabels.push(`<text x="${x.toFixed(1)}" y="${h - 6}" text-anchor="middle" fill="var(--text-muted)" font-size="9">${escapeHtml(labels[i])}</text>`);
  }

  return `
    <div class="chart-box">
      <div class="chart-tooltip hidden"></div>
      <svg viewBox="0 0 ${w} ${h}" width="100%" style="max-height:170px; display:block;" role="img" aria-label="Period bar chart">
        ${gridLines.join('')}
        ${bars.join('')}
        ${avgLine}
        ${xLabels.join('')}
      </svg>
    </div>
  `;
}

import { escapeHtml } from '../../utils/dom.js';

/**
 * Accessible modal & bottom-sheet helper with focus trap, trigger focus restoration,
 * and floating-dock suppression (body.modal-open).
 * - variant: 'sheet' -> mobile bottom sheet (<= 75vh, drag handle) for pickers & confirmations
 * - variant: 'modal' -> full-height mobile sheet (<= 94dvh) for complex multi-field forms
 */
export function openModal({ title, bodyHtml, onMount, variant = 'modal' }) {
  const root = document.getElementById('modal-root');
  if (!root) return;

  const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  if (typeof root._cleanup === 'function') {
    root._cleanup();
    root._cleanup = null;
  }

  const isSheet = variant === 'sheet';
  root.classList.toggle('modal-variant-sheet', isSheet);
  root.innerHTML = `
    <div class="modal-panel ${isSheet ? 'modal-sheet' : 'modal-full'}" role="document">
      ${isSheet ? '<div class="sheet-handle" aria-hidden="true"></div>' : ''}
      <div class="modal-header">
        <h2 class="modal-title">${escapeHtml(title)}</h2>
        <button type="button" class="icon-btn" data-modal-close aria-label="Close">✕</button>
      </div>
      <div class="modal-body">${bodyHtml}</div>
    </div>
  `;

  root.classList.remove('hidden');
  root.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');

  const panel = root.querySelector('.modal-panel');
  const getFocusable = () =>
    Array.from(
      panel.querySelectorAll(
        'button:not([disabled]), [href], input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
    ).filter((el) => el.offsetParent !== null);

  const handleBackdrop = (e) => {
    if (e.target === root || e.target.closest('[data-modal-close]')) {
      closeModal();
    }
  };
  const handleKey = (e) => {
    if (e.key === 'Escape') {
      closeModal();
      return;
    }
    if (e.key === 'Tab') {
      const focusables = getFocusable();
      if (focusables.length === 0) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };

  root._previousFocus = previousFocus;
  root._cleanup = () => {
    root.removeEventListener('click', handleBackdrop);
    window.removeEventListener('keydown', handleKey);
  };

  root.addEventListener('click', handleBackdrop);
  window.addEventListener('keydown', handleKey);

  if (typeof onMount === 'function') {
    onMount(panel, closeModal);
  }

  // Move initial focus inside dialog if onMount didn't already focus an input
  if (!panel.contains(document.activeElement)) {
    const focusables = getFocusable();
    if (focusables.length > 0) focusables[0].focus();
  }
}

export function openSheet(opts) {
  return openModal({ ...opts, variant: 'sheet' });
}

export function closeModal() {
  const root = document.getElementById('modal-root');
  if (!root) return;
  if (typeof root._cleanup === 'function') {
    root._cleanup();
    root._cleanup = null;
  }
  const prev = root._previousFocus;
  root._previousFocus = null;
  root.classList.add('hidden');
  root.classList.remove('modal-variant-sheet');
  root.setAttribute('aria-hidden', 'true');
  root.innerHTML = '';
  document.body.classList.remove('modal-open');
  if (prev && typeof prev.focus === 'function' && document.contains(prev)) {
    try {
      prev.focus();
    } catch {
      // ignore
    }
  }
}

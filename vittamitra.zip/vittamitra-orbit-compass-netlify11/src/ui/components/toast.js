/**
 * Toast notification component with optional Undo / Action button.
 */

export function showToast(message, { type = 'info', durationMs = 3000, actionLabel = null, onAction = null } = {}) {
  const root = document.getElementById('toast-root');
  if (!root) return;

  const el = document.createElement('div');
  el.className = `toast ${type === 'error' ? 'toast-error' : ''}`;
  el.style.pointerEvents = 'auto';
  el.style.display = 'flex';
  el.style.alignItems = 'center';
  el.style.justifyContent = 'space-between';
  el.style.gap = '12px';

  const msgSpan = document.createElement('span');
  msgSpan.textContent = message;
  msgSpan.style.textAlign = 'left';
  el.appendChild(msgSpan);

  let timer = null;
  if (actionLabel && typeof onAction === 'function') {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'toast-action-btn';
    btn.textContent = actionLabel;
    btn.addEventListener('click', async () => {
      if (timer) clearTimeout(timer);
      el.remove();
      await onAction();
    });
    el.appendChild(btn);
  }

  root.appendChild(el);
  const timeout = actionLabel ? Math.max(durationMs, 6000) : durationMs;
  timer = setTimeout(() => {
    el.remove();
  }, timeout);
}

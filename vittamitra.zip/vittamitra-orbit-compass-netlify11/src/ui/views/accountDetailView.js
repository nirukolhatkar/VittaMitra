import { getAccountTypeMeta, isLiabilityAccount } from '../../constants/accountTypes.js';
import { AccountRepository } from '../../db/repositories/accountRepository.js';
import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString, parseRupeesToPaise } from '../../utils/money.js';
import { formatRelativeDate, toLocalDateString } from '../../utils/date.js';
import { generateUUID } from '../../utils/uuid.js';
import {
  bindTransactionLongPress,
  openAddTransactionWithContext,
  pasteClipboardToContext,
  setPageContext,
} from '../../services/txContextClipboard.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const accountDetailState = {
  tab: 'all', // 'all' | 'credit' | 'debit' | 'adjustments'
  asOfDate: toLocalDateString(),
  pageSize: 50,
  lastAccountId: null,
};

function fmtBal(paise, show) {
  return show ? formatINR(paise) : '*****';
}

/**
 * Reusable Adjust Balance (As-On-Date) Modal with live difference calculation,
 * historical impact warning, zero-difference guard, idempotency protection,
 * and explicit confirmation step before saving.
 */
export async function openAdjustBalanceModal(
  ctx,
  accountId,
  { existingAdjustment = null, initialDate = toLocalDateString(), onSaved = null } = {}
) {
  const { repos, services } = ctx;
  const account = await repos.accounts.getById(accountId);
  if (!account) {
    showToast('Account not found', { type: 'error' });
    return;
  }

  const isEdit = Boolean(existingAdjustment);
  const isCC = isLiabilityAccount(account);
  const idempotencyKey = generateUUID();

  let adjDate = existingAdjustment?.date_key || initialDate || toLocalDateString();
  let actualInputText = existingAdjustment
    ? paiseToDecimalString(existingAdjustment.target_balance_paise ?? 0)
    : '';
  let notesText = existingAdjustment?.notes || '';
  let step = 'form'; // 'form' | 'confirm'
  let currentPreview = null;
  let submitting = false;

  const renderStep = async (panel, close) => {
    const body = panel.querySelector('.modal-body');
    const calcAccount = await repos.accounts.getReconciledAccountAsOf(account.id, adjDate);
    let baseCalculatedPaise = calcAccount?.current_balance_paise ?? 0;

    if (isEdit && existingAdjustment) {
      try {
        const p = await services.transactions.previewBalanceAdjustment({
          account_id: account.id,
          date: adjDate,
          actual_balance_paise: existingAdjustment.target_balance_paise ?? 0,
          excludeTxId: existingAdjustment.id,
        });
        baseCalculatedPaise = p.calculatedAsOfPaise;
      } catch {
        // fallback to baseCalculatedPaise
      }
    }

    if (step === 'confirm' && currentPreview) {
      const isInc = currentPreview.deltaPaise > 0;
      const deltaAbs = formatINR(Math.abs(currentPreview.deltaPaise));
      const deltaSigned = `${isInc ? '+' : '−'}${deltaAbs}`;
      const badgeClass = isInc ? 'text-success' : 'text-danger';
      const dirText = isCC
        ? isInc
          ? 'Increase Outstanding Liability'
          : 'Decrease Outstanding Liability'
        : isInc
          ? 'Increase Balance'
          : 'Decrease Balance';

      body.innerHTML = `
        <div class="stack" style="gap:12px;">
          <div class="card" style="padding:14px;">
            <div class="item-meta">Account</div>
            <div class="item-title" style="margin-top:2px;">${escapeHtml(account.icon || '🏛️')} ${escapeHtml(account.name)}</div>
            <div class="item-meta" style="margin-top:8px;">Adjustment Date</div>
            <div class="item-title" style="margin-top:2px;">${escapeHtml(formatRelativeDate(currentPreview.date))} (${escapeHtml(currentPreview.date)})</div>
          </div>

          <div class="card stack" style="padding:14px; gap:8px;">
            <div style="display:flex; justify-content:space-between; font-size:0.86rem;">
              <span class="text-secondary">System calculated (${escapeHtml(currentPreview.date)})</span>
              <strong style="font-variant-numeric:tabular-nums;">${formatINR(currentPreview.calculatedAsOfPaise)}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:0.86rem;">
              <span class="text-secondary">Actual ${isCC ? 'outstanding' : 'balance'} entered</span>
              <strong style="font-variant-numeric:tabular-nums;">${formatINR(currentPreview.actualPaise)}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; padding-top:8px; border-top:1px solid var(--border-subtle);">
              <div>
                <div style="font-size:0.84rem; font-weight:600;">Adjustment (${dirText})</div>
                <div class="item-meta">Recorded as BALANCE_ADJUSTMENT (excluded from income/expense)</div>
              </div>
              <strong class="${badgeClass}" style="font-size:1.1rem; font-variant-numeric:tabular-nums;">${deltaSigned}</strong>
            </div>
          </div>

          ${
            currentPreview.hasSubsequentTransactions
              ? `<div class="alert-banner alert-warning" style="padding:10px 12px; font-size:0.8rem; line-height:1.4;">
                  <span>⚠️ <strong>Historical balance impact:</strong> Transactions exist after ${escapeHtml(currentPreview.date)} (net ${currentPreview.subsequentNetPaise >= 0 ? '+' : '−'}${formatINR(Math.abs(currentPreview.subsequentNetPaise))}). Your projected current ${isCC ? 'outstanding' : 'balance'} will become <strong>${formatINR(currentPreview.projectedCurrentBalancePaise)}</strong>.</span>
                </div>`
              : ''
          }

          ${
            notesText
              ? `<div class="item-meta">Note: <strong>${escapeHtml(notesText)}</strong></div>`
              : ''
          }

          <div class="modal-footer" style="justify-content:space-between;">
            <button type="button" class="btn btn-secondary" id="btn-adj-back">← Back</button>
            <button type="button" class="btn btn-primary" id="btn-adj-confirm">${isEdit ? 'Confirm Update' : 'Confirm Adjustment'}</button>
          </div>
        </div>
      `;

      body.querySelector('#btn-adj-back')?.addEventListener('click', () => {
        step = 'form';
        renderStep(panel, close);
      });

      body.querySelector('#btn-adj-confirm')?.addEventListener('click', async (ev) => {
        if (submitting) return;
        submitting = true;
        ev.currentTarget.disabled = true;
        try {
          if (isEdit) {
            await services.transactions.updateBalanceAdjustment(existingAdjustment.id, {
              date: currentPreview.date,
              actual_balance_paise: currentPreview.actualPaise,
              notes: notesText,
            });
            showToast('Balance adjustment updated');
          } else {
            await services.transactions.createBalanceAdjustment({
              account_id: account.id,
              date: currentPreview.date,
              actual_balance_paise: currentPreview.actualPaise,
              notes: notesText,
              idempotency_key: idempotencyKey,
            });
            showToast('Balance adjusted');
          }
          close();
          if (typeof onSaved === 'function') await onSaved();
        } catch (err) {
          submitting = false;
          ev.currentTarget.disabled = false;
          showToast(err?.message || 'Unable to save balance adjustment', { type: 'error' });
        }
      });
      return;
    }

    body.innerHTML = `
      <form id="adj-balance-form" class="stack" style="gap:12px;">
        <div class="card" style="padding:12px 14px; display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div class="item-meta">Account</div>
            <div class="item-title">${escapeHtml(account.icon || '🏛️')} ${escapeHtml(account.name)}</div>
          </div>
          <div style="text-align:right;">
            <div class="item-meta">Calculated as on ${escapeHtml(formatRelativeDate(adjDate))}</div>
            <strong id="adj-calc-val" style="font-variant-numeric:tabular-nums;">${formatINR(baseCalculatedPaise)}</strong>
          </div>
        </div>

        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" for="adj-date">Adjustment Date</label>
          <input id="adj-date" type="date" class="form-control" required value="${escapeHtml(adjDate)}">
        </div>

        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" for="adj-actual">${isCC ? 'Actual Outstanding as on date (₹)' : 'Actual Balance as on date (₹)'}</label>
          <input id="adj-actual" class="form-control" inputmode="decimal" required
            placeholder="${paiseToDecimalString(baseCalculatedPaise)}" value="${escapeHtml(actualInputText)}">
        </div>

        <div id="adj-live-diff" class="card" style="padding:10px 14px; background:var(--bg-surface-elevated);">
          <div class="item-meta">Enter the actual ${isCC ? 'outstanding' : 'balance'} to preview the adjustment difference.</div>
        </div>

        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" for="adj-notes">Reason / Notes (optional)</label>
          <input id="adj-notes" class="form-control" maxlength="160"
            placeholder="e.g. Bank statement reconciliation" value="${escapeHtml(notesText)}">
        </div>

        <div class="modal-footer" style="justify-content:space-between; flex-wrap:wrap;">
          ${
            isEdit
              ? `<button type="button" class="btn btn-danger btn-sm" id="btn-adj-delete">Delete</button>`
              : '<div></div>'
          }
          <div class="row-actions">
            <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
            <button type="submit" class="btn btn-primary">Review Adjustment</button>
          </div>
        </div>
      </form>
    `;

    const dateInput = body.querySelector('#adj-date');
    const actualInput = body.querySelector('#adj-actual');
    const notesInput = body.querySelector('#adj-notes');
    const diffBox = body.querySelector('#adj-live-diff');

    const updateLiveDiff = async () => {
      const raw = actualInput.value.trim();
      actualInputText = raw;
      if (!raw) {
        diffBox.innerHTML = `<div class="item-meta">Enter the actual ${isCC ? 'outstanding' : 'balance'} to preview the adjustment difference.</div>`;
        return;
      }
      try {
        const preview = await services.transactions.previewBalanceAdjustment({
          account_id: account.id,
          date: adjDate,
          actual_balance_rupees: raw,
          excludeTxId: isEdit ? existingAdjustment.id : null,
        });
        if (preview.deltaPaise === 0) {
          diffBox.innerHTML = `<div class="item-meta">✓ No difference — actual balance already matches calculated balance (${formatINR(preview.calculatedAsOfPaise)}).</div>`;
          return;
        }
        const isInc = preview.deltaPaise > 0;
        const badgeCls = isInc ? 'text-success' : 'text-danger';
        const label = isCC
          ? isInc
            ? 'Increase Outstanding'
            : 'Decrease Outstanding'
          : isInc
            ? 'Increase Balance'
            : 'Decrease Balance';
        diffBox.innerHTML = `
          <div style="display:flex; justify-content:space-between; align-items:center; gap:8px;">
            <span style="font-size:0.84rem; font-weight:600;">${label}</span>
            <strong class="${badgeCls}" style="font-size:1.02rem; font-variant-numeric:tabular-nums;">
              ${isInc ? '+' : '−'}${formatINR(Math.abs(preview.deltaPaise))}
            </strong>
          </div>
          ${
            preview.hasSubsequentTransactions
              ? `<div class="item-meta" style="margin-top:4px;">Projected current balance after later entries: <strong>${formatINR(preview.projectedCurrentBalancePaise)}</strong></div>`
              : ''
          }
        `;
      } catch {
        diffBox.innerHTML = `<div class="text-danger" style="font-size:0.8rem;">Enter a valid numeric amount (e.g. 50000 or -1200.50).</div>`;
      }
    };

    dateInput?.addEventListener('change', (e) => {
      if (e.target.value) {
        adjDate = e.target.value;
        renderStep(panel, close);
      }
    });
    actualInput?.addEventListener('input', updateLiveDiff);
    notesInput?.addEventListener('input', (e) => {
      notesText = e.target.value;
    });
    if (actualInputText) updateLiveDiff();

    body.querySelector('#btn-adj-delete')?.addEventListener('click', async () => {
      const undoToken = await services.transactions.softDeleteTransaction(existingAdjustment.id);
      close();
      if (typeof onSaved === 'function') await onSaved();
      if (undoToken) {
        showToast('Balance adjustment deleted', {
          actionLabel: 'Undo',
          onAction: async () => {
            await services.transactions.restoreTransaction(undoToken);
            if (typeof onSaved === 'function') await onSaved();
            showToast('Balance adjustment restored');
          },
        });
      }
    });

    body.querySelector('#adj-balance-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        const preview = await services.transactions.previewBalanceAdjustment({
          account_id: account.id,
          date: adjDate,
          actual_balance_rupees: actualInput.value.trim(),
          excludeTxId: isEdit ? existingAdjustment.id : null,
        });
        if (preview.deltaPaise === 0) {
          showToast('Actual balance already matches calculated balance — no adjustment needed', { type: 'info' });
          return;
        }
        currentPreview = preview;
        step = 'confirm';
        renderStep(panel, close);
      } catch (err) {
        showToast(err?.message || 'Invalid balance or date', { type: 'error' });
      }
    });
  };

  openModal({
    title: isEdit ? 'Edit Balance Adjustment' : 'Adjust Balance',
    bodyHtml: '<div class="loading-state">Calculating balance…</div>',
    onMount: (panel, close) => {
      renderStep(panel, close);
    },
  });
}

/**
 * Dedicated Account Detail Page (#/account-detail) matching reference screenshot 61002.jpg
 * (excluding "+ Link a payment mode" and excluding Opening Balance card).
 */
export async function renderAccountDetailView(container, ctx) {
  const { repos, services, state } = ctx;
  const accountId = state.selectedAccountId;
  if (!accountId) {
    window.location.hash = '#/accounts';
    return;
  }

  if (accountDetailState.lastAccountId !== accountId) {
    accountDetailState.lastAccountId = accountId;
    accountDetailState.tab = 'all';
    accountDetailState.asOfDate = toLocalDateString();
    accountDetailState.pageSize = 50;
  }

  const [settings, acc, categories, accounts] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.getReconciledAccountAsOf(accountId, accountDetailState.asOfDate),
    repos.categories.list({ includeArchived: true }),
    repos.accounts.list({ includeArchived: true }),
  ]);

  if (!acc) {
    window.location.hash = '#/accounts';
    return;
  }

  const titleEl = document.getElementById('topbar-title');
  if (titleEl) titleEl.textContent = acc.name;

  setPageContext(ctx, {
    route: 'account-detail',
    label: acc.name,
    shortLabel: acc.name.slice(0, 12),
    accountName: acc.name,
    overrides: { account_id: acc.id, date: accountDetailState.asOfDate },
    onPasteRefresh: () => renderAccountDetailView(container, ctx),
  });

  const allTxs = await services.transactions.listTransactions({
    accountId: acc.id,
    endDate: accountDetailState.asOfDate,
    sort: 'desc',
  });

  const showBalances = settings.show_balances !== false;
  const catMap = new Map(categories.map((c) => [c.id, c]));
  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const meta = getAccountTypeMeta(acc.type);
  const isCC = isLiabilityAccount(acc);
  const cc = isCC ? AccountRepository.getCreditCardMetrics(acc) : null;
  const displayBalPaise = isCC ? cc.outstandingPaise : acc.current_balance_paise;
  const isBalNeg = !isCC && displayBalPaise < 0;

  // Determine whether each transaction is Credit (inflow/reduces CC due) or Debit (outflow/increases CC due) for THIS account
  const classifyAccountFlow = (tx) => {
    if (tx.type === 'BALANCE_ADJUSTMENT') {
      const delta = tx.adjustment_delta_paise ?? 0;
      return {
        kind: 'adjustment',
        isPositiveEffect: isCC ? delta < 0 : delta > 0,
        signedPrefix: delta > 0 ? '+' : '−',
      };
    }
    if (tx.type === 'income') {
      return { kind: 'credit', isPositiveEffect: true, signedPrefix: '+' };
    }
    if (tx.type === 'expense') {
      return { kind: 'debit', isPositiveEffect: false, signedPrefix: '−' };
    }
    if (tx.type === 'transfer') {
      const isIncoming = tx.to_account_id === acc.id;
      return {
        kind: isIncoming ? 'credit' : 'debit',
        isPositiveEffect: isIncoming,
        signedPrefix: isIncoming ? '+' : '−',
      };
    }
    // Debt ledger events
    const isInflow = tx.debt_event_type === 'PRINCIPAL_RECEIVED' || tx.debt_event_type === 'BORROWED';
    return {
      kind: isInflow ? 'credit' : 'debit',
      isPositiveEffect: isInflow,
      signedPrefix: isInflow ? '+' : '−',
    };
  };

  const filteredTxs = allTxs.filter((tx) => {
    if (accountDetailState.tab === 'all') return true;
    const flow = classifyAccountFlow(tx);
    if (accountDetailState.tab === 'adjustments') return flow.kind === 'adjustment';
    if (accountDetailState.tab === 'credit') return flow.kind === 'credit';
    if (accountDetailState.tab === 'debit') return flow.kind === 'debit';
    return true;
  });

  const visibleTxs = filteredTxs.slice(0, accountDetailState.pageSize);
  const adjCount = allTxs.filter((t) => t.type === 'BALANCE_ADJUSTMENT').length;

  container.innerHTML = `
    <div class="stack" style="gap:16px;">
      <!-- Account Hero Balance Card (No Opening Balance, No Link Payment Mode) -->
      <section class="card" style="padding:18px; border-radius:var(--radius-lg);">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:10px;">
          <div style="min-width:0;">
            <div style="font-size:0.82rem; font-weight:500; color:var(--text-secondary);">
              ${isCC ? 'Current Outstanding' : 'Available Balance'}
            </div>
            <div class="${isCC ? (displayBalPaise > 0 ? 'text-danger' : '') : (isBalNeg ? 'text-danger' : '')}" style="font-size:clamp(1.45rem, 5.5vw, 1.9rem); font-weight:700; font-variant-numeric:tabular-nums; letter-spacing:-0.02em; margin-top:4px; overflow-wrap:anywhere;">
              ${fmtBal(displayBalPaise, showBalances)}
            </div>
            ${
              isCC && cc.limitPaise > 0
                ? `<div class="item-meta" style="margin-top:4px;">Available Credit: <strong>${fmtBal(cc.availableCreditPaise, showBalances)}</strong> of ${fmtBal(cc.limitPaise, showBalances)}</div>`
                : ''
            }
          </div>
          <div style="text-align:right; flex-shrink:0;">
            <label for="acc-detail-asof" class="item-meta" style="display:block; font-size:0.7rem; margin-bottom:4px;">As on date</label>
            <input id="acc-detail-asof" type="date" class="form-control" style="padding:5px 8px; font-size:0.78rem; width:auto;" value="${escapeHtml(accountDetailState.asOfDate)}">
          </div>
        </div>

        <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-top:14px; padding-top:12px; border-top:1px solid var(--border-subtle);">
          <div style="display:flex; align-items:center; gap:6px; font-size:0.84rem; color:var(--text-secondary);">
            <span>Incorrect balance?</span>
            <button type="button" id="btn-acc-adjust" style="background:none; border:none; padding:4px 2px; color:var(--accent-ink); font-weight:700; cursor:pointer; font-size:0.86rem;">
              Adjust Balance
            </button>
          </div>
          <div class="row-actions" style="gap:6px;">
            ${state.clipboardTx ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-acc-paste">📋 Paste</button>` : ''}
            <button type="button" class="btn btn-secondary btn-sm" id="btn-acc-edit-meta">Edit Account</button>
          </div>
        </div>
      </section>

      <!-- 4-Tab Bar: All | Credit | Debit | Adjustments -->
      <div class="segmented" role="tablist" aria-label="Account transaction filter" style="width:100%; justify-content:space-between;">
        <button type="button" style="flex:1;" data-ad-tab="all" class="${accountDetailState.tab === 'all' ? 'active' : ''}">All (${allTxs.length})</button>
        <button type="button" style="flex:1;" data-ad-tab="credit" class="${accountDetailState.tab === 'credit' ? 'active' : ''}">Credit</button>
        <button type="button" style="flex:1;" data-ad-tab="debit" class="${accountDetailState.tab === 'debit' ? 'active' : ''}">Debit</button>
        <button type="button" style="flex:1;" data-ad-tab="adjustments" class="${accountDetailState.tab === 'adjustments' ? 'active' : ''}">Adjustments${adjCount ? ` (${adjCount})` : ''}</button>
      </div>

      <!-- Full Account Transactions List -->
      ${
        visibleTxs.length === 0
          ? `<div class="empty-state">
              <div class="empty-state-icon">${accountDetailState.tab === 'adjustments' ? '⚖️' : '🧾'}</div>
              <div class="empty-state-title">No ${accountDetailState.tab === 'all' ? '' : accountDetailState.tab + ' '}transactions</div>
              <div class="empty-state-text">
                ${
                  accountDetailState.tab === 'adjustments'
                    ? 'Tap Adjust Balance above if your account balance needs a correction.'
                    : `No entries recorded for ${escapeHtml(acc.name)} up to ${escapeHtml(formatRelativeDate(accountDetailState.asOfDate))}.`
                }
              </div>
              ${
                accountDetailState.tab === 'adjustments'
                  ? `<button type="button" class="btn btn-primary btn-sm" id="btn-empty-adjust">Adjust Balance</button>`
                  : `<button type="button" class="btn btn-primary btn-sm" id="btn-empty-add">+ Add Transaction</button>`
              }
            </div>`
          : `<div class="grouped-card" id="acc-detail-tx-list">
              ${visibleTxs
                .map((tx) => {
                  const flow = classifyAccountFlow(tx);
                  const isAdj = tx.type === 'BALANCE_ADJUSTMENT';
                  const cat = tx.category_id ? catMap.get(tx.category_id) : null;
                  const otherAcc =
                    tx.type === 'transfer'
                      ? accMap.get(tx.account_id === acc.id ? tx.to_account_id : tx.account_id)
                      : null;

                  const icon = isAdj
                    ? '⚖️'
                    : tx.type === 'transfer'
                      ? '⇄'
                      : tx.type === 'debt'
                        ? '🤝'
                        : cat?.icon || '🧾';

                  const title = isAdj
                    ? tx.description || 'Balance Adjustment'
                    : tx.description || (tx.type === 'transfer' ? `Transfer ${tx.account_id === acc.id ? 'to' : 'from'} ${otherAcc?.name || 'Account'}` : cat?.name || tx.type);

                  const sub = isAdj
                    ? `Balance Adjustment · ${tx.adjustment_direction === 'increase' ? 'Increase' : 'Decrease'}`
                    : tx.type === 'transfer'
                      ? `${accMap.get(tx.account_id)?.name || 'Account'} → ${accMap.get(tx.to_account_id)?.name || 'Account'}`
                      : cat?.name || tx.type;

                  const amtClass = flow.isPositiveEffect ? 'text-success' : 'text-danger';
                  const amtDisplay = showBalances
                    ? `${flow.signedPrefix}${formatINR(tx.amount_paise)}`
                    : '*****';

                  return `
                    <div class="grouped-row grouped-row-clickable" data-ad-tx="${tx.id}" data-ad-is-adj="${isAdj ? '1' : '0'}">
                      <div class="list-row-main" style="flex:1; min-width:0;">
                        <span class="avatar-badge">${escapeHtml(icon)}</span>
                        <div style="min-width:0;">
                          <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                            ${escapeHtml(title)}
                            ${isAdj ? '<span class="badge badge-muted" style="margin-left:6px; font-size:0.68rem;">Adjustment</span>' : ''}
                          </div>
                          <div class="item-meta">${escapeHtml(sub)}</div>
                        </div>
                      </div>
                      <div class="tx-amt-col">
                        <strong class="${amtClass}" style="font-variant-numeric:tabular-nums;">${amtDisplay}</strong>
                        <span class="tx-date-sub">${escapeHtml(formatRelativeDate(tx.date_key))}</span>
                      </div>
                    </div>
                  `;
                })
                .join('')}
            </div>
            ${
              filteredTxs.length > visibleTxs.length
                ? `<button type="button" class="btn btn-secondary" id="btn-ad-load-more">
                    Load more (${filteredTxs.length - visibleTxs.length} remaining)
                  </button>`
                : ''
            }`
      }
    </div>
  `;

  container.querySelector('#acc-detail-asof')?.addEventListener('change', (e) => {
    if (e.target.value) {
      accountDetailState.asOfDate = e.target.value;
      renderAccountDetailView(container, ctx);
    }
  });

  const launchAdjust = () =>
    openAdjustBalanceModal(ctx, acc.id, {
      initialDate: accountDetailState.asOfDate,
      onSaved: () => renderAccountDetailView(container, ctx),
    });

  container.querySelector('#btn-acc-adjust')?.addEventListener('click', launchAdjust);
  container.querySelector('#btn-empty-adjust')?.addEventListener('click', launchAdjust);

  container.querySelector('#btn-empty-add')?.addEventListener('click', () => {
    openAddTransactionWithContext(ctx);
  });

  container.querySelector('#btn-acc-paste')?.addEventListener('click', async () => {
    await pasteClipboardToContext(ctx, {
      onRefresh: () => renderAccountDetailView(container, ctx),
    });
  });

  container.querySelector('#btn-acc-edit-meta')?.addEventListener('click', () => {
    state.editAccountOnOpen = acc.id;
    window.location.hash = '#/accounts';
  });

  container.querySelectorAll('[data-ad-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      accountDetailState.tab = btn.getAttribute('data-ad-tab');
      accountDetailState.pageSize = 50;
      renderAccountDetailView(container, ctx);
    });
  });

  container.querySelector('#btn-ad-load-more')?.addEventListener('click', () => {
    accountDetailState.pageSize += 50;
    renderAccountDetailView(container, ctx);
  });

  // Tap row -> Edit Adjustment or Edit Transaction
  container.querySelectorAll('[data-ad-tx]').forEach((row) => {
    row.addEventListener('click', async () => {
      const txId = row.getAttribute('data-ad-tx');
      const isAdj = row.getAttribute('data-ad-is-adj') === '1';
      if (isAdj) {
        const adjTx = await services.transactions.getTransactionById(txId);
        if (adjTx) {
          openAdjustBalanceModal(ctx, acc.id, {
            existingAdjustment: adjTx,
            onSaved: () => renderAccountDetailView(container, ctx),
          });
        }
        return;
      }
      state.txDraft = { editId: txId, returnRoute: 'account-detail' };
      window.location.hash = '#/add-transaction';
    });
  });

  // Long-press regular transactions for Copy / Make Favourite / Delete / Cancel
  const listEl = container.querySelector('#acc-detail-tx-list');
  if (listEl) {
    bindTransactionLongPress(listEl, ctx, {
      selector: '[data-ad-tx][data-ad-is-adj="0"]',
      attr: 'data-ad-tx',
      onRefresh: () => renderAccountDetailView(container, ctx),
    });
  }
}

import { generateUUID } from '../../utils/uuid.js';
import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString, parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString, toLocalDateTimeString } from '../../utils/date.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { resolveTransactionContext } from '../../services/txContextClipboard.js';
import { openModal, openSheet } from '../components/modal.js';
import { showToast } from '../components/toast.js';

/**
 * Safely evaluates simple arithmetic expressions (+, -, *, /) for the inline calculator.
 */
export function evaluateCalcExpression(expr) {
  const raw = String(expr || '').replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').trim();
  if (!raw || /[^0-9+\-*/.() ]/.test(raw)) return null;

  // Tokenize numbers, operators, and parentheses
  const tokens = [];
  let i = 0;
  while (i < raw.length) {
    const ch = raw[i];
    if (ch === ' ') { i++; continue; }
    if ('+-*/()'.includes(ch)) {
      tokens.push(ch);
      i++;
      continue;
    }
    if ((ch >= '0' && ch <= '9') || ch === '.') {
      let numStr = '';
      let dots = 0;
      while (i < raw.length && ((raw[i] >= '0' && raw[i] <= '9') || raw[i] === '.')) {
        if (raw[i] === '.') dots++;
        numStr += raw[i++];
      }
      if (dots > 1 || numStr === '.') return null;
      tokens.push(Number(numStr));
      continue;
    }
    return null;
  }
  if (tokens.length === 0) return null;

  let pos = 0;
  const peek = () => tokens[pos];
  const consume = () => tokens[pos++];

  function parseExpr() {
    let left = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = consume();
      const right = parseTerm();
      left = op === '+' ? left + right : left - right;
    }
    return left;
  }

  function parseTerm() {
    let left = parseFactor();
    while (peek() === '*' || peek() === '/') {
      const op = consume();
      const right = parseFactor();
      if (op === '/') {
        if (right === 0) throw new Error('Division by zero');
        left = left / right;
      } else {
        left = left * right;
      }
    }
    return left;
  }

  function parseFactor() {
    const tok = peek();
    if (tok === '+' || tok === '-') {
      consume();
      const val = parseFactor();
      return tok === '-' ? -val : val;
    }
    if (tok === '(') {
      consume();
      const val = parseExpr();
      if (consume() !== ')') throw new Error('Unmatched parenthesis');
      return val;
    }
    if (typeof tok === 'number' && Number.isFinite(tok)) {
      consume();
      return tok;
    }
    throw new Error('Unexpected token');
  }

  try {
    const val = parseExpr();
    if (pos !== tokens.length) return null;
    if (typeof val === 'number' && Number.isFinite(val) && val >= 0) {
      return Math.round(val * 100) / 100;
    }
  } catch {
    return null;
  }
  return null;
}

/**
 * Add / Edit Transaction View — Definitive Layout Reference (Screenshot 59912.jpg + Orbit Language):
 * - Header: Circular Back button + "Add transaction" title
 * - Segmented pill: Expense | Income | Transfer
 * - Clean 2-column Date & Time row respecting inherited page context
 * - Prominent ₹ Amount row with numeric keypad support + inline Calculator toggle
 * - Spacious Category row (> opens searchable Category selector sheet)
 * - Spacious Payment mode / Account row (> opens Account selector sheet, adapts for Income/Transfer)
 * - "Other details": Notes (full-history autocomplete), Tags (inherited + top-5 recent pills with dot indicators), Attachments, Family/Ref/Favourite
 * - Fixed bottom-right Save FAB + Save & Add Another pill
 */
export async function renderAddTransactionView(container, ctx) {
  const { repos, services, state } = ctx;
  const draft = state.txDraft || {};
  const isEdit = Boolean(draft.editId);
  const returnRoute = (draft.returnRoute && draft.returnRoute !== 'add-transaction') ? draft.returnRoute : 'home';

  const [settings, accounts, expenseCats, incomeCats, tags, family, allDescriptions, allRecentTxs] =
    await Promise.all([
      repos.settings.getSettings(),
      repos.accounts.list({ includeArchived: false }),
      repos.categories.list({ type: 'expense', includeArchived: false }),
      repos.categories.list({ type: 'income', includeArchived: false }),
      repos.tags.list({ includeArchived: false }),
      repos.family.list({ includeInactive: false }),
      services.transactions.getRecentDescriptions(0),
      services.transactions.listTransactions({ sort: 'desc' }),
    ]);

  let existingTx = null;
  let existingAttachments = [];
  if (isEdit) {
    existingTx = await services.transactions.getTransactionById(draft.editId);
    if (existingTx) {
      existingAttachments = await repos.attachments.listByTransaction(existingTx.id);
    }
  }

  if (accounts.length === 0) {
    container.innerHTML = `
      <div class="tx-screen" style="text-align:center; padding-top:40px;">
        <div style="font-size:2rem;">🏛️</div>
        <h2 class="empty-state-title">Add an account first</h2>
        <p class="empty-state-text">Create at least one Bank Account, Credit Card, Wallet, or Cash account first.</p>
        <a href="#/accounts" class="btn btn-primary">+ Add Account</a>
      </div>
    `;
    return;
  }

  // Order categories by recent usage first
  const catRecency = new Map();
  allRecentTxs.forEach((tx, idx) => {
    if (tx.category_id && !catRecency.has(tx.category_id)) catRecency.set(tx.category_id, idx);
  });
  const sortRecentFirst = (list) =>
    [...list].sort((a, b) => {
      const ra = catRecency.has(a.id) ? catRecency.get(a.id) : 999999;
      const rb = catRecency.has(b.id) ? catRecency.get(b.id) : 999999;
      return ra - rb || a.name.localeCompare(b.name);
    });

  const sortedExpenseCats = sortRecentFirst(expenseCats);
  const sortedIncomeCats = sortRecentFirst(incomeCats);

  // Resolve initial values via centralised 4-level context hierarchy
  const appDefaults = {
    account_id: accounts.some((a) => a.id === settings.default_account_id) ? settings.default_account_id : accounts[0]?.id,
    expense_category_id: settings.default_expense_category_id || sortedExpenseCats[0]?.id || null,
    income_category_id: settings.default_income_category_id || sortedIncomeCats[0]?.id || null,
  };

  const resolvedInit = isEdit && existingTx
    ? {
        type: existingTx.type,
        amount_paise: existingTx.amount_paise,
        date: existingTx.date_key,
        time: existingTx.occurred_at_local?.slice(11, 16) || toLocalDateTimeString().slice(11, 16),
        account_id: existingTx.account_id,
        to_account_id: existingTx.to_account_id,
        category_id: existingTx.category_id,
        description: existingTx.description || '',
        notes: existingTx.notes || '',
        reference_no: existingTx.reference_no || '',
        family_member_id: existingTx.family_member_id || null,
        tag_ids: existingTx.tag_ids || [],
        inheritedBadges: [],
        fromClipboard: false,
      }
    : resolveTransactionContext({
        explicit: {
          type: draft.type,
          amount_paise: draft.amount_paise,
          date: draft.date,
          time: draft.time,
          account_id: draft.account_id,
          to_account_id: draft.to_account_id,
          category_id: draft.category_id,
          description: draft.description,
          notes: draft.notes,
          reference_no: draft.reference_no,
          family_member_id: draft.family_member_id,
          tag_ids: draft.tag_ids,
        },
        appDefaults,
      });

  const fallbackAccId = accounts.some((a) => a.id === resolvedInit.account_id)
    ? resolvedInit.account_id
    : accounts[0]?.id;
  const fallbackToAccId =
    resolvedInit.to_account_id && accounts.some((a) => a.id === resolvedInit.to_account_id && a.id !== fallbackAccId)
      ? resolvedInit.to_account_id
      : accounts.find((a) => a.id !== fallbackAccId)?.id || '';

  const formState = {
    type: resolvedInit.type || 'expense',
    amountText: resolvedInit.amount_paise ? paiseToDecimalString(resolvedInit.amount_paise) : '',
    date: resolvedInit.date || toLocalDateString(),
    time: resolvedInit.time || toLocalDateTimeString().slice(11, 16),
    accountId: fallbackAccId,
    toAccountId: fallbackToAccId,
    categoryId: resolvedInit.category_id,
    description: resolvedInit.description || resolvedInit.notes || '',
    familyMemberId: resolvedInit.family_member_id || '',
    referenceNo: resolvedInit.reference_no || '',
    selectedTagIds: new Set(resolvedInit.tag_ids || []),
    showCalc: false,
    calcExpr: '',
    pendingFile: null,
    duplicateConfirmed: false,
    inheritedBadges: draft.inheritedBadges || [],
    fromClipboard: Boolean(draft.fromClipboard),
    copiedSourceTitle: draft.copiedSourceTitle || null,
    isDirty: false,
    isSubmitting: false,
    submitIdempotencyKey: generateUUID(),
  };

  if (ctx.router && typeof ctx.router.setDirtyGuard === 'function') {
    ctx.router.setDirtyGuard(() => Boolean(formState.isDirty && (String(formState.amountText || '').trim() || String(formState.description || '').trim())));
  }

  // Top 5 recently used tags
  const recentTagOrder = [];
  const seenRecentTagIds = new Set();
  for (const tx of allRecentTxs) {
    for (const tid of tx.tag_ids || []) {
      if (!seenRecentTagIds.has(tid)) {
        seenRecentTagIds.add(tid);
        recentTagOrder.push(tid);
      }
      if (recentTagOrder.length >= 5) break;
    }
    if (recentTagOrder.length >= 5) break;
  }
  const tagById = new Map(tags.map((t) => [t.id, t]));
  const getVisibleTags = () => {
    const ids = new Set([...formState.selectedTagIds, ...recentTagOrder]);
    if (ids.size < 5) {
      for (const t of tags) {
        ids.add(t.id);
        if (ids.size >= 5) break;
      }
    }
    return Array.from(ids).map((id) => tagById.get(id)).filter(Boolean);
  };

  const getValidCatForType = (t) => {
    const list = t === 'income' ? sortedIncomeCats : sortedExpenseCats;
    if (formState.categoryId && list.some((c) => c.id === formState.categoryId)) {
      return list.find((c) => c.id === formState.categoryId);
    }
    const remembered = t === 'income' ? settings.default_income_category_id : settings.default_expense_category_id;
    return list.find((c) => c.id === remembered) || list[0] || null;
  };

  const openCategorySheet = () => {
    const catList = formState.type === 'income' ? sortedIncomeCats : sortedExpenseCats;
    openSheet({
      title: `Select ${formState.type === 'income' ? 'Income' : 'Expense'} Category`,
      bodyHtml: `
        <div class="stack" style="gap:10px;">
          <div style="position:sticky; top:0; z-index:4; background:var(--bg-surface); padding-bottom:4px;">
            <input id="cat-sheet-search" type="search" class="form-control" placeholder="🔍 Search categories…" autocomplete="off">
          </div>
          <div id="cat-sheet-list" class="grouped-card" style="max-height:55vh; overflow-y:auto;"></div>
        </div>
      `,
      onMount: (panel, close) => {
        const searchEl = panel.querySelector('#cat-sheet-search');
        const listEl = panel.querySelector('#cat-sheet-list');
        const renderList = (q) => {
          const term = String(q || '').trim().toLowerCase();
          const filtered = term ? catList.filter((c) => c.name.toLowerCase().includes(term)) : catList;
          if (filtered.length === 0) {
            listEl.innerHTML = `<div class="grouped-row"><span class="item-meta">No category matches "${escapeHtml(q)}".</span></div>`;
            return;
          }
          listEl.innerHTML = filtered
            .map(
              (c) => `
              <div class="grouped-row grouped-row-clickable ${c.id === formState.categoryId ? 'cat-row-selected' : ''}" data-sheet-cat="${c.id}" style="padding:13px 14px;">
                <div class="list-row-main">
                  <span class="avatar-badge" style="width:36px; height:36px;">${escapeHtml(c.icon || '🏷️')}</span>
                  <span class="item-title" style="${c.id === formState.categoryId ? 'color:var(--accent);' : ''}">${escapeHtml(c.name)}</span>
                </div>
                ${c.id === formState.categoryId ? '<strong style="color:var(--accent);">✓</strong>' : ''}
              </div>`
            )
            .join('');
          listEl.querySelectorAll('[data-sheet-cat]').forEach((row) => {
            row.addEventListener('click', () => {
              formState.categoryId = row.getAttribute('data-sheet-cat');
              close();
              renderForm();
            });
          });
        };
        renderList('');
        searchEl?.focus();
        searchEl?.addEventListener('input', (e) => renderList(e.target.value));
      },
    });
  };

  const openAccountSheet = (field = 'accountId') => {
    const isDest = field === 'toAccountId';
    const currentVal = isDest ? formState.toAccountId : formState.accountId;
    openModal({
      title: isDest ? 'Select Destination Account' : formState.type === 'income' ? 'Received Into' : 'Select Payment Mode',
      bodyHtml: `
        <div class="grouped-card" style="max-height:60vh; overflow-y:auto;">
          ${accounts
            .map(
              (a) => `
              <div class="grouped-row grouped-row-clickable" data-sheet-acc="${a.id}" style="padding:12px 14px;">
                <div class="list-row-main">
                  <span class="avatar-badge" style="width:36px; height:36px;">${escapeHtml(a.icon || '🏛️')}</span>
                  <div>
                    <div class="item-title" style="${a.id === currentVal ? 'color:var(--accent);' : ''}">${escapeHtml(a.name)}</div>
                    <div class="item-meta">${escapeHtml(a.institution || a.type.replace('_', ' '))}</div>
                  </div>
                </div>
                ${a.id === currentVal ? '<strong style="color:var(--accent);">✓</strong>' : ''}
              </div>`
            )
            .join('')}
        </div>
      `,
      onMount: (panel, close) => {
        panel.querySelectorAll('[data-sheet-acc]').forEach((row) => {
          row.addEventListener('click', () => {
            const chosenId = row.getAttribute('data-sheet-acc');
            if (isDest) formState.toAccountId = chosenId;
            else formState.accountId = chosenId;
            close();
            renderForm();
          });
        });
      },
    });
  };

  const renderForm = () => {
    const isTransfer = formState.type === 'transfer';
    const selectedCat = isTransfer ? null : getValidCatForType(formState.type);
    if (!isTransfer && selectedCat) formState.categoryId = selectedCat.id;
    const selectedAcc = accounts.find((a) => a.id === formState.accountId) || accounts[0];
    const selectedToAcc = accounts.find((a) => a.id === formState.toAccountId) || accounts.find((a) => a.id !== selectedAcc?.id) || null;
    if (isTransfer && selectedToAcc) formState.toAccountId = selectedToAcc.id;

    const paymentLabel =
      formState.type === 'income'
        ? 'Received into'
        : isTransfer
          ? 'From account'
          : 'Payment mode';

    const showBanner = formState.fromClipboard || formState.inheritedBadges.length > 0;

    container.innerHTML = `
      <form id="tx-entry-form" class="tx-screen" autocomplete="off">
        <!-- Screenshot Header: Back arrow + "Add transaction" -->
        <div class="tx-header">
          <button type="button" id="btn-tx-back" class="tx-back-btn" aria-label="Go back">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M12 19l-7-7 7-7"></path></svg>
          </button>
          <h2 class="tx-header-title">${isEdit ? 'Edit transaction' : 'Add transaction'}</h2>
        </div>

        <!-- 3-Way Type Segmented Pill -->
        <div class="tx-type-track" role="tablist" aria-label="Transaction type">
          <button type="button" data-tx-type="expense" class="${formState.type === 'expense' ? 'active' : ''}">Expense</button>
          <button type="button" data-tx-type="income" class="${formState.type === 'income' ? 'active' : ''}">Income</button>
          <button type="button" data-tx-type="transfer" class="${formState.type === 'transfer' ? 'active' : ''}">Transfer</button>
        </div>

        ${
          showBanner
            ? `<div class="tx-ctx-banner">
                ${formState.fromClipboard ? `<span>📋 Pasted from "${escapeHtml(formState.copiedSourceTitle || 'Clipboard')}"</span>` : ''}
                ${formState.inheritedBadges.map((b) => `<span>${escapeHtml(b)}</span>`).join('')}
              </div>`
            : ''
        }

        <!-- Prominent Amount Hero Input First + Calculator Toggle -->
        <div style="padding:8px 0 4px;">
          <div class="tx-row-label" style="margin-bottom:6px;">Amount (INR)</div>
          <div class="tx-amount-box">
            <span class="tx-row-icon" style="font-size:1.45rem;" aria-hidden="true">₹</span>
            <input id="tx-amount" name="amount_rupees" class="tx-amount-input" style="font-size:1.75rem;" inputmode="decimal"
              placeholder="0.00" required value="${escapeHtml(formState.amountText)}">
            <button type="button" id="btn-toggle-calc" class="tx-calc-btn ${formState.showCalc ? 'active' : ''}" aria-label="Toggle calculator" title="Calculator">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"></rect><path d="M8 6h8M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"></path></svg>
            </button>
          </div>
        </div>

        <!-- Inline Calculator Pad -->
        <div id="tx-calc-pad" class="tx-calc-pad ${formState.showCalc ? '' : 'hidden'}">
          <div id="tx-calc-expr" class="tx-calc-expr">${escapeHtml(formState.calcExpr || formState.amountText || '0')}</div>
          <div class="tx-calc-grid">
            ${['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '−', 'C', '0', '.', '+']
              .map((k) => `<button type="button" class="tx-calc-key ${['÷', '×', '−', '+'].includes(k) ? 'op' : ''}" data-calc-key="${k}">${k}</button>`)
              .join('')}
            <button type="button" class="tx-calc-key" data-calc-key="⌫" style="grid-column: span 2;">⌫ Back</button>
            <button type="button" class="tx-calc-key eq" data-calc-key="=" style="grid-column: span 2;">= Apply</button>
          </div>
        </div>

        <!-- 1-Tap Recent Category Chips + Sheet Trigger (Expense & Income) -->
        ${
          !isTransfer
            ? `<div>
                <input type="hidden" id="tx-category" name="category_id" value="${escapeHtml(selectedCat?.id || '')}">
                <div class="tx-row tx-row-clickable" id="row-pick-category" role="button" tabindex="0">
                  <span class="tx-row-icon">${escapeHtml(selectedCat?.icon || '🏷️')}</span>
                  <div class="tx-row-body">
                    <div class="tx-row-label">Category</div>
                    <div class="tx-row-value">${escapeHtml(selectedCat?.name || 'Select category')}</div>
                  </div>
                  <span class="text-muted" style="font-size:1.25rem;">›</span>
                </div>
                <div class="tx-quick-chips" aria-label="Quick categories">
                  ${(formState.type === 'income' ? sortedIncomeCats : sortedExpenseCats)
                    .slice(0, 5)
                    .map((c) => `<button type="button" class="tx-quick-chip ${selectedCat?.id === c.id ? 'active' : ''}" data-quick-cat="${c.id}" aria-pressed="${selectedCat?.id === c.id ? 'true' : 'false'}"><span>${escapeHtml(c.icon || '🏷️')}</span><span>${escapeHtml(c.name)}</span></button>`)
                    .join('')}
                  <button type="button" class="tx-quick-chip more-chip" id="btn-more-cats">All ›</button>
                </div>
              </div>`
            : ''
        }

        <!-- 1-Tap Recent Account Chips + Sheet Trigger -->
        <div>
          <input type="hidden" id="tx-account" name="account_id" value="${escapeHtml(selectedAcc?.id || '')}">
          <div class="tx-row tx-row-clickable" id="row-pick-account" role="button" tabindex="0">
            <span class="tx-row-icon">${escapeHtml(selectedAcc?.icon || '💳')}</span>
            <div class="tx-row-body">
              <div class="tx-row-label">${paymentLabel}</div>
              <div class="tx-row-value">${escapeHtml(selectedAcc?.name || 'Select account')}</div>
            </div>
            <span class="text-muted" style="font-size:1.25rem;">›</span>
          </div>
          <div class="tx-quick-chips" aria-label="Quick accounts">
            ${accounts
              .slice(0, 4)
              .map((a) => `<button type="button" class="tx-quick-chip ${selectedAcc?.id === a.id ? 'active' : ''}" data-quick-acc="${a.id}" aria-pressed="${selectedAcc?.id === a.id ? 'true' : 'false'}"><span>${escapeHtml(a.icon || '🏛️')}</span><span>${escapeHtml(a.name)}</span></button>`)
              .join('')}
            ${accounts.length > 4 ? '<button type="button" class="tx-quick-chip more-chip" id="btn-more-accs">All ›</button>' : ''}
          </div>
        </div>

        <!-- Destination Account Row + 1-Tap Swap (Transfers only) -->
        ${
          isTransfer
            ? `<div class="tx-swap-row">
                <button type="button" class="btn btn-secondary btn-sm" id="btn-swap-transfer" aria-label="Swap source and destination accounts">⇄ Swap Accounts</button>
              </div>
              <div class="tx-row tx-row-clickable" id="row-pick-to-account" role="button" tabindex="0">
                <input type="hidden" id="tx-to-account" name="to_account_id" value="${escapeHtml(selectedToAcc?.id || '')}">
                <span class="tx-row-icon">${escapeHtml(selectedToAcc?.icon || '🏛️')}</span>
                <div class="tx-row-body">
                  <div class="tx-row-label">To account</div>
                  <div class="tx-row-value">${escapeHtml(selectedToAcc?.name || 'Select destination account')}</div>
                </div>
                <span class="text-muted" style="font-size:1.25rem;">›</span>
              </div>`
            : ''
        }

        <!-- Compact Date & Time Row + Today / Yesterday Quick Pills -->
        <div>
          <div class="tx-datetime-row">
            <div class="tx-datetime-item">
              <span class="tx-row-icon" aria-hidden="true">
                <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="3"></rect><path d="M16 2v4M8 2v4M3 10h18"></path></svg>
              </span>
              <input id="tx-date" name="date" type="date" class="tx-datetime-input" required value="${escapeHtml(formState.date)}" aria-label="Transaction date">
            </div>
            <div class="tx-datetime-item">
              <span class="tx-row-icon" aria-hidden="true">
                <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path></svg>
              </span>
              <input id="tx-time" name="time" type="time" class="tx-datetime-input" required value="${escapeHtml(formState.time)}" aria-label="Transaction time">
            </div>
          </div>
          <div class="tx-date-quick-bar">
            <button type="button" class="tx-date-pill ${formState.date === toLocalDateString() ? 'active' : ''}" data-quick-date="today">Today</button>
            <button type="button" class="tx-date-pill" data-quick-date="yesterday">Yesterday</button>
          </div>
        </div>

        <!-- Other Details Section -->
        <div class="tx-section-label">Other details</div>

        <!-- Write a note (Full-History Autocomplete) -->
        <div class="tx-row" style="align-items:flex-start;">
          <span class="tx-row-icon" style="margin-top:4px;" aria-hidden="true">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16M4 12h12M4 18h8"></path></svg>
          </span>
          <div class="tx-row-body autocomplete-wrap">
            <input id="tx-desc" name="description" class="tx-inline-input" maxlength="160" autocomplete="off"
              placeholder="Write a note (${allDescriptions.length.toLocaleString('en-IN')} past notes)…"
              value="${escapeHtml(formState.description)}">
            <div id="tx-desc-suggestions" class="suggestions-box hidden" style="max-height:200px; overflow-y:auto;"></div>
          </div>
        </div>

        <!-- Add Tags Row + Dot Pill Chips -->
        <div class="tx-row" style="align-items:flex-start;">
          <span class="tx-row-icon" style="margin-top:4px; font-size:1.35rem;" aria-hidden="true">#</span>
          <div class="tx-row-body">
            <div class="autocomplete-wrap">
              <div style="display:flex; gap:8px; align-items:center;">
                <input id="tx-new-tag" class="tx-inline-input" autocomplete="off" placeholder="Add tags">
                <button type="button" class="btn btn-secondary btn-sm" id="btn-inline-add-tag">Add</button>
              </div>
              <div id="tx-tag-suggestions" class="suggestions-box hidden"></div>
            </div>
            <div class="tx-tag-pills" id="tx-tag-picker">
              ${getVisibleTags()
                .map((t) => {
                  const sel = formState.selectedTagIds.has(t.id);
                  return `
                    <button type="button" class="tx-tag-pill ${sel ? 'selected' : ''}" data-toggle-tag="${t.id}">
                      <span class="tx-tag-pill-dot"></span>
                      <span>${escapeHtml(t.name)}</span>
                    </button>`;
                })
                .join('')}
            </div>
          </div>
        </div>

        <!-- Add Attachment Row -->
        <div class="tx-row tx-row-clickable" id="row-pick-attachment">
          <span class="tx-row-icon" aria-hidden="true">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"></path></svg>
          </span>
          <div class="tx-row-body">
            <div class="tx-row-value" style="font-weight:500; color:${formState.pendingFile ? 'var(--text-primary)' : 'var(--text-muted)'};">
              ${formState.pendingFile ? `📎 ${escapeHtml(formState.pendingFile.name)}` : 'Add attachment'}
            </div>
            <input id="tx-attachment" type="file" accept="image/*,application/pdf" class="hidden">
          </div>
          <span class="text-muted" style="font-size:1.25rem;">›</span>
        </div>

        ${
          existingAttachments.length > 0
            ? `<div class="stack" style="gap:6px; padding:8px 4px;">
                ${existingAttachments
                  .map(
                    (att) => `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:6px 10px; background:var(--bg-surface-elevated); border-radius:10px;">
                      <span class="item-meta">📎 ${escapeHtml(att.file_name)}</span>
                      <div class="row-actions">
                        <button type="button" class="btn btn-secondary btn-sm" data-view-att="${att.local_blob_key}">View</button>
                        <button type="button" class="btn btn-danger btn-sm" data-del-att="${att.id}">✕</button>
                      </div>
                    </div>`
                  )
                  .join('')}
              </div>`
            : ''
        }

        <!-- Optional Family / Reference / Favourite -->
        <details class="accordion" style="margin-top:14px;">
          <summary style="padding:10px 14px; font-size:0.84rem;">
            <span>Family, Reference &amp; ★ Favourite</span>
            <span class="text-muted">⌄</span>
          </summary>
          <div style="padding:0 14px 14px;" class="stack">
            <div class="form-row">
              <select id="tx-family" name="family_member_id" class="form-control" style="padding:8px 10px; font-size:0.86rem;">
                <option value="">Family: Unassigned</option>
                ${family.map((m) => `<option value="${m.id}" ${formState.familyMemberId === m.id ? 'selected' : ''}>${escapeHtml(m.icon)} ${escapeHtml(m.name)}</option>`).join('')}
              </select>
              <input id="tx-ref" name="reference_no" class="form-control" style="padding:8px 10px; font-size:0.86rem;" maxlength="50"
                placeholder="Ref No. (UPI/Bill)" value="${escapeHtml(formState.referenceNo)}">
            </div>
            <div style="display:flex; justify-content:space-between; gap:8px;">
              <button type="button" class="btn btn-secondary btn-sm" id="btn-save-favorite">★ Save as Favourite</button>
              ${isEdit ? `<button type="button" class="btn btn-danger btn-sm" id="btn-delete-tx">Delete</button>` : ''}
            </div>
          </div>
        </details>

        <div id="duplicate-warning-slot" style="margin-top:10px;"></div>

        <!-- Floating Bottom-Right Actions: Pay via UPI (Expenses), Save & Add Another, Save FAB -->
        <div class="tx-save-fab-bar">
          ${
            !isEdit
              ? `<button type="submit" class="tx-save-another-pill" data-save-mode="another">+ Another</button>`
              : ''
          }
          <button type="submit" class="tx-save-fab" data-save-mode="close" aria-label="${isEdit ? 'Save changes' : 'Save transaction'}" title="Save transaction">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
          </button>
        </div>
      </form>
    `;

    // Sync live inputs into formState so sheet pickers never lose typed values
    const amtInput = container.querySelector('#tx-amount');
    amtInput?.addEventListener('input', (e) => {
      formState.amountText = e.target.value;
      formState.isDirty = true;
    });

    container.querySelectorAll('[data-quick-cat]').forEach((btn) => {
      btn.addEventListener('click', () => {
        formState.categoryId = btn.getAttribute('data-quick-cat');
        formState.isDirty = true;
        renderForm();
      });
    });
    container.querySelector('#btn-more-cats')?.addEventListener('click', openCategorySheet);

    container.querySelectorAll('[data-quick-acc]').forEach((btn) => {
      btn.addEventListener('click', () => {
        formState.accountId = btn.getAttribute('data-quick-acc');
        if (formState.type === 'transfer' && formState.toAccountId === formState.accountId) {
          formState.toAccountId = accounts.find((a) => a.id !== formState.accountId)?.id || '';
        }
        formState.isDirty = true;
        renderForm();
      });
    });
    container.querySelector('#btn-more-accs')?.addEventListener('click', () => openAccountSheet(false));

    container.querySelector('#btn-swap-transfer')?.addEventListener('click', () => {
      const prevFrom = formState.accountId;
      formState.accountId = formState.toAccountId || prevFrom;
      formState.toAccountId = prevFrom;
      formState.isDirty = true;
      renderForm();
    });

    container.querySelectorAll('[data-quick-date]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const mode = btn.getAttribute('data-quick-date');
        const d = new Date();
        if (mode === 'yesterday') d.setDate(d.getDate() - 1);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        formState.date = `${y}-${m}-${day}`;
        formState.isDirty = true;
        renderForm();
      });
    });
    container.querySelector('#tx-date')?.addEventListener('change', (e) => {
      formState.date = e.target.value;
    });
    container.querySelector('#tx-time')?.addEventListener('change', (e) => {
      formState.time = e.target.value;
    });
    container.querySelector('#tx-family')?.addEventListener('change', (e) => {
      formState.familyMemberId = e.target.value;
    });
    container.querySelector('#tx-ref')?.addEventListener('input', (e) => {
      formState.referenceNo = e.target.value;
    });

    // Back button (always navigates cleanly out of Add Transaction)
    container.querySelector('#btn-tx-back')?.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      state.txDraft = null;
      if (typeof ctx.navigateTo === 'function') {
        ctx.navigateTo(returnRoute);
      } else {
        window.location.hash = `#/${returnRoute}`;
      }
    });

    // Type switch
    container.querySelectorAll('[data-tx-type]').forEach((btn) => {
      btn.addEventListener('click', () => {
        formState.type = btn.getAttribute('data-tx-type');
        formState.duplicateConfirmed = false;
        renderForm();
      });
    });

    // Calculator toggle & keys
    container.querySelector('#btn-toggle-calc')?.addEventListener('click', () => {
      formState.showCalc = !formState.showCalc;
      if (formState.showCalc && !formState.calcExpr && formState.amountText) {
        formState.calcExpr = formState.amountText;
      }
      renderForm();
    });

    container.querySelectorAll('[data-calc-key]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const key = btn.getAttribute('data-calc-key');
        const exprEl = container.querySelector('#tx-calc-expr');
        if (key === 'C') {
          formState.calcExpr = '';
        } else if (key === '⌫') {
          formState.calcExpr = formState.calcExpr.slice(0, -1);
        } else if (key === '=') {
          const res = evaluateCalcExpression(formState.calcExpr);
          if (res !== null) {
            formState.amountText = String(res);
            formState.calcExpr = String(res);
            if (amtInput) amtInput.value = formState.amountText;
            formState.showCalc = false;
            renderForm();
            return;
          }
          showToast('Invalid expression', { type: 'error' });
        } else {
          formState.calcExpr += key;
        }
        if (exprEl) exprEl.textContent = formState.calcExpr || '0';
      });
    });

    // Category & Account selector sheets
    container.querySelector('#row-pick-category')?.addEventListener('click', openCategorySheet);
    container.querySelector('#row-pick-account')?.addEventListener('click', () => openAccountSheet('accountId'));
    container.querySelector('#row-pick-to-account')?.addEventListener('click', () => openAccountSheet('toAccountId'));

    // Attachment trigger
    const fileInput = container.querySelector('#tx-attachment');
    container.querySelector('#row-pick-attachment')?.addEventListener('click', () => fileInput?.click());
    fileInput?.addEventListener('change', () => {
      formState.pendingFile = fileInput.files?.[0] || null;
      renderForm();
    });

    // Full-history Notes autocomplete
    const descInput = container.querySelector('#tx-desc');
    const sugBox = container.querySelector('#tx-desc-suggestions');
    const updateSuggestions = () => {
      if (!descInput || !sugBox) return;
      formState.description = descInput.value;
      const val = descInput.value.trim().toLowerCase();
      if (!val || allDescriptions.length === 0) {
        sugBox.classList.add('hidden');
        return;
      }
      const prefixMatches = [];
      const containsMatches = [];
      for (const d of allDescriptions) {
        const dl = d.toLowerCase();
        if (dl === val) continue;
        if (dl.startsWith(val)) prefixMatches.push(d);
        else if (dl.includes(val)) containsMatches.push(d);
        if (prefixMatches.length >= 10) break;
      }
      const matches = [...prefixMatches, ...containsMatches].slice(0, 10);
      if (matches.length === 0) {
        sugBox.classList.add('hidden');
        return;
      }
      sugBox.innerHTML = matches.map((m) => `<button type="button" class="suggestion-item">${escapeHtml(m)}</button>`).join('');
      sugBox.classList.remove('hidden');
      sugBox.querySelectorAll('.suggestion-item').forEach((btn) => {
        const pick = (ev) => {
          ev.preventDefault();
          descInput.value = btn.textContent;
          formState.description = btn.textContent;
          sugBox.classList.add('hidden');
        };
        btn.addEventListener('pointerdown', pick);
        btn.addEventListener('mousedown', pick);
      });
    };
    descInput?.addEventListener('input', updateSuggestions);
    descInput?.addEventListener('focus', updateSuggestions);
    descInput?.addEventListener('blur', () => setTimeout(() => sugBox?.classList.add('hidden'), 180));

    // Tag pill toggle & inline search/create
    const selectOrAppendTagChip = (tagObj) => {
      formState.selectedTagIds.add(tagObj.id);
      renderForm();
    };

    container.querySelectorAll('[data-toggle-tag]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-toggle-tag');
        if (formState.selectedTagIds.has(id)) {
          formState.selectedTagIds.delete(id);
          btn.classList.remove('selected');
        } else {
          formState.selectedTagIds.add(id);
          btn.classList.add('selected');
        }
      });
    });

    const tagInput = container.querySelector('#tx-new-tag');
    const tagSugBox = container.querySelector('#tx-tag-suggestions');
    const updateTagSuggestions = () => {
      if (!tagInput || !tagSugBox) return;
      const q = tagInput.value.trim().replace(/^#+/, '').toLowerCase();
      if (!q) {
        tagSugBox.classList.add('hidden');
        return;
      }
      const matches = tags.filter((t) => t.normalized_key.includes(q)).slice(0, 8);
      if (matches.length === 0) {
        tagSugBox.classList.add('hidden');
        return;
      }
      tagSugBox.innerHTML = matches
        .map((m) => `<button type="button" class="suggestion-item" data-sug-tag="${m.id}">${escapeHtml(formatTagDisplay(m))} <span class="item-meta">(existing)</span></button>`)
        .join('');
      tagSugBox.classList.remove('hidden');
      tagSugBox.querySelectorAll('[data-sug-tag]').forEach((btn) => {
        const pick = (ev) => {
          ev.preventDefault();
          const chosen = tagById.get(btn.getAttribute('data-sug-tag'));
          if (chosen) selectOrAppendTagChip(chosen);
        };
        btn.addEventListener('pointerdown', pick);
        btn.addEventListener('mousedown', pick);
      });
    };
    tagInput?.addEventListener('input', updateTagSuggestions);
    tagInput?.addEventListener('focus', updateTagSuggestions);
    tagInput?.addEventListener('blur', () => setTimeout(() => tagSugBox?.classList.add('hidden'), 180));

    container.querySelector('#btn-inline-add-tag')?.addEventListener('click', async () => {
      const raw = tagInput?.value?.trim();
      if (!raw) return;
      const cleanKey = raw.replace(/^#+/, '').trim().toLowerCase();
      const alreadyExists = tags.find((t) => t.normalized_key === cleanKey);
      if (alreadyExists) {
        selectOrAppendTagChip(alreadyExists);
        showToast(`Selected existing tag ${formatTagDisplay(alreadyExists)}`);
        return;
      }
      try {
        const created = await repos.tags.createTag({ name: raw });
        tags.push(created);
        tagById.set(created.id, created);
        selectOrAppendTagChip(created);
        showToast(`Added ${formatTagDisplay(created)}`);
      } catch (err) {
        setSubmitting(false);
        showToast(err.message, { type: 'error' });
      }
    });

    // Existing attachments
    container.querySelectorAll('[data-view-att]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const blobRec = await repos.attachments.getBlob(btn.getAttribute('data-view-att'));
        const blob = blobRec?.blob || blobRec;
        if (!blob) return showToast('Attachment not found', { type: 'error' });
        const objectUrl = URL.createObjectURL(blob);
        window.open(objectUrl, '_blank');
        setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      });
    });
    container.querySelectorAll('[data-del-att]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await repos.attachments.deleteAttachment(btn.getAttribute('data-del-att'));
        existingAttachments = existingAttachments.filter((a) => a.id !== btn.getAttribute('data-del-att'));
        renderForm();
        showToast('Attachment removed');
      });
    });

    container.querySelector('#btn-save-favorite')?.addEventListener('click', async () => {
      try {
        const amountPaise = parseRupeesToPaise(formState.amountText, { allowNegative: false });
        const favName = formState.description.trim() || selectedCat?.name || 'Quick Entry';
        await repos.favorites.createFavorite({
          name: favName,
          type: formState.type,
          amount_paise: amountPaise,
          category_id: formState.type === 'transfer' ? null : formState.categoryId,
          account_id: formState.accountId,
          to_account_id: formState.type === 'transfer' ? formState.toAccountId : null,
          description: formState.description,
          family_member_id: formState.familyMemberId || null,
          tag_ids: Array.from(formState.selectedTagIds),
        });
        showToast(`Saved "${favName}" to Favourites`);
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });

    container.querySelector('#btn-delete-tx')?.addEventListener('click', async () => {
      if (!existingTx) return;
      await services.transactions.softDeleteTransaction(existingTx.id);
      state.txDraft = null;
      window.location.hash = `#/${returnRoute}`;
      showToast('Transaction deleted', {
        actionLabel: 'Undo',
        onAction: async () => {
          await services.transactions.restoreTransaction(existingTx.id);
          showToast('Transaction restored');
        },
      });
    });

    // Submit / Save handler
    const form = container.querySelector('#tx-entry-form');
    let saveMode = 'close';
    form.querySelectorAll('button[type="submit"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        saveMode = btn.getAttribute('data-save-mode') || 'close';
      });
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (formState.isSubmitting) return;
      const submitBtns = Array.from(form.querySelectorAll('button[type="submit"]'));
      const setSubmitting = (busy) => {
        formState.isSubmitting = busy;
        submitBtns.forEach((b) => { b.disabled = busy; });
      };
      setSubmitting(true);
      let amountPaise;
      try {
        amountPaise = parseRupeesToPaise(formState.amountText, { allowNegative: false });
      } catch (err) {
        setSubmitting(false);
        showToast(err.message, { type: 'error' });
        return;
      }

      const payload = {
        type: formState.type,
        amount_paise: amountPaise,
        date: formState.date,
        time: formState.time,
        category_id: formState.type === 'transfer' ? null : formState.categoryId,
        account_id: formState.accountId,
        to_account_id: formState.type === 'transfer' ? formState.toAccountId : null,
        description: formState.description,
        family_member_id: formState.familyMemberId || null,
        reference_no: formState.referenceNo,
        tag_ids: Array.from(formState.selectedTagIds),
        idempotency_key: isEdit ? null : formState.submitIdempotencyKey,
      };

      if (!formState.duplicateConfirmed) {
        const dups = await services.transactions.findPossibleDuplicates({
          type: payload.type,
          amount_paise: payload.amount_paise,
          date_key: payload.date,
          account_id: payload.account_id,
          to_account_id: payload.to_account_id,
          description: payload.description,
          excludeId: isEdit ? existingTx?.id : null,
        });
        if (dups.length > 0) {
          const slot = container.querySelector('#duplicate-warning-slot');
          slot.innerHTML = `
            <div class="alert-banner alert-warning" style="padding:8px 12px; font-size:0.82rem;">
              <span>⚠️ Similar ${payload.type} of ${formatINR(payload.amount_paise)} on ${payload.date} exists.</span>
              <button type="button" class="btn btn-secondary btn-sm" id="btn-confirm-dup">Save anyway</button>
            </div>
          `;
          slot.querySelector('#btn-confirm-dup').addEventListener('click', () => {
            formState.duplicateConfirmed = true;
            form.requestSubmit();
          });
          setSubmitting(false);
          return;
        }
      }

      try {
        let saved;
        if (isEdit) {
          saved = await services.transactions.updateTransaction(existingTx.id, payload);
        } else {
          saved = await services.transactions.createTransaction(payload);
        }

        if (formState.pendingFile) {
          await repos.attachments.addAttachment(saved.id, formState.pendingFile);
        }

        const settingsPatch = { default_account_id: payload.account_id };
        if (payload.type === 'expense' && payload.category_id) settingsPatch.default_expense_category_id = payload.category_id;
        if (payload.type === 'income' && payload.category_id) settingsPatch.default_income_category_id = payload.category_id;
        await repos.settings.updateSettings(settingsPatch);

        if (payload.type === 'expense' && payload.date && services.budgets?.evaluateMonthBudgets) {
          try {
            const [by, bm] = String(payload.date).split('-').map(Number);
            if (by && bm) {
              const evalRes = await services.budgets.evaluateMonthBudgets(by, bm - 1);
              if (evalRes?.newAlerts?.length > 0) {
                const a = evalRes.newAlerts[0];
                showToast(`Budget alert: "${a.budgetName}" reached ${a.threshold}% (${Math.round(a.percentUsed)}% used)`, {
                  type: a.threshold >= 100 ? 'error' : 'warning',
                  durationMs: 5000,
                });
              }
            }
          } catch (budgetErr) {
            console.warn('Budget alert evaluation skipped:', budgetErr);
          }
        }

        formState.isDirty = false;
      ctx.router?.clearDirtyGuard?.();
      if (saveMode === 'another' && !isEdit) {
        formState.submitIdempotencyKey = generateUUID();
        setSubmitting(false);
          showToast('Saved! Ready for next entry');
          state.txDraft = {
            type: formState.type,
            date: payload.date,
            account_id: payload.account_id,
            tag_ids: Array.from(formState.selectedTagIds),
            returnRoute,
          };
          renderAddTransactionView(container, ctx);
        } else {
          state.txDraft = null;
          showToast(isEdit ? 'Transaction updated' : 'Transaction saved');
          if (typeof ctx.navigateTo === 'function') {
            ctx.navigateTo(returnRoute);
          } else {
            window.location.hash = `#/${returnRoute}`;
          }
        }
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });
  };

  renderForm();
}

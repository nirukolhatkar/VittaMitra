import { setPageContext } from '../../services/txContextClipboard.js';
import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { getCategoryColor } from '../../utils/colors.js';
import { shiftMonth, toLocalDateString } from '../../utils/date.js';
import {
  bindChartTooltips,
  renderBarChartSvg,
  renderCumulativeTrendSvg,
  renderDoughnutChartSvg,
} from '../components/charts.js';
import { showToast } from '../components/toast.js';

const analysisState = {
  mode: 'month', // 'week' | 'month' | 'year' | 'fy' | 'custom'
  weekOffset: 0,
  customStart: '',
  customEnd: '',
  catTab: 'expense',
  trendTab: 'expense',
  modeTab: 'expense', // 'expense' | 'income' | 'transfer'
  comparePrev: true,
  accountId: '',
  familyId: '',
};

export async function renderAnalysisView(container, ctx) {
  setPageContext(ctx, { date: `${ctx.state.selectedYear}-${String(ctx.state.selectedMonth + 1).padStart(2, '0')}-01`, sourceLabel: 'Insights' });
  const { repos, services, state } = ctx;
  const [settings, accounts, family] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.list({ includeArchived: true }),
    repos.family.list({ includeInactive: true }),
  ]);

  if (!analysisState.customStart) {
    const today = toLocalDateString();
    analysisState.customStart = `${today.slice(0, 7)}-01`;
    analysisState.customEnd = today;
  }

  const af = state.analysisFilter || null;
  const effMode = af
    ? (af.startDate || af.endDate ? 'custom' : 'all')
    : analysisState.mode;
  const [report, budgetEval] = await Promise.all([
    services.analytics.buildAnalysisReport({
      mode: effMode,
      year: state.selectedYear,
      month: state.selectedMonth,
      weekOffset: analysisState.weekOffset,
      customStart: af?.startDate || analysisState.customStart,
      customEnd: af?.endDate || analysisState.customEnd,
      accountIds: af?.accountIds?.length ? af.accountIds : (analysisState.accountId ? [analysisState.accountId] : []),
      accountMode: af?.accountMode || 'include',
      familyIds: af?.familyIds?.length ? af.familyIds : (analysisState.familyId ? [analysisState.familyId] : []),
      familyMode: af?.familyMode || 'include',
      categoryIds: af?.categoryIds || [],
      categoryMode: af?.categoryMode || 'include',
      tagIds: af?.tagIds || [],
      tagMode: af?.tagMode || 'any',
      type: af?.type || 'all',
      search: af?.search || '',
      years: af?.years || [],
      months: af?.months || [],
    }),
    !af && analysisState.mode === 'month'
      ? services.budgets.evaluateMonthBudgets(state.selectedYear, state.selectedMonth)
      : Promise.resolve(null),
  ]);

  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');

  const activeCatRows = report.categories[analysisState.catTab];
  const activeCatTotal = analysisState.catTab === 'expense' ? report.spending : report.income;

  const activeTrend = report.trends[analysisState.trendTab];
  const trendColor = analysisState.trendTab === 'expense' ? '#f46978' : '#34d399';
  const activeBarAvg =
    activeTrend.current.values.length > 0
      ? Math.round(
          activeTrend.current.values.reduce((s, v) => s + v, 0) /
            Math.max(1, report.period.granularity === 'day' ? report.elapsedDays : activeTrend.current.values.length)
        )
      : 0;

  const weekdayAvg = Math.round(report.weekdaySpend.values.reduce((s, v) => s + v, 0) / 7);
  const activeModeRows = report.paymentModes[analysisState.modeTab];
  const overallBudget = budgetEval?.budgets?.find((b) => b.budget.scope_type === 'overall') || budgetEval?.budgets?.[0] || null;

  container.innerHTML = `
    <div class="stack">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Insights</h2>
          <div class="compass-subtitle">${af ? `Filtered: ${escapeHtml(af.label)}` : 'Spending breakdowns, trends, and cash flow analytics'}</div>
        </div>
        ${af ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-clear-analysis-filter">✕ Clear filter</button>` : ''}
      </div>
      <div class="segmented" style="width:100%; justify-content:space-between;">
        <button type="button" style="flex:1;" data-an-mode="week" class="${analysisState.mode === 'week' ? 'active' : ''}">Week</button>
        <button type="button" style="flex:1;" data-an-mode="month" class="${analysisState.mode === 'month' ? 'active' : ''}">Month</button>
        <button type="button" style="flex:1;" data-an-mode="year" class="${analysisState.mode === 'year' ? 'active' : ''}">Year</button>
        <button type="button" style="flex:1;" data-an-mode="fy" class="${analysisState.mode === 'fy' ? 'active' : ''}">FY</button>
        <button type="button" style="flex:1;" data-an-mode="custom" class="${analysisState.mode === 'custom' ? 'active' : ''}">Custom</button>
      </div>

      ${
        analysisState.mode === 'custom'
          ? `<div class="card form-row" style="padding:12px;">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">From</label>
                <input type="date" id="an-custom-start" class="form-control" value="${escapeHtml(analysisState.customStart)}">
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">To</label>
                <input type="date" id="an-custom-end" class="form-control" value="${escapeHtml(analysisState.customEnd)}">
              </div>
            </div>`
          : `<div class="toolbar card" style="padding:10px 14px;">
              <button type="button" class="icon-btn" id="an-prev" aria-label="Previous period">‹</button>
              <div style="text-align:center;">
                <div class="item-title">${escapeHtml(report.period.label)}</div>
                <div class="item-meta">${report.transactionCount} transaction${report.transactionCount === 1 ? '' : 's'}</div>
              </div>
              <button type="button" class="icon-btn" id="an-next" aria-label="Next period">›</button>
            </div>`
      }

      <div class="toolbar">
        <div class="row-actions" style="flex:1; flex-wrap:wrap;">
          <select id="an-flt-acc" class="filter-inline-select" aria-label="Filter by account">
            <option value="">All Accounts</option>
            ${accounts.map((a) => `<option value="${a.id}" ${analysisState.accountId === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
          </select>
          <select id="an-flt-fam" class="filter-inline-select" aria-label="Filter by family">
            <option value="">All Family</option>
            ${family.map((f) => `<option value="${f.id}" ${analysisState.familyId === f.id ? 'selected' : ''}>${escapeHtml(f.name)}</option>`).join('')}
          </select>
        </div>
        <button type="button" class="btn btn-secondary btn-sm" id="btn-export-pdf-report">📄 PDF Report</button>
      </div>

      <section class="hero-card">
        <div class="hero-split">
          <div>
            <div class="hero-stat-label text-danger">Spending</div>
            <div class="hero-stat-value">${fmt(report.spending)}</div>
          </div>
          <div class="hero-split-right">
            <div class="hero-stat-label text-success">Income</div>
            <div class="hero-stat-value">${fmt(report.income)}</div>
          </div>
        </div>
        <div class="hero-footer-pill" style="margin-bottom:10px;">
          <span class="text-muted">Net Balance</span>
          <strong class="${report.netBalance < 0 ? 'text-danger' : 'text-success'}">${fmt(report.netBalance)}</strong>
        </div>
        <div class="item-meta" style="line-height:1.45;">
          ✦ <strong>${fmt(report.spending)}</strong> spent in ${escapeHtml(report.period.label)}.
          ${
            report.prevSamePointSpend > 0
              ? `At the same point in ${escapeHtml(report.period.prevLabel)} it was <strong>${fmt(report.prevSamePointSpend)}</strong>.`
              : `Previous period (${escapeHtml(report.period.prevLabel)}): <strong>${fmt(report.prevSpending)}</strong>.`
          }
        </div>
      </section>

      ${
        analysisState.mode === 'month'
          ? `<section class="card stack" style="gap:10px;">
              <div class="toolbar">
                <span class="card-title">Budget</span>
                <a href="#/budgets" class="btn btn-secondary btn-sm">${overallBudget ? 'Manage Budgets' : 'Set Up Budget'}</a>
              </div>
              ${
                overallBudget
                  ? `<div>
                      <div style="display:flex; justify-content:space-between; font-size:0.86rem;">
                        <span>${escapeHtml(overallBudget.budget.name)}</span>
                        <strong>${fmt(overallBudget.spentPaise)} / ${fmt(overallBudget.effectiveBudgetPaise)} (${Math.round(overallBudget.percentUsed)}%)</strong>
                      </div>
                      <div class="progress-track" style="height:8px;">
                        <div class="progress-fill" style="width:${Math.min(100, Math.round(overallBudget.percentUsed))}%; background:${overallBudget.status === 'exceeded' ? 'var(--danger)' : overallBudget.status === 'warning' ? 'var(--warning)' : 'var(--success)'};"></div>
                      </div>
                      <div class="item-meta" style="margin-top:6px;">
                        Remaining: <strong>${fmt(overallBudget.remainingPaise)}</strong> · ${overallBudget.daysRemaining} days left · Projected: ${fmt(overallBudget.projectedMonthEndPaise)}
                      </div>
                    </div>`
                  : `<div class="item-meta">No budget set for ${escapeHtml(report.period.label)}.</div>`
              }
            </section>`
          : ''
      }

      <section class="card stack" style="gap:12px;">
        <div class="toolbar">
          <span class="card-title">Categories</span>
          <div class="segmented">
            <button type="button" data-an-cat="expense" class="${analysisState.catTab === 'expense' ? 'active' : ''}">Spending</button>
            <button type="button" data-an-cat="income" class="${analysisState.catTab === 'income' ? 'active' : ''}">Income</button>
          </div>
        </div>

        ${renderDoughnutChartSvg(activeCatRows, {
          totalPaise: activeCatTotal,
          centerLabel: analysisState.catTab === 'expense' ? 'Spending' : 'Income',
          showBalances: show,
        })}

        ${
          activeCatRows.length === 0
            ? `<div class="item-meta">No ${analysisState.catTab} transactions in this period.</div>`
            : `<div class="grouped-card">
                ${activeCatRows
                  .map((r) => {
                    const color = getCategoryColor(r.category);
                    let deltaHtml = '<span class="item-meta">—</span>';
                    if (r.deltaPct !== null) {
                      const up = r.deltaPct >= 0;
                      const cls = analysisState.catTab === 'expense' ? (up ? 'text-danger' : 'text-success') : (up ? 'text-success' : 'text-danger');
                      deltaHtml = `<span class="${cls}" style="font-size:0.72rem; font-weight:600;">${up ? '▲' : '▼'} ${Math.abs(Math.round(r.deltaPct))}%</span>`;
                    }
                    return `
                      <div class="grouped-row grouped-row-clickable" data-an-open-cat="${r.id}">
                        <div class="list-row-main" style="min-width:0;">
                          <span class="avatar-badge" style="width:34px; height:34px; font-size:0.95rem; background:${escapeHtml(color)}26; border:1px solid ${escapeHtml(color)}55;">
                            ${escapeHtml(r.category.icon)}
                          </span>
                          <div style="min-width:0;">
                            <div class="item-title" style="font-size:0.88rem;">${escapeHtml(r.category.name)}</div>
                            <div class="item-meta">${r.count} txn${r.count === 1 ? '' : 's'} · ${r.sharePct.toFixed(1)}%</div>
                          </div>
                        </div>
                        <div class="row-actions">
                          <div style="text-align:right;">
                            <div class="item-title" style="font-variant-numeric:tabular-nums;">${fmt(r.total)}</div>
                            <div>${deltaHtml}</div>
                          </div>
                          <span class="text-muted">›</span>
                        </div>
                      </div>`;
                  })
                  .join('')}
              </div>`
        }
      </section>

      <section class="card stack" style="gap:12px;">
        <div class="toolbar">
          <span class="card-title">Trends</span>
          <div class="segmented">
            <button type="button" data-an-trend="expense" class="${analysisState.trendTab === 'expense' ? 'active' : ''}">Spending</button>
            <button type="button" data-an-trend="income" class="${analysisState.trendTab === 'income' ? 'active' : ''}">Income</button>
          </div>
        </div>

        <div>
          <div class="item-meta" style="margin-bottom:4px;">Cumulative Total (tap any point for date &amp; value)</div>
          ${renderCumulativeTrendSvg({
            keys: activeTrend.current.keys,
            labels: activeTrend.current.labels,
            current: activeTrend.current.cumulative,
            previous: activeTrend.previous.cumulative,
            elapsedCount: report.period.granularity === 'day' ? report.elapsedDays : null,
            projectedEnd: analysisState.trendTab === 'expense' && analysisState.mode === 'month' ? report.projectedSpend : null,
            showCompare: analysisState.comparePrev,
            accentColor: trendColor,
            showBalances: show,
          })}
        </div>

        <div>
          <div class="item-meta" style="margin-bottom:4px;">${report.period.granularity === 'month' ? 'Month-wise' : 'Day-wise'} (tap any bar for exact value)</div>
          ${renderBarChartSvg({
            keys: activeTrend.current.keys,
            labels: activeTrend.current.labels,
            values: activeTrend.current.values,
            avgValue: activeBarAvg,
            barColor: trendColor,
            showBalances: show,
          })}
        </div>

        <div class="toggle-bar">
          <span>Compare with <strong>${escapeHtml(report.period.prevLabel)}</strong></span>
          <label class="switch">
            <input type="checkbox" id="an-compare-toggle" ${analysisState.comparePrev ? 'checked' : ''}>
            <span class="switch-track"></span>
          </label>
        </div>

        ${
          analysisState.mode === 'month' && report.spending > 0
            ? `<div class="item-meta">✦ Projected month-end spending: <strong>${fmt(report.projectedSpend)}</strong>.</div>`
            : ''
        }
      </section>

      <section class="card stack" style="gap:12px;">
        <div class="toolbar">
          <span class="card-title">Payment Modes</span>
          <div class="segmented">
            <button type="button" data-an-pm="expense" class="${analysisState.modeTab === 'expense' ? 'active' : ''}">Spending</button>
            <button type="button" data-an-pm="income" class="${analysisState.modeTab === 'income' ? 'active' : ''}">Income</button>
            <button type="button" data-an-pm="transfer" class="${analysisState.modeTab === 'transfer' ? 'active' : ''}">Transfers</button>
          </div>
        </div>
        ${
          activeModeRows.length === 0
            ? `<div class="item-meta">No ${analysisState.modeTab} activity in this period.</div>`
            : analysisState.modeTab === 'transfer'
              ? `<div class="grouped-card">
                  ${activeModeRows
                    .map(
                      (r) => `
                      <div class="grouped-row" style="padding:11px 14px;">
                        <div style="min-width:0; display:flex; align-items:center; gap:6px; overflow:hidden;">
                          <span class="item-title" style="font-size:0.86rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(r.sourceAccount.name)}</span>
                          <span class="text-muted">→</span>
                          <span class="item-title" style="font-size:0.86rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(r.destinationAccount.name)}</span>
                        </div>
                        <strong style="font-variant-numeric:tabular-nums; flex-shrink:0;">${fmt(r.total)}</strong>
                      </div>`
                    )
                    .join('')}
                </div>`
              : `<div class="grouped-card">
                  ${activeModeRows
                    .map(
                      (r) => `
                      <div class="grouped-row" style="padding:10px 14px;">
                        <span class="item-title" style="font-size:0.88rem;">${escapeHtml(r.account.icon || '🏛️')} ${escapeHtml(r.account.name)}</span>
                        <strong style="font-variant-numeric:tabular-nums;">${fmt(r.total)}</strong>
                      </div>`
                    )
                    .join('')}
                </div>`
        }
      </section>

      <section class="card stack" style="gap:10px;">
        <span class="card-title">Spending by Day of Week</span>
        <div class="item-meta">Spot weekday vs. weekend spending patterns (tap any bar).</div>
        ${renderBarChartSvg({
          keys: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
          labels: report.weekdaySpend.labels,
          values: report.weekdaySpend.values,
          avgValue: weekdayAvg,
          barColor: '#818cf8',
          showBalances: show,
        })}
      </section>

      ${
        report.topExpenses.length > 0
          ? `<section class="card stack" style="gap:10px;">
              <div class="toolbar">
                <span class="card-title">Top 5 Largest Expenses</span>
                <span class="badge badge-accent">${Math.round(report.top5SharePct)}% of spend</span>
              </div>
              <div class="grouped-card">
                ${report.topExpenses
                  .map((tx) => {
                    const cat = tx.category_id ? report.lookups.catMap.get(tx.category_id) : null;
                    const color = getCategoryColor(cat);
                    return `
                      <div class="grouped-row grouped-row-clickable" data-an-edit-tx="${tx.id}" style="padding:10px 12px;">
                        <div class="list-row-main" style="min-width:0;">
                          <span class="avatar-badge" style="width:32px; height:32px; font-size:0.9rem; background:${escapeHtml(color)}26;">${escapeHtml(cat?.icon || '🧾')}</span>
                          <div style="min-width:0;">
                            <div class="item-title" style="font-size:0.86rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(tx.description || cat?.name || 'Expense')}</div>
                            <div class="item-meta">${escapeHtml(cat?.name || '')} · ${escapeHtml(tx.date_key)}</div>
                          </div>
                        </div>
                        <strong class="text-danger" style="font-variant-numeric:tabular-nums;">${fmt(tx.amount_paise)}</strong>
                      </div>`;
                  })
                  .join('')}
              </div>
            </section>`
          : ''
      }

      ${
        report.tags.length > 0
          ? `<section class="card stack" style="gap:10px;">
              <span class="card-title">Tags</span>
              <div class="chip-picker">
                ${report.tags
                  .slice(0, 15)
                  .map(
                    (r) => `
                    <button type="button" class="chip-btn" data-an-tag="${r.id}">
                      ${escapeHtml(formatTagDisplay(r.tag))} · <strong>${fmt(r.total)}</strong>
                    </button>`
                  )
                  .join('')}
              </div>
            </section>`
          : ''
      }

      ${
        report.family.length > 0
          ? `<section class="card stack" style="gap:10px;">
              <span class="card-title">Family Spending</span>
              <div class="grouped-card">
                ${report.family
                  .map(
                    (r) => `
                    <div class="grouped-row" style="padding:10px 14px;">
                      <span class="item-title" style="font-size:0.88rem;">${escapeHtml(r.member.icon || '👤')} ${escapeHtml(r.member.name)}</span>
                      <strong style="font-variant-numeric:tabular-nums;">${fmt(r.total)}</strong>
                    </div>`
                  )
                  .join('')}
              </div>
            </section>`
          : ''
      }

      <section class="card stack" style="gap:12px;">
        <span class="card-title">Stats</span>
        <div class="grid-2">
          <div>
            <div class="hero-stat-label text-danger">Avg Spending / Day</div>
            <div class="item-title" style="font-size:1.08rem; margin-top:4px;">${fmt(report.stats.avgSpendPerDay)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-danger">Avg Spending / Txn</div>
            <div class="item-title" style="font-size:1.08rem; margin-top:4px;">${fmt(report.stats.avgSpendPerTx)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-success">Avg Income / Day</div>
            <div class="item-title" style="font-size:1.08rem; margin-top:4px;">${fmt(report.stats.avgIncomePerDay)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-success">Avg Income / Txn</div>
            <div class="item-title" style="font-size:1.08rem; margin-top:4px;">${fmt(report.stats.avgIncomePerTx)}</div>
          </div>
        </div>
        ${
          report.stats.highestBucket
            ? `<div class="item-meta">Highest spending ${report.period.granularity === 'month' ? 'month' : 'day'}: <strong>${escapeHtml(report.stats.highestBucket.key)}</strong> (${fmt(report.stats.highestBucket.amount)})</div>`
            : ''
        }
      </section>
    </div>
  `;

  bindChartTooltips(container);
  container.querySelector('#btn-clear-analysis-filter')?.addEventListener('click', () => {
    state.analysisFilter = null;
    renderAnalysisView(container, ctx);
  });

  container.querySelectorAll('[data-an-mode]').forEach((b) => {
    b.addEventListener('click', () => {
      analysisState.mode = b.getAttribute('data-an-mode');
      analysisState.weekOffset = 0;
      renderAnalysisView(container, ctx);
    });
  });

  container.querySelector('#an-prev')?.addEventListener('click', () => {
    if (analysisState.mode === 'week') analysisState.weekOffset -= 1;
    else if (analysisState.mode === 'year' || analysisState.mode === 'fy') state.selectedYear -= 1;
    else {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, -1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
    }
    renderAnalysisView(container, ctx);
  });

  container.querySelector('#an-next')?.addEventListener('click', () => {
    if (analysisState.mode === 'week') analysisState.weekOffset += 1;
    else if (analysisState.mode === 'year' || analysisState.mode === 'fy') state.selectedYear += 1;
    else {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, 1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
    }
    renderAnalysisView(container, ctx);
  });

  container.querySelector('#an-custom-start')?.addEventListener('change', (e) => {
    analysisState.customStart = e.target.value;
    renderAnalysisView(container, ctx);
  });
  container.querySelector('#an-custom-end')?.addEventListener('change', (e) => {
    analysisState.customEnd = e.target.value;
    renderAnalysisView(container, ctx);
  });

  container.querySelector('#an-flt-acc')?.addEventListener('change', (e) => {
    analysisState.accountId = e.target.value;
    renderAnalysisView(container, ctx);
  });
  container.querySelector('#an-flt-fam')?.addEventListener('change', (e) => {
    analysisState.familyId = e.target.value;
    renderAnalysisView(container, ctx);
  });

  container.querySelectorAll('[data-an-cat]').forEach((b) => {
    b.addEventListener('click', () => {
      analysisState.catTab = b.getAttribute('data-an-cat');
      renderAnalysisView(container, ctx);
    });
  });

  container.querySelectorAll('[data-an-trend]').forEach((b) => {
    b.addEventListener('click', () => {
      analysisState.trendTab = b.getAttribute('data-an-trend');
      renderAnalysisView(container, ctx);
    });
  });

  container.querySelectorAll('[data-an-pm]').forEach((b) => {
    b.addEventListener('click', () => {
      analysisState.modeTab = b.getAttribute('data-an-pm');
      renderAnalysisView(container, ctx);
    });
  });

  container.querySelector('#an-compare-toggle')?.addEventListener('change', (e) => {
    analysisState.comparePrev = e.target.checked;
    renderAnalysisView(container, ctx);
  });

  // Tapping any category opens full Category Detail Analytics view!
  container.querySelectorAll('[data-an-open-cat]').forEach((row) => {
    row.addEventListener('click', () => {
      state.selectedCategoryId = row.getAttribute('data-an-open-cat');
      window.location.hash = '#/category-detail';
    });
  });

  container.querySelectorAll('[data-an-edit-tx]').forEach((row) => {
    row.addEventListener('click', () => {
      state.txDraft = { editId: row.getAttribute('data-an-edit-tx'), returnRoute: 'analysis' };
      window.location.hash = '#/add-transaction';
    });
  });

  container.querySelectorAll('[data-an-tag]').forEach((b) => {
    b.addEventListener('click', () => {
      state.selectedTagId = b.getAttribute('data-an-tag');
      window.location.hash = '#/tag-detail';
    });
  });

  container.querySelector('#btn-export-pdf-report')?.addEventListener('click', () => {
    const html = services.analytics.buildPrintableReportHtml(report);
    const win = window.open('', '_blank');
    if (win) {
      win.document.open();
      win.document.write(html);
      win.document.close();
    } else {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Statement_${report.period.label.replace(/\s+/g, '_')}.html`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('Statement downloaded — open in Chrome and tap Print → Save as PDF');
    }
  });
}

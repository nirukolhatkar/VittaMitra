import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString } from '../../utils/money.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { getMonthLabel, shiftMonth } from '../../utils/date.js';
import { BudgetService } from '../../services/budgetService.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { openAddTransactionWithContext, setPageContext } from '../../services/txContextClipboard.js';

const budgetsViewState = {
  tab: 'monthly', // 'monthly' | 'annual'
};

export async function renderBudgetsView(container, ctx) {
  const { repos, services, state } = ctx;
  const [settings, expenseCats, tags, evalRes] = await Promise.all([
    repos.settings.getSettings(),
    repos.categories.list({ type: 'expense', includeArchived: false }),
    repos.tags.list({ includeArchived: false }),
    services.budgets.evaluateMonthBudgets(state.selectedYear, state.selectedMonth),
  ]);

  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');
  const monthLabel = getMonthLabel(state.selectedYear, state.selectedMonth);
  const periodKey = BudgetService.monthKey(state.selectedYear, state.selectedMonth);

  // Trigger non-repeating toast alerts for any newly crossed thresholds
  for (const alert of evalRes.newAlerts) {
    showToast(`Budget alert: "${alert.budgetName}" reached ${alert.threshold}% (${Math.round(alert.percentUsed)}% used)`, {
      type: alert.threshold >= 100 ? 'error' : 'info',
      durationMs: 4500,
    });
  }

  const openBudgetModal = (existing = null) => {
    const isEdit = Boolean(existing);
    const scopeType = existing?.scope_type || 'overall';
    const thresholds = existing?.alert_thresholds || [50, 75, 90, 100];

    openModal({
      title: isEdit ? 'Edit Budget' : 'Create Budget',
      bodyHtml: `
        <form id="budget-form">
          <div class="form-group">
            <label class="form-label" for="b-scope">Budget Type</label>
            <select id="b-scope" name="scope_type" class="form-control">
              <option value="overall" ${scopeType === 'overall' ? 'selected' : ''}>Overall Monthly Budget</option>
              <option value="category" ${scopeType === 'category' ? 'selected' : ''}>Category / Subcategory Budget</option>
              <option value="tag" ${scopeType === 'tag' ? 'selected' : ''}>Tag Budget</option>
            </select>
          </div>

          <div class="form-group ${scopeType === 'category' ? '' : 'hidden'}" id="b-cat-wrap">
            <label class="form-label" for="b-cat">Expense Category</label>
            <select id="b-cat" name="category_id" class="form-control">
              ${expenseCats
                .map((c) => `<option value="${c.id}" ${existing?.scope_id === c.id ? 'selected' : ''}>${escapeHtml(c.icon)} ${escapeHtml(c.name)}</option>`)
                .join('')}
            </select>
          </div>

          <div class="form-group ${scopeType === 'tag' ? '' : 'hidden'}" id="b-tag-wrap">
            <label class="form-label" for="b-tag">Tag</label>
            <select id="b-tag" name="tag_id" class="form-control">
              ${tags
                .map((t) => `<option value="${t.id}" ${existing?.scope_id === t.id ? 'selected' : ''}>${escapeHtml(formatTagDisplay(t))}</option>`)
                .join('')}
            </select>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="b-name">Budget Name</label>
              <input id="b-name" name="name" class="form-control" required maxlength="60"
                value="${escapeHtml(existing?.name || 'Monthly Spending Limit')}" placeholder="e.g. Groceries">
            </div>
            <div class="form-group">
              <label class="form-label" for="b-amount">Monthly Limit (₹)</label>
              <input id="b-amount" name="amount_rupees" class="form-control" inputmode="decimal" required
                value="${existing ? paiseToDecimalString(existing.amount_paise) : ''}" placeholder="e.g. 50000">
            </div>
          </div>

          <div class="form-group">
            <label class="checkbox-row">
              <input type="checkbox" name="is_recurring" ${existing ? (existing.is_recurring ? 'checked' : '') : 'checked'}>
              <span>Repeat automatically every month</span>
            </label>
          </div>

          <div class="form-group">
            <label class="checkbox-row">
              <input type="checkbox" name="carry_forward" ${existing?.carry_forward ? 'checked' : ''}>
              <span>Carry forward unused budget from previous month</span>
            </label>
          </div>

          <div class="form-group">
            <label class="form-label" for="b-thresholds">Alert Thresholds (% comma-separated)</label>
            <input id="b-thresholds" name="thresholds" class="form-control"
              value="${escapeHtml(thresholds.join(', '))}" placeholder="50, 75, 90, 100">
          </div>

          <div class="modal-footer" style="justify-content:space-between;">
            ${isEdit ? '<button type="button" class="btn btn-danger btn-sm" id="b-delete">Delete</button>' : '<div></div>'}
            <div class="row-actions">
              <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
              <button type="submit" class="btn btn-primary">${isEdit ? 'Save' : 'Create'}</button>
            </div>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        const scopeSel = panel.querySelector('#b-scope');
        const catWrap = panel.querySelector('#b-cat-wrap');
        const tagWrap = panel.querySelector('#b-tag-wrap');
        const nameInput = panel.querySelector('#b-name');

        scopeSel.addEventListener('change', () => {
          const val = scopeSel.value;
          catWrap.classList.toggle('hidden', val !== 'category');
          tagWrap.classList.toggle('hidden', val !== 'tag');
          if (!isEdit) {
            if (val === 'overall') nameInput.value = 'Monthly Spending Limit';
            else if (val === 'category') nameInput.value = expenseCats[0]?.name || 'Category Budget';
            else nameInput.value = tags[0] ? formatTagDisplay(tags[0]) : 'Tag Budget';
          }
        });

        panel.querySelector('#b-delete')?.addEventListener('click', async () => {
          await repos.budgets.softDelete(existing.id);
          close();
          renderBudgetsView(container, ctx);
          showToast(`Budget "${existing.name}" deleted`, {
            actionLabel: 'Undo',
            onAction: async () => {
              await repos.budgets.restore(existing.id);
              renderBudgetsView(container, ctx);
              showToast('Budget restored');
            },
          });
        });

        panel.querySelector('#budget-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const sType = fd.get('scope_type');
          const sId = sType === 'category' ? fd.get('category_id') : sType === 'tag' ? fd.get('tag_id') : null;
          const thList = String(fd.get('thresholds') || '50,75,90,100')
            .split(',')
            .map((x) => Number(x.trim()))
            .filter((n) => Number.isFinite(n) && n > 0);

          const payload = {
            name: fd.get('name'),
            scope_type: sType,
            scope_id: sId,
            amount_rupees: fd.get('amount_rupees'),
            period_month: existing?.period_month || periodKey,
            is_recurring: panel.querySelector('[name="is_recurring"]').checked,
            carry_forward: panel.querySelector('[name="carry_forward"]').checked,
            alert_thresholds: thList,
          };

          try {
            if (isEdit) {
              await repos.budgets.updateBudget(existing.id, payload);
              showToast('Budget updated');
            } else {
              await repos.budgets.createBudget(payload);
              showToast('Budget created');
            }
            close();
            renderBudgetsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  if (budgetsViewState.tab === 'annual') {
    const yearReport = await services.analytics.buildAnalysisReport({
      mode: 'year',
      year: state.selectedYear,
      month: state.selectedMonth,
    });
    const allBudgets = await repos.budgets.listAll();
    const annualTotalBudget = allBudgets.reduce((s, b) => s + b.amount_paise * 12, 0);

    container.innerHTML = `
      <div class="stack">
        <div class="toolbar">
          <div class="segmented">
            <button type="button" data-b-tab="monthly">Monthly</button>
            <button type="button" data-b-tab="annual" class="active">Annual (${state.selectedYear})</button>
          </div>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-budget">+ Add Budget</button>
        </div>

        <section class="hero-card">
          <div class="hero-kicker">ANNUAL BUDGET PLAN · ${state.selectedYear}</div>
          <div class="hero-split" style="margin-top:10px; margin-bottom:0;">
            <div>
              <div class="hero-stat-label text-danger">YTD Spending</div>
              <div class="hero-stat-value">${fmt(yearReport.spending)}</div>
            </div>
            <div class="hero-split-right">
              <div class="hero-stat-label text-success">Annualized Plan</div>
              <div class="hero-stat-value">${fmt(annualTotalBudget)}</div>
            </div>
          </div>
        </section>

        ${
          allBudgets.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-title">No budgets configured yet</div>
                <p class="empty-state-text">Add monthly budgets to automatically build your annual plan.</p>
              </div>`
            : `<div class="grouped-card">
                ${allBudgets
                  .map(
                    (b) => `
                    <div class="grouped-row grouped-row-clickable" data-edit-budget="${b.id}">
                      <div>
                        <div class="item-title">${escapeHtml(b.name)}</div>
                        <div class="item-meta">${fmt(b.amount_paise)} / month · ${b.scope_type}</div>
                      </div>
                      <strong style="font-variant-numeric:tabular-nums;">${fmt(b.amount_paise * 12)} / yr</strong>
                    </div>`
                  )
                  .join('')}
              </div>`
        }
      </div>
    `;
  } else {
    container.innerHTML = `
      <div class="stack">
        <div class="toolbar">
          <div class="segmented">
            <button type="button" data-b-tab="monthly" class="active">Monthly</button>
            <button type="button" data-b-tab="annual">Annual</button>
          </div>
          <div class="month-pill">
            <button type="button" id="b-prev-month">‹</button>
            <span class="month-pill-label">${monthLabel}</span>
            <button type="button" id="b-next-month">›</button>
          </div>
        </div>

        <div class="toolbar">
          <button type="button" class="btn btn-secondary btn-sm" id="btn-copy-prev-budget">⧉ Copy Prev Month</button>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-budget">+ Add Budget</button>
        </div>

        ${
          evalRes.budgets.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🎯</div>
                <h3 class="empty-state-title">No budgets for ${monthLabel}</h3>
                <p class="empty-state-text">
                  Create an Overall, Category, or Tag budget with configurable 50/75/90/100% alerts and optional carry-forward.
                </p>
                <button type="button" class="btn btn-primary btn-sm" id="btn-empty-add-budget">+ Create First Budget</button>
              </div>`
            : `<div class="stack">
                ${evalRes.budgets
                  .map((ev) => {
                    const barColor =
                      ev.status === 'exceeded' ? 'var(--danger)' : ev.status === 'warning' ? 'var(--warning)' : 'var(--success)';
                    return `
                      <div class="card stack" style="gap:10px;" data-edit-budget="${ev.budget.id}">
                        <div class="toolbar">
                          <div>
                            <div class="item-title">
                              ${escapeHtml(ev.budget.name)}
                              <span class="badge badge-muted">${ev.budget.scope_type}</span>
                              ${ev.carryForwardPaise > 0 ? `<span class="badge badge-accent">+${fmt(ev.carryForwardPaise)} carry-fwd</span>` : ''}
                            </div>
                            <div class="item-meta">Budget: ${fmt(ev.effectiveBudgetPaise)} · ${ev.daysRemaining} days remaining</div>
                          </div>
                          <button type="button" class="btn btn-secondary btn-sm" data-edit-budget-btn="${ev.budget.id}">Edit</button>
                        </div>

                        <div>
                          <div style="display:flex; justify-content:space-between; font-size:0.86rem;">
                            <span>Spent: <strong>${fmt(ev.spentPaise)}</strong> (${Math.round(ev.percentUsed)}%)</span>
                            <span class="${ev.remainingPaise < 0 ? 'text-danger' : 'text-success'}">
                              ${ev.remainingPaise < 0 ? 'Over by ' : 'Left: '}<strong>${fmt(Math.abs(ev.remainingPaise))}</strong>
                            </span>
                          </div>
                          <div class="progress-track" style="height:9px;">
                            <div class="progress-fill" style="width:${Math.min(100, Math.round(ev.percentUsed))}%; background:${barColor};"></div>
                          </div>
                        </div>

                        <div style="display:flex; justify-content:space-between; font-size:0.76rem; color:var(--text-muted);">
                          <span>Avg/day: <strong>${fmt(ev.avgDailySpendPaise)}</strong></span>
                          <span>Projected end: <strong class="${ev.projectedMonthEndPaise > ev.effectiveBudgetPaise ? 'text-danger' : ''}">${fmt(ev.projectedMonthEndPaise)}</strong></span>
                        </div>
                      </div>
                    `;
                  })
                  .join('')}
              </div>`
        }
      </div>
    `;
  }

  container.querySelectorAll('[data-b-tab]').forEach((b) => {
    b.addEventListener('click', () => {
      budgetsViewState.tab = b.getAttribute('data-b-tab');
      renderBudgetsView(container, ctx);
    });
  });

  container.querySelector('#b-prev-month')?.addEventListener('click', () => {
    const next = shiftMonth(state.selectedYear, state.selectedMonth, -1);
    state.selectedYear = next.year;
    state.selectedMonth = next.month;
    renderBudgetsView(container, ctx);
  });

  container.querySelector('#b-next-month')?.addEventListener('click', () => {
    const next = shiftMonth(state.selectedYear, state.selectedMonth, 1);
    state.selectedYear = next.year;
    state.selectedMonth = next.month;
    renderBudgetsView(container, ctx);
  });

  container.querySelector('#btn-add-budget')?.addEventListener('click', () => openBudgetModal());
  container.querySelector('#btn-empty-add-budget')?.addEventListener('click', () => openBudgetModal());

  container.querySelector('#btn-copy-prev-budget')?.addEventListener('click', async () => {
    const res = await services.budgets.copyPreviousMonthBudgets(state.selectedYear, state.selectedMonth);
    showToast(
      res.copiedCount > 0
        ? `Copied ${res.copiedCount} budget${res.copiedCount === 1 ? '' : 's'} from ${res.fromMonth}`
        : `No new budgets found in ${res.fromMonth} to copy`
    );
    renderBudgetsView(container, ctx);
  });

  container.querySelectorAll('[data-edit-budget-btn], [data-edit-budget]').forEach((el) => {
    el.addEventListener('click', async (e) => {
      const id = el.getAttribute('data-edit-budget-btn') || el.getAttribute('data-edit-budget');
      if (!el.hasAttribute('data-edit-budget-btn') && e.target.closest('button')) return;
      const b = await repos.budgets.getById(id);
      if (b) openBudgetModal(b);
    });
  });
}

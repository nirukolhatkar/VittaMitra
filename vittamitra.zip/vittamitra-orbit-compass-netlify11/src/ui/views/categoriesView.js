import { setPageContext } from '../../services/txContextClipboard.js';
import { escapeHtml } from '../../utils/dom.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const viewState = {
  type: 'expense',
  showArchived: false,
};

export async function renderCategoriesView(container, ctx) {
  setPageContext(ctx, { sourceLabel: 'Categories' });
  const { repos, services } = ctx;
  const tree = await repos.categories.listTree({
    type: viewState.type,
    includeArchived: viewState.showArchived,
  });

  const allParents = (await repos.categories.list({ type: viewState.type, includeArchived: false }))
    .filter((c) => !c.parent_id);

  container.innerHTML = `
    <div class="stack">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Categories</h2>
          <div class="compass-subtitle">Organise spending and income categories</div>
        </div>
      </div>
      <div class="toolbar">
        <div class="segmented" role="tablist" aria-label="Category type">
          <button type="button" data-cat-type="expense" class="${viewState.type === 'expense' ? 'active' : ''}">Expense</button>
          <button type="button" data-cat-type="income" class="${viewState.type === 'income' ? 'active' : ''}">Income</button>
        </div>

        <div class="row-actions">
          <label class="checkbox-row" style="font-size:0.84rem;">
            <input type="checkbox" id="toggle-archived-cats" ${viewState.showArchived ? 'checked' : ''}>
            <span>Show archived</span>
          </label>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-category">+ Add Category</button>
        </div>
      </div>

      ${
        tree.length === 0
          ? `<div class="empty-state">
              <div class="empty-state-icon">🏷️</div>
              <h3 class="empty-state-title">No ${viewState.type} categories</h3>
              <p class="empty-state-text">Create a category to organise your ${viewState.type} records.</p>
            </div>`
          : `<div class="list" id="category-list">
              ${tree
                .map(
                  (cat) => `
                  <div>
                    <div class="list-row" data-cat-id="${cat.id}">
                      <div class="list-row-main">
                        <span class="avatar-badge" style="background:${escapeHtml(cat.color)}20; color:${escapeHtml(cat.color)};">
                          ${escapeHtml(cat.icon)}
                        </span>
                        <div>
                          <div class="item-title">
                            ${escapeHtml(cat.name)}
                            ${cat.is_archived ? '<span class="badge badge-muted">Archived</span>' : ''}
                          </div>
                          <div class="item-meta">
                            ${cat.subcategories.length} subcategor${cat.subcategories.length === 1 ? 'y' : 'ies'}
                            ${cat.is_default ? ' · Default' : ''}
                          </div>
                        </div>
                      </div>
                      <div class="row-actions">
                        <button type="button" class="btn btn-secondary btn-sm" data-edit-cat="${cat.id}">Edit</button>
                        <button type="button" class="icon-btn" data-cat-menu="${cat.id}" data-cat-is-parent="1" aria-label="More category options" title="More options">⋮</button>
                      </div>
                    </div>

                    ${
                      cat.subcategories.length > 0
                        ? `<div class="subcategory-list">
                            ${cat.subcategories
                              .map(
                                (sub) => `
                                <div class="list-row" data-cat-id="${sub.id}">
                                  <div class="list-row-main">
                                    <span class="avatar-badge" style="width:32px; height:32px; font-size:0.95rem; background:${escapeHtml(sub.color)}20;">
                                      ${escapeHtml(sub.icon)}
                                    </span>
                                    <div>
                                      <div class="item-title">
                                        ${escapeHtml(sub.name)}
                                        ${sub.is_archived ? '<span class="badge badge-muted">Archived</span>' : ''}
                                      </div>
                                      <div class="item-meta">Subcategory of ${escapeHtml(cat.name)}</div>
                                    </div>
                                  </div>
                                  <div class="row-actions">
                                    <button type="button" class="btn btn-secondary btn-sm" data-edit-cat="${sub.id}">Edit</button>
                                    <button type="button" class="icon-btn" data-cat-menu="${sub.id}" data-cat-is-parent="0" aria-label="More subcategory options" title="More options">⋮</button>
                                  </div>
                                </div>`
                              )
                              .join('')}
                          </div>`
                        : ''
                    }
                  </div>`
                )
                .join('')}
            </div>`
      }
    </div>
  `;

  container.querySelectorAll('[data-cat-type]').forEach((btn) => {
    btn.addEventListener('click', () => {
      viewState.type = btn.getAttribute('data-cat-type');
      renderCategoriesView(container, ctx);
    });
  });

  container.querySelector('#toggle-archived-cats')?.addEventListener('change', (e) => {
    viewState.showArchived = e.target.checked;
    renderCategoriesView(container, ctx);
  });

  const openCategoryForm = (existing = null, defaultParentId = null) => {
    const isEdit = Boolean(existing);
    const parentId = existing ? existing.parent_id : defaultParentId;
    const parentOptions = allParents
      .filter((p) => !existing || p.id !== existing.id)
      .map(
        (p) =>
          `<option value="${p.id}" ${parentId === p.id ? 'selected' : ''}>${escapeHtml(p.icon)} ${escapeHtml(p.name)}</option>`
      )
      .join('');

    openModal({
      title: isEdit ? 'Edit Category' : parentId ? 'Add Subcategory' : 'Add Category',
      bodyHtml: `
        <form id="category-form">
          <div class="form-group">
            <label class="form-label" for="cat-name">Category Name</label>
            <input id="cat-name" name="name" class="form-control" required maxlength="60"
              value="${escapeHtml(existing?.name || '')}" placeholder="e.g. Groceries, Broadband">
          </div>
          <div class="form-group">
            <label class="form-label" for="cat-parent">Parent Category (optional)</label>
            <select id="cat-parent" name="parent_id" class="form-control">
              <option value="">None (Top-level ${viewState.type} category)</option>
              ${parentOptions}
            </select>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="cat-icon">Icon (Emoji)</label>
              <input id="cat-icon" name="icon" class="form-control" maxlength="4"
                value="${escapeHtml(existing?.icon || '🏷️')}">
            </div>
            <div class="form-group">
              <label class="form-label" for="cat-color">Colour</label>
              <input id="cat-color" name="color" type="color" class="form-control" style="height:42px; padding:4px;"
                value="${escapeHtml(existing?.color || '#34d399')}">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Create'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        const form = panel.querySelector('#category-form');
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          const payload = {
            name: fd.get('name'),
            type: existing ? existing.type : viewState.type,
            parent_id: fd.get('parent_id') || null,
            icon: fd.get('icon') || '🏷️',
            color: fd.get('color') || '#34d399',
          };
          try {
            if (isEdit) {
              await repos.categories.updateCategory(existing.id, payload);
              showToast('Category updated');
            } else {
              await repos.categories.createCategory(payload);
              showToast('Category created');
            }
            close();
            renderCategoriesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  container.querySelector('#btn-add-category')?.addEventListener('click', () => openCategoryForm());

  container.querySelectorAll('[data-add-sub]').forEach((btn) => {
    btn.addEventListener('click', () => openCategoryForm(null, btn.getAttribute('data-add-sub')));
  });

  container.querySelectorAll('[data-cat-menu]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const catId = btn.getAttribute('data-cat-menu');
      const isParent = btn.getAttribute('data-cat-is-parent') === '1';
      const catObj = await repos.categories.getById(catId);
      if (!catObj) return;
      openModal({
        title: `${catObj.icon || '🏷️'} ${catObj.name}`,
        bodyHtml: `
          <div class="stack" style="gap:8px;">
            ${isParent ? `<button type="button" class="btn btn-secondary" id="cat-m-sub" style="justify-content:flex-start;">+ Add Subcategory</button>` : ''}
            <button type="button" class="btn btn-secondary" id="cat-m-edit" style="justify-content:flex-start;">✏️ Edit Category</button>
            <button type="button" class="btn btn-secondary" id="cat-m-archive" style="justify-content:flex-start;">${catObj.is_archived ? '♻️ Restore Category' : '📦 Archive Category'}</button>
            <button type="button" class="btn btn-danger" id="cat-m-delete" style="justify-content:flex-start;">🗑 Delete Category</button>
            <button type="button" class="btn btn-secondary" data-modal-close style="justify-content:center; margin-top:4px;">Cancel</button>
          </div>
        `,
        onMount: (panel, close) => {
          panel.querySelector('#cat-m-sub')?.addEventListener('click', () => {
            close();
            openCategoryModal({ parentId: catObj.id });
          });
          panel.querySelector('#cat-m-edit')?.addEventListener('click', () => {
            close();
            openCategoryModal({ existing: catObj });
          });
          panel.querySelector('#cat-m-archive')?.addEventListener('click', async () => {
            await repos.categories.setArchived(catObj.id, !catObj.is_archived);
            close();
            showToast(catObj.is_archived ? 'Category restored' : 'Category archived');
            renderCategoriesView(container, ctx);
          });
          panel.querySelector('#cat-m-delete')?.addEventListener('click', async () => {
            const count = await services.transactions.countByCategory(catObj.id);
            if (count > 0) {
              showToast(`Used by ${count} transactions — archive it instead`, { type: 'error' });
              return;
            }
            await repos.categories.softDelete(catObj.id);
            close();
            showToast('Category deleted');
            renderCategoriesView(container, ctx);
          });
        },
      });
    });
  });

  container.querySelectorAll('[data-edit-cat]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const cat = await repos.categories.getById(btn.getAttribute('data-edit-cat'));
      if (cat) openCategoryForm(cat);
    });
  });

  container.querySelectorAll('[data-archive-cat]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-archive-cat');
      const currentlyArchived = btn.getAttribute('data-archived') === 'true';
      try {
        await repos.categories.setArchived(id, !currentlyArchived);
        showToast(currentlyArchived ? 'Category restored' : 'Category archived');
        renderCategoriesView(container, ctx);
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });
  });

  container.querySelectorAll('[data-delete-cat]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-delete-cat');
      try {
        const refCount = services?.transactions ? await services.transactions.countByCategory(id) : 0;
        await repos.categories.deleteCategorySafe(id, { referencedTransactionCount: refCount });
        renderCategoriesView(container, ctx);
        showToast('Category deleted', {
          actionLabel: 'Undo',
          onAction: async () => {
            await repos.categories.restore(id);
            renderCategoriesView(container, ctx);
            showToast('Category restored');
          },
        });
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 4200 });
      }
    });
  });
}

import { escapeHtml } from '../../utils/dom.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const rulesViewState = {
  tab: 'rules', // 'rules' | 'merchants'
  search: '',
};

const RULE_TYPE_LABELS = {
  exact_merchant: 'Exact Merchant',
  narration_pattern: 'Narration Pattern',
  confirmed_preference: 'Confirmed Pref',
};

export async function renderCategorisationRulesView(container, ctx) {
  const { db, repos, services } = ctx;
  if (services.statementCategorisation) {
    await services.statementCategorisation.ensureBuiltInMerchantDictionary();
  }

  const [allRulesRaw, allMerchantsRaw, categories] = await Promise.all([
    db.table('personal_learning_rules').toArray(),
    db.table('merchant_dictionary').toArray(),
    repos.categories.list({ includeArchived: false }),
  ]);

  const catMap = new Map(categories.map((c) => [c.id, c]));
  const rules = allRulesRaw
    .filter((r) => !r.deleted_at)
    .sort((a, b) => (Number(b.priority) || 0) - (Number(a.priority) || 0));

  const merchants = allMerchantsRaw
    .filter((m) => !m.deleted_at)
    .sort((a, b) => {
      const aPers = a.is_builtin === false ? 1 : 0;
      const bPers = b.is_builtin === false ? 1 : 0;
      if (aPers !== bPers) return bPers - aPers;
      return String(a.display_name || a.normalized_merchant).localeCompare(String(b.display_name || b.normalized_merchant));
    });

  const q = rulesViewState.search.trim().toLowerCase();
  const filteredRules = q
    ? rules.filter((r) =>
        `${r.match_key || ''} ${r.match_pattern || ''} ${catMap.get(r.subcategory_id || r.category_id)?.name || ''}`
          .toLowerCase()
          .includes(q)
      )
    : rules;
  const filteredMerchants = q
    ? merchants.filter((m) =>
        `${m.display_name || ''} ${m.normalized_merchant || ''} ${m.category_hint || ''}`
          .toLowerCase()
          .includes(q)
      )
    : merchants;

  const catOptionsHtml = (selectedId) =>
    `<option value="">-- Uncategorized --</option>` +
    categories
      .map(
        (c) =>
          `<option value="${c.id}" ${selectedId === c.id ? 'selected' : ''}>${c.parent_id ? '↳ ' : ''}${escapeHtml(c.name)} (${escapeHtml(c.type)})</option>`
      )
      .join('');

  const openRuleModal = (existing = null) => {
    const isEdit = Boolean(existing);
    openModal({
      title: isEdit ? 'Edit Categorisation Rule' : 'Add Personal Categorisation Rule',
      bodyHtml: `
        <form id="cat-rule-form" class="stack" style="gap:10px;">
          <div class="grid-2" style="gap:8px;">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Rule Type</label>
              <select name="rule_type" class="form-control">
                <option value="exact_merchant" ${(existing?.rule_type || 'exact_merchant') === 'exact_merchant' ? 'selected' : ''}>Exact Merchant</option>
                <option value="narration_pattern" ${existing?.rule_type === 'narration_pattern' ? 'selected' : ''}>Narration Pattern</option>
                <option value="confirmed_preference" ${existing?.rule_type === 'confirmed_preference' ? 'selected' : ''}>Confirmed Preference</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Priority</label>
              <input name="priority" type="number" min="1" max="999" class="form-control" value="${existing?.priority ?? 200}">
            </div>
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Merchant Name or Narration Keyword *</label>
            <input name="match_text" class="form-control" required maxlength="80"
              value="${escapeHtml(existing?.match_pattern || existing?.match_key || '')}" placeholder="e.g. Blue Tokai, school bus, apollo">
          </div>
          <div class="grid-2" style="gap:8px;">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Transaction Type</label>
              <select name="tx_type" class="form-control">
                <option value="expense" ${(existing?.tx_type || 'expense') === 'expense' ? 'selected' : ''}>Expense</option>
                <option value="income" ${existing?.tx_type === 'income' ? 'selected' : ''}>Income</option>
                <option value="transfer" ${existing?.tx_type === 'transfer' ? 'selected' : ''}>Transfer</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Category / Subcategory</label>
              <select name="category_id" class="form-control">${catOptionsHtml(existing?.subcategory_id || existing?.category_id)}</select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">${isEdit ? 'Save Rule' : 'Create Rule'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#cat-rule-form')?.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const ruleType = fd.get('rule_type');
          const matchText = String(fd.get('match_text') || '').trim();
          const chosenId = fd.get('category_id') || null;
          const chosenObj = chosenId ? catMap.get(chosenId) : null;
          const categoryId = chosenObj?.parent_id ? chosenObj.parent_id : chosenId;
          const subcategoryId = chosenObj?.parent_id ? chosenObj.id : null;
          const priority = Number(fd.get('priority')) || 200;
          try {
            if (isEdit) {
              await repos.statementImport.learningRules.update(existing.id, {
                rule_type: ruleType,
                match_key: matchText.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(),
                match_pattern: ruleType === 'narration_pattern' ? matchText : '',
                category_id: categoryId,
                subcategory_id: subcategoryId,
                tx_type: fd.get('tx_type'),
                priority,
              });
              showToast('Categorisation rule updated');
            } else {
              await repos.statementImport.createLearningRule({
                rule_type: ruleType,
                match_key: matchText,
                match_pattern: ruleType === 'narration_pattern' ? matchText : '',
                category_id: categoryId,
                subcategory_id: subcategoryId,
                tx_type: fd.get('tx_type'),
                priority,
                is_active: true,
              });
              showToast('Categorisation rule created');
            }
            close();
            renderCategorisationRulesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openMerchantOverrideModal = (existing = null) => {
    openModal({
      title: existing ? `Personal Override: ${existing.display_name}` : 'Add Personal Merchant Override',
      bodyHtml: `
        <form id="merch-override-form" class="stack" style="gap:10px;">
          <div class="item-meta">Personal overrides always take precedence over built-in merchant dictionary entries.</div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Merchant Name *</label>
            <input name="display_name" class="form-control" required maxlength="60"
              value="${escapeHtml(existing?.display_name || '')}" placeholder="e.g. Swiggy, Amazon, Local Kirana">
          </div>
          <div class="grid-2" style="gap:8px;">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Transaction Type</label>
              <select name="tx_type_hint" class="form-control">
                <option value="expense" ${(existing?.tx_type_hint || 'expense') === 'expense' ? 'selected' : ''}>Expense</option>
                <option value="income" ${existing?.tx_type_hint === 'income' ? 'selected' : ''}>Income</option>
                <option value="transfer" ${existing?.tx_type_hint === 'transfer' ? 'selected' : ''}>Transfer</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Category Hint</label>
              <select name="category_hint" class="form-control">
                <option value="">-- None --</option>
                ${categories
                  .map((c) => `<option value="${escapeHtml(c.name)}" ${existing?.category_hint === c.name ? 'selected' : ''}>${c.parent_id ? '↳ ' : ''}${escapeHtml(c.name)}</option>`)
                  .join('')}
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Save Personal Override</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#merch-override-form')?.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await repos.statementImport.upsertMerchantEntry({
              normalized_merchant: fd.get('display_name'),
              display_name: fd.get('display_name'),
              category_hint: fd.get('category_hint') || null,
              tx_type_hint: fd.get('tx_type_hint') || 'expense',
              is_builtin: false,
            });
            showToast('Personal merchant override saved');
            close();
            renderCategorisationRulesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  container.innerHTML = `
    <div class="stack" style="gap:14px;">
      <section class="card stack" style="gap:10px; padding:16px;">
        <div class="toolbar">
          <div>
            <div class="item-title" style="font-size:1.05rem;">My Categorisation Rules</div>
            <div class="item-meta">100% local personal rules &amp; merchant overrides learned from your corrections</div>
          </div>
          <a href="#/statement-import" class="btn btn-secondary btn-sm">← Statement Import</a>
        </div>

        <div class="segmented" style="width:100%;">
          <button type="button" style="flex:1;" data-rules-tab="rules" class="${rulesViewState.tab === 'rules' ? 'active' : ''}">
            Personal Rules (${rules.length})
          </button>
          <button type="button" style="flex:1;" data-rules-tab="merchants" class="${rulesViewState.tab === 'merchants' ? 'active' : ''}">
            Merchant Dictionary (${merchants.filter((m) => m.is_builtin === false).length} personal)
          </button>
        </div>

        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <input id="rules-search-input" class="form-control" style="flex:1; min-width:160px;" placeholder="Search rules or merchants…" value="${escapeHtml(rulesViewState.search)}">
          ${
            rulesViewState.tab === 'rules'
              ? `<button type="button" class="btn btn-primary btn-sm" id="btn-add-cat-rule">+ Add Rule</button>`
              : `<button type="button" class="btn btn-primary btn-sm" id="btn-add-merch-override">+ Add Override</button>`
          }
        </div>
      </section>

      ${
        rulesViewState.tab === 'rules'
          ? filteredRules.length === 0
            ? `<div class="card" style="padding:18px; text-align:center;">
                <div class="item-meta">No personal categorisation rules yet. Correct a category during Statement Import or tap "+ Add Rule" above.</div>
              </div>`
            : `<div class="grouped-card">
                ${filteredRules
                  .map((r) => {
                    const cat = catMap.get(r.subcategory_id || r.category_id);
                    const paused = r.is_active === false;
                    return `
                      <div class="grouped-row" style="align-items:flex-start; gap:10px; ${paused ? 'opacity:0.6;' : ''}">
                        <div style="min-width:0; flex:1;">
                          <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
                            <span class="item-title">${escapeHtml(r.match_pattern || r.match_key)}</span>
                            <span class="badge badge-muted" style="font-size:0.68rem;">${escapeHtml(RULE_TYPE_LABELS[r.rule_type] || r.rule_type)}</span>
                            ${paused ? `<span class="badge badge-muted" style="font-size:0.68rem;">Paused</span>` : ''}
                          </div>
                          <div class="item-meta">
                            → ${escapeHtml(cat ? cat.name : 'Uncategorized')} (${escapeHtml(r.tx_type || 'expense')}) · Priority ${r.priority ?? 100} · Used ${r.hit_count || 0}×
                          </div>
                        </div>
                        <div style="display:flex; gap:4px; flex-wrap:wrap;">
                          <button type="button" class="btn btn-secondary btn-sm" data-toggle-rule="${r.id}">${paused ? 'Resume' : 'Pause'}</button>
                          <button type="button" class="btn btn-secondary btn-sm" data-edit-rule="${r.id}">Edit</button>
                          <button type="button" class="btn btn-danger btn-sm" data-del-rule="${r.id}">🗑</button>
                        </div>
                      </div>
                    `;
                  })
                  .join('')}
              </div>`
          : `<div class="grouped-card">
              ${filteredMerchants
                .slice(0, 80)
                .map((m) => {
                  const isPersonal = m.is_builtin === false;
                  return `
                    <div class="grouped-row" style="align-items:center; gap:10px;">
                      <div style="min-width:0; flex:1;">
                        <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
                          <span class="item-title">${escapeHtml(m.display_name || m.normalized_merchant)}</span>
                          <span class="badge badge-muted" style="font-size:0.68rem; ${isPersonal ? 'background:rgba(16,185,129,0.16); color:var(--success);' : ''}">
                            ${isPersonal ? 'Personal Override' : 'Built-in'}
                          </span>
                        </div>
                        <div class="item-meta">
                          ${escapeHtml(m.category_hint || 'Transfer / Uncategorized')} · ${escapeHtml(m.tx_type_hint || 'expense')}
                        </div>
                      </div>
                      <div style="display:flex; gap:4px;">
                        <button type="button" class="btn btn-secondary btn-sm" data-override-merch="${m.id}">${isPersonal ? 'Edit' : 'Override'}</button>
                        ${isPersonal ? `<button type="button" class="btn btn-danger btn-sm" data-del-merch="${m.id}">🗑</button>` : ''}
                      </div>
                    </div>
                  `;
                })
                .join('')}
            </div>`
      }
    </div>
  `;

  container.querySelectorAll('[data-rules-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      rulesViewState.tab = btn.getAttribute('data-rules-tab');
      renderCategorisationRulesView(container, ctx);
    });
  });

  container.querySelector('#rules-search-input')?.addEventListener('change', (e) => {
    rulesViewState.search = e.target.value || '';
    renderCategorisationRulesView(container, ctx);
  });

  container.querySelector('#btn-add-cat-rule')?.addEventListener('click', () => openRuleModal(null));
  container.querySelector('#btn-add-merch-override')?.addEventListener('click', () => openMerchantOverrideModal(null));

  container.querySelectorAll('[data-toggle-rule]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const r = rules.find((x) => x.id === btn.getAttribute('data-toggle-rule'));
      if (!r) return;
      await repos.statementImport.learningRules.update(r.id, { is_active: r.is_active === false });
      showToast(r.is_active === false ? 'Rule resumed' : 'Rule paused');
      renderCategorisationRulesView(container, ctx);
    });
  });

  container.querySelectorAll('[data-edit-rule]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const r = rules.find((x) => x.id === btn.getAttribute('data-edit-rule'));
      if (r) openRuleModal(r);
    });
  });

  container.querySelectorAll('[data-del-rule]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await repos.statementImport.learningRules.softDelete(btn.getAttribute('data-del-rule'));
      showToast('Rule deleted');
      renderCategorisationRulesView(container, ctx);
    });
  });

  container.querySelectorAll('[data-override-merch]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const m = merchants.find((x) => x.id === btn.getAttribute('data-override-merch'));
      if (m) openMerchantOverrideModal(m);
    });
  });

  container.querySelectorAll('[data-del-merch]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await repos.statementImport.merchantDictionary.softDelete(btn.getAttribute('data-del-merch'));
      showToast('Personal override removed (built-in default restored)');
      renderCategorisationRulesView(container, ctx);
    });
  });
}

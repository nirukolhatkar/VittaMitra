import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { getCategoryColor } from '../../utils/colors.js';
import { formatRelativeDate, shiftMonth, toLocalDateString } from '../../utils/date.js';
import { bindChartTooltips, renderBarChartSvg } from '../components/charts.js';
import { showToast } from '../components/toast.js';
import { bindTransactionLongPress, setPageContext } from '../../services/txContextClipboard.js';

const catDetailState = {
  mode: 'month', // 'week' | 'month' | 'year' | 'fy' | 'custom'
  weekOffset: 0,
  customStart: '',
  customEnd: '',
  comparePrev: false,
};

/**
 * Full Category Detail Analytics View (inspired by screenshot 58628.jpg):
 * - Opens whenever the user taps any category in Analysis
 * - Shows Week/Month/Year/FY/Custom period, Total Spending/Income hero,
 *   all transactions (tap to Edit, one-tap Copy), interactive Trend Bar Chart,
 *   Tags, Payment Modes, and Average/Maximum Stats + PDF export.
 */
export async function renderCategoryDetailView(container, ctx) {
  const { repos, services, state } = ctx;
  const catId = state.selectedCategoryId;
  if (!catId) {
    window.location.hash = '#/analysis';
    return;
  }

  const [category, settings] = await Promise.all([
    repos.categories.getById(catId),
    repos.settings.getSettings(),
  ]);
  if (!category) {
    window.location.hash = '#/analysis';
    return;
  }

  const catColor = getCategoryColor(category);
  const isIncome = category.type === 'income';
  const titleEl = document.getElementById('topbar-title');
  if (titleEl) titleEl.textContent = `${category.icon} ${category.name}`;
  setPageContext(ctx, {
    route: 'category-detail',
    label: category.name,
    shortLabel: category.name.slice(0, 14),
    categoryName: category.name,
    overrides: { category_id: category.id, type: category.type },
    onPasteRefresh: () => renderCategoryDetailView(container, ctx),
  });

  if (!catDetailState.customStart) {
    const today = toLocalDateString();
    catDetailState.customStart = `${today.slice(0, 7)}-01`;
    catDetailState.customEnd = today;
  }

  const report = await services.analytics.buildAnalysisReport({
    mode: catDetailState.mode,
    year: state.selectedYear,
    month: state.selectedMonth,
    weekOffset: catDetailState.weekOffset,
    customStart: catDetailState.customStart,
    customEnd: catDetailState.customEnd,
    categoryIds: [catId],
  });

  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');
  const totalVal = isIncome ? report.income : report.spending;
  const trendData = isIncome ? report.trends.income : report.trends.expense;
  const modeRows = isIncome ? report.paymentModes.income : report.paymentModes.expense;

  const nonZeroBuckets = trendData.current.values.filter((v) => v > 0);
  const avgPerBucket =
    nonZeroBuckets.length > 0
      ? Math.round(totalVal / Math.max(1, trendData.current.values.length))
      : 0;
  const maxPerBucket = trendData.current.values.length ? Math.max(...trendData.current.values) : 0;
  const avgPerTx = report.transactionCount > 0 ? Math.round(totalVal / report.transactionCount) : 0;
  const maxPerTx = report.transactions.length
    ? Math.max(...report.transactions.map((t) => t.amount_paise))
    : 0;
  const bucketUnit = report.period.granularity === 'month' ? 'month' : 'day';

  container.innerHTML = `
    <div class="stack">
      <div class="segmented" style="width:100%; justify-content:space-between;">
        <button type="button" style="flex:1;" data-cd-mode="week" class="${catDetailState.mode === 'week' ? 'active' : ''}">Week</button>
        <button type="button" style="flex:1;" data-cd-mode="month" class="${catDetailState.mode === 'month' ? 'active' : ''}">Month</button>
        <button type="button" style="flex:1;" data-cd-mode="year" class="${catDetailState.mode === 'year' ? 'active' : ''}">Year</button>
        <button type="button" style="flex:1;" data-cd-mode="fy" class="${catDetailState.mode === 'fy' ? 'active' : ''}">FY</button>
        <button type="button" style="flex:1;" data-cd-mode="custom" class="${catDetailState.mode === 'custom' ? 'active' : ''}">Custom</button>
      </div>

      ${
        catDetailState.mode === 'custom'
          ? `<div class="card form-row" style="padding:12px;">
              <input type="date" id="cd-start" class="form-control" value="${escapeHtml(catDetailState.customStart)}">
              <input type="date" id="cd-end" class="form-control" value="${escapeHtml(catDetailState.customEnd)}">
            </div>`
          : `<div class="toolbar card" style="padding:10px 14px;">
              <button type="button" class="icon-btn" id="cd-prev">‹</button>
              <div style="text-align:center;">
                <div class="item-title">${escapeHtml(report.period.label)}</div>
                <div class="item-meta">${report.transactionCount} TRANSACTION${report.transactionCount === 1 ? '' : 'S'}</div>
              </div>
              <button type="button" class="icon-btn" id="cd-next">›</button>
            </div>`
      }

      <section class="hero-card" style="border-color:${escapeHtml(catColor)}44;">
        <div class="toolbar">
          <div>
            <div class="hero-stat-label" style="color:${escapeHtml(catColor)};">
              ${isIncome ? 'TOTAL INCOME' : 'TOTAL SPENDING'}
            </div>
            <div class="hero-stat-value">${fmt(totalVal)}</div>
          </div>
          <button type="button" class="btn btn-secondary btn-sm" id="cd-pdf">📄 PDF</button>
        </div>
      </section>

      <section class="stack" style="gap:8px;">
        <div class="section-heading">
          <span class="section-heading-left">Transactions</span>
          <span class="item-meta">${report.transactions.length} total</span>
        </div>
        ${
          report.transactions.length === 0
            ? `<div class="empty-state"><div class="empty-state-title">No transactions in ${escapeHtml(report.period.label)}</div></div>`
            : `<div class="grouped-card">
                ${report.transactions
                  .map((tx) => {
                    const acc = report.lookups.accMap.get(tx.account_id);
                    const amtClass = isIncome ? 'text-success' : 'text-danger';
                    return `
                      <div class="grouped-row">
                        <div class="list-row-main" style="flex:1; min-width:0; cursor:pointer;" data-cd-edit="${tx.id}">
                          <span class="avatar-badge" style="background:${escapeHtml(catColor)}22;">${escapeHtml(category.icon)}</span>
                          <div style="min-width:0;">
                            <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(tx.description || category.name)}</div>
                            <div class="item-meta">${escapeHtml(acc?.name || '')}</div>
                          </div>
                        </div>
                        <div class="tx-amt-col">
                          <strong class="${amtClass}" style="font-variant-numeric:tabular-nums;">${fmt(tx.amount_paise)}</strong>
                          <span class="tx-date-sub">${escapeHtml(formatRelativeDate(tx.date_key))}</span>
                        </div>
                      </div>`;
                  })
                  .join('')}
              </div>`
        }
      </section>

      <section class="card stack" style="gap:10px;">
        <span class="card-title">Trends</span>
        ${renderBarChartSvg({
          keys: trendData.current.keys,
          labels: trendData.current.labels,
          values: trendData.current.values,
          avgValue: avgPerBucket,
          barColor: catColor,
          showBalances: show,
        })}
      </section>

      ${
        report.tags.length > 0
          ? `<section class="card stack" style="gap:10px;">
              <span class="card-title">Tags</span>
              <div class="chip-picker">
                ${report.tags
                  .map(
                    (r) =>
                      `<button type="button" class="chip-btn" data-cd-tag="${r.id}">${escapeHtml(formatTagDisplay(r.tag))}</button>`
                  )
                  .join('')}
              </div>
            </section>`
          : ''
      }

      <section class="card stack" style="gap:10px;">
        <span class="card-title">Payment Modes</span>
        ${
          modeRows.length === 0
            ? `<div class="item-meta">No payment mode data.</div>`
            : `<div class="grouped-card">
                ${modeRows
                  .map(
                    (r) => `
                    <div class="grouped-row" style="padding:10px 12px;">
                      <span class="item-title" style="font-size:0.88rem;">${escapeHtml(r.account.icon || '🏛️')} ${escapeHtml(r.account.name)}</span>
                      <strong style="font-variant-numeric:tabular-nums;">${fmt(r.total)}</strong>
                    </div>`
                  )
                  .join('')}
              </div>`
        }
      </section>

      <section class="card stack" style="gap:12px;">
        <span class="card-title">Stats</span>
        <div class="grid-2">
          <div>
            <div class="hero-stat-label" style="color:${escapeHtml(catColor)};">Avg / ${bucketUnit}</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(avgPerBucket)}</div>
          </div>
          <div>
            <div class="hero-stat-label" style="color:${escapeHtml(catColor)};">Avg / Transaction</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(avgPerTx)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-success">Max / ${bucketUnit}</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(maxPerBucket)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-success">Max / Transaction</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(maxPerTx)}</div>
          </div>
        </div>
      </section>
    </div>
  `;

  bindChartTooltips(container);

  container.querySelectorAll('[data-cd-mode]').forEach((b) => {
    b.addEventListener('click', () => {
      catDetailState.mode = b.getAttribute('data-cd-mode');
      catDetailState.weekOffset = 0;
      renderCategoryDetailView(container, ctx);
    });
  });

  container.querySelector('#cd-prev')?.addEventListener('click', () => {
    if (catDetailState.mode === 'week') catDetailState.weekOffset -= 1;
    else if (catDetailState.mode === 'year' || catDetailState.mode === 'fy') state.selectedYear -= 1;
    else {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, -1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
    }
    renderCategoryDetailView(container, ctx);
  });

  container.querySelector('#cd-next')?.addEventListener('click', () => {
    if (catDetailState.mode === 'week') catDetailState.weekOffset += 1;
    else if (catDetailState.mode === 'year' || catDetailState.mode === 'fy') state.selectedYear += 1;
    else {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, 1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
    }
    renderCategoryDetailView(container, ctx);
  });

  container.querySelector('#cd-start')?.addEventListener('change', (e) => {
    catDetailState.customStart = e.target.value;
    renderCategoryDetailView(container, ctx);
  });
  container.querySelector('#cd-end')?.addEventListener('change', (e) => {
    catDetailState.customEnd = e.target.value;
    renderCategoryDetailView(container, ctx);
  });

  container.querySelectorAll('[data-cd-edit]').forEach((el) => {
    el.addEventListener('click', () => {
      state.txDraft = { editId: el.getAttribute('data-cd-edit'), returnRoute: 'category-detail' };
      window.location.hash = '#/add-transaction';
    });
  });

  bindTransactionLongPress(container, ctx, {
    selector: '[data-cd-edit]',
    attr: 'data-cd-edit',
    onRefresh: () => renderCategoryDetailView(container, ctx),
  });

  container.querySelectorAll('[data-cd-tag]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedTagId = btn.getAttribute('data-cd-tag');
      window.location.hash = '#/tag-detail';
    });
  });

  container.querySelector('#cd-pdf')?.addEventListener('click', () => {
    const html = services.analytics.buildPrintableReportHtml(report, {
      titleOverride: `${category.name} — ${report.period.label}`,
    });
    const win = window.open('', '_blank');
    if (win) {
      win.document.open();
      win.document.write(html);
      win.document.close();
    } else {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${category.name.replace(/\s+/g, '_')}_${report.period.label.replace(/\s+/g, '_')}.html`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('Category report downloaded');
    }
  });
}

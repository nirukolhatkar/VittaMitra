import { FAMILY_RELATIONSHIPS } from '../../constants/defaultSeeds.js';
import { escapeHtml } from '../../utils/dom.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { openAddTransactionWithContext, setPageContext } from '../../services/txContextClipboard.js';

export async function renderFamilyView(container, ctx) {
  const { repos } = ctx;
  const members = await repos.family.list({ includeInactive: true });

  container.innerHTML = `
    <div class="stack">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Family</h2>
          <div class="compass-subtitle">Attribute transactions across household members</div>
        </div>
      </div>
      <div class="toolbar">
        <div>
          <div class="item-meta">Single-login attribution profiles (no separate family logins required).</div>
        </div>
        <button type="button" class="btn btn-primary btn-sm" id="btn-add-member">+ Add Member</button>
      </div>

      <div class="list" id="family-list">
        ${members
          .map(
            (m) => `
            <div class="list-row" data-member-id="${m.id}">
              <div class="list-row-main">
                <span class="avatar-badge">${escapeHtml(m.icon)}</span>
                <div>
                  <div class="item-title">
                    ${escapeHtml(m.name)}
                    <span class="badge ${m.is_active ? 'badge-asset' : 'badge-muted'}">
                      ${m.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <div class="item-meta">${escapeHtml(m.relationship)}</div>
                </div>
              </div>
              <div class="row-actions">
                <button type="button" class="btn btn-secondary btn-sm" data-edit-member="${m.id}">Edit</button>
                <button type="button" class="btn btn-secondary btn-sm" data-toggle-member="${m.id}" data-active="${m.is_active}">
                  ${m.is_active ? 'Deactivate' : 'Activate'}
                </button>
                <button type="button" class="btn btn-danger btn-sm" data-delete-member="${m.id}">Delete</button>
              </div>
            </div>`
          )
          .join('')}
      </div>
    </div>
  `;

  const openMemberForm = (existing = null) => {
    const isEdit = Boolean(existing);
    const relOptions = FAMILY_RELATIONSHIPS.map(
      (r) => `<option value="${escapeHtml(r)}" ${(existing?.relationship || 'Spouse') === r ? 'selected' : ''}>${escapeHtml(r)}</option>`
    ).join('');

    openModal({
      title: isEdit ? 'Edit Family Member' : 'Add Family Member',
      bodyHtml: `
        <form id="family-form">
          <div class="form-group">
            <label class="form-label" for="fam-name">Name</label>
            <input id="fam-name" name="name" class="form-control" required maxlength="50"
              value="${escapeHtml(existing?.name || '')}" placeholder="e.g. Spouse, Child, Parents">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="fam-rel">Relationship</label>
              <select id="fam-rel" name="relationship" class="form-control">${relOptions}</select>
            </div>
            <div class="form-group">
              <label class="form-label" for="fam-icon">Icon (Emoji)</label>
              <input id="fam-icon" name="icon" class="form-control" maxlength="4"
                value="${escapeHtml(existing?.icon || '👤')}">
            </div>
          </div>
          <div class="form-group">
            <label class="checkbox-row">
              <input type="checkbox" name="is_active" ${existing ? (existing.is_active ? 'checked' : '') : 'checked'}>
              <span>Active for transaction attribution</span>
            </label>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Add Member'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        const form = panel.querySelector('#family-form');
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          const payload = {
            name: fd.get('name'),
            relationship: fd.get('relationship'),
            icon: fd.get('icon') || '👤',
            is_active: form.querySelector('[name="is_active"]').checked,
          };
          try {
            if (isEdit) {
              await repos.family.updateMember(existing.id, payload);
              showToast('Family member updated');
            } else {
              await repos.family.createMember(payload);
              showToast('Family member added');
            }
            close();
            renderFamilyView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  container.querySelector('#btn-add-member')?.addEventListener('click', () => openMemberForm());

  container.querySelectorAll('[data-edit-member]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const m = await repos.family.getById(btn.getAttribute('data-edit-member'));
      if (m) openMemberForm(m);
    });
  });

  container.querySelectorAll('[data-toggle-member]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-toggle-member');
      const active = btn.getAttribute('data-active') === 'true';
      await repos.family.updateMember(id, { is_active: !active });
      showToast(active ? 'Member deactivated' : 'Member activated');
      renderFamilyView(container, ctx);
    });
  });

  container.querySelectorAll('[data-delete-member]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-delete-member');
      await repos.family.softDelete(id);
      renderFamilyView(container, ctx);
      showToast('Family member deleted', {
        actionLabel: 'Undo',
        onAction: async () => {
          await repos.family.restore(id);
          renderFamilyView(container, ctx);
          showToast('Family member restored');
        },
      });
    });
  });
}

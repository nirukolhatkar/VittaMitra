import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { formatTagDisplay, formatTagsForExport } from '../../utils/normalize.js';
import { parseCsvText, STANDARD_SHEET_NAME } from '../../services/importExportService.js';
import { showToast } from '../components/toast.js';

const ieState = {
  tab: 'import', // 'import' | 'export' | 'backup'
  busy: false,
  progressText: '',
  progressPct: 0,
  workbook: null,
  filename: '',
  selectedSheet: '',
  preview: null,
  createUnknownCategories: true,
  createUnknownAccounts: true,
  exportFilters: {
    startDate: '',
    endDate: '',
    type: 'all',
    accountId: '',
    categoryId: '',
    tagId: '',
    familyMemberId: '',
  },
  pendingRestoreJson: null,
  restoreConfirmed: false,
  confirmClearTx: false,
};

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function updateProgressUI(container, phase, done, total) {
  const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
  ieState.progressText = total > 0 ? `${phase}: ${done.toLocaleString('en-IN')} / ${total.toLocaleString('en-IN')} (${pct}%)` : phase;
  ieState.progressPct = pct;

  const box = container.querySelector('#ie-progress-box');
  const txt = container.querySelector('#ie-progress-text');
  const fill = container.querySelector('#ie-progress-fill');
  if (box) box.classList.remove('hidden');
  if (txt) txt.textContent = ieState.progressText;
  if (fill) fill.style.width = `${pct}%`;
}

export async function renderImportExportView(container, ctx) {
  const { repos, services, state } = ctx;
  if (state?.ieTab) {
    ieState.tab = state.ieTab;
    state.ieTab = null;
  }

  const [settings, accounts, categories, tags, family, batches] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.list({ includeArchived: true }),
    repos.categories.list({ includeArchived: true }),
    repos.tags.list({ includeArchived: true }),
    repos.family.list({ includeInactive: true }),
    services.importExport.listImportBatches(),
  ]);

  const tabBar = `
    <div class="segmented" style="width:100%; justify-content:space-between;">
      <button type="button" style="flex:1;" data-ie-tab="import" class="${ieState.tab === 'import' ? 'active' : ''}" ${ieState.busy ? 'disabled' : ''}>Import</button>
      <button type="button" style="flex:1;" data-ie-tab="export" class="${ieState.tab === 'export' ? 'active' : ''}" ${ieState.busy ? 'disabled' : ''}>Export</button>
      <button type="button" style="flex:1;" data-ie-tab="backup" class="${ieState.tab === 'backup' ? 'active' : ''}" ${ieState.busy ? 'disabled' : ''}>Backup</button>
    </div>
  `;

  const progressBoxHtml = `
    <div id="ie-progress-box" class="card ${ieState.busy ? '' : 'hidden'}" style="border-color:var(--accent);">
      <div id="ie-progress-text" class="item-title" style="font-size:0.86rem;">
        ${escapeHtml(ieState.progressText || 'Working…')}
      </div>
      <div class="progress-track" style="height:8px; margin-top:8px;">
        <div id="ie-progress-fill" class="progress-fill" style="width:${ieState.progressPct}%; transition:width 0.12s linear;"></div>
      </div>
      <div class="item-meta" style="margin-top:6px;">Please wait — do not tap again until complete.</div>
    </div>
  `;

  if (ieState.tab === 'import') {
    const p = ieState.preview;
    const selectedCount = p ? p.rows.filter((r) => r.include && r.isValid).length : 0;
    const includedDupCount = p ? p.rows.filter((r) => r.include && r.isPossibleDuplicate).length : 0;

    container.innerHTML = `
      <div class="stack">
        ${tabBar}
        ${progressBoxHtml}

        <section class="card stack" style="gap:12px;">
          <div>
            <h2 class="card-title">Import Excel (.xlsx) or CSV</h2>
            <p class="card-subtitle">
              Exact 8-column <code>Sheet1</code> format. Handles large files (15,000–1,00,000 rows) in chunks and splits every <code>#tag</code> cleanly.
            </p>
          </div>

          <input id="ie-file-input" type="file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
            class="form-control" style="padding:8px;" ${ieState.busy ? 'disabled' : ''}>

          ${
            ieState.workbook && ieState.workbook.sheetNames.length > 1
              ? `<div class="form-group" style="margin-bottom:0;">
                  <label class="form-label" for="ie-sheet-select">Select Worksheet</label>
                  <select id="ie-sheet-select" class="form-control" ${ieState.busy ? 'disabled' : ''}>
                    ${ieState.workbook.sheetNames
                      .map((name) => `<option value="${escapeHtml(name)}" ${name === ieState.selectedSheet ? 'selected' : ''}>${escapeHtml(name)}</option>`)
                      .join('')}
                  </select>
                </div>`
              : ''
          }
        </section>

        ${
          p
            ? `<section class="card stack" style="gap:12px;">
                <div class="toolbar">
                  <div>
                    <div class="card-title">Preview: ${escapeHtml(p.filename)}</div>
                    <div class="item-meta">Worksheet: ${escapeHtml(p.sheetName)}</div>
                  </div>
                  <button type="button" class="btn btn-secondary btn-sm" id="ie-clear-preview" ${ieState.busy ? 'disabled' : ''}>Clear</button>
                </div>

                <div class="grid-3">
                  <div class="metric-card" style="padding:10px;">
                    <div class="metric-label">Valid</div>
                    <div class="item-title text-success" style="font-size:1.15rem;">${p.validCount.toLocaleString('en-IN')}</div>
                  </div>
                  <div class="metric-card" style="padding:10px;">
                    <div class="metric-label">Invalid</div>
                    <div class="item-title ${p.invalidCount > 0 ? 'text-danger' : ''}" style="font-size:1.15rem;">${p.invalidCount.toLocaleString('en-IN')}</div>
                  </div>
                  <div class="metric-card" style="padding:10px;">
                    <div class="metric-label">Duplicates</div>
                    <div class="item-title" style="font-size:1.15rem; color:var(--warning);">${p.duplicateCount.toLocaleString('en-IN')}</div>
                  </div>
                </div>

                ${
                  p.duplicateCount > 0
                    ? `<div class="card" style="background:var(--bg-surface-elevated); padding:12px;">
                        <div class="toolbar">
                          <div>
                            <div class="item-title" style="font-size:0.86rem;">Suspected Duplicates (${p.duplicateCount.toLocaleString('en-IN')})</div>
                            <div class="item-meta">Skipped by default to prevent accidental double-imports.</div>
                          </div>
                          <button type="button" class="btn btn-secondary btn-sm" id="ie-toggle-dups" ${ieState.busy ? 'disabled' : ''}>
                            ${includedDupCount > 0 ? 'Skip All Duplicates' : 'Include All Duplicates'}
                          </button>
                        </div>
                      </div>`
                    : ''
                }

                ${
                  p.whitespaceWarnings.length > 0
                    ? `<div class="warning-banner">
                        <strong>Whitespace trimmed (${p.whitespaceWarnings.length}):</strong><br>
                        ${p.whitespaceWarnings.slice(0, 3).map((w) => escapeHtml(w)).join('<br>')}
                      </div>`
                    : ''
                }

                ${
                  p.unknownCategories.length > 0
                    ? `<div class="card" style="background:var(--bg-surface-elevated); padding:12px;">
                        <label class="checkbox-row">
                          <input type="checkbox" id="ie-create-cats" ${ieState.createUnknownCategories ? 'checked' : ''} ${ieState.busy ? 'disabled' : ''}>
                          <span>Create ${p.unknownCategories.length} unknown categor${p.unknownCategories.length === 1 ? 'y' : 'ies'}</span>
                        </label>
                        <div class="item-meta" style="margin-top:6px;">
                          ${p.unknownCategories.map((c) => `${escapeHtml(c.name)} (${c.type})`).join(', ')}
                        </div>
                      </div>`
                    : ''
                }

                ${
                  p.unknownAccounts.length > 0
                    ? `<div class="card" style="background:var(--bg-surface-elevated); padding:12px;">
                        <label class="checkbox-row">
                          <input type="checkbox" id="ie-create-accs" ${ieState.createUnknownAccounts ? 'checked' : ''} ${ieState.busy ? 'disabled' : ''}>
                          <span>Create ${p.unknownAccounts.length} unknown account${p.unknownAccounts.length === 1 ? '' : 's'}</span>
                        </label>
                        <div class="item-meta" style="margin-top:6px;">
                          ${p.unknownAccounts.map((a) => escapeHtml(a.name)).join(', ')}
                        </div>
                      </div>`
                    : ''
                }

                <div class="grouped-card" style="max-height:280px; overflow-y:auto;">
                  ${p.rows
                    .slice(0, 100)
                    .map(
                      (row, idx) => `
                      <div class="grouped-row" style="padding:10px 12px; align-items:flex-start;">
                        <div class="list-row-main" style="align-items:flex-start; flex:1; min-width:0;">
                          <input type="checkbox" data-ie-row="${idx}" ${row.include ? 'checked' : ''} ${!row.isValid || ieState.busy ? 'disabled' : ''}>
                          <div style="min-width:0;">
                            <div class="item-title" style="font-size:0.84rem;">
                              Row ${row.rowNumber}: ${escapeHtml(row.note || row.categoryName || row.type || 'Invalid row')}
                              ${row.isPossibleDuplicate ? '<span class="badge" style="background:var(--warning-soft); color:var(--warning);">Duplicate?</span>' : ''}
                            </div>
                            <div class="item-meta">
                              ${escapeHtml(row.occurred_at_local || 'Bad date')} · ${escapeHtml(row.type || '?')} · ${escapeHtml(row.paymentMode || '?')}${row.toPaymentMode ? ` → ${escapeHtml(row.toPaymentMode)}` : ''}
                              ${row.tags.length ? ` · ${escapeHtml(formatTagsForExport(row.tags))}` : ''}
                            </div>
                            ${row.errors.length ? `<div class="text-danger" style="font-size:0.74rem; margin-top:3px;">${row.errors.map(escapeHtml).join(' | ')}</div>` : ''}
                          </div>
                        </div>
                        <strong style="font-size:0.84rem; font-variant-numeric:tabular-nums;">
                          ${row.amount_paise ? formatINR(row.amount_paise) : '—'}
                        </strong>
                      </div>`
                    )
                    .join('')}
                </div>
                ${p.rows.length > 100 ? `<div class="item-meta">Showing first 100 of ${p.rows.length.toLocaleString('en-IN')} rows; all ${selectedCount.toLocaleString('en-IN')} selected rows will import.</div>` : ''}

                <button type="button" class="btn btn-primary" id="ie-commit-btn" ${ieState.busy || selectedCount === 0 ? 'disabled' : ''}>
                  ${ieState.busy ? 'Importing… please wait' : `Confirm & Import (${selectedCount.toLocaleString('en-IN')} rows)`}
                </button>
              </section>`
            : ''
        }

        ${
          batches.length > 0
            ? `<section class="stack" style="gap:8px;">
                <div class="section-heading">
                  <span class="section-heading-left">Import History</span>
                  <span class="item-meta">Tap Rollback to undo a batch</span>
                </div>
                <div class="grouped-card">
                  ${batches
                    .slice(0, 10)
                    .map(
                      (b) => `
                      <div class="grouped-row" style="padding:10px 14px;">
                        <div style="min-width:0;">
                          <div class="item-title" style="font-size:0.85rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                            ${escapeHtml(b.filename)}
                            ${b.rolled_back_at ? '<span class="badge badge-muted">Rolled back</span>' : ''}
                          </div>
                          <div class="item-meta">
                            ${escapeHtml(String(b.imported_at || '').slice(0, 16).replace('T', ' '))} · Imported ${b.imported_rows.toLocaleString('en-IN')}/${b.total_rows.toLocaleString('en-IN')}
                          </div>
                        </div>
                        <div class="row-actions">
                          ${
                            !b.rolled_back_at && b.imported_rows > 0
                              ? `<button type="button" class="btn btn-danger btn-sm" data-rollback-batch="${b.id}" ${ieState.busy ? 'disabled' : ''}>Rollback</button>`
                              : `<span class="badge ${b.error_count > 0 ? 'badge-liability' : 'badge-asset'}">${b.error_count} err</span>`
                          }
                        </div>
                      </div>`
                    )
                    .join('')}
                </div>
              </section>`
            : ''
        }
      </div>
    `;

    container.querySelector('#ie-file-input')?.addEventListener('change', async (e) => {
      const file = e.target.files?.[0];
      if (!file || ieState.busy) return;
      ieState.busy = true;
      updateProgressUI(container, `Reading ${file.name}…`, 0, 100);
      try {
        ieState.filename = file.name;
        let sheetRows;
        if (file.name.toLowerCase().endsWith('.csv')) {
          const text = await file.text();
          sheetRows = parseCsvText(text);
          ieState.workbook = null;
          ieState.selectedSheet = STANDARD_SHEET_NAME;
        } else {
          const buf = await file.arrayBuffer();
          const wb = await services.importExport.parseWorkbookBuffer(buf);
          if (!wb.sheetNames.length) throw new Error('No worksheets found in workbook');
          ieState.workbook = wb;
          ieState.selectedSheet = wb.sheetNames.includes(STANDARD_SHEET_NAME)
            ? STANDARD_SHEET_NAME
            : wb.sheetNames[0];
          sheetRows = wb.sheets[ieState.selectedSheet];
        }

        ieState.preview = await services.importExport.buildImportPreview({
          sheetRows,
          filename: file.name,
          sheetName: ieState.selectedSheet,
          onProgress: ({ phase, done, total }) => updateProgressUI(container, phase, done, total),
        });
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 4500 });
      } finally {
        ieState.busy = false;
        renderImportExportView(container, ctx);
      }
    });

    container.querySelector('#ie-sheet-select')?.addEventListener('change', async (e) => {
      if (ieState.busy) return;
      ieState.selectedSheet = e.target.value;
      ieState.busy = true;
      updateProgressUI(container, `Validating ${ieState.selectedSheet}…`, 0, 100);
      try {
        ieState.preview = await services.importExport.buildImportPreview({
          sheetRows: ieState.workbook.sheets[ieState.selectedSheet],
          filename: ieState.filename,
          sheetName: ieState.selectedSheet,
          onProgress: ({ phase, done, total }) => updateProgressUI(container, phase, done, total),
        });
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 4500 });
      } finally {
        ieState.busy = false;
        renderImportExportView(container, ctx);
      }
    });

    container.querySelector('#ie-clear-preview')?.addEventListener('click', () => {
      ieState.preview = null;
      ieState.workbook = null;
      renderImportExportView(container, ctx);
    });

    container.querySelector('#ie-toggle-dups')?.addEventListener('click', () => {
      if (!ieState.preview) return;
      const shouldInclude = includedDupCount === 0;
      for (const r of ieState.preview.rows) {
        if (r.isPossibleDuplicate && r.isValid) r.include = shouldInclude;
      }
      renderImportExportView(container, ctx);
    });

    container.querySelector('#ie-create-cats')?.addEventListener('change', (e) => {
      ieState.createUnknownCategories = e.target.checked;
    });
    container.querySelector('#ie-create-accs')?.addEventListener('change', (e) => {
      ieState.createUnknownAccounts = e.target.checked;
    });

    container.querySelectorAll('[data-ie-row]').forEach((cb) => {
      cb.addEventListener('change', () => {
        const idx = Number(cb.getAttribute('data-ie-row'));
        if (ieState.preview?.rows?.[idx]) {
          ieState.preview.rows[idx].include = cb.checked;
          const btn = container.querySelector('#ie-commit-btn');
          if (btn) {
            const count = ieState.preview.rows.filter((r) => r.include && r.isValid).length;
            btn.textContent = `Confirm & Import (${count.toLocaleString('en-IN')} rows)`;
            btn.disabled = count === 0;
          }
        }
      });
    });

    container.querySelector('#ie-commit-btn')?.addEventListener('click', async () => {
      if (!ieState.preview || ieState.busy || services.importExport.isImporting) return;
      ieState.busy = true;
      const commitBtn = container.querySelector('#ie-commit-btn');
      if (commitBtn) {
        commitBtn.disabled = true;
        commitBtn.textContent = 'Importing… please wait';
      }
      updateProgressUI(container, 'Preparing import', 0, selectedCount);

      try {
        const res = await services.importExport.commitImport(ieState.preview, {
          createUnknownCategories: ieState.createUnknownCategories,
          createUnknownAccounts: ieState.createUnknownAccounts,
          onProgress: ({ phase, done, total }) => updateProgressUI(container, phase, done, total),
        });
        ieState.preview = null;
        ieState.workbook = null;
        showToast(
          `Imported ${res.importedCount.toLocaleString('en-IN')} transactions (${res.skippedCount.toLocaleString('en-IN')} skipped)`
        );
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 4500 });
      } finally {
        ieState.busy = false;
        renderImportExportView(container, ctx);
      }
    });

    container.querySelectorAll('[data-rollback-batch]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (ieState.busy) return;
        const batchId = btn.getAttribute('data-rollback-batch');
        ieState.busy = true;
        updateProgressUI(container, 'Rolling back import batch…', 0, 100);
        try {
          const res = await services.importExport.rollbackImportBatch(batchId, {
            onProgress: ({ phase, done, total }) => updateProgressUI(container, phase, done, total),
          });
          showToast(`Rolled back ${res.removedCount.toLocaleString('en-IN')} transactions`);
        } catch (err) {
          showToast(err.message, { type: 'error' });
        } finally {
          ieState.busy = false;
          renderImportExportView(container, ctx);
        }
      });
    });
  } else if (ieState.tab === 'export') {
    const f = ieState.exportFilters;
    container.innerHTML = `
      <div class="stack">
        ${tabBar}
        ${progressBoxHtml}

        <section class="card stack" style="gap:12px;">
          <div>
            <h2 class="card-title">Standard Excel &amp; CSV Export</h2>
            <p class="card-subtitle">
              Exports exact <code>Sheet1</code> with 8 columns (Date, Category, Amount, Note, Type, Payment mode, To payment mode, Tags) and zero internal UUIDs.
            </p>
          </div>

          <div class="form-row">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">From Date</label>
              <input type="date" id="exp-start" class="form-control" value="${escapeHtml(f.startDate)}">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">To Date</label>
              <input type="date" id="exp-end" class="form-control" value="${escapeHtml(f.endDate)}">
            </div>
          </div>

          <div class="form-row">
            <select id="exp-type" class="form-control">
              <option value="all" ${f.type === 'all' ? 'selected' : ''}>All Types</option>
              <option value="expense" ${f.type === 'expense' ? 'selected' : ''}>Expense</option>
              <option value="income" ${f.type === 'income' ? 'selected' : ''}>Income</option>
              <option value="transfer" ${f.type === 'transfer' ? 'selected' : ''}>Transfer</option>
            </select>
            <select id="exp-acc" class="form-control">
              <option value="">All Accounts</option>
              ${accounts.map((a) => `<option value="${a.id}" ${f.accountId === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
            </select>
          </div>

          <div class="form-row">
            <select id="exp-cat" class="form-control">
              <option value="">All Categories</option>
              ${categories.map((c) => `<option value="${c.id}" ${f.categoryId === c.id ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
            </select>
            <select id="exp-tag" class="form-control">
              <option value="">All Tags</option>
              ${tags.map((t) => `<option value="${t.id}" ${f.tagId === t.id ? 'selected' : ''}>${escapeHtml(formatTagDisplay(t))}</option>`).join('')}
            </select>
          </div>

          <select id="exp-fam" class="form-control">
            <option value="">All Family Members</option>
            ${family.map((m) => `<option value="${m.id}" ${f.familyMemberId === m.id ? 'selected' : ''}>${escapeHtml(m.name)}</option>`).join('')}
          </select>

          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" style="flex:1;" id="btn-export-xlsx">📥 Download Excel (.xlsx)</button>
            <button type="button" class="btn btn-secondary" id="btn-export-csv">📄 Download CSV</button>
          </div>
        </section>
      </div>
    `;

    const bind = (sel, key) => {
      container.querySelector(sel)?.addEventListener('change', (e) => {
        ieState.exportFilters[key] = e.target.value;
      });
    };
    bind('#exp-start', 'startDate');
    bind('#exp-end', 'endDate');
    bind('#exp-type', 'type');
    bind('#exp-acc', 'accountId');
    bind('#exp-cat', 'categoryId');
    bind('#exp-tag', 'tagId');
    bind('#exp-fam', 'familyMemberId');

    container.querySelector('#btn-export-xlsx')?.addEventListener('click', async () => {
      const { bytes, rowCount } = await services.importExport.exportStandardXlsx(ieState.exportFilters);
      const blob = new Blob([bytes], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      const stamp = new Date().toISOString().slice(0, 10);
      downloadBlob(blob, `Personal_Finance_Transactions_${stamp}.xlsx`);
      showToast(`Exported ${rowCount.toLocaleString('en-IN')} transactions to Excel`);
    });

    container.querySelector('#btn-export-csv')?.addEventListener('click', async () => {
      const { csv, rowCount } = await services.importExport.exportStandardCsv(ieState.exportFilters);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const stamp = new Date().toISOString().slice(0, 10);
      downloadBlob(blob, `Personal_Finance_Transactions_${stamp}.csv`);
      showToast(`Exported ${rowCount.toLocaleString('en-IN')} transactions to CSV`);
    });
  } else {
    // Full JSON Backup, Scheduled Backup, Google Drive Link, Restore & Duplicate Cleanup
    const lastBackupLabel = settings.last_backup_at
      ? String(settings.last_backup_at).slice(0, 16).replace('T', ' ')
      : 'Never';
    const lastDriveLabel = settings.gdrive_last_backup_at
      ? String(settings.gdrive_last_backup_at).slice(0, 16).replace('T', ' ')
      : 'Not backed up yet';

    container.innerHTML = `
      <div class="stack">
        ${tabBar}
        ${progressBoxHtml}

        <section class="card stack" style="gap:12px;">
          <div>
            <h2 class="card-title">Complete Application Backup (JSON)</h2>
            <p class="card-subtitle">
              Saves all accounts, categories, transactions, ledger postings, bills, recurring rules, budgets, tags, family members, favourites &amp; settings.
            </p>
            <div class="item-meta" style="margin-top:4px;">Last local/cloud backup: <strong>${escapeHtml(lastBackupLabel)}</strong></div>
          </div>
          <button type="button" class="btn btn-primary" id="btn-download-json-backup">💾 Download Complete Backup (.zip)</button>
        </section>

        <section class="card stack" style="gap:12px;">
          <div>
            <h2 class="card-title">⏰ Scheduled Backup Reminder</h2>
            <p class="card-subtitle">
              Because mobile web browsers pause background jobs when closed, the app checks your schedule on launch and prompts you with a one-tap backup reminder when due.
            </p>
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="ie-backup-schedule">Backup Frequency</label>
            <select id="ie-backup-schedule" class="form-control">
              <option value="off" ${(settings.backup_schedule || 'off') === 'off' ? 'selected' : ''}>Off (Manual only)</option>
              <option value="daily" ${settings.backup_schedule === 'daily' ? 'selected' : ''}>Daily</option>
              <option value="weekly" ${settings.backup_schedule === 'weekly' ? 'selected' : ''}>Weekly</option>
              <option value="monthly" ${settings.backup_schedule === 'monthly' ? 'selected' : ''}>Monthly</option>
            </select>
          </div>
        </section>

        <section class="card stack" style="gap:12px;">
          <div class="toolbar" style="align-items:flex-start;">
            <div>
              <h2 class="card-title">☁️ Google Drive Auto-Backup</h2>
              <p class="card-subtitle">
                Grant Drive access once — updates a single rolling backup file in your Google Drive automatically whenever your schedule is due.
              </p>
              <div class="item-meta" style="margin-top:4px;">Last Drive backup: <strong>${escapeHtml(lastDriveLabel)}</strong></div>
            </div>
            <span class="badge ${settings.gdrive_connected ? 'badge-asset' : 'badge-muted'}">
              ${settings.gdrive_connected ? 'Connected' : 'Not linked'}
            </span>
          </div>

          <label class="checkbox-row">
            <input type="checkbox" id="ie-gdrive-auto" ${settings.gdrive_auto_upload !== false && settings.gdrive_connected ? 'checked' : ''} ${!settings.gdrive_connected ? 'disabled' : ''}>
            <span>Auto-upload to Google Drive on app launch when scheduled backup is due</span>
          </label>

          <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" style="flex:1;" id="btn-gdrive-backup" ${ieState.busy ? 'disabled' : ''}>
              ${settings.gdrive_connected ? '☁️ Backup to Drive Now' : '☁️ Connect Google Drive & Backup'}
            </button>
            ${
              settings.gdrive_connected
                ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-gdrive-restore" ${ieState.busy ? 'disabled' : ''}>📥 Restore Latest</button>
                   <button type="button" class="btn btn-secondary btn-sm" id="btn-gdrive-disconnect">Disconnect</button>`
                : ''
            }
          </div>

          <details class="accordion" ${settings.gdrive_client_id ? '' : 'open'}>
            <summary style="padding:8px 12px; font-size:0.82rem;">
              <span>One-Time Setup (Google OAuth Client ID)</span>
              <span class="text-muted">⌄</span>
            </summary>
            <div style="padding:0 12px 12px;" class="stack">
              <div class="item-meta" style="line-height:1.45;">
                1. Open Google Cloud Console → Credentials → Create OAuth Client ID (Web App).<br>
                2. Add your app origin below under <strong>Authorized JavaScript Origins</strong>:
              </div>
              <div style="display:flex; gap:6px; align-items:center;">
                <input type="text" class="form-control" readonly value="${escapeHtml(window.location.origin)}" style="font-size:0.78rem; padding:6px 8px;">
                <button type="button" class="btn btn-secondary btn-sm" id="btn-copy-origin">Copy</button>
              </div>
              <div style="display:flex; gap:6px;">
                <input id="ie-gdrive-client-id" class="form-control" type="text" style="font-size:0.82rem;"
                  placeholder="Paste Client ID (xxxx.apps.googleusercontent.com)"
                  value="${escapeHtml(settings.gdrive_client_id || '')}">
                <button type="button" class="btn btn-secondary btn-sm" id="btn-save-gdrive-id">Save</button>
              </div>
            </div>
          </details>
        </section>

        <section class="card stack" style="gap:12px;">
          <div>
            <h2 class="card-title">Clean Up Accidental Duplicates</h2>
            <p class="card-subtitle">
              Scans for exact duplicate transactions (same date/time, amount, type, account, category &amp; note), keeps one copy, and reverses duplicate ledger postings.
            </p>
          </div>
          <button type="button" class="btn btn-secondary" id="btn-remove-exact-dups" ${ieState.busy ? 'disabled' : ''}>
            🧹 Scan &amp; Remove Exact Duplicates
          </button>
        </section>

        <section class="card stack" style="gap:12px;">
          <div>
            <h2 class="card-title">Restore from Backup (.zip / .json)</h2>
            <p class="card-subtitle">
              Restoring overwrites your current local data. Download a backup of your current data first before confirming.
            </p>
          </div>

          <input id="ie-restore-file" type="file" accept=".zip,.json,application/zip,application/json" class="form-control" style="padding:8px;">

          ${
            ieState.pendingRestoreJson
              ? `<div class="warning-banner">
                  <strong>Backup ready to restore</strong> (exported ${escapeHtml(String(ieState.pendingRestoreJson.exported_at || '').slice(0, 19).replace('T', ' '))}):
                  ${(ieState.pendingRestoreJson.tables?.transactions || []).length.toLocaleString('en-IN')} transactions,
                  ${(ieState.pendingRestoreJson.tables?.accounts || []).length} accounts,
                  ${(ieState.pendingRestoreJson.tables?.attachment_blobs || []).length} attachments.
                </div>
                <label class="checkbox-row">
                  <input type="checkbox" id="ie-confirm-restore" ${ieState.restoreConfirmed ? 'checked' : ''}>
                  <span>I understand this will overwrite my current local data</span>
                </label>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                  <button type="button" class="btn btn-secondary btn-sm" id="btn-backup-before-restore">Backup Current First</button>
                  <button type="button" class="btn btn-danger" id="btn-exec-restore">Restore Backup Now</button>
                </div>`
              : ''
          }
        </section>

        <section class="card stack" style="gap:12px; border-color:var(--danger-soft);">
          <div>
            <h2 class="card-title text-danger">Clear All Transactions (Fresh Re-Import)</h2>
            <p class="card-subtitle">
              Removes all transactions, postings, and import history while keeping your Accounts, Categories, and Settings intact.
            </p>
          </div>
          <label class="checkbox-row">
            <input type="checkbox" id="ie-confirm-clear-tx" ${ieState.confirmClearTx ? 'checked' : ''}>
            <span>I want to clear all transactions for a clean re-import</span>
          </label>
          <button type="button" class="btn btn-danger btn-sm" id="btn-clear-all-tx" ${!ieState.confirmClearTx || ieState.busy ? 'disabled' : ''}>
            🗑 Clear All Transactions
          </button>
        </section>
      </div>
    `;

    const triggerJsonBackup = async () => {
      const zipRes = await services.importExport.exportCompleteZipBackup();
      downloadBlob(zipRes.blob, zipRes.filename);
      await repos.settings.updateSettings({ last_backup_at: new Date().toISOString() });
      const attCount = zipRes.counts?.attachments || 0;
      showToast(attCount > 0 ? `Backup ZIP downloaded (includes ${attCount} attachment${attCount === 1 ? '' : 's'})` : 'Complete Backup ZIP downloaded');
      renderImportExportView(container, ctx);
    };

    container.querySelector('#btn-download-json-backup')?.addEventListener('click', triggerJsonBackup);
    container.querySelector('#btn-backup-before-restore')?.addEventListener('click', triggerJsonBackup);

    container.querySelector('#ie-backup-schedule')?.addEventListener('change', async (e) => {
      const freq = e.target.value;
      await repos.settings.updateSettings({ backup_schedule: freq });
      showToast(freq === 'off' ? 'Scheduled backup reminder turned off' : `Scheduled backup set to ${freq}`);
    });

    container.querySelector('#btn-save-gdrive-id')?.addEventListener('click', async () => {
      const val = container.querySelector('#ie-gdrive-client-id')?.value?.trim() || '';
      await repos.settings.updateSettings({ gdrive_client_id: val });
      showToast(val ? 'Google Drive Client ID saved' : 'Google Drive Client ID cleared');
    });

    container.querySelector('#btn-copy-origin')?.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(window.location.origin);
        showToast('Origin URL copied');
      } catch {
        showToast(window.location.origin);
      }
    });

    container.querySelector('#ie-gdrive-auto')?.addEventListener('change', async (e) => {
      await repos.settings.updateSettings({ gdrive_auto_upload: e.target.checked });
      showToast(e.target.checked ? 'Auto-upload to Google Drive enabled' : 'Auto-upload to Google Drive paused');
    });

    container.querySelector('#btn-gdrive-disconnect')?.addEventListener('click', async () => {
      services.googleDrive.accessToken = null;
      await repos.settings.updateSettings({ gdrive_connected: false, gdrive_auto_upload: false });
      showToast('Google Drive disconnected');
      renderImportExportView(container, ctx);
    });

    container.querySelector('#btn-gdrive-backup')?.addEventListener('click', async () => {
      if (ieState.busy) return;
      const clientId = container.querySelector('#ie-gdrive-client-id')?.value?.trim() || settings.gdrive_client_id || '';
      if (!clientId) {
        showToast('Paste your Google OAuth Web Client ID in One-Time Setup first', { type: 'error' });
        return;
      }
      ieState.busy = true;
      updateProgressUI(container, 'Uploading backup to Google Drive…', 45, 100);
      try {
        await repos.settings.updateSettings({ gdrive_client_id: clientId });
        const backup = await services.importExport.exportCompleteJsonBackup();
        const res = await services.googleDrive.uploadBackupToDrive(clientId, backup, {
          silent: false,
          existingFileId: settings.gdrive_backup_file_id || null,
        });
        await repos.settings.updateSettings({
          gdrive_connected: true,
          gdrive_auto_upload: true,
          gdrive_backup_file_id: res.fileId,
          last_backup_at: res.uploadedAt,
          gdrive_last_backup_at: res.uploadedAt,
        });
        showToast(res.updatedInPlace ? 'Google Drive backup updated' : 'Connected & backed up to Google Drive');
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 5000 });
      } finally {
        ieState.busy = false;
        renderImportExportView(container, ctx);
      }
    });

    container.querySelector('#btn-gdrive-restore')?.addEventListener('click', async () => {
      if (ieState.busy) return;
      const clientId = container.querySelector('#ie-gdrive-client-id')?.value?.trim() || settings.gdrive_client_id || '';
      ieState.busy = true;
      updateProgressUI(container, 'Fetching latest backup from Google Drive…', 50, 100);
      try {
        const { backup } = await services.googleDrive.downloadLatestBackupFromDrive(
          clientId,
          settings.gdrive_backup_file_id || null
        );
        ieState.pendingRestoreJson = backup;
        ieState.restoreConfirmed = false;
        showToast('Backup downloaded from Drive — review & confirm restore below');
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 5000 });
      } finally {
        ieState.busy = false;
        renderImportExportView(container, ctx);
      }
    });

    container.querySelector('#btn-remove-exact-dups')?.addEventListener('click', async () => {
      if (ieState.busy) return;
      ieState.busy = true;
      updateProgressUI(container, 'Scanning for exact duplicates…', 0, 100);
      try {
        const res = await services.importExport.removeExactDuplicateTransactions({
          onProgress: ({ phase, done, total }) => updateProgressUI(container, phase, done, total),
        });
        showToast(
          res.removedCount > 0
            ? `Removed ${res.removedCount.toLocaleString('en-IN')} exact duplicate transactions`
            : 'No exact duplicates found'
        );
      } catch (err) {
        showToast(err.message, { type: 'error' });
      } finally {
        ieState.busy = false;
        renderImportExportView(container, ctx);
      }
    });

    container.querySelector('#ie-restore-file')?.addEventListener('change', async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      try {
        const buf = await file.arrayBuffer();
        const parsed = await services.importExport.parseBackupFileBuffer(buf);
        ieState.pendingRestoreJson = parsed;
        ieState.restoreConfirmed = false;
        renderImportExportView(container, ctx);
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });

    container.querySelector('#ie-confirm-restore')?.addEventListener('change', (e) => {
      ieState.restoreConfirmed = e.target.checked;
    });

    container.querySelector('#btn-exec-restore')?.addEventListener('click', async () => {
      if (!ieState.restoreConfirmed) {
        showToast('Please check the confirmation box before restoring', { type: 'error' });
        return;
      }
      try {
        const restoreRes = await services.importExport.restoreCompleteJsonBackup(ieState.pendingRestoreJson);
        ieState.pendingRestoreJson = null;
        ieState.restoreConfirmed = false;
        const attRestored = restoreRes?.counts?.attachment_blobs || 0;
        showToast(attRestored > 0 ? `Backup restored with ${attRestored} attachment${attRestored === 1 ? '' : 's'}` : 'Backup restored successfully');
        window.location.hash = '#/home';
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });

    container.querySelector('#ie-confirm-clear-tx')?.addEventListener('change', (e) => {
      ieState.confirmClearTx = e.target.checked;
      const btn = container.querySelector('#btn-clear-all-tx');
      if (btn) btn.disabled = !ieState.confirmClearTx;
    });

    container.querySelector('#btn-clear-all-tx')?.addEventListener('click', async () => {
      if (!ieState.confirmClearTx || ieState.busy) return;
      await services.importExport.clearTransactionsOnly();
      ieState.confirmClearTx = false;
      showToast('All transactions cleared — ready for a clean import');
      renderImportExportView(container, ctx);
    });
  }

  container.querySelectorAll('[data-ie-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (ieState.busy) return;
      ieState.tab = btn.getAttribute('data-ie-tab');
      renderImportExportView(container, ctx);
    });
  });
}

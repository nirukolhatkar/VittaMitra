import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { showToast } from '../components/toast.js';
import { bindChartTooltips } from '../components/charts.js';

function compactNw(paise) {
  const r = Math.abs(paise) / 100;
  const sign = paise < 0 ? '-' : '';
  if (r >= 10000000) return `${sign}₹${(r / 10000000).toFixed(2)}Cr`;
  if (r >= 100000) return `${sign}₹${(r / 100000).toFixed(2)}L`;
  if (r >= 1000) return `${sign}₹${(r / 1000).toFixed(1)}k`;
  return `${sign}₹${Math.round(r)}`;
}

function renderNetWorthTrendSvg(snapshots, showBalances) {
  if (!snapshots || snapshots.length === 0) {
    return `<div class="item-meta" style="text-align:center; padding:18px 0;">Tap "Save Snapshot" to start tracking your monthly Net Worth trend.</div>`;
  }
  const pts = snapshots.slice(-12);
  const w = 340;
  const h = 152;
  const padL = 48;
  const padR = 14;
  const padT = 16;
  const padB = 24;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const vals = pts.map((s) => s.net_worth_paise || 0);
  const minVal = Math.min(0, ...vals);
  const maxVal = Math.max(1, ...vals);
  const span = Math.max(1, maxVal - minVal);

  const xAt = (i) => (pts.length === 1 ? padL + plotW / 2 : padL + (i / (pts.length - 1)) * plotW);
  const yAt = (v) => padT + plotH - ((v - minVal) / span) * plotH;

  const path = pts.map((s, i) => `${i === 0 ? 'M' : 'L'}${xAt(i).toFixed(1)},${yAt(s.net_worth_paise).toFixed(1)}`).join(' ');
  const dots = pts.map((s, i) => {
    const label = String(s.snapshot_date || '').slice(0, 7);
    const valStr = showBalances ? formatINR(s.net_worth_paise) : '*****';
    return `<circle cx="${xAt(i).toFixed(1)}" cy="${yAt(s.net_worth_paise).toFixed(1)}" r="4.5" fill="#22c55e" stroke="var(--bg-surface)" stroke-width="1.2" style="cursor:pointer;"
      data-tip-title="${escapeHtml(s.snapshot_date)}" data-tip-value="${escapeHtml(valStr)}" data-tip-sub="Assets ${showBalances ? compactNw((s.assets_paise || 0) + (s.investments_paise || 0)) : '***'}">
      <title>${escapeHtml(label)}: ${escapeHtml(valStr)}</title>
    </circle>
    <text x="${xAt(i).toFixed(1)}" y="${h - 6}" text-anchor="middle" fill="var(--text-muted)" font-size="8.5">${escapeHtml(label.slice(2))}</text>`;
  });

  return `
    <div class="chart-box">
      <div class="chart-tooltip hidden"></div>
      <svg viewBox="0 0 ${w} ${h}" width="100%" style="max-height:165px; display:block;">
        <line x1="${padL}" y1="${yAt(maxVal).toFixed(1)}" x2="${w - padR}" y2="${yAt(maxVal).toFixed(1)}" stroke="var(--border-subtle)" stroke-dasharray="2 3"/>
        <text x="${padL - 5}" y="${(yAt(maxVal) + 3).toFixed(1)}" text-anchor="end" fill="var(--text-muted)" font-size="9">${showBalances ? escapeHtml(compactNw(maxVal)) : '***'}</text>
        <line x1="${padL}" y1="${yAt(minVal).toFixed(1)}" x2="${w - padR}" y2="${yAt(minVal).toFixed(1)}" stroke="var(--border-subtle)" stroke-dasharray="2 3"/>
        <text x="${padL - 5}" y="${(yAt(minVal) + 3).toFixed(1)}" text-anchor="end" fill="var(--text-muted)" font-size="9">${showBalances ? escapeHtml(compactNw(minVal)) : '***'}</text>
        ${pts.length > 1 ? `<path d="${path}" fill="none" stroke="#22c55e" stroke-width="2.4" stroke-linejoin="round"/>` : ''}
        ${dots.join('')}
      </svg>
    </div>
  `;
}

export async function renderNetWorthView(container, ctx) {
  const { repos, services } = ctx;
  const [settings, nw] = await Promise.all([
    repos.settings.getSettings(),
    services.wealth.getNetWorthSummary(),
  ]);

  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');

  container.innerHTML = `
    <div class="stack">
      <section class="hero-card">
        <div class="toolbar" style="margin-bottom:6px;">
          <span class="hero-label">Total Net Worth</span>
          <button type="button" class="btn btn-secondary btn-sm" id="btn-save-nw-snap">📸 Save Snapshot</button>
        </div>
        <div class="hero-balance ${nw.netWorthPaise < 0 ? 'text-danger' : ''}">${fmt(nw.netWorthPaise)}</div>
        <div class="item-meta" style="margin-top:4px;">
          Total Assets ${fmt(nw.totalAssetsPaise)} − Total Liabilities ${fmt(nw.totalLiabilitiesPaise)}
        </div>
      </section>

      <section class="grid-2">
        <a href="#/accounts" class="card stack" style="gap:4px; text-decoration:none;">
          <span class="item-meta">🏦 Liquid Assets</span>
          <strong class="item-title text-success">${fmt(nw.liquidAssetsPaise)}</strong>
          <span class="item-meta">Banks, Wallets &amp; Cash</span>
        </a>
        <a href="#/investments" class="card stack" style="gap:4px; text-decoration:none;">
          <span class="item-meta">📈 Investments</span>
          <strong class="item-title text-success">${fmt(nw.totalInvestmentsPaise)}</strong>
          <span class="item-meta">${nw.investmentsCount} holdings</span>
        </a>
        <a href="#/debts" class="card stack" style="gap:4px; text-decoration:none;">
          <span class="item-meta">💸 Debt Receivables</span>
          <strong class="item-title text-success">${fmt(nw.totalReceivablesPaise || 0)}</strong>
          <span class="item-meta">Money lent to people</span>
        </a>
        <a href="#/debts" class="card stack" style="gap:4px; text-decoration:none;">
          <span class="item-meta">🤝 Debt Payables</span>
          <strong class="item-title text-danger">${fmt(nw.totalPayablesPaise || 0)}</strong>
          <span class="item-meta">Money borrowed</span>
        </a>
        <a href="#/accounts" class="card stack" style="gap:4px; text-decoration:none;">
          <span class="item-meta">💳 Credit Card Dues</span>
          <strong class="item-title text-danger">${fmt(nw.creditCardLiabilitiesPaise)}</strong>
          <span class="item-meta">Current outstanding</span>
        </a>
        <a href="#/investments" class="card stack" style="gap:4px; text-decoration:none;">
          <span class="item-meta">🏡 Active Loans</span>
          <strong class="item-title text-danger">${fmt(nw.loanLiabilitiesPaise)}</strong>
          <span class="item-meta">${nw.activeLoansCount} loans · EMI ${fmt(nw.totalMonthlyEmiPaise)}</span>
        </a>
      </section>

      <section class="card stack" style="gap:10px;">
        <div class="card-title">Net Worth Composition</div>
        ${
          nw.assetBreakdown.length === 0
            ? '<div class="item-meta">Add accounts, investments, debts, or loans to view your wealth breakdown.</div>'
            : nw.assetBreakdown
                .map((row) => {
                  const denom = Math.max(1, nw.totalAssetsPaise + nw.totalLiabilitiesPaise);
                  const pct = Math.round((row.value / denom) * 100);
                  return `
                    <div>
                      <div class="toolbar" style="margin-bottom:4px;">
                        <span class="item-title" style="font-size:0.84rem;">${escapeHtml(row.label)}</span>
                        <span class="item-title" style="font-size:0.84rem;">${fmt(row.value)} (${pct}%)</span>
                      </div>
                      <div class="progress-track" style="height:7px;">
                        <div class="progress-fill" style="width:${pct}%; background:${row.color};"></div>
                      </div>
                    </div>
                  `;
                })
                .join('')
        }
      </section>

      <section class="card stack" style="gap:8px;">
        <div class="toolbar">
          <div class="card-title">Net Worth Trend</div>
          <span class="item-meta">${nw.snapshots.length} snapshot${nw.snapshots.length === 1 ? '' : 's'}</span>
        </div>
        ${renderNetWorthTrendSvg(nw.snapshots, show)}
      </section>
    </div>
  `;

  bindChartTooltips(container);

  container.querySelector('#btn-save-nw-snap')?.addEventListener('click', async () => {
    await services.wealth.recordNetWorthSnapshot();
    showToast('Net Worth snapshot saved for this month');
    renderNetWorthView(container, ctx);
  });
}

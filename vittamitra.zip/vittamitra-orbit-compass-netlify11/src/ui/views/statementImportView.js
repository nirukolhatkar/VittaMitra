import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString, parseRupeesToPaise } from '../../utils/money.js';
import { filterStagedRows, getReviewFilterCounts } from '../../services/statementReviewService.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const stmtViewState = {
  drafts: [],
  pendingFiles: new Map(), // draftId -> File (in-memory only, released after extraction)
  busy: false,
  progressMsg: '',
  abortController: null,
  activeBatchId: null,
  activeExtractedCache: new Map(), // batchId -> { arrayBuffer, extracted, previewUrl } (in-memory only)
  stagedPageLimit: 50,
  reviewFilter: 'all',
  reviewSearch: '',
  selectedRowIds: new Set(),
  historyFilter: 'all',
};

function formatFileSize(bytes) {
  const b = Number(bytes) || 0;
  if (b >= 1024 * 1024) return `${(b / (1024 * 1024)).toFixed(2)} MB`;
  if (b >= 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${b} B`;
}

function shortHash(hex) {
  if (!hex) return '—';
  return `${hex.slice(0, 10)}…${hex.slice(-6)}`;
}

function promptPdfPasswordInMemory(filename) {
  return new Promise((resolve) => {
    let settled = false;
    openModal({
      title: 'Unlock Password-Protected PDF',
      bodyHtml: `
        <form id="pdf-pwd-form" class="stack" style="gap:10px;">
          <div class="item-meta">
            <strong>${escapeHtml(filename)}</strong> is password-protected. Enter the PDF password to extract locally in memory. The password is never saved or logged.
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">PDF Password</label>
            <input name="pdf_password" type="password" autocomplete="off" class="form-control" required placeholder="Enter statement password">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="pdf-pwd-cancel">Skip File</button>
            <button type="submit" class="btn btn-primary" style="flex:1;">Unlock &amp; Extract</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#pdf-pwd-cancel')?.addEventListener('click', () => {
          settled = true;
          close();
          resolve(null);
        });
        panel.querySelector('#pdf-pwd-form')?.addEventListener('submit', (e) => {
          e.preventDefault();
          const input = e.target.querySelector('input[name="pdf_password"]');
          const pwd = input ? input.value : '';
          if (input) input.value = '';
          settled = true;
          close();
          resolve(pwd);
        });
      },
      onClose: () => {
        if (!settled) resolve(null);
      },
    });
  });
}

export async function renderStatementImportView(container, ctx) {
  const prevScrollY = typeof window !== 'undefined' && document.documentElement.getAttribute('data-route-active') === 'statement-import' ? window.scrollY : 0;
  const { repos, services } = ctx;
  const [accounts, categories, batches] = await Promise.all([
    repos.accounts.list({ includeArchived: false }),
    repos.categories.list({ includeArchived: false }),
    repos.statementImport.listStatementBatches({ includeDeleted: false }),
  ]);

  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const catMap = new Map(categories.map((c) => [c.id, c]));
  const sourceLabels = {
    user_correction: 'Confirmed',
    exact_merchant: 'Exact Rule',
    narration_pattern: 'Pattern Rule',
    confirmed_preference: 'History',
    merchant_dictionary: 'Merchant Dict',
    description_analysis: 'Narration',
    uncategorized: 'Uncategorized',
    unclassified: 'Pending',
  };
  const activeBatch = stmtViewState.activeBatchId
    ? batches.find((b) => b.id === stmtViewState.activeBatchId) || null
    : null;
  const [activeStaged, activeMatches] = activeBatch
    ? await Promise.all([
        services.statementNormalisation.listStagedByBatch(activeBatch.id),
        services.statementReconciliation ? services.statementReconciliation.listMatchesByBatch(activeBatch.id) : Promise.resolve([]),
      ])
    : [[], []];
  const matchByStagedId = new Map();
  for (const m of activeMatches) {
    if (!matchByStagedId.has(m.staged_tx_id)) matchByStagedId.set(m.staged_tx_id, []);
    matchByStagedId.get(m.staged_tx_id).push(m);
  }

  let activeSummary = null;
  if (activeBatch?.summary_json) {
    try {
      activeSummary = JSON.parse(activeBatch.summary_json);
    } catch {
      activeSummary = null;
    }
  }

  const renderDraftCard = (d) => {
    const statusBadge = !d.valid
      ? `<span class="badge" style="background:rgba(239,68,68,0.16); color:var(--danger);">Invalid File</span>`
      : d.isDuplicateFile
        ? `<span class="badge" style="background:rgba(245,158,11,0.18); color:var(--warning);">Duplicate SHA-256</span>`
        : `<span class="badge" style="background:rgba(16,185,129,0.16); color:var(--success);">Validated</span>`;

    return `
      <article class="card stack" style="gap:10px; padding:14px;" data-draft-id="${escapeHtml(d.draftId)}">
        <div class="toolbar" style="align-items:flex-start; gap:8px;">
          <div style="min-width:0; flex:1;">
            <div class="item-title" style="overflow-wrap:anywhere;">${escapeHtml(d.filename)}</div>
            <div class="item-meta">
              ${escapeHtml((d.fileExt || '?').toUpperCase())} · ${formatFileSize(d.fileSize)}
              ${d.fileHash ? ` · SHA-256 ${escapeHtml(shortHash(d.fileHash))}` : ''}
            </div>
          </div>
          <div style="display:flex; align-items:center; gap:6px;">
            ${statusBadge}
            <button type="button" class="icon-btn" data-remove-draft="${escapeHtml(d.draftId)}" aria-label="Remove file" title="Remove">✕</button>
          </div>
        </div>

        ${
          d.errors.length > 0
            ? `<div style="padding:8px 10px; border-radius:var(--radius-sm); background:rgba(239,68,68,0.12); color:var(--danger); font-size:0.82rem;">
                ${d.errors.map((err) => `<div>• ${escapeHtml(err)}</div>`).join('')}
              </div>`
            : ''
        }

        ${
          d.warnings.length > 0
            ? `<div style="padding:8px 10px; border-radius:var(--radius-sm); background:rgba(245,158,11,0.12); color:var(--warning); font-size:0.82rem;">
                ${d.warnings.map((w) => `<div>⚠ ${escapeHtml(w)}</div>`).join('')}
              </div>`
            : ''
        }

        ${
          d.isDuplicateFile && d.duplicateOfBatch
            ? `<div style="padding:10px; border-radius:var(--radius-sm); background:rgba(245,158,11,0.12); border:1px solid rgba(245,158,11,0.35); font-size:0.82rem;">
                <div style="font-weight:600; color:var(--warning);">Previously uploaded file detected</div>
                <div class="item-meta" style="margin-top:2px;">
                  Matches "${escapeHtml(d.duplicateOfBatch.filename)}" uploaded on ${escapeHtml(String(d.duplicateOfBatch.imported_at || '').slice(0, 10))} (${escapeHtml(d.duplicateOfBatch.status || 'uploaded')}).
                </div>
                <label style="display:flex; align-items:center; gap:8px; margin-top:8px; cursor:pointer;">
                  <input type="checkbox" data-draft-allow-dup="${escapeHtml(d.draftId)}" ${d.allowDuplicateUpload ? 'checked' : ''}>
                  <span>Allow re-upload as a new batch</span>
                </label>
              </div>`
            : ''
        }

        ${
          d.valid
            ? `<div class="grid-2" style="gap:10px;">
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Target Account (Confirm Required)</label>
                  <select class="form-control" data-draft-account="${escapeHtml(d.draftId)}">
                    <option value="">-- Select Account --</option>
                    ${accounts
                      .map(
                        (a) =>
                          `<option value="${a.id}" ${d.accountId === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`
                      )
                      .join('')}
                  </select>
                  ${d.matchReason ? `<div class="item-meta" style="margin-top:3px;">Auto-detected: ${escapeHtml(d.matchReason)}</div>` : ''}
                </div>
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Institution</label>
                  <input class="form-control" maxlength="60" data-draft-institution="${escapeHtml(d.draftId)}"
                    value="${escapeHtml(d.institution || '')}" placeholder="e.g. HDFC Bank, ICICI Bank">
                </div>
              </div>
              <div class="grid-3" style="gap:10px;">
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Period Start</label>
                  <input type="date" class="form-control" data-draft-start="${escapeHtml(d.draftId)}" value="${escapeHtml(d.periodStart || '')}">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Period End</label>
                  <input type="date" class="form-control" data-draft-end="${escapeHtml(d.draftId)}" value="${escapeHtml(d.periodEnd || '')}">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Masked Ref</label>
                  <input class="form-control" maxlength="16" data-draft-ref="${escapeHtml(d.draftId)}"
                    value="${escapeHtml(d.maskedAccountRef || '')}" placeholder="XXXX1234">
                </div>
              </div>`
            : ''
        }
      </article>
    `;
  };

  const renderExtractionSummarySection = () => {
    if (!activeBatch) return '';
    const acc = accMap.get(activeBatch.account_id);
    const cache = stmtViewState.activeExtractedCache.get(activeBatch.id);
    const isImgBatch = activeBatch.source_type === 'upi_screenshot' || ['jpg', 'jpeg', 'png', 'webp'].includes(activeBatch.file_ext);
    const canRemap = Boolean(cache && activeSummary?.headerCells?.length > 0 && activeBatch.file_ext !== 'pdf' && !isImgBatch);
    const reviewCounts = getReviewFilterCounts(activeStaged);
    const filteredStaged = filterStagedRows(activeStaged, {
      filter: stmtViewState.reviewFilter,
      search: stmtViewState.reviewSearch,
    });
    const visibleStaged = filteredStaged.slice(0, stmtViewState.stagedPageLimit);
    const selectedInBatch = [...stmtViewState.selectedRowIds].filter((id) => activeStaged.some((r) => r.id === id));
    const filterTabs = [
      { key: 'all', label: `All (${reviewCounts.all})` },
      { key: 'new', label: `New (${reviewCounts.new})` },
      { key: 'duplicates', label: `Duplicates (${reviewCounts.duplicates})` },
      { key: 'needs_attention', label: `Needs Attention (${reviewCounts.needs_attention})` },
      { key: 'approved', label: `Approved (${reviewCounts.approved})` },
      { key: 'excluded', label: `Excluded (${reviewCounts.excluded})` },
    ];

    return `
      <section class="card stack" style="gap:12px; padding:16px; border:1px solid var(--accent);" aria-label="Extraction Summary">
        <div class="stack" style="gap:8px;">
          <div style="min-width:0;">
            <div class="item-title" style="font-size:0.98rem; overflow-wrap:anywhere;">${escapeHtml(activeBatch.filename)}</div>
            <div class="item-meta" style="margin-top:2px;">
              ${escapeHtml(activeBatch.institution || 'Institution unset')} · ${escapeHtml(acc ? acc.name : 'Account unset')}
              ${activeBatch.period_start || activeBatch.period_end ? ` · ${escapeHtml(activeBatch.period_start || '?')} → ${escapeHtml(activeBatch.period_end || '?')}` : ''}
            </div>
          </div>
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <button type="button" class="btn btn-secondary btn-sm" id="btn-rerun-categorise">Categorise</button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-rerun-reconcile">Reconcile</button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-close-summary">Close</button>
          </div>
        </div>

        <div class="grid-3" style="gap:8px;">
          <div class="metric-card" style="padding:10px;">
            <div class="metric-label">Extracted Txns</div>
            <div class="item-title" style="font-size:1rem;">${activeStaged.length}</div>
          </div>
          <div class="metric-card" style="padding:10px;">
            <div class="metric-label">Pages / Sheets</div>
            <div class="item-title" style="font-size:1rem;">${activeSummary?.pageCount || 1}</div>
          </div>
          <div class="metric-card" style="padding:10px;">
            <div class="metric-label">Skipped Rows</div>
            <div class="item-title" style="font-size:1rem;">${activeSummary?.skippedNonTxRows ?? 0}</div>
          </div>
        </div>

        ${
          activeSummary?.reconciliation
            ? `<div style="display:flex; gap:6px; flex-wrap:wrap; font-size:0.75rem;">
                ${activeSummary.reconciliation.exactDuplicates + activeSummary.reconciliation.probableDuplicates > 0 ? `<span class="badge" style="background:rgba(245,158,11,0.16); color:var(--warning);">Duplicates: ${activeSummary.reconciliation.exactDuplicates + activeSummary.reconciliation.probableDuplicates}</span>` : ''}
                ${activeSummary.reconciliation.internalTransfers + activeSummary.reconciliation.ccSettlements > 0 ? `<span class="badge badge-muted">Transfers/CC: ${activeSummary.reconciliation.internalTransfers + activeSummary.reconciliation.ccSettlements}</span>` : ''}
                ${activeSummary.reconciliation.refundLinks > 0 ? `<span class="badge badge-muted">Refunds: ${activeSummary.reconciliation.refundLinks}</span>` : ''}
                ${activeSummary.reconciliation.recurringCandidates > 0 ? `<span class="badge badge-muted">Recurring: ${activeSummary.reconciliation.recurringCandidates}</span>` : ''}
                ${
                  activeSummary.reconciliation.balanceCheck?.available
                    ? activeSummary.reconciliation.balanceCheck.verified
                      ? `<span class="badge" style="background:rgba(16,185,129,0.16); color:var(--success);">✓ Balance Verified</span>`
                      : `<span class="badge" style="background:rgba(239,68,68,0.16); color:var(--danger);">⚠ Balance Diff: ${formatINR(activeSummary.reconciliation.balanceCheck.discrepancyPaise)}</span>`
                    : ''
                }
              </div>`
            : ''
        }

        ${
          activeBatch.opening_balance_paise !== null || activeBatch.closing_balance_paise !== null
            ? `<div class="grid-2" style="gap:8px;">
                <div class="metric-card" style="padding:10px;">
                  <div class="metric-label">Opening Balance</div>
                  <div class="item-title">${activeBatch.opening_balance_paise !== null ? formatINR(activeBatch.opening_balance_paise) : '—'}</div>
                </div>
                <div class="metric-card" style="padding:10px;">
                  <div class="metric-label">Closing Balance</div>
                  <div class="item-title">${activeBatch.closing_balance_paise !== null ? formatINR(activeBatch.closing_balance_paise) : '—'}</div>
                </div>
              </div>`
            : ''
        }

        ${
          activeSummary?.rawOcrSamples?.length > 0
            ? `<details class="card" style="padding:10px; background:var(--bg-surface-elevated); font-size:0.78rem;">
                <summary style="cursor:pointer; font-weight:600; color:var(--accent-ink);">
                  View Raw On-Device OCR Output (${activeSummary.rawOcrSamples.length} image${activeSummary.rawOcrSamples.length === 1 ? '' : 's'})
                </summary>
                <div class="stack" style="gap:8px; margin-top:8px;">
                  ${activeSummary.rawOcrSamples
                    .map(
                      (s) => `<div>
                        <div class="item-meta" style="font-weight:600;">${escapeHtml(s.filename)} · ${escapeHtml(s.engine || 'OCR')}${s.confidence ? ` · ${s.confidence}% conf` : ''}${s.processingMs ? ` · ${s.processingMs}ms` : ''}</div>
                        <pre style="margin:4px 0 0; padding:8px; background:var(--bg-canvas); border-radius:6px; white-space:pre-wrap; word-break:break-word; font-size:0.74rem; max-height:160px; overflow:auto;">${escapeHtml(s.text)}</pre>
                      </div>`
                    )
                    .join('')}
                </div>
              </details>`
            : ''
        }

        ${
          activeSummary?.warnings?.length > 0
            ? `<div style="padding:10px; border-radius:var(--radius-sm); background:rgba(245,158,11,0.12); color:var(--warning); font-size:0.82rem;">
                ${activeSummary.warnings.map((w) => `<div>⚠ ${escapeHtml(w)}</div>`).join('')}
              </div>`
            : ''
        }

        ${
          canRemap
            ? `<div style="display:flex; justify-content:space-between; align-items:center; gap:8px; flex-wrap:wrap;">
                <span class="item-meta">${activeSummary.needsManualMapping ? 'Auto-mapping incomplete — please map columns manually.' : 'Columns auto-mapped from statement header.'}</span>
                <button type="button" class="btn btn-secondary btn-sm" id="btn-manual-remap">Adjust Column Mapping</button>
              </div>`
            : ''
        }

        ${
          isImgBatch
            ? `<div class="card stack" style="gap:10px; padding:12px; background:var(--bg-surface-elevated);">
                ${
                  cache?.previewUrl
                    ? `<img src="${cache.previewUrl}" alt="Uploaded transaction screenshot" style="max-height:220px; width:auto; max-width:100%; border-radius:var(--radius-sm); object-fit:contain; align-self:center; border:1px solid var(--border-subtle);">`
                    : ''
                }
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Paste Text Copied from Screenshot (Google Lens / Select Text)</label>
                  <textarea id="stmt-img-ocr-text" class="form-control" rows="4" placeholder="Example:&#10;Paid to Swiggy&#10;₹450.00&#10;22 Nov 2026&#10;UPI transaction ID 409812345678"></textarea>
                </div>
                <button type="button" class="btn btn-primary btn-sm" id="btn-extract-img-text">Extract Transactions from Screenshot Text</button>
              </div>`
            : ''
        }

        ${
          activeSummary?.lastCommitReport
            ? `<div class="card stack" style="gap:6px; padding:12px; background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.35);">
                <div class="toolbar">
                  <strong style="font-size:0.86rem; color:var(--success);">Import Completion Report</strong>
                  <div style="display:flex; gap:6px;">
                    <a href="#/transactions" class="btn btn-secondary btn-sm">View Ledger</a>
                    ${
                      (activeBatch.imported_count || 0) > 0
                        ? `<button type="button" class="btn btn-danger btn-sm" id="btn-rollback-stmt-batch">Roll Back Batch</button>`
                        : ''
                    }
                  </div>
                </div>
                <div class="item-meta">
                  Imported: <strong>${activeSummary.lastCommitReport.totalImportedInBatch ?? activeSummary.lastCommitReport.importedCount}</strong>
                  · Pre-commit duplicate skips: <strong>${activeSummary.lastCommitReport.skippedDuplicateRecheck || 0}</strong>
                  · Failed: <strong>${activeSummary.lastCommitReport.failedCount || 0}</strong>
                </div>
                ${
                  (activeSummary.lastCommitReport.failedRows || []).length > 0
                    ? `<div style="font-size:0.76rem; color:var(--danger);">
                        ${activeSummary.lastCommitReport.failedRows.map((f) => `<div>• ${escapeHtml(f.description)}: ${escapeHtml(f.error)}</div>`).join('')}
                      </div>`
                    : ''
                }
              </div>`
            : ''
        }

        ${
          activeStaged.length > 0
            ? `<div class="stack" style="gap:8px; padding-top:8px; border-top:1px solid var(--border-subtle);">
                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                  ${filterTabs
                    .map(
                      (ft) =>
                        `<button type="button" class="chip ${stmtViewState.reviewFilter === ft.key ? 'active' : ''}" data-review-filter="${ft.key}" style="font-size:0.74rem; padding:4px 10px;">${escapeHtml(ft.label)}</button>`
                    )
                    .join('')}
                </div>
                <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                  <input id="stmt-review-search" class="form-control" style="flex:1; min-width:160px;" placeholder="Filter narration, merchant, UTR…" value="${escapeHtml(stmtViewState.reviewSearch)}">
                  <button type="button" class="btn btn-primary btn-sm" id="btn-approve-all-ready">Approve Ready (${reviewCounts.new})</button>
                </div>
                <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; justify-content:space-between; font-size:0.78rem;">
                  <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                    <input type="checkbox" id="chk-select-all-visible" ${visibleStaged.length > 0 && visibleStaged.every((r) => stmtViewState.selectedRowIds.has(r.id)) ? 'checked' : ''}>
                    <span>Select visible (${visibleStaged.length})</span>
                  </label>
                  <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                    ${
                      activeStaged.some((r) => r.status === 'failed')
                        ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-retry-failed">Retry Failed (${activeStaged.filter((r) => r.status === 'failed').length})</button>`
                        : ''
                    }
                    <button type="button" class="btn btn-primary btn-sm" id="btn-commit-approved" ${reviewCounts.approved === 0 ? 'disabled' : ''}>
                      Import Approved to Ledger (${reviewCounts.approved})
                    </button>
                  </div>
                </div>
                ${
                  selectedInBatch.length > 0
                    ? `<div class="card" style="padding:8px 10px; background:var(--bg-surface-elevated); display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                        <strong style="font-size:0.78rem; margin-right:4px;">${selectedInBatch.length} selected:</strong>
                        <button type="button" class="btn btn-primary btn-sm" id="btn-bulk-approve">Approve</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="btn-bulk-exclude">Exclude</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="btn-bulk-categorise">Bulk Categorise</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="btn-bulk-account">Bulk Account</button>
                        <button type="button" class="btn btn-secondary btn-sm" id="btn-bulk-clear">Clear</button>
                      </div>`
                    : ''
                }
              </div>`
            : ''
        }

        ${
          visibleStaged.length === 0
            ? `<div class="item-meta" style="padding:10px 0;">${activeStaged.length === 0 ? 'No transactions extracted yet.' : 'No staged transactions match the current filter.'} ${canRemap ? 'Try adjusting the column mapping above.' : ''}</div>`
            : `<div class="grouped-card">
                ${visibleStaged
                  .map((r) => {
                    const isCredit = (r.credit_paise || 0) > 0 && (r.debit_paise || 0) === 0;
                    const splitArr = r.splits_json ? (() => { try { return JSON.parse(r.splits_json); } catch { return []; } })() : [];
                    const stColor =
                      r.status === 'approved'
                        ? 'background:rgba(16,185,129,0.16); color:var(--success);'
                        : r.status === 'excluded'
                          ? 'background:rgba(148,163,184,0.16); color:var(--text-secondary);'
                          : r.status === 'duplicate' || r.status === 'needs_attention'
                            ? 'background:rgba(245,158,11,0.16); color:var(--warning);'
                            : '';
                    const rowAccName = accMap.get(r.account_id)?.name || 'Unassigned';
                    return `
                      <div class="grouped-row" style="display:flex; flex-direction:column; align-items:stretch; gap:8px; padding:12px; ${r.status === 'excluded' ? 'opacity:0.65;' : ''}">
                        <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:10px;">
                          <div style="display:flex; align-items:flex-start; gap:8px; min-width:0; flex:1;">
                            <input type="checkbox" data-select-staged="${r.id}" ${stmtViewState.selectedRowIds.has(r.id) ? 'checked' : ''} style="margin-top:3px; flex-shrink:0;" aria-label="Select row">
                            <div style="min-width:0; flex:1;">
                              <div class="item-title" style="font-size:0.9rem; line-height:1.3; overflow-wrap:break-word;">${escapeHtml(r.merchant || r.description)}</div>
                              <div class="item-meta" style="font-size:0.74rem; margin-top:2px;">
                                ${escapeHtml(r.date_key || 'Date ambiguous')} · ${escapeHtml(rowAccName)} · ${escapeHtml(r.tx_type)}
                              </div>
                            </div>
                          </div>
                          <strong class="${isCredit ? 'text-success' : 'text-danger'}" style="font-size:0.95rem; font-variant-numeric:tabular-nums; white-space:nowrap; flex-shrink:0;">
                            ${isCredit ? '+' : '−'}${formatINR(r.amount_paise)}
                          </strong>
                        </div>

                        <div class="item-meta" style="font-size:0.76rem; line-height:1.35; padding-left:24px; overflow-wrap:break-word; color:var(--text-secondary);">
                          ${escapeHtml(r.raw_narration)}${r.upi_id ? ` · ${escapeHtml(r.upi_id)}` : ''}${r.transaction_reference ? ` · UTR ${escapeHtml(r.transaction_reference)}` : ''}
                        </div>

                        ${
                          r.status === 'failed' && r.import_error
                            ? `<div style="font-size:0.74rem; color:var(--danger); padding-left:24px;">✕ Import failed: ${escapeHtml(r.import_error)}</div>`
                            : r.status === 'imported'
                              ? `<div style="font-size:0.74rem; color:var(--success); padding-left:24px;">✓ Imported into ledger</div>`
                              : ''
                        }
                        ${
                          r.status === 'duplicate'
                            ? `<div style="font-size:0.74rem; color:var(--warning); padding-left:24px;">⚠ ${escapeHtml(r.duplicate_reason || 'Possible duplicate')}</div>`
                            : r.requires_confirmation
                              ? `<div style="font-size:0.74rem; color:var(--warning); padding-left:24px;">⚠ Needs confirmation: ${escapeHtml((r.ambiguous_fields || []).join(', ') || r.tx_status)}</div>`
                              : ''
                        }

                        <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; padding-left:24px; padding-top:4px; border-top:1px solid var(--border-subtle);">
                          <div style="display:flex; align-items:center; gap:5px; flex-wrap:wrap;">
                            <span class="badge badge-muted" style="font-size:0.68rem; ${stColor}">${escapeHtml(r.status.replace(/_/g, ' '))}</span>
                            ${splitArr.length > 0 ? `<span class="badge badge-muted" style="font-size:0.68rem;">Split (${splitArr.length})</span>` : ''}
                            <span class="badge badge-muted" style="font-size:0.68rem;">
                              ${splitArr.length > 0 ? 'Split' : escapeHtml((catMap.get(r.subcategory_id || r.category_id)?.name) || (r.tx_type === 'transfer' ? 'Transfer' : 'Uncategorized'))}
                              · ${Math.round((Number(r.confidence_score) || 0) * 100)}%
                            </span>
                          </div>
                          <div style="display:flex; gap:6px; flex-wrap:wrap;">
                            ${
                              (matchByStagedId.get(r.id) || []).some((m) => m.resolution === 'pending')
                                ? `<button type="button" class="btn btn-primary btn-sm" style="padding:3px 10px; font-size:0.74rem;" data-compare-match="${(matchByStagedId.get(r.id) || []).find((m) => m.resolution === 'pending').id}">Compare</button>`
                                : ''
                            }
                            ${
                              r.status === 'approved'
                                ? `<button type="button" class="btn btn-secondary btn-sm" style="padding:3px 10px; font-size:0.74rem;" data-row-status="${r.id}:new">Unapprove</button>`
                                : `<button type="button" class="btn btn-primary btn-sm" style="padding:3px 10px; font-size:0.74rem;" data-row-status="${r.id}:approved">Approve</button>`
                            }
                            ${
                              r.status === 'excluded'
                                ? `<button type="button" class="btn btn-secondary btn-sm" style="padding:3px 10px; font-size:0.74rem;" data-row-status="${r.id}:new">Restore</button>`
                                : `<button type="button" class="btn btn-secondary btn-sm" style="padding:3px 10px; font-size:0.74rem;" data-row-status="${r.id}:excluded">Exclude</button>`
                            }
                            <button type="button" class="btn btn-secondary btn-sm" style="padding:3px 10px; font-size:0.74rem;" data-edit-cat-staged="${r.id}">Edit</button>
                          </div>
                        </div>
                      </div>
                    `;
                  })
                  .join('')}
              </div>
              ${
                filteredStaged.length > visibleStaged.length
                  ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-load-more-staged">Show More (${filteredStaged.length - visibleStaged.length} remaining)</button>`
                  : ''
              }`
        }
      </section>
    `;
  };

  container.innerHTML = `
    <div class="stack" style="gap:16px;">
      <div class="import-stepper" aria-label="Import progress">
        <div class="import-step ${!activeBatch ? 'active' : 'done'}"><span class="step-num">1</span><span>Upload</span></div>
        <div class="import-step-line"></div>
        <div class="import-step ${activeBatch && activeBatch.status !== 'imported' ? 'active' : activeBatch?.status === 'imported' ? 'done' : ''}"><span class="step-num">2</span><span>Review &amp; Edit</span></div>
        <div class="import-step-line"></div>
        <div class="import-step ${activeBatch?.status === 'imported' ? 'active done' : ''}"><span class="step-num">3</span><span>Post to Ledger</span></div>
      </div>
      <section class="card stack" style="gap:12px; padding:18px;">
        <div class="toolbar">
          <div>
            <div class="item-title" style="font-size:1.05rem;">Smart Statement Import</div>
            <div class="item-meta">100% local on-device processing · Supports PDF, CSV, XLS, XLSX &amp; UPI Screenshots (JPG, PNG, WebP)</div>
          </div>
          <a href="#/categorisation-rules" class="btn btn-secondary btn-sm">My Rules →</a>
        </div>

        ${
          stmtViewState.progressMsg
            ? `<div style="display:flex; align-items:center; justify-content:space-between; gap:8px; padding:10px 12px; border-radius:var(--radius-sm); background:var(--accent-soft); color:var(--accent-ink); font-size:0.84rem; font-weight:600;">
                <span>⏳ ${escapeHtml(stmtViewState.progressMsg)}</span>
                <button type="button" class="btn btn-secondary btn-sm" id="btn-cancel-extraction">Cancel</button>
              </div>`
            : ''
        }

        <label for="stmt-file-input" id="stmt-dropzone" style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:24px 16px; border:1.5px dashed var(--border-subtle); border-radius:var(--radius-md); background:var(--bg-surface-elevated); cursor:pointer; text-align:center;">
          <span style="font-size:1.6rem;" aria-hidden="true">📄</span>
          <div class="item-title">Select or drop bank / credit card statements</div>
          <div class="item-meta">Multiple files or UPI screenshots allowed · PDF, CSV, XLS, XLSX, JPG, PNG, WebP · Stays 100% on-device</div>
          <input id="stmt-file-input" type="file" accept=".pdf,.csv,.xls,.xlsx,.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" multiple style="display:none;">
        </label>

        ${
          stmtViewState.drafts.length > 0
            ? `<div class="stack" style="gap:10px;">
                <div class="toolbar">
                  <span class="item-title" style="font-size:0.9rem;">Staged Files (${stmtViewState.drafts.length})</span>
                  <button type="button" class="btn btn-secondary btn-sm" id="btn-clear-drafts">Clear All</button>
                </div>
                ${stmtViewState.drafts.map(renderDraftCard).join('')}
                <button type="button" class="btn btn-primary" id="btn-confirm-batches" ${stmtViewState.busy ? 'disabled' : ''}>
                  Confirm Accounts &amp; Extract Statement${stmtViewState.drafts.length > 1 ? 's' : ''}
                </button>
              </div>`
            : ''
        }
      </section>

      ${renderExtractionSummarySection()}

      <section class="stack" style="gap:10px;">
        <div class="section-heading">
          <span class="section-heading-left">Import History (${batches.length})</span>
          <a href="#/categorisation-rules" style="font-size:0.82rem; color:var(--accent-ink); font-weight:600;">My Rules ›</a>
        </div>

        ${
          batches.length > 0
            ? `<div style="display:flex; gap:6px; flex-wrap:wrap;">
                ${[
                  { k: 'all', l: 'All' },
                  { k: 'statement', l: 'Statements' },
                  { k: 'upi_screenshot', l: 'UPI Screenshots' },
                  { k: 'imported', l: 'Imported' },
                  { k: 'pending', l: 'Pending Review' },
                ]
                  .map(
                    (f) =>
                      `<button type="button" class="chip ${stmtViewState.historyFilter === f.k ? 'active' : ''}" data-history-filter="${f.k}" style="font-size:0.74rem; padding:4px 10px;">${f.l}</button>`
                  )
                  .join('')}
              </div>`
            : ''
        }

        ${(() => {
          const filteredBatches = batches.filter((b) => {
            if (stmtViewState.historyFilter === 'statement') return b.source_type !== 'upi_screenshot';
            if (stmtViewState.historyFilter === 'upi_screenshot') return b.source_type === 'upi_screenshot';
            if (stmtViewState.historyFilter === 'imported') return b.status === 'imported' || b.status === 'partially_imported';
            if (stmtViewState.historyFilter === 'pending') return b.status !== 'imported';
            return true;
          });
          if (filteredBatches.length === 0) {
            return `<div class="card" style="padding:18px; text-align:center;">
              <div class="item-meta">${batches.length === 0 ? 'No statement batches uploaded yet. Upload your first PDF, CSV, XLS, XLSX, or UPI screenshot above.' : 'No batches match the selected history filter.'}</div>
            </div>`;
          }
          return `<div class="stack" style="gap:10px;">
            ${filteredBatches
              .map((b) => {
                const acc = accMap.get(b.account_id);
                const isUpi = b.source_type === 'upi_screenshot';
                const periodTxt =
                  b.period_start || b.period_end
                    ? `${b.period_start || '?'} → ${b.period_end || '?'}`
                    : 'Period not set';
                return `
                  <article class="card stack" style="gap:8px; padding:14px;">
                    <div class="toolbar" style="align-items:flex-start; gap:8px;">
                      <div style="min-width:0; flex:1;">
                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                          <span class="item-title" style="overflow-wrap:anywhere;">${escapeHtml(b.filename)}</span>
                          <span class="badge badge-muted" style="font-size:0.66rem;">${isUpi ? 'UPI Screenshot' : 'Statement'}</span>
                        </div>
                        <div class="item-meta">
                          ${escapeHtml(b.institution || 'Institution unset')}
                          · ${escapeHtml(acc ? acc.name : 'Account unset')}
                          ${b.masked_account_ref ? ` (${escapeHtml(b.masked_account_ref)})` : ''}
                        </div>
                        <div class="item-meta">
                          ${escapeHtml(periodTxt)} · ${b.row_count || 0} staged · <strong>${b.imported_count || 0} imported</strong> · ${formatFileSize(b.file_size)}
                        </div>
                      </div>
                      <span class="badge badge-muted">${escapeHtml(b.status || 'uploaded')}</span>
                    </div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                      <button type="button" class="btn btn-primary btn-sm" data-view-batch="${b.id}">Open Review (${b.row_count || 0})</button>
                      ${
                        (b.imported_count || 0) > 0
                          ? `<button type="button" class="btn btn-danger btn-sm" data-rollback-history-batch="${b.id}">Roll Back</button>`
                          : `<button type="button" class="btn btn-secondary btn-sm" data-edit-batch="${b.id}">Edit Metadata</button>
                             <button type="button" class="btn btn-danger btn-sm" data-del-batch="${b.id}">Delete</button>`
                      }
                    </div>
                  </article>
                `;
              })
              .join('')}
          </div>`;
        })()}
      </section>
    </div>
  `;

  const handleFiles = async (fileList) => {
    const files = Array.from(fileList || []);
    if (files.length === 0) return;
    stmtViewState.busy = true;
    stmtViewState.progressMsg = `Inspecting ${files.length} file${files.length === 1 ? '' : 's'}…`;
    renderStatementImportView(container, ctx);
    try {
      const inspected = await services.statementUpload.inspectUploadedFiles(
        files.map((file) => ({ file }))
      );
      inspected.forEach((draft, idx) => {
        if (files[idx]) stmtViewState.pendingFiles.set(draft.draftId, files[idx]);
      });
      stmtViewState.drafts = [...stmtViewState.drafts, ...inspected];
      showToast(`Inspected ${inspected.length} file${inspected.length === 1 ? '' : 's'}`);
    } catch (err) {
      showToast(err.message || 'Failed to inspect files', { type: 'error' });
    } finally {
      stmtViewState.busy = false;
      stmtViewState.progressMsg = '';
      stmtViewState.abortController = null;
      renderStatementImportView(container, ctx);
    }
  };

  container.querySelector('#stmt-file-input')?.addEventListener('change', (e) => {
    handleFiles(e.target.files);
  });

  const dropzone = container.querySelector('#stmt-dropzone');
  if (dropzone) {
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = 'var(--accent)';
    });
    dropzone.addEventListener('dragleave', () => {
      dropzone.style.borderColor = 'var(--border-subtle)';
    });
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = 'var(--border-subtle)';
      handleFiles(e.dataTransfer?.files);
    });
  }

  container.querySelector('#btn-clear-drafts')?.addEventListener('click', () => {
    stmtViewState.drafts = [];
    stmtViewState.pendingFiles.clear();
    renderStatementImportView(container, ctx);
  });

  container.querySelectorAll('[data-remove-draft]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-remove-draft');
      stmtViewState.drafts = stmtViewState.drafts.filter((d) => d.draftId !== id);
      stmtViewState.pendingFiles.delete(id);
      renderStatementImportView(container, ctx);
    });
  });

  const bindDraftField = (selector, prop, isCheckbox = false) => {
    container.querySelectorAll(selector).forEach((el) => {
      el.addEventListener('change', (e) => {
        const id = el.getAttribute(selector.slice(1, -1));
        const draft = stmtViewState.drafts.find((d) => d.draftId === id);
        if (!draft) return;
        draft[prop] = isCheckbox ? Boolean(e.target.checked) : e.target.value;
        if (prop === 'allowDuplicateUpload') {
          draft.include = draft.valid && (!draft.isDuplicateFile || draft.allowDuplicateUpload);
        }
      });
    });
  };
  bindDraftField('[data-draft-account]', 'accountId');
  bindDraftField('[data-draft-institution]', 'institution');
  bindDraftField('[data-draft-start]', 'periodStart');
  bindDraftField('[data-draft-end]', 'periodEnd');
  bindDraftField('[data-draft-ref]', 'maskedAccountRef');
  bindDraftField('[data-draft-allow-dup]', 'allowDuplicateUpload', true);

  container.querySelector('#btn-cancel-extraction')?.addEventListener('click', () => {
    stmtViewState.abortController?.abort();
    showToast('Cancelling extraction…');
  });

  container.querySelector('#btn-confirm-batches')?.addEventListener('click', async () => {
    stmtViewState.busy = true;
    stmtViewState.abortController = typeof AbortController !== 'undefined' ? new AbortController() : null;
    try {
      const includedDrafts = stmtViewState.drafts.filter(
        (d) => d.include && d.valid && (!d.isDuplicateFile || d.allowDuplicateUpload)
      );
      const res = await services.statementUpload.createConfirmedBatches(stmtViewState.drafts);
      if (res.created.length === 0) {
        showToast('No eligible files selected for extraction.', { type: 'error' });
        stmtViewState.busy = false;
        return;
      }

      let totalExtracted = 0;
      const draftByHash = new Map(includedDrafts.map((d) => [d.fileHash, d]));
      for (let i = 0; i < res.created.length; i += 1) {
        const batch = res.created[i];

        if (batch.source_type === 'upi_screenshot') {
          const sourceFiles = Array.isArray(batch.source_files) ? batch.source_files : [];
          const imageInputs = [];
          let firstPreviewUrl = null;
          for (const sf of sourceFiles) {
            const d = stmtViewState.pendingFiles.has(sf.draftId)
              ? { draftId: sf.draftId }
              : draftByHash.get(sf.file_hash);
            const fObj = d ? stmtViewState.pendingFiles.get(d.draftId) : null;
            if (!fObj) continue;
            const ab = await fObj.arrayBuffer();
            if (!firstPreviewUrl && typeof URL !== 'undefined' && URL.createObjectURL) {
              firstPreviewUrl = URL.createObjectURL(fObj);
            }
            imageInputs.push({ filename: sf.filename, mimeType: sf.mime_type, arrayBuffer: ab });
          }
          stmtViewState.progressMsg = `Processing ${imageInputs.length} UPI screenshot${imageInputs.length === 1 ? '' : 's'} locally…`;
          renderStatementImportView(container, ctx);
          try {
            const out = await services.statementNormalisation.extractAndStageUpiScreenshotBatch({
              batchId: batch.id,
              imageInputs,
              signal: stmtViewState.abortController?.signal || null,
              onProgress: (p) => {
                stmtViewState.progressMsg = p.message;
              },
            });
            if (out.stagedRows.length > 0 && services.statementCategorisation) {
              await services.statementCategorisation.categoriseBatch(batch.id);
              if (services.statementReconciliation) await services.statementReconciliation.reconcileBatch(batch.id);
            }
            totalExtracted += out.stagedRows.length;
            stmtViewState.activeBatchId = batch.id;
            stmtViewState.stagedPageLimit = 50;
            stmtViewState.activeExtractedCache.set(batch.id, { imageInputs, previewUrl: firstPreviewUrl });
          } catch (extErr) {
            showToast(`${batch.filename}: ${extErr.message}`, { type: 'error' });
          }
          continue;
        }

        const draft = draftByHash.get(batch.file_hash) || includedDrafts[i];
        const fileObj = draft ? stmtViewState.pendingFiles.get(draft.draftId) : null;
        if (!fileObj) continue;

        let password = '';
        if (batch.is_password_protected) {
          const entered = await promptPdfPasswordInMemory(batch.filename);
          if (entered === null) continue;
          password = entered;
        }

        const arrayBuffer = await fileObj.arrayBuffer();
        stmtViewState.progressMsg = `Extracting ${batch.filename}…`;
        renderStatementImportView(container, ctx);

        try {
          const out = await services.statementNormalisation.extractAndStageBatch({
            batchId: batch.id,
            arrayBuffer,
            password,
            onProgress: (p) => {
              stmtViewState.progressMsg = `${batch.filename}: ${p.message}`;
            },
          });
          if (out.stagedRows.length > 0 && services.statementCategorisation) {
            await services.statementCategorisation.categoriseBatch(batch.id);
              if (services.statementReconciliation) await services.statementReconciliation.reconcileBatch(batch.id);
          }
          totalExtracted += out.stagedRows.length;
          stmtViewState.activeBatchId = batch.id;
          stmtViewState.stagedPageLimit = 50;
          if (batch.file_ext !== 'pdf') {
            stmtViewState.activeExtractedCache.set(batch.id, { arrayBuffer, extracted: out.extracted });
          }
        } catch (extErr) {
          showToast(`${batch.filename}: ${extErr.message}`, { type: 'error' });
        } finally {
          password = '';
          if (draft) stmtViewState.pendingFiles.delete(draft.draftId);
        }
      }

      stmtViewState.drafts = [];
      stmtViewState.pendingFiles.clear();
      showToast(`Extracted ${totalExtracted} transaction${totalExtracted === 1 ? '' : 's'} across ${res.created.length} batch${res.created.length === 1 ? '' : 'es'}`);
    } catch (err) {
      showToast(err.message || 'Could not process statements', { type: 'error' });
    } finally {
      stmtViewState.busy = false;
      stmtViewState.progressMsg = '';
      renderStatementImportView(container, ctx);
    }
  });

  container.querySelector('#btn-extract-img-text')?.addEventListener('click', async () => {
    if (!activeBatch) return;
    const rawText = container.querySelector('#stmt-img-ocr-text')?.value || '';
    if (!rawText.trim()) {
      showToast('Paste screenshot text first.', { type: 'error' });
      return;
    }
    const cache = stmtViewState.activeExtractedCache.get(activeBatch.id);
    const imgInputs = cache?.imageInputs?.length
      ? cache.imageInputs
      : [{ filename: activeBatch.filename, mimeType: activeBatch.mime_type || 'image/png', arrayBuffer: new ArrayBuffer(0) }];
    try {
      const res = await services.statementNormalisation.extractAndStageUpiScreenshotBatch({
        batchId: activeBatch.id,
        imageInputs: [imgInputs[0]],
        manualOcrTexts: [rawText],
      });
      if (res.stagedRows.length > 0 && services.statementCategorisation) {
        await services.statementCategorisation.categoriseBatch(activeBatch.id);
        if (services.statementReconciliation) await services.statementReconciliation.reconcileBatch(activeBatch.id);
      }
      showToast(`Parsed & categorised ${res.stagedRows.length} UPI transaction${res.stagedRows.length === 1 ? '' : 's'}`);
      renderStatementImportView(container, ctx);
    } catch (err) {
      showToast(err.message || 'Could not parse screenshot text', { type: 'error' });
    }
  });

  container.querySelector('#btn-close-summary')?.addEventListener('click', () => {
    if (stmtViewState.activeBatchId) {
      const c = stmtViewState.activeExtractedCache.get(stmtViewState.activeBatchId);
      if (c?.previewUrl && typeof URL !== 'undefined' && URL.revokeObjectURL) URL.revokeObjectURL(c.previewUrl);
      stmtViewState.activeExtractedCache.delete(stmtViewState.activeBatchId);
    }
    stmtViewState.activeBatchId = null;
    renderStatementImportView(container, ctx);
  });

  container.querySelector('#btn-load-more-staged')?.addEventListener('click', () => {
    stmtViewState.stagedPageLimit += 50;
    renderStatementImportView(container, ctx);
  });

  container.querySelector('#btn-rerun-reconcile')?.addEventListener('click', async () => {
    if (!activeBatch || !services.statementReconciliation) return;
    const res = await services.statementReconciliation.reconcileBatch(activeBatch.id);
    const dupTotal = res.summary.exactDuplicates + res.summary.probableDuplicates + res.summary.crossScreenshotDuplicates;
    showToast(`Reconciled: ${dupTotal} duplicate${dupTotal === 1 ? '' : 's'}, ${res.summary.internalTransfers + res.summary.ccSettlements} transfer/CC match(es)`);
    renderStatementImportView(container, ctx);
  });

  container.querySelectorAll('[data-compare-match]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const matchId = btn.getAttribute('data-compare-match');
      const match = activeMatches.find((m) => m.id === matchId);
      if (!match) return;
      const staged = activeStaged.find((r) => r.id === match.staged_tx_id);
      if (!staged) return;
      const matchedLedger = match.matched_tx_id ? await ctx.db.table('transactions').get(match.matched_tx_id) : null;
      const matchedStaged = match.matched_staged_tx_id ? await ctx.db.table('staged_transactions').get(match.matched_staged_tx_id) : null;
      const other = matchedLedger || matchedStaged;

      openModal({
        title: `Compare Match · ${String(match.match_type || '').replace(/_/g, ' ')}`,
        bodyHtml: `
          <div class="stack" style="gap:10px;">
            <div class="badge badge-muted" style="align-self:flex-start;">
              Match Confidence: ${Math.round((Number(match.confidence_score) || 0) * 100)}%
            </div>
            <div class="item-meta">${(match.match_reasons || []).map((r) => `• ${escapeHtml(r)}`).join('<br>')}</div>
            <div class="grid-2" style="gap:8px;">
              <div class="card" style="padding:10px; background:var(--bg-surface-elevated);">
                <div class="item-meta" style="font-weight:600;">New Staged Row</div>
                <div class="item-title" style="margin-top:4px;">${escapeHtml(staged.merchant || staged.description)}</div>
                <div class="item-meta">${escapeHtml(staged.date_key || '—')} · ${formatINR(staged.amount_paise)}</div>
                <div class="item-meta" style="font-size:0.72rem; margin-top:4px; overflow-wrap:anywhere;">${escapeHtml(staged.raw_narration)}</div>
              </div>
              <div class="card" style="padding:10px; background:var(--bg-surface-elevated);">
                <div class="item-meta" style="font-weight:600;">${matchedLedger ? 'Existing Ledger Txn' : 'Earlier Staged Row'}</div>
                ${
                  other
                    ? `<div class="item-title" style="margin-top:4px;">${escapeHtml(other.merchant || other.description || '—')}</div>
                       <div class="item-meta">${escapeHtml(other.date_key || '—')} · ${formatINR(other.amount_paise || 0)}</div>
                       <div class="item-meta" style="font-size:0.72rem; margin-top:4px; overflow-wrap:anywhere;">${escapeHtml(other.raw_narration || other.notes || other.description || '')}</div>`
                    : `<div class="item-meta" style="margin-top:4px;">Pattern match (${escapeHtml(match.match_type)})</div>`
                }
              </div>
            </div>
            <div class="modal-footer" style="gap:8px;">
              <button type="button" class="btn btn-secondary" id="btn-reject-match" style="flex:1;">Not a Duplicate (Keep)</button>
              <button type="button" class="btn btn-danger" id="btn-confirm-match" style="flex:1;">Confirm Duplicate (Exclude)</button>
            </div>
          </div>
        `,
        onMount: (panel, close) => {
          panel.querySelector('#btn-reject-match')?.addEventListener('click', async () => {
            await services.statementReconciliation.resolveMatch(match.id, 'rejected');
            showToast('Match rejected — row kept for review');
            close();
            renderStatementImportView(container, ctx);
          });
          panel.querySelector('#btn-confirm-match')?.addEventListener('click', async () => {
            await services.statementReconciliation.resolveMatch(match.id, 'confirmed');
            showToast('Duplicate confirmed — row excluded');
            close();
            renderStatementImportView(container, ctx);
          });
        },
      });
    });
  });

  container.querySelector('#btn-rerun-categorise')?.addEventListener('click', async () => {
    if (!activeBatch || !services.statementCategorisation) return;
    const res = await services.statementCategorisation.categoriseBatch(activeBatch.id);
        if (services.statementReconciliation) await services.statementReconciliation.reconcileBatch(activeBatch.id);
    showToast(`Categorised ${res.totalCategorised} rows (${res.highConfidenceCount} high-confidence)`);
    renderStatementImportView(container, ctx);
  });

  // Review filter tabs & search
  container.querySelectorAll('[data-review-filter]').forEach((chip) => {
    chip.addEventListener('click', () => {
      stmtViewState.reviewFilter = chip.getAttribute('data-review-filter') || 'all';
      stmtViewState.stagedPageLimit = 50;
      renderStatementImportView(container, ctx);
    });
  });

  container.querySelector('#stmt-review-search')?.addEventListener('change', (e) => {
    stmtViewState.reviewSearch = e.target.value || '';
    renderStatementImportView(container, ctx);
  });

  container.querySelector('#btn-approve-all-ready')?.addEventListener('click', async () => {
    if (!activeBatch || !services.statementReview) return;
    const res = await services.statementReview.approveAllReady(activeBatch.id);
    showToast(`Approved ${res.approvedCount} ready transaction${res.approvedCount === 1 ? '' : 's'}`);
    renderStatementImportView(container, ctx);
  });

  const runCommit = async (includeFailedRetry = false) => {
    if (!activeBatch || !services.statementCommit) return;
    try {
      const res = await services.statementCommit.commitApprovedBatch(activeBatch.id, { includeFailedRetry });
      const msg =
        res.failedCount > 0
          ? `Imported ${res.importedCount} to ledger · ${res.failedCount} failed (edit & retry)`
          : `Imported ${res.importedCount} transaction${res.importedCount === 1 ? '' : 's'} into VittaMitra ledger`;
      showToast(msg, { type: res.failedCount > 0 ? 'error' : 'info' });
      renderStatementImportView(container, ctx);
    } catch (err) {
      showToast(err.message || 'Commit failed', { type: 'error' });
    }
  };

  container.querySelector('#btn-commit-approved')?.addEventListener('click', () => runCommit(false));
  container.querySelector('#btn-retry-failed')?.addEventListener('click', () => runCommit(true));

  container.querySelector('#btn-rollback-stmt-batch')?.addEventListener('click', async () => {
    if (!activeBatch || !services.statementCommit) return;
    try {
      const rb = await services.statementCommit.rollbackStatementBatch(activeBatch.id);
      showToast(`Rolled back ${rb.rolledBackCount || 0} ledger transaction(s)`);
      renderStatementImportView(container, ctx);
    } catch (err) {
      showToast(err.message || 'Rollback failed', { type: 'error' });
    }
  });

  // Selection checkboxes
  container.querySelector('#chk-select-all-visible')?.addEventListener('change', (e) => {
    const visibleIds = filterStagedRows(activeStaged, {
      filter: stmtViewState.reviewFilter,
      search: stmtViewState.reviewSearch,
    })
      .slice(0, stmtViewState.stagedPageLimit)
      .map((r) => r.id);
    if (e.target.checked) visibleIds.forEach((id) => stmtViewState.selectedRowIds.add(id));
    else visibleIds.forEach((id) => stmtViewState.selectedRowIds.delete(id));
    renderStatementImportView(container, ctx);
  });

  container.querySelectorAll('[data-select-staged]').forEach((chk) => {
    chk.addEventListener('change', (e) => {
      const id = chk.getAttribute('data-select-staged');
      if (e.target.checked) stmtViewState.selectedRowIds.add(id);
      else stmtViewState.selectedRowIds.delete(id);
      renderStatementImportView(container, ctx);
    });
  });

  // Bulk actions
  const getSelectedIds = () => [...stmtViewState.selectedRowIds].filter((id) => activeStaged.some((r) => r.id === id));

  container.querySelector('#btn-bulk-clear')?.addEventListener('click', () => {
    stmtViewState.selectedRowIds.clear();
    renderStatementImportView(container, ctx);
  });

  container.querySelector('#btn-bulk-approve')?.addEventListener('click', async () => {
    const res = await services.statementReview.bulkSetStatus(getSelectedIds(), 'approved');
    stmtViewState.selectedRowIds.clear();
    showToast(`Approved ${res.updatedCount} row${res.updatedCount === 1 ? '' : 's'}${res.skipped.length ? ` (${res.skipped.length} skipped)` : ''}`);
    renderStatementImportView(container, ctx);
  });

  container.querySelector('#btn-bulk-exclude')?.addEventListener('click', async () => {
    const res = await services.statementReview.bulkSetStatus(getSelectedIds(), 'excluded');
    stmtViewState.selectedRowIds.clear();
    showToast(`Excluded ${res.updatedCount} row${res.updatedCount === 1 ? '' : 's'}`);
    renderStatementImportView(container, ctx);
  });

  container.querySelector('#btn-bulk-categorise')?.addEventListener('click', () => {
    const ids = getSelectedIds();
    if (ids.length === 0) return;
    openModal({
      title: `Bulk Categorise (${ids.length} rows)`,
      bodyHtml: `
        <form id="bulk-cat-form" class="stack" style="gap:10px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Category / Subcategory</label>
            <select name="category_id" class="form-control" required>
              <option value="">-- Select Category --</option>
              ${categories
                .map((c) => `<option value="${c.id}">${c.parent_id ? '↳ ' : ''}${escapeHtml(c.name)} (${escapeHtml(c.type)})</option>`)
                .join('')}
            </select>
          </div>
          <label style="display:flex; align-items:center; gap:8px; font-size:0.84rem; cursor:pointer;">
            <input type="checkbox" name="learn_rules">
            <span>Also learn personal merchant rules for these rows</span>
          </label>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Apply to ${ids.length} Rows</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#bulk-cat-form')?.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const chosenId = fd.get('category_id');
          const obj = catMap.get(chosenId);
          const catId = obj?.parent_id ? obj.parent_id : chosenId;
          const subId = obj?.parent_id ? obj.id : null;
          const res = await services.statementReview.bulkUpdateCategory(ids, {
            categoryId: catId,
            subcategoryId: subId,
            learnRules: Boolean(fd.get('learn_rules')),
          });
          stmtViewState.selectedRowIds.clear();
          showToast(`Updated category on ${res.updatedCount} rows`);
          close();
          renderStatementImportView(container, ctx);
        });
      },
    });
  });

  container.querySelector('#btn-bulk-account')?.addEventListener('click', () => {
    const ids = getSelectedIds();
    if (ids.length === 0) return;
    openModal({
      title: `Bulk Assign Account (${ids.length} rows)`,
      bodyHtml: `
        <form id="bulk-acc-form" class="stack" style="gap:10px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Target Account</label>
            <select name="account_id" class="form-control" required>
              <option value="">-- Select Account --</option>
              ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('')}
            </select>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Assign to ${ids.length} Rows</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#bulk-acc-form')?.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const res = await services.statementReview.bulkAssignAccount(ids, fd.get('account_id'));
          stmtViewState.selectedRowIds.clear();
          showToast(`Assigned account on ${res.updatedCount} rows`);
          close();
          renderStatementImportView(container, ctx);
        });
      },
    });
  });

  // Per-row quick approve / exclude / restore
  container.querySelectorAll('[data-row-status]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const [id, nextStatus] = btn.getAttribute('data-row-status').split(':');
      try {
        await services.statementReview.setStagedStatus(id, nextStatus);
        showToast(`Row marked as ${nextStatus}`);
        renderStatementImportView(container, ctx);
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });
  });

  // Full transaction-level edit modal (Date, Description, Account, Type, Category/Subcategory, Split Transaction, Learn)
  container.querySelectorAll('[data-edit-cat-staged]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const staged = activeStaged.find((r) => r.id === btn.getAttribute('data-edit-cat-staged'));
      if (!staged) return;
      const existingSplits = staged.splits_json
        ? (() => { try { return JSON.parse(staged.splits_json); } catch { return []; } })()
        : [];
      const catOptionsHtml = (selectedId) =>
        `<option value="">-- Uncategorized --</option>` +
        categories
          .map((c) => `<option value="${c.id}" ${selectedId === c.id ? 'selected' : ''}>${c.parent_id ? '↳ ' : ''}${escapeHtml(c.name)} (${escapeHtml(c.type)})</option>`)
          .join('');

      openModal({
        title: 'Edit Staged Transaction',
        bodyHtml: `
          <form id="staged-full-edit-form" class="stack" style="gap:10px;">
            <div class="item-meta" style="font-size:0.74rem; padding:8px; border-radius:var(--radius-sm); background:var(--bg-surface-elevated); overflow-wrap:anywhere;">
              <strong>Original Narration (preserved):</strong><br>${escapeHtml(staged.raw_narration)}
            </div>
            <div class="grid-2" style="gap:8px;">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Date</label>
                <input name="date_key" type="date" class="form-control" required value="${escapeHtml(staged.date_key || '')}">
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Transaction Type</label>
                <select name="tx_type" id="edit-staged-type" class="form-control">
                  <option value="expense" ${staged.tx_type === 'expense' ? 'selected' : ''}>Expense</option>
                  <option value="income" ${staged.tx_type === 'income' ? 'selected' : ''}>Income</option>
                  <option value="transfer" ${staged.tx_type === 'transfer' ? 'selected' : ''}>Transfer / Settlement</option>
                </select>
              </div>
            </div>
            <div class="grid-2" style="gap:8px;">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Amount (₹)</label>
                <input name="amount_rupees" id="edit-staged-amount" class="form-control" inputmode="decimal" required placeholder="0.00" value="${escapeHtml(staged.amount_paise ? paiseToDecimalString(staged.amount_paise) : '')}">
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Description / Merchant</label>
                <input name="description" class="form-control" required maxlength="100" value="${escapeHtml(staged.description || staged.merchant || '')}">
              </div>
            </div>
            <div class="grid-2" style="gap:8px;">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Account</label>
                <select name="account_id" class="form-control" required>
                  <option value="">-- Select Account --</option>
                  ${accounts.map((a) => `<option value="${a.id}" ${staged.account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
                </select>
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">To Account (Transfers)</label>
                <select name="to_account_id" class="form-control">
                  <option value="">— None —</option>
                  ${accounts.map((a) => `<option value="${a.id}" ${staged.to_account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
                </select>
              </div>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Category / Subcategory</label>
              <select name="category_id" class="form-control">${catOptionsHtml(staged.subcategory_id || staged.category_id)}</select>
            </div>
            <div class="card stack" style="gap:8px; padding:10px; background:var(--bg-surface-elevated);">
              <div class="toolbar">
                <span class="item-title" id="edit-staged-split-total" style="font-size:0.82rem;">Split Transaction (Total: ${formatINR(staged.amount_paise)})</span>
                <button type="button" class="btn btn-secondary btn-sm" id="btn-add-split-leg">+ Add Split</button>
              </div>
              <div id="staged-splits-slot" class="stack" style="gap:6px;"></div>
            </div>
            <label style="display:flex; align-items:center; gap:8px; font-size:0.84rem; cursor:pointer;">
              <input type="checkbox" name="save_rule" checked>
              <span>Remember category correction as a personal rule</span>
            </label>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" style="flex:1;">Save Changes</button>
            </div>
          </form>
        `,
        onMount: (panel, close) => {
          const splitsSlot = panel.querySelector('#staged-splits-slot');
          const addSplitRow = (leg = { category_id: '', amount_paise: 0, note: '' }) => {
            const div = document.createElement('div');
            div.className = 'split-leg-row';
            div.style.cssText = 'display:flex; gap:6px; align-items:center;';
            div.innerHTML = `
              <select class="form-control split-cat" style="flex:1;">${catOptionsHtml(leg.category_id)}</select>
              <input class="form-control split-amt" style="width:100px;" inputmode="decimal" placeholder="₹" value="${leg.amount_paise ? paiseToDecimalString(leg.amount_paise) : ''}">
              <button type="button" class="icon-btn split-rm" aria-label="Remove split">✕</button>
            `;
            div.querySelector('.split-rm').addEventListener('click', () => div.remove());
            splitsSlot.appendChild(div);
          };
          existingSplits.forEach(addSplitRow);
          panel.querySelector('#btn-add-split-leg')?.addEventListener('click', () => addSplitRow());
          const amtInput = panel.querySelector('#edit-staged-amount');
          const splitTotalEl = panel.querySelector('#edit-staged-split-total');
          amtInput?.addEventListener('input', () => {
            try {
              const p = parseRupeesToPaise(amtInput.value || '0', { allowZero: true, allowNegative: false });
              if (splitTotalEl) splitTotalEl.textContent = `Split Transaction (Total: ${formatINR(p)})`;
            } catch {
              // ignore intermediate typing
            }
          });

          panel.querySelector('#staged-full-edit-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            const chosenId = fd.get('category_id') || null;
            const chosenObj = chosenId ? catMap.get(chosenId) : null;
            const catId = chosenObj?.parent_id ? chosenObj.parent_id : chosenId;
            const subId = chosenObj?.parent_id ? chosenObj.id : null;

            const splitRows = Array.from(splitsSlot.querySelectorAll('.split-leg-row'));
            const splits = [];
            try {
              for (const rowEl of splitRows) {
                const cId = rowEl.querySelector('.split-cat')?.value;
                const amtStr = rowEl.querySelector('.split-amt')?.value;
                if (!cId && !amtStr) continue;
                splits.push({
                  category_id: cId,
                  amount_paise: parseRupeesToPaise(amtStr || '0', { allowZero: false, allowNegative: false }),
                });
              }
              const nextAmountPaise = parseRupeesToPaise(String(fd.get('amount_rupees') || '').trim(), {
                allowZero: false,
                allowNegative: false,
              });
              await services.statementReview.updateStagedTransaction(
                staged.id,
                {
                  amount_paise: nextAmountPaise,
                  date_key: fd.get('date_key'),
                  tx_type: fd.get('tx_type'),
                  description: fd.get('description'),
                  account_id: fd.get('account_id'),
                  to_account_id: fd.get('to_account_id') || null,
                  category_id: catId,
                  subcategory_id: subId,
                  splits,
                },
                { learnRule: Boolean(fd.get('save_rule')), ruleType: 'exact_merchant' }
              );
              showToast('Staged transaction updated');
              close();
              renderStatementImportView(container, ctx);
            } catch (err) {
              showToast(err.message, { type: 'error' });
            }
          });
        },
      });
    });
  });

  container.querySelectorAll('[data-history-filter]').forEach((chip) => {
    chip.addEventListener('click', () => {
      stmtViewState.historyFilter = chip.getAttribute('data-history-filter') || 'all';
      renderStatementImportView(container, ctx);
    });
  });

  container.querySelectorAll('[data-rollback-history-batch]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-rollback-history-batch');
      try {
        const rb = await services.statementCommit.rollbackStatementBatch(id);
        showToast(`Rolled back ${rb.rolledBackCount || 0} ledger transaction(s)`);
        renderStatementImportView(container, ctx);
      } catch (err) {
        showToast(err.message || 'Rollback failed', { type: 'error' });
      }
    });
  });

  container.querySelectorAll('[data-view-batch]').forEach((btn) => {
    btn.addEventListener('click', () => {
      stmtViewState.activeBatchId = btn.getAttribute('data-view-batch');
      stmtViewState.stagedPageLimit = 50;
      renderStatementImportView(container, ctx);
    });
  });

  container.querySelectorAll('[data-edit-batch]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const batch = await repos.statementImport.getBatchById(btn.getAttribute('data-edit-batch'));
      if (!batch) return;
      openModal({
        title: 'Edit Statement Batch Metadata',
        bodyHtml: `
          <form id="edit-stmt-batch-form" class="stack" style="gap:10px;">
            <div class="item-meta">${escapeHtml(batch.filename)}</div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Confirmed Account</label>
              <select name="account_id" class="form-control" required>
                <option value="">-- Select Account --</option>
                ${accounts
                  .map((a) => `<option value="${a.id}" ${batch.account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`)
                  .join('')}
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Institution</label>
              <input name="institution" class="form-control" maxlength="60" value="${escapeHtml(batch.institution || '')}">
            </div>
            <div class="grid-2" style="gap:10px;">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Period Start</label>
                <input name="period_start" type="date" class="form-control" value="${escapeHtml(batch.period_start || '')}">
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Period End</label>
                <input name="period_end" type="date" class="form-control" value="${escapeHtml(batch.period_end || '')}">
              </div>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Masked Account Ref</label>
              <input name="masked_account_ref" class="form-control" maxlength="16" value="${escapeHtml(batch.masked_account_ref || '')}" placeholder="XXXX1234">
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" style="flex:1;">Save Metadata</button>
            </div>
          </form>
        `,
        onMount: (panel, close) => {
          panel.querySelector('#edit-stmt-batch-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const fd = new FormData(e.target);
            try {
              await repos.statementImport.updateStatementBatchMetadata(batch.id, {
                account_id: fd.get('account_id'),
                account_confirmed: true,
                institution: fd.get('institution'),
                period_start: fd.get('period_start'),
                period_end: fd.get('period_end'),
                masked_account_ref: fd.get('masked_account_ref'),
              });
              showToast('Batch metadata updated');
              close();
              renderStatementImportView(container, ctx);
            } catch (err) {
              showToast(err.message, { type: 'error' });
            }
          });
        },
      });
    });
  });

  container.querySelectorAll('[data-del-batch]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        const id = btn.getAttribute('data-del-batch');
        await repos.statementImport.softDeleteStatementBatch(id);
        stmtViewState.activeExtractedCache.delete(id);
        if (stmtViewState.activeBatchId === id) stmtViewState.activeBatchId = null;
        showToast('Statement batch deleted');
        renderStatementImportView(container, ctx);
      } catch (err) {
        showToast(err.message, { type: 'error' });
      }
    });
  });
  if (prevScrollY > 0 && typeof window !== 'undefined') {
    requestAnimationFrame(() => window.scrollTo(0, prevScrollY));
  }
}

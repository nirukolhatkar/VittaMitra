import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { getCategoryColor } from '../../utils/colors.js';
import { formatRelativeDate, getMonthLabel, shiftMonth } from '../../utils/date.js';
import { showToast } from '../components/toast.js';
import { bindTransactionLongPress, setPageContext } from '../../services/txContextClipboard.js';

const tagDetailState = {
  period: 'all', // 'week' | 'month' | 'year' | 'all'
  weekOffset: 0,
  catTab: 'expense',
  modeTab: 'expense',
};

function toDateKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export async function renderTagDetailView(container, ctx) {
  const { repos, services, state } = ctx;
  const tagId = state.selectedTagId;
  if (!tagId) {
    window.location.hash = '#/tags';
    return;
  }

  const [tag, settings, allTags, categories, accounts] = await Promise.all([
    repos.tags.getById(tagId),
    repos.settings.getSettings(),
    repos.tags.list({ includeArchived: true }),
    repos.categories.list({ includeArchived: true }),
    repos.accounts.list({ includeArchived: true }),
  ]);

  if (!tag) {
    window.location.hash = '#/tags';
    return;
  }

  const titleEl = document.getElementById('topbar-title');
  if (titleEl) titleEl.textContent = formatTagDisplay(tag);
  const tagDisplay = formatTagDisplay(tag);
  setPageContext(ctx, {
    route: 'tag-detail',
    label: tagDisplay,
    shortLabel: tagDisplay.slice(0, 14),
    tagName: tagDisplay,
    overrides: { add_tag_id: tag.id },
    onPasteRefresh: () => renderTagDetailView(container, ctx),
  });

  const now = new Date();
  const weekStartDay = Number(settings.week_start_day ?? 1);
  let filterOpts = { tagIds: [tag.id], tagMode: 'any' };
  let periodSubtitle = 'All Time';

  if (tagDetailState.period === 'year') {
    filterOpts.years = [String(state.selectedYear)];
    periodSubtitle = String(state.selectedYear);
  } else if (tagDetailState.period === 'month') {
    filterOpts.monthYear = { year: state.selectedYear, month: state.selectedMonth };
    periodSubtitle = getMonthLabel(state.selectedYear, state.selectedMonth);
  } else if (tagDetailState.period === 'week') {
    const ref = new Date(now.getFullYear(), now.getMonth(), now.getDate() + tagDetailState.weekOffset * 7);
    const diff = (ref.getDay() - weekStartDay + 7) % 7;
    const start = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate() - diff);
    const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 6);
    filterOpts.startDate = toDateKey(start);
    filterOpts.endDate = toDateKey(end);
    periodSubtitle = `${filterOpts.startDate} to ${filterOpts.endDate}`;
  }

  const txs = await services.transactions.listTransactions(filterOpts);
  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');

  const catMap = new Map(categories.map((c) => [c.id, c]));
  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const tagMap = new Map(allTags.map((t) => [t.id, t]));

  let spending = 0;
  let income = 0;
  let spendCount = 0;
  let incCount = 0;
  const monthsSeen = new Set();
  const catTotals = { expense: new Map(), income: new Map() };
  const modeTotals = { expense: new Map(), income: new Map(), transfer: new Map() };
  const coTags = new Map();

  for (const tx of txs) {
    if (tx.date_key) monthsSeen.add(tx.date_key.slice(0, 7));
    if (tx.type === 'expense') {
      spending += tx.amount_paise;
      spendCount += 1;
      if (tx.category_id) {
        catTotals.expense.set(tx.category_id, (catTotals.expense.get(tx.category_id) || 0) + tx.amount_paise);
      }
      modeTotals.expense.set(tx.account_id, (modeTotals.expense.get(tx.account_id) || 0) + tx.amount_paise);
    } else if (tx.type === 'income') {
      income += tx.amount_paise;
      incCount += 1;
      if (tx.category_id) {
        catTotals.income.set(tx.category_id, (catTotals.income.get(tx.category_id) || 0) + tx.amount_paise);
      }
      modeTotals.income.set(tx.account_id, (modeTotals.income.get(tx.account_id) || 0) + tx.amount_paise);
    } else if (tx.type === 'transfer') {
      const pairKey = `${tx.account_id}->${tx.to_account_id}`;
      modeTotals.transfer.set(pairKey, (modeTotals.transfer.get(pairKey) || 0) + tx.amount_paise);
    }

    for (const tid of tx.tag_ids || []) {
      if (tid !== tag.id) coTags.set(tid, (coTags.get(tid) || 0) + 1);
    }
  }

  const netBalance = income - spending;
  const activeMonths = Math.max(1, monthsSeen.size);
  const avgSpendMonth = Math.round(spending / activeMonths);
  const avgSpendTx = spendCount > 0 ? Math.round(spending / spendCount) : 0;
  const avgIncMonth = Math.round(income / activeMonths);
  const avgIncTx = incCount > 0 ? Math.round(income / incCount) : 0;

  const activeCatRows = Array.from(catTotals[tagDetailState.catTab].entries())
    .map(([id, total]) => ({ cat: catMap.get(id), total }))
    .sort((a, b) => b.total - a.total);
  const activeCatSum = tagDetailState.catTab === 'expense' ? spending : income;

  const activeModeRows =
    tagDetailState.modeTab === 'transfer'
      ? Array.from(modeTotals.transfer.entries())
          .map(([pair, total]) => {
            const [srcId, dstId] = pair.split('->');
            return {
              label: `${accMap.get(srcId)?.name || 'Account'} → ${accMap.get(dstId)?.name || 'Account'}`,
              total,
            };
          })
          .sort((a, b) => b.total - a.total)
      : Array.from(modeTotals[tagDetailState.modeTab].entries())
          .map(([id, total]) => ({
            label: `${accMap.get(id)?.icon || '🏛️'} ${accMap.get(id)?.name || 'Account'}`,
            total,
          }))
          .sort((a, b) => b.total - a.total);

  const coTagList = Array.from(coTags.entries())
    .map(([id, count]) => ({ tag: tagMap.get(id), count }))
    .filter((x) => x.tag)
    .sort((a, b) => b.count - a.count);

  const recentTxs = txs.slice(0, 10);

  container.innerHTML = `
    <div class="stack">
      <div class="segmented" style="width:100%; justify-content:space-between;">
        <button type="button" style="flex:1;" data-td-period="week" class="${tagDetailState.period === 'week' ? 'active' : ''}">Week</button>
        <button type="button" style="flex:1;" data-td-period="month" class="${tagDetailState.period === 'month' ? 'active' : ''}">Month</button>
        <button type="button" style="flex:1;" data-td-period="year" class="${tagDetailState.period === 'year' ? 'active' : ''}">Year</button>
        <button type="button" style="flex:1;" data-td-period="all" class="${tagDetailState.period === 'all' ? 'active' : ''}">All Time</button>
      </div>

      <div class="toolbar card" style="padding:10px 14px;">
        ${tagDetailState.period !== 'all' ? '<button type="button" class="icon-btn" id="td-prev" aria-label="Previous period">‹</button>' : '<div style="width:36px;"></div>'}
        <div style="text-align:center;">
          <div class="item-title">${escapeHtml(periodSubtitle)}</div>
          <div class="item-meta">${txs.length} TRANSACTION${txs.length === 1 ? '' : 'S'}</div>
        </div>
        ${tagDetailState.period !== 'all' ? '<button type="button" class="icon-btn" id="td-next" aria-label="Next period">›</button>' : '<div style="width:36px;"></div>'}
      </div>

      <section class="hero-card">
        <div class="hero-split">
          <div>
            <div class="hero-stat-label text-danger">Spending</div>
            <div class="hero-stat-value">${fmt(spending)}</div>
          </div>
          <div class="hero-split-right">
            <div class="hero-stat-label text-success">Income</div>
            <div class="hero-stat-value">${fmt(income)}</div>
          </div>
        </div>
        <div class="hero-footer-pill">
          <span class="text-muted">Net Balance</span>
          <strong class="${netBalance < 0 ? 'text-danger' : 'text-success'}">${fmt(netBalance)}</strong>
        </div>
      </section>

      <section class="stack" style="gap:8px;">
        <div class="section-heading">
          <span class="section-heading-left">Transactions</span>
          <span class="item-meta">${txs.length} total</span>
        </div>
        ${
          recentTxs.length === 0
            ? `<div class="empty-state"><div class="empty-state-title">No transactions for ${escapeHtml(formatTagDisplay(tag))} in ${escapeHtml(periodSubtitle)}</div></div>`
            : `<div class="grouped-card">
                ${recentTxs
                  .map((tx) => {
                    const cat = tx.category_id ? catMap.get(tx.category_id) : null;
                    const acc = accMap.get(tx.account_id);
                    const amtClass = tx.type === 'income' ? 'text-success' : tx.type === 'expense' ? 'text-danger' : 'text-muted';
                    return `
                      <div class="grouped-row">
                        <div class="list-row-main" style="flex:1; min-width:0; cursor:pointer;" data-td-edit="${tx.id}">
                          <span class="avatar-badge">${escapeHtml(tx.type === 'transfer' ? '⇄' : cat?.icon || '🧾')}</span>
                          <div style="min-width:0;">
                            <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(tx.description || cat?.name || tx.type)}</div>
                            <div class="item-meta">${escapeHtml(acc?.name || '')}</div>
                          </div>
                        </div>
                        <div class="tx-amt-col">
                          <strong class="${amtClass}" style="font-variant-numeric:tabular-nums;">${fmt(tx.amount_paise)}</strong>
                          <span class="tx-date-sub">${escapeHtml(formatRelativeDate(tx.date_key))}</span>
                        </div>
                      </div>`;
                  })
                  .join('')}
              </div>`
        }
      </section>

      <section class="card stack" style="gap:12px;">
        <div class="toolbar">
          <span class="card-title">Categories</span>
          <div class="segmented">
            <button type="button" data-td-cat="expense" class="${tagDetailState.catTab === 'expense' ? 'active' : ''}">Spending</button>
            <button type="button" data-td-cat="income" class="${tagDetailState.catTab === 'income' ? 'active' : ''}">Income</button>
          </div>
        </div>
        ${
          activeCatRows.length === 0
            ? `<div class="item-meta">No ${tagDetailState.catTab} transactions in this period.</div>`
            : activeCatRows
                .map((row) => {
                  const pct = activeCatSum > 0 ? Math.round((row.total / activeCatSum) * 100) : 0;
                  const color = getCategoryColor(row.cat);
                  return `
                    <div class="grouped-row-clickable" data-td-open-cat="${escapeHtml(row.cat?.id || '')}" style="padding:8px 6px; border-radius:10px;">
                      <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.86rem;">
                        <span>${escapeHtml(row.cat?.icon || '🏷️')} ${escapeHtml(row.cat?.name || 'Uncategorised')}</span>
                        <span style="display:inline-flex; align-items:center; gap:6px;">
                          <strong>${fmt(row.total)} <span class="item-meta">(${pct}%)</span></strong>
                          <span class="text-muted">›</span>
                        </span>
                      </div>
                      <div class="progress-track">
                        <div class="progress-fill" style="width:${pct}%; background:${escapeHtml(color)};"></div>
                      </div>
                    </div>`;
                })
                .join('')
        }
      </section>

      ${
        coTagList.length > 0
          ? `<section class="card stack" style="gap:10px;">
              <span class="card-title">Related Tags</span>
              <div class="chip-picker">
                ${coTagList
                  .map(
                    (item) => `
                    <button type="button" class="chip-btn" data-jump-tag="${item.tag.id}">
                      ${escapeHtml(formatTagDisplay(item.tag))} <span class="item-meta">(${item.count})</span>
                    </button>`
                  )
                  .join('')}
              </div>
            </section>`
          : ''
      }

      <section class="card stack" style="gap:12px;">
        <div class="toolbar">
          <span class="card-title">Payment Modes</span>
          <div class="segmented">
            <button type="button" data-td-mode="expense" class="${tagDetailState.modeTab === 'expense' ? 'active' : ''}">Spending</button>
            <button type="button" data-td-mode="income" class="${tagDetailState.modeTab === 'income' ? 'active' : ''}">Income</button>
            <button type="button" data-td-mode="transfer" class="${tagDetailState.modeTab === 'transfer' ? 'active' : ''}">Transfers</button>
          </div>
        </div>
        ${
          activeModeRows.length === 0
            ? `<div class="item-meta">No ${tagDetailState.modeTab} entries in this period.</div>`
            : `<div class="grouped-card">
                ${activeModeRows
                  .map(
                    (row) => `
                    <div class="grouped-row" style="padding:10px 12px;">
                      <span class="item-title" style="font-size:0.86rem;">${escapeHtml(row.label)}</span>
                      <strong style="font-variant-numeric:tabular-nums;">${fmt(row.total)}</strong>
                    </div>`
                  )
                  .join('')}
              </div>`
        }
      </section>

      <section class="card stack" style="gap:12px;">
        <span class="card-title">Stats</span>
        <div class="grid-2">
          <div>
            <div class="hero-stat-label text-danger">Avg Spending / Month</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(avgSpendMonth)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-danger">Avg Spending / Txn</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(avgSpendTx)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-success">Avg Income / Month</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(avgIncMonth)}</div>
          </div>
          <div>
            <div class="hero-stat-label text-success">Avg Income / Txn</div>
            <div class="item-title" style="font-size:1.05rem; margin-top:4px;">${fmt(avgIncTx)}</div>
          </div>
        </div>
      </section>
    </div>
  `;

  container.querySelectorAll('[data-td-period]').forEach((b) => {
    b.addEventListener('click', () => {
      tagDetailState.period = b.getAttribute('data-td-period');
      tagDetailState.weekOffset = 0;
      renderTagDetailView(container, ctx);
    });
  });

  container.querySelector('#td-prev')?.addEventListener('click', () => {
    if (tagDetailState.period === 'week') tagDetailState.weekOffset -= 1;
    else if (tagDetailState.period === 'year') state.selectedYear -= 1;
    else if (tagDetailState.period === 'month') {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, -1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
    }
    renderTagDetailView(container, ctx);
  });

  container.querySelector('#td-next')?.addEventListener('click', () => {
    if (tagDetailState.period === 'week') tagDetailState.weekOffset += 1;
    else if (tagDetailState.period === 'year') state.selectedYear += 1;
    else if (tagDetailState.period === 'month') {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, 1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
    }
    renderTagDetailView(container, ctx);
  });

  container.querySelectorAll('[data-td-cat]').forEach((b) => {
    b.addEventListener('click', () => {
      tagDetailState.catTab = b.getAttribute('data-td-cat');
      renderTagDetailView(container, ctx);
    });
  });

  container.querySelectorAll('[data-td-mode]').forEach((b) => {
    b.addEventListener('click', () => {
      tagDetailState.modeTab = b.getAttribute('data-td-mode');
      renderTagDetailView(container, ctx);
    });
  });

  container.querySelectorAll('[data-td-edit]').forEach((el) => {
    el.addEventListener('click', () => {
      state.txDraft = { editId: el.getAttribute('data-td-edit'), returnRoute: 'tag-detail' };
      window.location.hash = '#/add-transaction';
    });
  });

  container.querySelectorAll('[data-td-open-cat]').forEach((row) => {
    row.addEventListener('click', () => {
      const catId = row.getAttribute('data-td-open-cat');
      if (!catId) return;
      state.txListPreset = {
        mode: 'list',
        tagIds: [tag.id],
        tagMode: 'any',
        categoryIds: [catId],
        categoryMode: 'include',
        search: '',
      };
      if (typeof ctx.navigateTo === 'function') ctx.navigateTo('transactions');
      else window.location.hash = '#/transactions';
    });
  });

  bindTransactionLongPress(container, ctx, {
    selector: '[data-td-edit]',
    attr: 'data-td-edit',
    onRefresh: () => renderTagDetailView(container, ctx),
  });

  container.querySelectorAll('[data-jump-tag]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedTagId = btn.getAttribute('data-jump-tag');
      renderTagDetailView(container, ctx);
    });
  });
}

import { escapeHtml } from '../../utils/dom.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const tagsViewState = {
  search: '',
};

/**
 * Tags List View (inspired by screenshot 58249.jpg):
 * - Non-blurring Search tags bar
 * - Rounded cards showing #tag, live transaction count, and ⋮ action menu
 * - Tapping any tag card opens its full Tag Detail Analytics view
 */
export async function renderTagsView(container, ctx) {
  const { repos, services, state } = ctx;
  const [tags, allTxs] = await Promise.all([
    repos.tags.list({ includeArchived: true }),
    services.transactions.listTransactions(),
  ]);

  const countByTag = new Map();
  for (const tx of allTxs) {
    for (const tid of tx.tag_ids || []) {
      countByTag.set(tid, (countByTag.get(tid) || 0) + 1);
    }
  }

  container.innerHTML = `
    <div class="stack">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Tags</h2>
          <div class="compass-subtitle">Tap any tag to inspect analytics, add, or paste entries</div>
        </div>
      </div>
      <div class="search-bar-row">
        <input id="tag-search-input" type="search" class="search-input-pill"
          placeholder="🔍 Search tags…" value="${escapeHtml(tagsViewState.search)}">
        <button type="button" class="btn btn-primary btn-sm" id="btn-add-tag">+ Add</button>
      </div>
      <div id="tag-list-results" class="stack"></div>
    </div>
  `;

  const resultsEl = container.querySelector('#tag-list-results');

  const openTagForm = (existing = null) => {
    const isEdit = Boolean(existing);
    openModal({
      title: isEdit ? 'Edit Tag' : 'Add Tag',
      bodyHtml: `
        <form id="tag-form">
          <div class="form-group">
            <label class="form-label" for="tag-name">Tag Name</label>
            <input id="tag-name" name="name" class="form-control" required maxlength="40"
              value="${escapeHtml(existing ? formatTagDisplay(existing) : '')}" placeholder="e.g. #petrol or athani_home_construction">
            <div class="form-help">A leading "#" is optional when typing and will always display cleanly.</div>
          </div>
          <div class="form-group">
            <label class="form-label" for="tag-color">Colour</label>
            <input id="tag-color" name="color" type="color" class="form-control" style="height:42px; padding:4px;"
              value="${escapeHtml(existing?.color || '#38bdf8')}">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Create Tag'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        const form = panel.querySelector('#tag-form');
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          try {
            if (isEdit) {
              await repos.tags.updateTag(existing.id, { name: fd.get('name'), color: fd.get('color') });
              showToast('Tag updated');
            } else {
              await repos.tags.createTag({ name: fd.get('name'), color: fd.get('color') });
              showToast('Tag created');
            }
            close();
            renderTagsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openTagActions = (tag) => {
    openModal({
      title: formatTagDisplay(tag),
      bodyHtml: `
        <div class="stack" style="gap:10px;">
          <button type="button" class="btn btn-secondary" id="act-tag-analytics">📊 View Tag Analytics</button>
          <button type="button" class="btn btn-secondary" id="act-tag-edit">✏️ Rename / Change Colour</button>
          <button type="button" class="btn btn-danger" id="act-tag-delete">🗑 Delete Tag</button>
        </div>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#act-tag-analytics')?.addEventListener('click', () => {
          close();
          state.selectedTagId = tag.id;
          window.location.hash = '#/tag-detail';
        });
        panel.querySelector('#act-tag-edit')?.addEventListener('click', () => {
          close();
          openTagForm(tag);
        });
        panel.querySelector('#act-tag-delete')?.addEventListener('click', async () => {
          await repos.tags.softDelete(tag.id);
          close();
          renderTagsView(container, ctx);
          showToast(`Tag ${formatTagDisplay(tag)} deleted`, {
            actionLabel: 'Undo',
            onAction: async () => {
              await repos.tags.restore(tag.id);
              renderTagsView(container, ctx);
              showToast('Tag restored');
            },
          });
        });
      },
    });
  };

  const renderResultsOnly = () => {
    const q = tagsViewState.search.trim().toLowerCase();
    const filtered = q
      ? tags.filter((t) => t.name.toLowerCase().includes(q) || formatTagDisplay(t).toLowerCase().includes(q))
      : tags;

    if (filtered.length === 0) {
      resultsEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">#️⃣</div>
          <h3 class="empty-state-title">${tags.length === 0 ? 'No tags created yet' : 'No matching tags'}</h3>
          <p class="empty-state-text">
            Create tags like <strong>#petrol</strong>, <strong>#athani</strong>, or <strong>#home_construction</strong> to track spending across categories.
          </p>
          ${tags.length === 0 ? '<button type="button" class="btn btn-primary btn-sm" id="btn-empty-add-tag">+ Add First Tag</button>' : ''}
        </div>
      `;
      resultsEl.querySelector('#btn-empty-add-tag')?.addEventListener('click', () => openTagForm());
      return;
    }

    resultsEl.innerHTML = filtered
      .map((t) => {
        const cnt = countByTag.get(t.id) || 0;
        return `
          <div class="list-row list-row-clickable" data-open-tag="${t.id}">
            <div class="list-row-main" style="min-width:0;">
              <span style="font-size:1.25rem; font-weight:800; color:${escapeHtml(t.color || '#38bdf8')};">#</span>
              <div style="min-width:0;">
                <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                  ${escapeHtml(t.name)}
                  ${t.is_archived ? '<span class="badge badge-muted">Archived</span>' : ''}
                </div>
                <div class="item-meta">${cnt} transaction${cnt === 1 ? '' : 's'}</div>
              </div>
            </div>
            <button type="button" class="icon-btn" style="width:32px; height:32px;" data-tag-menu="${t.id}" aria-label="Tag options">⋮</button>
          </div>
        `;
      })
      .join('');

    resultsEl.querySelectorAll('[data-open-tag]').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('[data-tag-menu]')) return;
        state.selectedTagId = row.getAttribute('data-open-tag');
        window.location.hash = '#/tag-detail';
      });
    });

    resultsEl.querySelectorAll('[data-tag-menu]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const tag = tags.find((t) => t.id === btn.getAttribute('data-tag-menu'));
        if (tag) openTagActions(tag);
      });
    });
  };

  renderResultsOnly();

  container.querySelector('#tag-search-input')?.addEventListener('input', (e) => {
    tagsViewState.search = e.target.value;
    renderResultsOnly(); // Non-blurring search!
  });

  container.querySelector('#btn-add-tag')?.addEventListener('click', () => openTagForm());
}

/**
 * Uniform deterministic color palette for Categories across all charts, badges, and views.
 */

export const CATEGORY_PALETTE = Object.freeze([
  '#6366f1', // Indigo
  '#34d399', // Emerald
  '#f472b6', // Pink
  '#fbbf24', // Amber
  '#38bdf8', // Sky
  '#a78bfa', // Violet
  '#fb923c', // Orange
  '#2dd4bf', // Teal
  '#f87171', // Rose
  '#60a5fa', // Blue
  '#c084fc', // Purple
  '#4ade80', // Green
  '#facc15', // Yellow
  '#22d3ee', // Cyan
  '#fb7185', // Coral
  '#818cf8', // Periwinkle
]);

const GENERIC_COLORS = new Set(['', '#475569', '#64748b', '#0f766e', '#94a3b8']);

/**
 * Returns a consistent, vivid hex color for a category across Doughnut charts,
 * category lists, progress bars, and detail screens.
 */
export function getCategoryColor(category) {
  if (!category) return '#64748b';
  const raw = String(category.color || '').trim().toLowerCase();
  if (raw && !GENERIC_COLORS.has(raw)) {
    return category.color;
  }
  const key = String(category.name || category.id || 'cat').trim().toLowerCase();
  let hash = 0;
  for (let i = 0; i < key.length; i += 1) {
    hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  }
  return CATEGORY_PALETTE[hash % CATEGORY_PALETTE.length];
}

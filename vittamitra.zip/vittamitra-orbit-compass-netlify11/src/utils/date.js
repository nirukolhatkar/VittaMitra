/**
 * Date, local wall-clock timestamp, and Indian Financial Year utilities.
 *
 * Financial Year default: 1 April to 31 March (fyStartMonth = 4).
 * Week start default: Monday (1).
 */

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export function nowIsoUtc() {
  return new Date().toISOString();
}

/**
 * Format a Date object as local wall-clock string "YYYY-MM-DD HH:mm:ss"
 * without timezone shifting.
 */
export function toLocalDateTimeString(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  const ss = String(date.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${d} ${hh}:${mm}:${ss}`;
}

export function toLocalDateString(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getMonthLabel(year, monthIndex0) {
  return `${MONTH_NAMES[monthIndex0]} ${year}`;
}

export function shiftMonth(year, monthIndex0, delta) {
  const d = new Date(year, monthIndex0 + delta, 1);
  return { year: d.getFullYear(), month: d.getMonth() };
}

/**
 * Compute Financial Year label & boundaries for a given year + 0-indexed month.
 * Default fyStartMonth = 4 (April): e.g. Nov 2026 -> FY 2026-27 (2026-04-01 to 2027-03-31).
 */
export function getFinancialYearInfo(year, monthIndex0, fyStartMonth = 4) {
  const month1 = monthIndex0 + 1;
  const startYear = month1 >= fyStartMonth ? year : year - 1;
  const endYear = fyStartMonth === 1 ? startYear : startYear + 1;
  const endMonth = fyStartMonth === 1 ? 12 : fyStartMonth - 1;
  const endDay = new Date(endYear, endMonth, 0).getDate();

  const label =
    fyStartMonth === 1
      ? `FY ${startYear}`
      : `FY ${startYear}-${String(endYear).slice(-2)}`;

  return {
    label,
    startDate: `${startYear}-${String(fyStartMonth).padStart(2, '0')}-01`,
    endDate: `${endYear}-${String(endMonth).padStart(2, '0')}-${String(endDay).padStart(2, '0')}`,
    startYear,
    endYear,
  };
}


/**
 * Formats a YYYY-MM-DD date key into a clean relative label:
 * "Today", "Yesterday", or "DD Mon YYYY" (e.g., "31 Oct 2026").
 */
export function formatRelativeDate(dateKey, referenceDate = new Date()) {
  if (!dateKey || !/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return String(dateKey || '');
  const todayKey = toLocalDateString(referenceDate);
  if (dateKey === todayKey) return 'Today';

  const yest = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), referenceDate.getDate() - 1);
  if (dateKey === toLocalDateString(yest)) return 'Yesterday';

  const [y, m, d] = dateKey.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  const mon = dt.toLocaleDateString('en-IN', { month: 'short' });
  return `${String(d).padStart(2, '0')} ${mon} ${y}`;
}

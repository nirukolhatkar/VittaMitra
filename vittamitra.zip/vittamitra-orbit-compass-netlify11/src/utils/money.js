/**
 * Integer-paise monetary utilities and Indian number formatting (en-IN).
 *
 * All INR values are stored as exact integer paise (1 INR = 100 paise).
 * Decimal strings are parsed without IEEE-754 floating-point multiplication
 * to eliminate rounding drift (e.g., 137.44 -> 13744, 19.99 -> 1999).
 */

const INR_FORMATTER = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const NUMBER_IN_FORMATTER = new Intl.NumberFormat('en-IN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/**
 * Safely parse a numeric or string rupee value into exact integer paise.
 * Accepts: 137.44, "137.44", "1,25,000.50", "₹500", "-42.5"
 * Throws an Error if invalid or has more than 2 significant decimal places unless allowRound=true.
 */
export function parseRupeesToPaise(input, { allowNegative = false, allowRound = false } = {}) {
  if (input === null || input === undefined) {
    throw new Error('Amount is required');
  }

  let raw = typeof input === 'number' ? input.toString() : String(input);
  raw = raw.trim().replace(/[₹,\s]/g, '');

  if (raw === '' || raw === '-' || raw === '+') {
    throw new Error('Amount cannot be empty');
  }

  if (!/^[+-]?\d+(\.\d+)?$/.test(raw)) {
    throw new Error(`Invalid monetary amount: "${input}"`);
  }

  const isNegative = raw.startsWith('-');
  if (isNegative && !allowNegative) {
    throw new Error('Amount cannot be negative');
  }

  const unsigned = raw.replace(/^[+-]/, '');
  const [wholePart, fracPart = ''] = unsigned.split('.');

  if (!allowRound && fracPart.length > 2) {
    const extraDigits = fracPart.slice(2);
    if (!/^0+$/.test(extraDigits)) {
      throw new Error(`Amount "${input}" has more than 2 decimal places`);
    }
  }

  const wholePaise = Number(wholePart) * 100;
  let fracPaise;
  if (fracPart.length === 0) {
    fracPaise = 0;
  } else if (fracPart.length === 1) {
    fracPaise = Number(fracPart) * 10;
  } else if (fracPart.length === 2) {
    fracPaise = Number(fracPart);
  } else {
    const thirdDigit = Number(fracPart[2]);
    fracPaise = Number(fracPart.slice(0, 2)) + (thirdDigit >= 5 ? 1 : 0);
  }

  const total = wholePaise + fracPaise;
  if (!Number.isSafeInteger(total)) {
    throw new Error(`Amount "${input}" exceeds safe integer range`);
  }

  return isNegative && total !== 0 ? -total : total;
}

/**
 * Convert integer paise back to an exact decimal string (e.g., 13744 -> "137.44", 50000 -> "500").
 * Useful for inputs and exact Excel export without floating-point noise.
 */
export function paiseToDecimalString(paise, { fixedDecimals = false } = {}) {
  if (!Number.isSafeInteger(paise)) {
    throw new Error(`Expected integer paise, received: ${paise}`);
  }
  const sign = paise < 0 ? '-' : '';
  const abs = Math.abs(paise);
  const rupees = Math.floor(abs / 100);
  const rem = abs % 100;
  if (!fixedDecimals && rem === 0) {
    return `${sign}${rupees}`;
  }
  return `${sign}${rupees}.${String(rem).padStart(2, '0')}`;
}

/**
 * Convert integer paise to numeric rupees for chart/Excel numeric cell writing.
 */
export function paiseToNumber(paise) {
  if (!Number.isSafeInteger(paise)) {
    throw new Error(`Expected integer paise, received: ${paise}`);
  }
  return Number(paiseToDecimalString(paise, { fixedDecimals: true }));
}

/**
 * Format integer paise using Indian numbering system (e.g., 12500000 -> "₹1,25,000.00").
 */
export function formatINR(paise, { showSymbol = true, showSign = false } = {}) {
  if (!Number.isSafeInteger(paise)) {
    throw new Error(`Expected integer paise, received: ${paise}`);
  }
  const absValue = Math.abs(paise) / 100;
  const formatted = showSymbol
    ? INR_FORMATTER.format(absValue)
    : NUMBER_IN_FORMATTER.format(absValue);

  if (paise < 0) return `-${formatted}`;
  if (showSign && paise > 0) return `+${formatted}`;
  return formatted;
}

/**
 * Sum an array of integer paise safely.
 */
export function sumPaise(values) {
  let total = 0;
  for (const val of values) {
    if (!Number.isSafeInteger(val)) {
      throw new Error(`Expected integer paise in sum, received: ${val}`);
    }
    total += val;
  }
  return total;
}

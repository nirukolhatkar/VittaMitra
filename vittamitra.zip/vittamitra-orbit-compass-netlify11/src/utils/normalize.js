/**
 * Normalization helpers for Tags and Account names.
 *
 * Tags:
 *   - Every '#' starts a separate tag (e.g., "#petrol #gold" -> ["#petrol", "#gold"],
 *     "#athani, #petrol" -> ["#athani", "#petrol"], "#cheeku_bday 🎂 #petrol" -> ["#cheeku_bday 🎂", "#petrol"]).
 *   - Trim whitespace and strip leading '#' for internal canonical storage.
 *   - Deduplicate case-insensitively (`normalized_key`).
 *   - Display in UI and export to Excel with a '#' prefix (e.g., "#petrol").
 *
 * Account names:
 *   - Trim leading/trailing whitespace and report `wasTrimmed` for import preview warnings.
 */

export function normalizeTagInput(raw) {
  if (raw === null || raw === undefined) return null;
  const trimmed = String(raw).trim();
  const stripped = trimmed.replace(/^#+/, '').trim();
  if (!stripped) return null;
  return {
    name: stripped,
    normalized_key: stripped.toLowerCase(),
    display: `#${stripped}`,
  };
}

export function formatTagDisplay(tagOrName) {
  const raw = typeof tagOrName === 'string' ? tagOrName : tagOrName?.name || '';
  const norm = normalizeTagInput(raw);
  return norm ? norm.display : '';
}

/**
 * Parse a tag cell from Excel/CSV into deduplicated normalized tag objects preserving order.
 * Splits on commas/semicolons/newlines AND bifurcates on every '#' so that:
 *   - "#petrol #gold"         -> ["#petrol", "#gold"]
 *   - "#petrol#gold"          -> ["#petrol", "#gold"]
 *   - "#athani, #petrol"      -> ["#athani", "#petrol"]
 *   - "#cheeku_bday 🎂 #gold" -> ["#cheeku_bday 🎂", "#gold"]
 *   - "petrol, gold"          -> ["#petrol", "#gold"]
 */
export function parseTagList(cellValue) {
  if (!cellValue) return [];
  const raw = String(cellValue).trim();
  if (!raw) return [];

  // Split on commas, semicolons, newlines, OR right before any '#' symbol
  const parts = raw.split(/[,;\r\n]+|(?=#)/);
  const seen = new Set();
  const results = [];
  for (const part of parts) {
    const norm = normalizeTagInput(part);
    if (!norm || seen.has(norm.normalized_key)) continue;
    seen.add(norm.normalized_key);
    results.push(norm);
  }
  return results;
}

/**
 * Format an array of tag names/objects for Excel export (e.g., "#athani, #petrol").
 * Returns empty string (blank cell) when there are no tags.
 */
export function formatTagsForExport(tags) {
  if (!Array.isArray(tags) || tags.length === 0) return '';
  return tags
    .map((t) => formatTagDisplay(t))
    .filter(Boolean)
    .join(', ');
}

/**
 * Trim leading/trailing whitespace from an account name and flag if corrected.
 */
export function normalizeAccountName(raw) {
  const original = raw === null || raw === undefined ? '' : String(raw);
  const name = original.trim();
  return {
    name,
    normalized_key: name.toLowerCase(),
    original,
    wasTrimmed: original !== name,
  };
}

import { ACCOUNT_TYPES } from '../../constants/accountTypes.js';
import { BaseRepository } from './baseRepository.js';
import {
  ACCOUNT_CLASS,
  ACCOUNT_TYPE_ORDER,
  getAccountTypeMeta,
  isLiabilityAccount,
} from '../../constants/accountTypes.js';
import { normalizeAccountName } from '../../utils/normalize.js';
import { parseRupeesToPaise, sumPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';
import { computeReconciledAccountBalance } from '../../services/ledgerRules.js';

/**
 * Atomically apply net ledger posting balance deltas to affected accounts
 * inside an active readwrite transaction that already includes `'accounts'`.
 */
export async function applyAccountBalanceDeltasInTx(db, deltasByAccountId) {
  if (!deltasByAccountId || deltasByAccountId.size === 0) return;
  const accountsTbl = db.table('accounts');
  const postingsTbl = db.table('ledger_postings');

  for (const [accountId, deltaPaise] of deltasByAccountId.entries()) {
    if (!accountId || !deltaPaise) continue;
    const acc = await accountsTbl.get(accountId);
    if (!acc) continue;

    let nextBalance;
    if (Number.isSafeInteger(acc.cached_balance_paise)) {
      nextBalance = acc.cached_balance_paise + deltaPaise;
    } else {
      // Legacy account not yet backfilled: compute exact balance from ledger postings (which already include this tx's writes)
      let accPostings;
      if (typeof postingsTbl.where === 'function') {
        accPostings = await postingsTbl.where('account_id').equals(accountId).toArray();
      } else {
        accPostings = (await postingsTbl.toArray()).filter((p) => p.account_id === accountId);
      }
      let sum = acc.opening_balance_paise || 0;
      for (const p of accPostings) {
        if (!p.deleted_at) sum += p.balance_delta_paise || 0;
      }
      nextBalance = sum;
    }

    await accountsTbl.put({
      ...acc,
      cached_balance_paise: nextBalance,
    });
  }
}

/**
 * Helper to accumulate net balance_delta_paise per account_id from added (+1) and removed (-1) postings.
 */
export function buildAccountDeltaMap(addedPostings = [], removedPostings = []) {
  const deltas = new Map();
  for (const p of addedPostings) {
    if (!p || !p.account_id) continue;
    deltas.set(p.account_id, (deltas.get(p.account_id) || 0) + (p.balance_delta_paise || 0));
  }
  for (const p of removedPostings) {
    if (!p || !p.account_id) continue;
    deltas.set(p.account_id, (deltas.get(p.account_id) || 0) - (p.balance_delta_paise || 0));
  }
  return deltas;
}

/**
 * Single-pass O(P) full ledger reconciliation of `cached_balance_paise` for all accounts.
 * Used after bulk rollbacks, duplicate purges, clear-transactions, and backup restores.
 */
export async function reconcileAllAccountCachedBalances(db) {
  const [accounts, postings] = await Promise.all([
    db.table('accounts').toArray(),
    db.table('ledger_postings').toArray(),
  ]);
  if (accounts.length === 0) return;

  const deltaByAccount = new Map();
  for (const p of postings) {
    if (p.deleted_at) continue;
    deltaByAccount.set(p.account_id, (deltaByAccount.get(p.account_id) || 0) + (p.balance_delta_paise || 0));
  }

  const updated = accounts.map((a) => ({
    ...a,
    cached_balance_paise: (a.opening_balance_paise || 0) + (deltaByAccount.get(a.id) || 0),
  }));

  await db.transaction('rw', ['accounts'], async () => {
    await db.table('accounts').bulkPut(updated);
  });
}

function nextCalendarDayKey(dateKey) {
  const parts = String(dateKey || '').slice(0, 10).split('-').map(Number);
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return null;
  const d = new Date(parts[0], parts[1] - 1, parts[2] + 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export class AccountRepository extends BaseRepository {
  constructor(db) {
    super(db, 'accounts', { syncable: true });
  }

  async _getActivePostings() {
    try {
      const all = await this.db.table('ledger_postings').toArray();
      return all.filter((p) => !p.deleted_at);
    } catch {
      return [];
    }
  }

  async list({ includeArchived = false, asOfDate = null } = {}) {
    const all = await this.getAll({ includeDeleted: false });
    const filtered = all.filter((a) => (includeArchived ? true : !a.is_archived));

    // O(1) fast path: when no historical asOfDate is requested and every account has an exact cached_balance_paise
    if (!asOfDate && filtered.every((a) => Number.isSafeInteger(a.cached_balance_paise))) {
      return filtered
        .map((a) => ({
          ...a,
          current_balance_paise: a.cached_balance_paise,
        }))
        .sort((a, b) => a.name.localeCompare(b.name));
    }

    // Fallback or asOfDate: single-pass O(P) aggregation instead of O(A * P)
    const postings = await this._getActivePostings();
    const deltaByAccount = new Map();
    for (const p of postings) {
      if (asOfDate) {
        const pDate = String(p.occurred_at_local || '').slice(0, 10);
        if (pDate && pDate > asOfDate) continue;
      }
      deltaByAccount.set(p.account_id, (deltaByAccount.get(p.account_id) || 0) + (p.balance_delta_paise || 0));
    }

    return filtered
      .map((a) => ({
        ...a,
        current_balance_paise: (a.opening_balance_paise || 0) + (deltaByAccount.get(a.id) || 0),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * Reconcile a single account as of a specific date ("YYYY-MM-DD"),
   * excluding all transactions occurring after `asOfDate`.
   */
  async getReconciledAccountAsOf(accountId, asOfDate) {
    const acc = await this.getById(accountId);
    if (!acc) return null;

    const postingsTbl = this.db.table('ledger_postings');
    let accPostings;
    if (typeof postingsTbl.where === 'function') {
      accPostings = (await postingsTbl.where('account_id').equals(accountId).toArray()).filter((p) => !p.deleted_at);
    } else {
      accPostings = (await this._getActivePostings()).filter((p) => p.account_id === accountId);
    }

    const balanceAsOfPaise = computeReconciledAccountBalance(acc, accPostings, asOfDate || null);
    return {
      ...acc,
      current_balance_paise: balanceAsOfPaise,
      as_of_date: asOfDate || null,
    };
  }

  /**
   * Batch-reconcile a set of accounts as of `asOfDate` in a single indexed pass.
   * When all accounts have `cached_balance_paise` and `where('occurred_at_local')` is available,
   * subtracts only postings strictly after `asOfDate` (exact identity: balAsOf = currentBal - postAfter).
   */
  async getReconciledBalancesAsOf(accounts, asOfDate) {
    const list = Array.isArray(accounts) ? accounts : [];
    const result = new Map();
    if (list.length === 0) return result;

    if (!asOfDate) {
      for (const a of list) {
        result.set(a.id, Number.isSafeInteger(a.current_balance_paise) ? a.current_balance_paise : (a.cached_balance_paise ?? a.opening_balance_paise ?? 0));
      }
      return result;
    }

    const postingsTbl = this.db.table('ledger_postings');
    const allHaveCached = list.every((a) => Number.isSafeInteger(a.cached_balance_paise));
    const nextDay = nextCalendarDayKey(asOfDate);

    if (allHaveCached && nextDay && typeof postingsTbl.where === 'function') {
      const afterPostings = await postingsTbl
        .where('occurred_at_local')
        .between(`${nextDay} 00:00:00`, '9999-12-31 23:59:59', true, true)
        .toArray();
      const afterDelta = new Map();
      for (const p of afterPostings) {
        if (p.deleted_at) continue;
        afterDelta.set(p.account_id, (afterDelta.get(p.account_id) || 0) + (p.balance_delta_paise || 0));
      }
      for (const a of list) {
        result.set(a.id, a.cached_balance_paise - (afterDelta.get(a.id) || 0));
      }
      return result;
    }

    // Fallback single-pass O(P) scan
    const postings = await this._getActivePostings();
    const deltaByAccount = new Map();
    for (const p of postings) {
      const pDate = String(p.occurred_at_local || '').slice(0, 10);
      if (pDate && pDate > asOfDate) continue;
      deltaByAccount.set(p.account_id, (deltaByAccount.get(p.account_id) || 0) + (p.balance_delta_paise || 0));
    }
    for (const a of list) {
      result.set(a.id, (a.opening_balance_paise || 0) + (deltaByAccount.get(a.id) || 0));
    }
    return result;
  }

  /**
   * Independently verify every account's `cached_balance_paise` against full `ledger_postings` replay.
   */
  async verifyCachedBalancesAgainstLedger() {
    const [accounts, postings] = await Promise.all([
      this.getAll({ includeDeleted: false }),
      this._getActivePostings(),
    ]);
    const deltaByAccount = new Map();
    for (const p of postings) {
      deltaByAccount.set(p.account_id, (deltaByAccount.get(p.account_id) || 0) + (p.balance_delta_paise || 0));
    }
    const mismatches = [];
    for (const a of accounts) {
      const replayed = (a.opening_balance_paise || 0) + (deltaByAccount.get(a.id) || 0);
      const cached = a.cached_balance_paise;
      if (cached !== replayed) {
        mismatches.push({
          accountId: a.id,
          name: a.name,
          cachedPaise: cached,
          replayedPaise: replayed,
          diffPaise: (cached ?? 0) - replayed,
        });
      }
    }
    return {
      ok: mismatches.length === 0,
      checkedCount: accounts.length,
      mismatches,
    };
  }

  async listGrouped() {
    const all = await this.list({ includeArchived: true });
    const active = all.filter((a) => !a.is_archived);
    const archived = all.filter((a) => a.is_archived);

    const groups = ACCOUNT_TYPE_ORDER.map((typeCode) => ({
      meta: getAccountTypeMeta(typeCode),
      items: active.filter((a) => getAccountTypeMeta(a.type).code === typeCode),
    }));

    return { groups, archived };
  }

  async findByName(rawName) {
    const norm = normalizeAccountName(rawName);
    const all = await this.getAll({ includeDeleted: false });
    const match = all.find((a) => a.normalized_key === norm.normalized_key) || null;
    return { match, normalized: norm };
  }

  async createAccount({
    name,
    type = 'bank_account',
    institution = '',
    identifier_masked = '',
    opening_balance_paise = 0,
    opening_balance_rupees = undefined,
    credit_limit_paise = 0,
    credit_limit_rupees = undefined,
    opening_date = toLocalDateString(),
    currency = 'INR',
    color = null,
    icon = null,
    include_in_available_balance = undefined,
    notes = '',
  }) {
    const norm = normalizeAccountName(name);
    if (!norm.name) throw new Error('Account name is required');

    const { match } = await this.findByName(norm.name);
    if (match) {
      throw new Error(`Account "${norm.name}" already exists`);
    }

    if (typeof type !== 'string' || !Object.prototype.hasOwnProperty.call(ACCOUNT_TYPES, type)) {
      throw new Error(`Unsupported account type: "${type}"`);
    }
    const typeMeta = getAccountTypeMeta(type);
    const openingPaise =
      opening_balance_rupees !== undefined
        ? parseRupeesToPaise(opening_balance_rupees, { allowNegative: typeMeta.code !== 'credit_card' })
        : opening_balance_paise;

    if (!Number.isSafeInteger(openingPaise)) {
      throw new Error('Opening balance must be integer paise');
    }

    let limitPaise = 0;
    if (typeMeta.code === 'credit_card') {
      limitPaise =
        credit_limit_rupees !== undefined && String(credit_limit_rupees).trim() !== ''
          ? parseRupeesToPaise(credit_limit_rupees, { allowNegative: false })
          : credit_limit_paise || 0;
    }

    const includeAvailable =
      include_in_available_balance !== undefined
        ? Boolean(include_in_available_balance)
        : typeMeta.defaultIncludeInAvailableBalance;

    return this.create({
      name: norm.name,
      normalized_key: norm.normalized_key,
      type: typeMeta.code,
      account_class: typeMeta.accountClass,
      institution: String(institution || '').trim(),
      identifier_masked: String(identifier_masked || '').trim(),
      opening_balance_paise: openingPaise,
      cached_balance_paise: openingPaise,
      credit_limit_paise: limitPaise,
      opening_date: opening_date || toLocalDateString(),
      currency: currency || 'INR',
      color: color || typeMeta.color,
      icon: icon || typeMeta.icon,
      include_in_available_balance: includeAvailable,
      is_archived: false,
      notes: String(notes || '').trim(),
    });
  }

  async updateAccount(id, patch) {
    const current = await this.getById(id);
    if (!current) throw new Error('Account not found');

    const nextPatch = { ...patch };
    const nextType = patch.type ? getAccountTypeMeta(patch.type).code : getAccountTypeMeta(current.type).code;

    if (patch.name !== undefined) {
      const norm = normalizeAccountName(patch.name);
      if (!norm.name) throw new Error('Account name cannot be empty');
      const all = await this.getAll({ includeDeleted: false });
      const duplicate = all.find((a) => a.id !== id && a.normalized_key === norm.normalized_key);
      if (duplicate) {
        throw new Error(`Account "${norm.name}" already exists`);
      }
      nextPatch.name = norm.name;
      nextPatch.normalized_key = norm.normalized_key;
    }

    if (patch.type !== undefined) {
      const typeMeta = getAccountTypeMeta(patch.type);
      nextPatch.type = typeMeta.code;
      nextPatch.account_class = typeMeta.accountClass;
    }

    if (patch.opening_balance_rupees !== undefined) {
      nextPatch.opening_balance_paise = parseRupeesToPaise(patch.opening_balance_rupees, {
        allowNegative: nextType !== 'credit_card',
      });
      delete nextPatch.opening_balance_rupees;
    }

    if (nextPatch.opening_balance_paise !== undefined && Number.isSafeInteger(current.cached_balance_paise)) {
      const openingDiff = nextPatch.opening_balance_paise - (current.opening_balance_paise || 0);
      nextPatch.cached_balance_paise = current.cached_balance_paise + openingDiff;
    }

    if (patch.credit_limit_rupees !== undefined) {
      const rawLimit = String(patch.credit_limit_rupees).trim();
      nextPatch.credit_limit_paise =
        rawLimit === '' ? 0 : parseRupeesToPaise(rawLimit, { allowNegative: false });
      delete nextPatch.credit_limit_rupees;
    }

    return this.update(id, nextPatch);
  }

  async setArchived(id, isArchived) {
    return this.update(id, { is_archived: Boolean(isArchived) });
  }

  static getCreditCardMetrics(account) {
    const rawBalance =
      account.current_balance_paise !== undefined
        ? account.current_balance_paise
        : account.opening_balance_paise || 0;
    const outstandingPaise = Math.max(0, rawBalance);
    const overpaymentCreditPaise = rawBalance < 0 ? Math.abs(rawBalance) : 0;
    const limitPaise = account.credit_limit_paise || 0;
    const availableCreditPaise = Math.max(0, limitPaise - rawBalance);
    return {
      outstandingPaise,
      overpaymentCreditPaise,
      limitPaise,
      availableCreditPaise,
    };
  }

  static summarizeAccounts(activeAccounts) {
    const assetAccounts = activeAccounts.filter((a) => !isLiabilityAccount(a));
    const liabilityAccounts = activeAccounts.filter((a) => isLiabilityAccount(a));
    const availableAccounts = assetAccounts.filter((a) => a.include_in_available_balance);
    const creditCards = liabilityAccounts.filter((a) => getAccountTypeMeta(a.type).code === 'credit_card');

    return {
      activeCount: activeAccounts.length,
      assetCount: assetAccounts.length,
      liabilityCount: liabilityAccounts.length,
      creditCardCount: creditCards.length,
      totalAvailableBalancePaise: sumPaise(availableAccounts.map((a) => a.current_balance_paise || 0)),
      totalAssetBalancePaise: sumPaise(assetAccounts.map((a) => a.current_balance_paise || 0)),
      totalCreditCardLiabilityPaise: sumPaise(
        creditCards.map((a) => AccountRepository.getCreditCardMetrics(a).outstandingPaise)
      ),
      totalCreditLimitPaise: sumPaise(creditCards.map((a) => a.credit_limit_paise || 0)),
      totalAvailableCreditPaise: sumPaise(
        creditCards.map((a) => AccountRepository.getCreditCardMetrics(a).availableCreditPaise)
      ),
      totalLiabilityBalancePaise: sumPaise(
        liabilityAccounts.map((a) => Math.max(0, a.current_balance_paise || 0))
      ),
      accountClass: ACCOUNT_CLASS,
    };
  }

  async getBalanceSummary() {
    const activeAccounts = await this.list({ includeArchived: false });
    return AccountRepository.summarizeAccounts(activeAccounts);
  }
}

import { BaseRepository } from './baseRepository.js';
import { normalizeCategoryKey } from '../../utils/categoryMatcher.js';
import { nowIsoUtc } from '../../utils/date.js';

export class CategoryRepository extends BaseRepository {
  constructor(db) {
    super(db, 'categories', { syncable: true });
  }

  async list({ type = null, includeArchived = false } = {}) {
    const all = await this.getAll({ includeDeleted: false });
    return all
      .filter((c) => {
        if (type && c.type !== type) return false;
        if (!includeArchived && c.is_archived) return false;
        return true;
      })
      .sort((a, b) => (a.sort_order || 999) - (b.sort_order || 999) || a.name.localeCompare(b.name));
  }

  async listTree({ type = null, includeArchived = false } = {}) {
    const items = await this.list({ type, includeArchived });
    const parentIds = new Set(items.filter((c) => !c.parent_id).map((c) => c.id));
    const parents = [];
    const childrenByParent = new Map();

    for (const c of items) {
      if (c.parent_id && parentIds.has(c.parent_id)) {
        if (!childrenByParent.has(c.parent_id)) childrenByParent.set(c.parent_id, []);
        childrenByParent.get(c.parent_id).push(c);
      } else {
        // Top-level categories AND non-archived children whose parent is archived stay visible
        parents.push(c);
      }
    }
    return parents.map((p) => ({
      ...p,
      subcategories: childrenByParent.get(p.id) || [],
    }));
  }

  async createCategory({ name, type, parent_id = null, icon = '🏷️', color = '#475569' }) {
    const cleanName = String(name || '').replace(/\s+/g, ' ').trim();
    if (!cleanName) throw new Error('Category name is required');
    if (type !== 'expense' && type !== 'income') {
      throw new Error('Category type must be "expense" or "income"');
    }

    if (parent_id) {
      const parent = await this.getById(parent_id);
      if (!parent) throw new Error('Parent category does not exist');
      if (parent.type !== type) {
        throw new Error('Subcategory must have the same type as its parent category');
      }
      if (parent.parent_id) {
        throw new Error('Only one level of subcategories is supported');
      }
    }

    const existing = await this.list({ type, includeArchived: true });
    const normNew = normalizeCategoryKey(cleanName);
    const duplicate = existing.find(
      (c) =>
        (c.parent_id || null) === (parent_id || null) &&
        (c.name.trim().toLowerCase() === cleanName.toLowerCase() ||
          (normNew && normalizeCategoryKey(c.name) === normNew))
    );
    if (duplicate) {
      throw new Error(`Category "${duplicate.name}" already exists`);
    }

    return this.create({
      name: cleanName,
      type,
      parent_id: parent_id || null,
      icon: icon || '🏷️',
      color: color || '#475569',
      is_default: false,
      is_archived: false,
      sort_order: existing.length + 1,
    });
  }

  async updateCategory(id, patch) {
    const current = await this.getById(id);
    if (!current) throw new Error('Category not found');

    const nextName =
      patch.name !== undefined ? String(patch.name).replace(/\s+/g, ' ').trim() : current.name;
    if (!nextName) throw new Error('Category name cannot be empty');

    const nextParentId = patch.parent_id !== undefined ? patch.parent_id || null : current.parent_id;
    if (nextParentId === id) {
      throw new Error('A category cannot be its own parent');
    }

    const existing = await this.list({ type: current.type, includeArchived: true });
    const normNext = normalizeCategoryKey(nextName);
    const duplicate = existing.find(
      (c) =>
        c.id !== id &&
        (c.parent_id || null) === nextParentId &&
        (c.name.trim().toLowerCase() === nextName.toLowerCase() ||
          (normNext && normalizeCategoryKey(c.name) === normNext))
    );
    if (duplicate) {
      throw new Error(`Category "${duplicate.name}" already exists`);
    }

    return this.update(id, {
      ...patch,
      name: nextName,
      parent_id: nextParentId,
    });
  }

  async setArchived(id, isArchived) {
    return this.update(id, { is_archived: Boolean(isArchived) });
  }

  /**
   * Counts all active records referencing this category across transactions, splits,
   * budgets, bills, recurring rules, favorites, learning rules, and subcategories.
   */
  async countAllReferences(id) {
    const safeList = async (tbl) => {
      try {
        return await this.db.table(tbl).toArray();
      } catch {
        return [];
      }
    };
    const [txs, splits, budgets, bills, recurring, favorites, rules, cats] = await Promise.all([
      typeof this.db.table('transactions').where === 'function'
        ? this.db.table('transactions').where('category_id').equals(id).toArray()
        : safeList('transactions'),
      typeof this.db.table('transaction_splits').where === 'function'
        ? this.db.table('transaction_splits').where('category_id').equals(id).toArray()
        : safeList('transaction_splits'),
      safeList('budgets'),
      safeList('bills'),
      safeList('recurring_rules'),
      safeList('favorite_templates'),
      safeList('personal_learning_rules'),
      this.list({ includeArchived: true }),
    ]);

    const txCount = txs.filter((r) => !r.deleted_at && r.category_id === id).length;
    const splitCount = splits.filter((r) => !r.deleted_at && r.category_id === id).length;
    const budgetCount = budgets.filter((r) => !r.deleted_at && r.scope_type === 'category' && r.scope_id === id).length;
    const billCount = bills.filter((r) => !r.deleted_at && r.category_id === id).length;
    const recurringCount = recurring.filter((r) => !r.deleted_at && r.category_id === id).length;
    const favoriteCount = favorites.filter((r) => !r.deleted_at && r.category_id === id).length;
    const ruleCount = rules.filter((r) => !r.deleted_at && (r.category_id === id || r.subcategory_id === id)).length;
    const childCount = cats.filter((c) => c.parent_id === id).length;

    return {
      txCount,
      splitCount,
      budgetCount,
      billCount,
      recurringCount,
      favoriteCount,
      ruleCount,
      childCount,
      total: txCount + splitCount + budgetCount + billCount + recurringCount + favoriteCount + ruleCount + childCount,
    };
  }

  /**
   * Atomically reassigns all linked records from `fromId` to `toId` and soft-deletes `fromId`.
   * Guarantees zero orphaned transactions, splits, budgets, bills, recurring rules, or subcategories.
   */
  async reassignAndDeleteCategory(fromId, toId) {
    if (!fromId || !toId) throw new Error('Source and target categories are required');
    if (fromId === toId) throw new Error('Please choose a different target category');

    const [fromCat, toCat] = await Promise.all([this.getById(fromId), this.getById(toId)]);
    if (!fromCat) throw new Error('Category to delete not found');
    if (!toCat || toCat.is_archived) throw new Error('Target category must be an active category');
    if (fromCat.type !== toCat.type) {
      throw new Error('Target category must have the same type (expense or income)');
    }

    const now = nowIsoUtc();
    const candidateStores = [
      'categories',
      'transactions',
      'transaction_splits',
      'budgets',
      'bills',
      'recurring_rules',
      'favorite_templates',
      'personal_learning_rules',
      'sync_queue',
    ];
    const activeStores = candidateStores.filter((name) => {
      try {
        return Boolean(this.db.table(name));
      } catch {
        return false;
      }
    });

    const summary = { transactions: 0, splits: 0, budgets: 0, bills: 0, recurring: 0, favorites: 0, rules: 0, subcategories: 0 };

    await this.db.transaction('rw', activeStores, async () => {
      const updateCatField = async (tblName, fieldName, counterKey, extraFilter = null) => {
        if (!activeStores.includes(tblName)) return;
        const tbl = this.db.table(tblName);
        const rows =
          fieldName === 'category_id' && typeof tbl.where === 'function' && (tblName === 'transactions' || tblName === 'transaction_splits')
            ? await tbl.where('category_id').equals(fromId).toArray()
            : await tbl.toArray();
        const toUpdate = rows
          .filter((r) => !r.deleted_at && r[fieldName] === fromId && (!extraFilter || extraFilter(r)))
          .map((r) => ({
            ...r,
            [fieldName]: toId,
            updated_at: now,
            version: (r.version || 1) + 1,
          }));
        if (toUpdate.length > 0) {
          await tbl.bulkPut(toUpdate);
          summary[counterKey] += toUpdate.length;
        }
      };

      await updateCatField('transactions', 'category_id', 'transactions');
      await updateCatField('transaction_splits', 'category_id', 'splits');
      await updateCatField('budgets', 'scope_id', 'budgets', (b) => b.scope_type === 'category');
      await updateCatField('bills', 'category_id', 'bills');
      await updateCatField('recurring_rules', 'category_id', 'recurring');
      await updateCatField('favorite_templates', 'category_id', 'favorites');

      if (activeStores.includes('personal_learning_rules')) {
        const tbl = this.db.table('personal_learning_rules');
        const rules = await tbl.toArray();
        const updatedRules = rules
          .filter((r) => !r.deleted_at && (r.category_id === fromId || r.subcategory_id === fromId))
          .map((r) => ({
            ...r,
            category_id: r.category_id === fromId ? toId : r.category_id,
            subcategory_id: r.subcategory_id === fromId ? null : r.subcategory_id,
            updated_at: now,
            version: (r.version || 1) + 1,
          }));
        if (updatedRules.length > 0) {
          await tbl.bulkPut(updatedRules);
          summary.rules = updatedRules.length;
        }
      }

      // Promote any child subcategories of fromId to top-level (simplifies hierarchy safely)
      const allCats = await this.db.table('categories').toArray();
      const children = allCats
        .filter((c) => !c.deleted_at && c.parent_id === fromId)
        .map((c) => ({ ...c, parent_id: null, updated_at: now, version: (c.version || 1) + 1 }));
      if (children.length > 0) {
        await this.db.table('categories').bulkPut(children);
        summary.subcategories = children.length;
      }

      // Soft-delete source category
      const tomb = { ...fromCat, deleted_at: now, updated_at: now, version: (fromCat.version || 1) + 1 };
      await this.db.table('categories').put(tomb);
    });

    return summary;
  }

  /**
   * Soft-delete a category only if it has zero linked references across the database.
   */
  async deleteCategorySafe(id, { referencedTransactionCount = null } = {}) {
    const refs = await this.countAllReferences(id);
    const txCount = referencedTransactionCount !== null ? Math.max(referencedTransactionCount, refs.txCount) : refs.txCount;
    if (txCount > 0 || refs.splitCount > 0 || refs.budgetCount > 0 || refs.billCount > 0 || refs.recurringCount > 0) {
      throw new Error(
        'Cannot delete a category linked to existing transactions or records. Archive it or reassign them first.'
      );
    }
    if (refs.childCount > 0) {
      throw new Error('Cannot delete a parent category that still has subcategories. Promote or reassign them first.');
    }
    return this.softDelete(id);
  }
}

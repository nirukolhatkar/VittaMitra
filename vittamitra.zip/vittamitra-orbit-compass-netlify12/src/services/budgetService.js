import { shiftMonth } from '../utils/date.js';

/**
 * Shared pure predicate returning all transactions (and their exact contributed paise)
 * that contribute to a budget's spent total. Used by both BudgetService.evaluateMonthBudgets()
 * and the clickable Budget Spent drill-down so totals reconcile to the exact paisa.
 *
 * Financial rules:
 * - Only `type === 'expense'` counts (transfers, debts, adjustments, and income refunds are excluded).
 * - Transactions with `exclude_from_budget === true` are excluded consistently.
 * - Parent-category budgets include direct parent + child subcategory expenses (including archived children).
 * - Split expenses (`is_split === true`) contribute the exact sum of matching split legs for category budgets.
 */
export function getBudgetContributingTransactions(budget, monthTxs, childCatIdsByParent, splitsByTxId = new Map()) {
  const matched = [];
  let totalSpentPaise = 0;

  let allowedCatIds = null;
  if (budget.scope_type === 'category') {
    allowedCatIds = new Set([budget.scope_id]);
    const children = childCatIdsByParent?.get(budget.scope_id);
    if (children) {
      for (const cid of children) allowedCatIds.add(cid);
    }
  }

  for (const tx of monthTxs || []) {
    if (!tx || tx.deleted_at) continue;
    if (tx.type !== 'expense') continue;
    if (tx.exclude_from_budget === true) continue;

    let contributedPaise = 0;
    if (budget.scope_type === 'overall') {
      contributedPaise = tx.amount_paise || 0;
    } else if (budget.scope_type === 'category') {
      if (tx.is_split && splitsByTxId && splitsByTxId.has(tx.id)) {
        const legs = splitsByTxId.get(tx.id) || [];
        for (const sp of legs) {
          if (!sp.deleted_at && allowedCatIds.has(sp.category_id)) {
            contributedPaise += sp.amount_paise || 0;
          }
        }
      } else if (tx.category_id && allowedCatIds.has(tx.category_id)) {
        contributedPaise = tx.amount_paise || 0;
      }
    } else if (budget.scope_type === 'tag') {
      if (Array.isArray(tx.tag_ids) && tx.tag_ids.includes(budget.scope_id)) {
        contributedPaise = tx.amount_paise || 0;
      }
    }

    if (contributedPaise > 0) {
      matched.push({ tx, contributedPaise });
      totalSpentPaise += contributedPaise;
    }
  }

  return { items: matched, totalSpentPaise };
}

/**
 * Budget Evaluation, Carry-Forward, Projection & Alert Service.
 */
export class BudgetService {
  constructor(repos, services) {
    this.repos = repos;
    this.services = services;
  }

  static monthKey(year, monthIndex0) {
    return `${year}-${String(monthIndex0 + 1).padStart(2, '0')}`;
  }

  _buildChildCategoryMap(categories) {
    const childCatIdsByParent = new Map();
    for (const c of categories || []) {
      if (c.parent_id) {
        if (!childCatIdsByParent.has(c.parent_id)) childCatIdsByParent.set(c.parent_id, new Set());
        childCatIdsByParent.get(c.parent_id).add(c.id);
      }
    }
    return childCatIdsByParent;
  }

  async _loadSplitsForTransactions(txs) {
    const splitTxs = (txs || []).filter((t) => t && t.is_split && !t.deleted_at);
    const splitsByTxId = new Map();
    if (splitTxs.length === 0) return splitsByTxId;

    const db = this.services?.transactions?.db || this.repos?.budgets?.db;
    if (!db) return splitsByTxId;
    const splitTbl = db.table('transaction_splits');

    if (typeof splitTbl.where === 'function') {
      const results = await Promise.all(
        splitTxs.map((t) => splitTbl.where('transaction_id').equals(t.id).toArray())
      );
      for (let i = 0; i < splitTxs.length; i += 1) {
        splitsByTxId.set(splitTxs[i].id, results[i].filter((s) => !s.deleted_at));
      }
    } else {
      const allSplits = await splitTbl.toArray();
      const idSet = new Set(splitTxs.map((t) => t.id));
      for (const sp of allSplits) {
        if (sp.deleted_at || !idSet.has(sp.transaction_id)) continue;
        if (!splitsByTxId.has(sp.transaction_id)) splitsByTxId.set(sp.transaction_id, []);
        splitsByTxId.get(sp.transaction_id).push(sp);
      }
    }
    return splitsByTxId;
  }

  _matchesBudget(tx, budget, childCatIdsByParent) {
    if (tx.type !== 'expense' || tx.exclude_from_budget === true) return false;
    if (budget.scope_type === 'overall') return true;
    if (budget.scope_type === 'category') {
      if (tx.category_id === budget.scope_id) return true;
      const children = childCatIdsByParent.get(budget.scope_id);
      return Boolean(children && children.has(tx.category_id));
    }
    if (budget.scope_type === 'tag') {
      return Array.isArray(tx.tag_ids) && tx.tag_ids.includes(budget.scope_id);
    }
    return false;
  }

  /**
   * Returns the exact contributing transactions and reconciled spent total for a given budget & month.
   */
  async getContributingTransactionsForBudget(budgetOrId, year, monthIndex0) {
    const budget =
      typeof budgetOrId === 'string'
        ? await this.repos.budgets.getById(budgetOrId)
        : budgetOrId;
    if (!budget) return { budget: null, items: [], totalSpentPaise: 0 };

    const [categories, monthTxs] = await Promise.all([
      this.repos.categories.list({ includeArchived: true }),
      this.services.transactions.listTransactions({
        monthYear: { year, month: monthIndex0 },
        type: 'expense',
        includeTags: budget.scope_type === 'tag',
      }),
    ]);

    const childCatIdsByParent = this._buildChildCategoryMap(categories);
    const splitsByTxId =
      budget.scope_type === 'category'
        ? await this._loadSplitsForTransactions(monthTxs)
        : new Map();

    const { items, totalSpentPaise } = getBudgetContributingTransactions(
      budget,
      monthTxs,
      childCatIdsByParent,
      splitsByTxId
    );
    return { budget, items, totalSpentPaise };
  }

  async evaluateMonthBudgets(year, monthIndex0) {
    const targetKey = BudgetService.monthKey(year, monthIndex0);
    const prev = shiftMonth(year, monthIndex0, -1);
    const prevKey = BudgetService.monthKey(prev.year, prev.month);

    const [allBudgets, categories] = await Promise.all([
      this.repos.budgets.listAll(),
      this.repos.categories.list({ includeArchived: true }),
    ]);

    const childCatIdsByParent = this._buildChildCategoryMap(categories);

    // Active budgets for targetKey: exact match for period_month OR recurring budgets started on/before targetKey
    const applicable = allBudgets.filter(
      (b) => b.period_month === targetKey || (b.is_recurring && b.period_month <= targetKey)
    );

    // Deduplicate by (scope_type, scope_id) preferring an explicit month override over a recurring rule
    const dedupMap = new Map();
    for (const b of applicable) {
      const sig = `${b.scope_type}|${b.scope_id || ''}`;
      const prevEntry = dedupMap.get(sig);
      if (!prevEntry || b.period_month === targetKey) {
        dedupMap.set(sig, b);
      }
    }
    const activeBudgets = Array.from(dedupMap.values());

    const needsTags = activeBudgets.some((b) => b.scope_type === 'tag');
    const needsPrevMonth = activeBudgets.some((b) => b.carry_forward && b.period_month <= prevKey);
    const hasCatBudget = activeBudgets.some((b) => b.scope_type === 'category');

    const [monthTxs, prevMonthTxs] =
      activeBudgets.length === 0
        ? [[], []]
        : await Promise.all([
            this.services.transactions.listTransactions({
              monthYear: { year, month: monthIndex0 },
              type: 'expense',
              includeTags: needsTags,
            }),
            needsPrevMonth
              ? this.services.transactions.listTransactions({
                  monthYear: { year: prev.year, month: prev.month },
                  type: 'expense',
                  includeTags: needsTags,
                })
              : Promise.resolve([]),
          ]);

    const [monthSplits, prevSplits] = hasCatBudget
      ? await Promise.all([
          this._loadSplitsForTransactions(monthTxs),
          needsPrevMonth ? this._loadSplitsForTransactions(prevMonthTxs) : Promise.resolve(new Map()),
        ])
      : [new Map(), new Map()];

    const daysInMonth = new Date(year, monthIndex0 + 1, 0).getDate();
    const today = new Date();
    const isCurrentMonth = today.getFullYear() === year && today.getMonth() === monthIndex0;
    const isPastMonth = year < today.getFullYear() || (year === today.getFullYear() && monthIndex0 < today.getMonth());
    const daysElapsed = isPastMonth ? daysInMonth : isCurrentMonth ? Math.max(1, today.getDate()) : 0;
    const daysRemaining = isPastMonth ? 0 : isCurrentMonth ? Math.max(0, daysInMonth - today.getDate()) : daysInMonth;

    const evaluated = [];
    const newAlerts = [];

    for (const b of activeBudgets) {
      let carryForwardPaise = 0;
      if (b.carry_forward && b.period_month <= prevKey) {
        const { totalSpentPaise: prevSpent } = getBudgetContributingTransactions(
          b,
          prevMonthTxs,
          childCatIdsByParent,
          prevSplits
        );
        carryForwardPaise = Math.max(0, b.amount_paise - prevSpent);
      }

      const effectiveBudgetPaise = b.amount_paise + carryForwardPaise;
      const { items: contributingItems, totalSpentPaise: spentPaise } = getBudgetContributingTransactions(
        b,
        monthTxs,
        childCatIdsByParent,
        monthSplits
      );

      const remainingPaise = effectiveBudgetPaise - spentPaise;
      const percentUsed = effectiveBudgetPaise > 0 ? (spentPaise / effectiveBudgetPaise) * 100 : 0;
      const avgDailySpendPaise = daysElapsed > 0 ? Math.round(spentPaise / daysElapsed) : 0;
      const projectedMonthEndPaise = isPastMonth
        ? spentPaise
        : daysElapsed > 0
          ? Math.round((spentPaise / daysElapsed) * daysInMonth)
          : 0;

      // Check alert thresholds without repeating already-triggered thresholds for this month
      const alreadyTriggered = new Set((b.triggered_alerts && b.triggered_alerts[targetKey]) || []);
      const thresholds = Array.isArray(b.alert_thresholds) ? b.alert_thresholds : [50, 75, 90, 100];
      const newlyCrossed = thresholds.filter((th) => percentUsed >= th && !alreadyTriggered.has(th));

      if (newlyCrossed.length > 0) {
        const highestNew = Math.max(...newlyCrossed);
        newAlerts.push({
          budgetId: b.id,
          budgetName: b.name,
          threshold: highestNew,
          percentUsed,
          spentPaise,
          effectiveBudgetPaise,
        });
        const nextTriggered = {
          ...(b.triggered_alerts || {}),
          [targetKey]: Array.from(new Set([...alreadyTriggered, ...newlyCrossed])).sort((a, c) => a - c),
        };
        await this.repos.budgets.update(b.id, { triggered_alerts: nextTriggered }).catch(() => {});
      }

      const matchedCategoryIds =
        b.scope_type === 'category'
          ? [b.scope_id, ...Array.from(childCatIdsByParent.get(b.scope_id) || [])]
          : [];

      evaluated.push({
        budget: b,
        baseBudgetPaise: b.amount_paise,
        carryForwardPaise,
        effectiveBudgetPaise,
        spentPaise,
        remainingPaise,
        contributingCount: contributingItems.length,
        matchedCategoryIds,
        percentUsed,
        daysInMonth,
        daysElapsed,
        daysRemaining,
        avgDailySpendPaise,
        projectedMonthEndPaise,
        status: percentUsed >= 100 ? 'exceeded' : percentUsed >= 75 ? 'warning' : 'healthy',
      });
    }

    return {
      periodKey: targetKey,
      daysInMonth,
      daysElapsed,
      daysRemaining,
      budgets: evaluated,
      newAlerts,
    };
  }

  /**
   * Copies budgets from the previous month into target (year, monthIndex0) if not already present.
   */
  async copyPreviousMonthBudgets(year, monthIndex0) {
    const targetKey = BudgetService.monthKey(year, monthIndex0);
    const prev = shiftMonth(year, monthIndex0, -1);
    const prevKey = BudgetService.monthKey(prev.year, prev.month);

    const all = await this.repos.budgets.listAll();
    const prevBudgets = all.filter((b) => b.period_month === prevKey || (b.is_recurring && b.period_month <= prevKey));
    const existingSigs = new Set(
      all.filter((b) => b.period_month === targetKey).map((b) => `${b.scope_type}|${b.scope_id || ''}`)
    );

    let copiedCount = 0;
    for (const pb of prevBudgets) {
      const sig = `${pb.scope_type}|${pb.scope_id || ''}`;
      if (existingSigs.has(sig)) continue;
      await this.repos.budgets.createBudget({
        name: pb.name,
        scope_type: pb.scope_type,
        scope_id: pb.scope_id,
        amount_paise: pb.amount_paise,
        period_month: targetKey,
        is_recurring: pb.is_recurring,
        carry_forward: pb.carry_forward,
        alert_thresholds: pb.alert_thresholds,
      });
      existingSigs.add(sig);
      copiedCount += 1;
    }
    return { copiedCount, fromMonth: prevKey, toMonth: targetKey };
  }
}

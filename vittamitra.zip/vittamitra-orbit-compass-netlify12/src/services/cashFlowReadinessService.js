import { advanceDateByFrequency } from './billsRecurringService.js';
import { toLocalDateString } from '../utils/date.js';

function addDaysToKey(dateKey, days) {
  const parts = String(dateKey || '').slice(0, 10).split('-').map(Number);
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return toLocalDateString();
  const d = new Date(parts[0], parts[1] - 1, parts[2] + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function diffDays(fromKey, toKey) {
  const a = String(fromKey).slice(0, 10).split('-').map(Number);
  const b = String(toKey).slice(0, 10).split('-').map(Number);
  const ta = Date.UTC(a[0], a[1] - 1, a[2]);
  const tb = Date.UTC(b[0], b[1] - 1, b[2]);
  return Math.round((tb - ta) / 86400000);
}

function resolveDayOfMonthInRange(dayOfMonth, startKey, endKey) {
  const dom = Number(dayOfMonth);
  if (!Number.isInteger(dom) || dom < 1 || dom > 31) return [];
  const [sy, sm] = startKey.split('-').map(Number);
  const [ey, em] = endKey.split('-').map(Number);
  const dates = [];
  let y = sy;
  let m = sm;
  for (let guard = 0; guard < 4; guard += 1) {
    const lastDay = new Date(y, m, 0).getDate();
    const clamped = Math.min(dom, lastDay);
    const key = `${y}-${String(m).padStart(2, '0')}-${String(clamped).padStart(2, '0')}`;
    if (key >= startKey && key <= endKey) dates.push(key);
    if (y > ey || (y === ey && m >= em)) break;
    m += 1;
    if (m > 12) {
      m = 1;
      y += 1;
    }
  }
  return dates;
}

/**
 * Pure date-wise cash-flow projection engine (integer paise).
 *
 * Critical financial rules enforced:
 * 1. Day-0 starting liquid cash uses `asOfDate = todayKey` across eligible asset accounts only
 *    (future-dated transactions are NOT baked into Day 0; they appear on their exact date_key).
 * 2. Credit card purchases never reduce liquid cash on purchase date; only CC bill settlements
 *    (asset -> liability transfer or explicit CC bill) reduce liquid cash, with deduplication.
 * 3. Asset-to-asset transfers are cash-neutral and never counted as income or expenditure.
 * 4. Paid bills and already-generated recurring occurrences are excluded.
 * 5. Overdue unpaid bills are bucketed immediately on Day 0 (`todayKey`).
 * 6. Conservative intraday ordering: outflows execute BEFORE expected income on the same date.
 * 7. Two parallel curves: Confirmed-Cash Curve vs With-Expected-Income Curve (expected income is
 *    never treated as guaranteed funds).
 */
export function projectCashFlowReadiness({
  todayKey = toLocalDateString(),
  horizonDays = 15,
  startingLiquidPaise = 0,
  minReservePaise = 0,
  accounts = [],
  bills = [],
  recurringRules = [],
  loans = [],
  futureTransactions = [],
}) {
  const safeHorizon = Math.max(1, Math.min(90, Number(horizonDays) || 15));
  const endKey = addDaysToKey(todayKey, safeHorizon);
  const accMap = new Map((accounts || []).map((a) => [a.id, a]));

  const isEligibleAsset = (accId) => {
    if (!accId) return true; // Unassigned bill defaults to liquid outflow
    const a = accMap.get(accId);
    if (!a) return true;
    return a.account_class === 'asset' && a.include_in_available_balance !== false;
  };
  const isCreditCard = (accId) => {
    const a = accMap.get(accId);
    return Boolean(a && a.type === 'credit_card');
  };

  const events = [];
  const coveredCcAccountIds = new Set();
  const coveredLoanNames = new Set();
  const coveredRecurringIds = new Set();

  // 1. Unpaid bills (overdue bucketed on Day 0; recurring bills expanded through endKey)
  for (const b of bills || []) {
    if (!b || b.deleted_at || b.is_active === false || b.status === 'paid') continue;
    if (!b.due_date || !Number.isSafeInteger(b.amount_paise) || b.amount_paise <= 0) continue;

    // If a bill is paid using a credit card, it increases CC liability rather than immediate liquid drain
    if (b.account_id && isCreditCard(b.account_id)) continue;

    const lowerName = String(b.name || '').toLowerCase();
    for (const acc of accounts || []) {
      if (acc.type === 'credit_card' && lowerName.includes(acc.name.toLowerCase())) {
        coveredCcAccountIds.add(acc.id);
      }
    }
    coveredLoanNames.add(lowerName);

    let occDate = String(b.due_date).slice(0, 10);
    let safety = 0;
    while (occDate <= endKey && safety < 40) {
      safety += 1;
      const isOverdue = occDate < todayKey;
      const effDate = isOverdue ? todayKey : occDate;
      events.push({
        date: effDate,
        originalDate: occDate,
        kind: 'outflow',
        source: 'bill',
        sourceId: b.id,
        label: isOverdue ? `${b.name} (Overdue from ${occDate})` : b.name,
        amountPaise: b.amount_paise,
        guaranteed: true,
      });
      if (!b.frequency || b.frequency === 'once') break;
      const next = advanceDateByFrequency(occDate, b.frequency, 1);
      if (!next || next <= occDate) break;
      occDate = next;
    }
  }

  // 2. Recurring rules (income, expense, transfer)
  for (const r of recurringRules || []) {
    if (!r || r.deleted_at || r.is_active === false) continue;
    if (!r.next_due_date || !Number.isSafeInteger(r.amount_paise) || r.amount_paise <= 0) continue;

    coveredRecurringIds.add(r.id);
    coveredLoanNames.add(String(r.name || '').toLowerCase());

    // Classify cash-flow impact strictly by account classes
    let kind = null;
    let guaranteed = true;
    if (r.type === 'income') {
      if (!isEligibleAsset(r.account_id)) continue;
      kind = 'expected_income';
      guaranteed = false; // Expected income is NEVER treated as guaranteed funds
    } else if (r.type === 'expense') {
      if (isCreditCard(r.account_id)) continue; // CC swipe does not drain liquid cash on swipe date
      if (!isEligibleAsset(r.account_id)) continue;
      kind = 'outflow';
    } else if (r.type === 'transfer') {
      const fromLiquid = isEligibleAsset(r.account_id);
      const toCc = isCreditCard(r.to_account_id);
      if (fromLiquid && toCc) {
        // Bank -> Credit Card bill settlement IS a real liquid cash outflow
        kind = 'outflow';
        coveredCcAccountIds.add(r.to_account_id);
      } else {
        // Liquid -> Liquid transfer is cash-neutral
        continue;
      }
    } else {
      continue;
    }

    let occDate = String(r.next_due_date).slice(0, 10);
    const ruleEnd = r.end_date ? String(r.end_date).slice(0, 10) : null;
    const lastGen = r.last_generated_date ? String(r.last_generated_date).slice(0, 10) : null;
    let safety = 0;
    while (occDate <= endKey && safety < 95) {
      safety += 1;
      if (ruleEnd && occDate > ruleEnd) break;
      if (!lastGen || occDate > lastGen) {
        const isOverdue = occDate < todayKey;
        const effDate = isOverdue ? todayKey : occDate;
        if (kind === 'expected_income' && isOverdue) {
          // Do not assume overdue unreceived income will land today
        } else {
          events.push({
            date: effDate,
            originalDate: occDate,
            kind,
            source: 'recurring',
            sourceId: r.id,
            label: isOverdue ? `${r.name} (Due ${occDate})` : r.name,
            amountPaise: r.amount_paise,
            guaranteed,
          });
        }
      }
      const next = advanceDateByFrequency(occDate, r.frequency || 'monthly', r.interval_value || 1);
      if (!next || next <= occDate) break;
      occDate = next;
    }
  }

  // 3. Active Loan EMIs (only when emi_day is configured AND not already linked/covered by a bill or recurring rule)
  for (const loan of loans || []) {
    if (!loan || loan.deleted_at || loan.is_active === false) continue;
    if (!Number.isSafeInteger(loan.emi_paise) || loan.emi_paise <= 0) continue;
    if ((loan.outstanding_paise || 0) <= 0) continue;
    if (loan.linked_recurring_rule_id && coveredRecurringIds.has(loan.linked_recurring_rule_id)) continue;
    const loanLower = String(loan.name || '').toLowerCase();
    if (loanLower && Array.from(coveredLoanNames).some((n) => n.includes(loanLower) || loanLower.includes(n))) {
      continue;
    }
    const emiDay = loan.emi_day || null;
    if (!emiDay) continue;
    const dates = resolveDayOfMonthInRange(emiDay, todayKey, endKey);
    for (const d of dates) {
      events.push({
        date: d,
        originalDate: d,
        kind: 'outflow',
        source: 'loan_emi',
        sourceId: loan.id,
        label: `${loan.name} EMI`,
        amountPaise: Math.min(loan.emi_paise, loan.outstanding_paise),
        guaranteed: true,
      });
    }
  }

  // 4. Credit Card Dues (only when due_day is configured AND not already covered by an explicit CC bill or transfer rule)
  for (const acc of accounts || []) {
    if (!acc || acc.deleted_at || acc.is_archived || acc.type !== 'credit_card') continue;
    const outstanding = Math.max(0, acc.current_balance_paise ?? acc.cached_balance_paise ?? 0);
    if (outstanding <= 0 || coveredCcAccountIds.has(acc.id)) continue;
    if (!acc.due_day) continue;
    const dates = resolveDayOfMonthInRange(acc.due_day, todayKey, endKey);
    if (dates.length > 0) {
      events.push({
        date: dates[0],
        originalDate: dates[0],
        kind: 'outflow',
        source: 'credit_card_due',
        sourceId: acc.id,
        label: `${acc.name} Bill Due`,
        amountPaise: outstanding,
        guaranteed: true,
      });
    }
  }

  // 5. Future-dated scheduled transactions (date_key > todayKey && date_key <= endKey)
  for (const tx of futureTransactions || []) {
    if (!tx || tx.deleted_at) continue;
    const d = String(tx.date_key || '').slice(0, 10);
    if (d <= todayKey || d > endKey) continue;
    if (!Number.isSafeInteger(tx.amount_paise) || tx.amount_paise <= 0) continue;

    if (tx.type === 'expense') {
      if (isCreditCard(tx.account_id) || !isEligibleAsset(tx.account_id)) continue;
      events.push({
        date: d,
        originalDate: d,
        kind: 'outflow',
        source: 'scheduled_tx',
        sourceId: tx.id,
        label: tx.description || 'Scheduled Expense',
        amountPaise: tx.amount_paise,
        guaranteed: true,
      });
    } else if (tx.type === 'income') {
      if (!isEligibleAsset(tx.account_id)) continue;
      events.push({
        date: d,
        originalDate: d,
        kind: 'expected_income',
        source: 'scheduled_tx',
        sourceId: tx.id,
        label: tx.description || 'Scheduled Income',
        amountPaise: tx.amount_paise,
        guaranteed: false,
      });
    } else if (tx.type === 'transfer') {
      if (isEligibleAsset(tx.account_id) && isCreditCard(tx.to_account_id)) {
        events.push({
          date: d,
          originalDate: d,
          kind: 'outflow',
          source: 'scheduled_tx',
          sourceId: tx.id,
          label: tx.description || 'Scheduled CC Payment',
          amountPaise: tx.amount_paise,
          guaranteed: true,
        });
      }
    }
  }

  // Sort strictly by date ascending, with OUTFLOWS BEFORE EXPECTED INCOME on the same calendar date
  events.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    const rank = (k) => (k === 'outflow' ? 0 : 1);
    if (rank(a.kind) !== rank(b.kind)) return rank(a.kind) - rank(b.kind);
    return b.amountPaise - a.amountPaise;
  });

  // Walk date-wise running curves
  let confirmedBal = startingLiquidPaise;
  let projectedBal = startingLiquidPaise;
  let totalOutflowsPaise = 0;
  let totalExpectedIncomePaise = 0;
  let lowestProjectedPaise = startingLiquidPaise;
  let lowestProjectedDate = todayKey;
  let lowestConfirmedPaise = startingLiquidPaise;
  let lowestConfirmedDate = todayKey;

  const timeline = [];
  const shortfalls = [];
  const reserveBreaches = [];
  const incomeDependentEvents = [];

  for (const ev of events) {
    const delta = ev.kind === 'outflow' ? -ev.amountPaise : ev.amountPaise;
    if (ev.kind === 'outflow') {
      totalOutflowsPaise += ev.amountPaise;
      confirmedBal += delta;
      projectedBal += delta;
    } else {
      totalExpectedIncomePaise += ev.amountPaise;
      projectedBal += delta;
    }

    if (projectedBal < lowestProjectedPaise) {
      lowestProjectedPaise = projectedBal;
      lowestProjectedDate = ev.date;
    }
    if (confirmedBal < lowestConfirmedPaise) {
      lowestConfirmedPaise = confirmedBal;
      lowestConfirmedDate = ev.date;
    }

    let status = 'safe';
    if (projectedBal < 0) {
      status = 'shortfall';
      if (ev.kind === 'outflow') {
        shortfalls.push({
          date: ev.date,
          daysFromToday: diffDays(todayKey, ev.date),
          obligation: ev.label,
          amountPaise: ev.amountPaise,
          deficitPaise: Math.abs(projectedBal),
          reserveGapPaise: minReservePaise - projectedBal,
        });
      }
    } else if (projectedBal < minReservePaise) {
      status = 'reserve_breach';
      if (ev.kind === 'outflow') {
        reserveBreaches.push({
          date: ev.date,
          daysFromToday: diffDays(todayKey, ev.date),
          obligation: ev.label,
          amountPaise: ev.amountPaise,
          reserveGapPaise: minReservePaise - projectedBal,
        });
      }
    } else if (confirmedBal < minReservePaise) {
      status = 'income_dependent';
      if (ev.kind === 'outflow') {
        incomeDependentEvents.push({
          date: ev.date,
          obligation: ev.label,
          confirmedBalancePaise: confirmedBal,
        });
      }
    }

    timeline.push({
      ...ev,
      deltaPaise: delta,
      confirmedBalancePaise: confirmedBal,
      projectedBalancePaise: projectedBal,
      status,
    });
  }

  // Identify when expected income is needed to cover the first shortfall/breach
  const firstCritical = shortfalls[0] || reserveBreaches[0] || null;
  const nextExpectedIncome = events.find((e) => e.kind === 'expected_income') || null;
  let incomeNeededByDate = firstCritical ? firstCritical.date : null;
  let incomeTimingNote = null;
  if (firstCritical) {
    const neededAmt = firstCritical.deficitPaise || firstCritical.reserveGapPaise;
    if (nextExpectedIncome && nextExpectedIncome.date > firstCritical.date) {
      const lateDays = diffDays(firstCritical.date, nextExpectedIncome.date);
      incomeTimingNote = `Expected income (${nextExpectedIncome.label} on ${nextExpectedIncome.date}) arrives ${lateDays} day${lateDays === 1 ? '' : 's'} after ${firstCritical.obligation} on ${firstCritical.date}.`;
    } else if (!nextExpectedIncome) {
      incomeTimingNote = `No expected income scheduled before ${firstCritical.date} to cover ${firstCritical.obligation}.`;
    } else {
      incomeTimingNote = `Additional funds needed by ${firstCritical.date} (${neededAmt} paise gap) even with scheduled income.`;
    }
  } else if (incomeDependentEvents.length > 0 && nextExpectedIncome) {
    incomeTimingNote = `Coverage depends on ${nextExpectedIncome.label} arriving on or before ${nextExpectedIncome.date}.`;
  }

  const overallStatus =
    shortfalls.length > 0
      ? 'shortfall'
      : reserveBreaches.length > 0
        ? 'reserve_breach'
        : incomeDependentEvents.length > 0
          ? 'income_dependent'
          : 'safe';

  return {
    todayKey,
    endKey,
    horizonDays: safeHorizon,
    startingLiquidPaise,
    minReservePaise,
    totalOutflowsPaise,
    totalExpectedIncomePaise,
    endingConfirmedPaise: confirmedBal,
    endingProjectedPaise: projectedBal,
    lowestConfirmedPaise,
    lowestConfirmedDate,
    lowestProjectedPaise,
    lowestProjectedDate,
    overallStatus,
    shortfalls,
    reserveBreaches,
    incomeDependentEvents,
    incomeNeededByDate,
    incomeTimingNote,
    timeline,
  };
}

export class CashFlowReadinessService {
  constructor(db, repos, services) {
    this.db = db;
    this.repos = repos;
    this.services = services;
  }

  async evaluateReadiness({ horizonDays = 15, todayKey = toLocalDateString() } = {}) {
    const endKey = addDaysToKey(todayKey, Math.max(1, Math.min(90, Number(horizonDays) || 15)));
    const nextDay = addDaysToKey(todayKey, 1);

    const [settings, accounts, bills, recurringRules, loans, futureTxs] = await Promise.all([
      this.repos.settings.getSettings(),
      this.repos.accounts.list({ includeArchived: false }),
      typeof this.repos.bills?.listAll === 'function' ? this.repos.bills.listAll() : Promise.resolve([]),
      typeof this.repos.recurring?.listAll === 'function' ? this.repos.recurring.listAll() : Promise.resolve([]),
      typeof this.repos.loans?.listAll === 'function' ? this.repos.loans.listAll() : Promise.resolve([]),
      this.services.transactions.listTransactions({
        startDate: nextDay,
        endDate: endKey,
        includeTags: false,
      }),
    ]);

    // Eligible Day-0 liquid cash strictly as of todayKey (excluding future-dated postings)
    const eligibleAssets = accounts.filter(
      (a) => a.account_class === 'asset' && a.include_in_available_balance !== false
    );
    const asOfMap = await this.repos.accounts.getReconciledBalancesAsOf(eligibleAssets, todayKey);
    let startingLiquidPaise = 0;
    for (const a of eligibleAssets) {
      startingLiquidPaise += asOfMap.get(a.id) || 0;
    }

    const minReservePaise = Number.isSafeInteger(settings?.min_cash_reserve_paise)
      ? Math.max(0, settings.min_cash_reserve_paise)
      : 0;

    return projectCashFlowReadiness({
      todayKey,
      horizonDays,
      startingLiquidPaise,
      minReservePaise,
      accounts,
      bills,
      recurringRules,
      loans,
      futureTransactions: futureTxs,
    });
  }
}

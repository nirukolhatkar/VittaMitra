import { generateUUID } from '../utils/uuid.js';
import { nowIsoUtc, toLocalDateString } from '../utils/date.js';
import { paiseToNumber, parseRupeesToPaise, sumPaise } from '../utils/money.js';
import { writeXlsxWorkbook } from '../../vendor/xlsx-lite.js';
import { buildDebtLedgerPostings } from './ledgerRules.js';
import { applyAccountBalanceDeltasInTx, buildAccountDeltaMap } from '../db/repositories/accountRepository.js';
import { DEBT_EVENT_TYPES, DEBT_STATUS, DEBT_TYPES } from '../db/repositories/debtRepository.js';

/**
 * Pure event-history reconciliation for a single debt.
 * Outstanding principal is ALWAYS calculated from active debt_events, never manually maintained.
 */
export function reconcileDebtFromEvents(debt, events = [], todayKey = toLocalDateString()) {
  const activeEvents = events
    .filter((e) => !e.deleted_at && e.debt_id === debt.id)
    .sort((a, b) => String(a.event_date || '').localeCompare(String(b.event_date || '')) || String(a.created_at || '').localeCompare(String(b.created_at || '')));

  let initialPrincipalPaise = 0;
  let adjustmentsPaise = 0;
  let principalRepaidPaise = 0;
  let writtenOffOrForgivenPaise = 0;
  let interestTotalPaise = 0;

  for (const ev of activeEvents) {
    const p = Number(ev.principal_paise) || 0;
    const intr = Number(ev.interest_paise) || 0;
    interestTotalPaise += intr;

    if (ev.event_type === DEBT_EVENT_TYPES.LENT || ev.event_type === DEBT_EVENT_TYPES.BORROWED) {
      initialPrincipalPaise += p;
    } else if (ev.event_type === DEBT_EVENT_TYPES.PRINCIPAL_RECEIVED || ev.event_type === DEBT_EVENT_TYPES.PRINCIPAL_PAID) {
      principalRepaidPaise += p;
    } else if (ev.event_type === DEBT_EVENT_TYPES.PRINCIPAL_ADJUSTMENT) {
      adjustmentsPaise += p; // can be positive or negative
    } else if (ev.event_type === DEBT_EVENT_TYPES.DEBT_WRITTEN_OFF || ev.event_type === DEBT_EVENT_TYPES.DEBT_FORGIVEN) {
      writtenOffOrForgivenPaise += p;
    }
  }

  // Fallback to debt.original_principal_paise only if no initial event exists yet
  const basePrincipalPaise = initialPrincipalPaise > 0 ? initialPrincipalPaise : (debt.original_principal_paise || 0);
  const outstandingPrincipalPaise = Math.max(
    0,
    basePrincipalPaise + adjustmentsPaise - principalRepaidPaise - writtenOffOrForgivenPaise
  );

  const effectivePrincipal = Math.max(1, basePrincipalPaise + Math.max(0, adjustmentsPaise));
  const progressPct = Math.min(
    100,
    Math.max(0, Math.round(((principalRepaidPaise + writtenOffOrForgivenPaise) / effectivePrincipal) * 100))
  );

  let status = DEBT_STATUS.ACTIVE;
  if (outstandingPrincipalPaise === 0) {
    status = writtenOffOrForgivenPaise > 0 && principalRepaidPaise < basePrincipalPaise
      ? DEBT_STATUS.WRITTEN_OFF
      : DEBT_STATUS.SETTLED;
  } else if (debt.expected_repayment_date && debt.expected_repayment_date < todayKey) {
    status = DEBT_STATUS.OVERDUE;
  } else if (principalRepaidPaise > 0 || writtenOffOrForgivenPaise > 0) {
    status = DEBT_STATUS.PARTIALLY_SETTLED;
  }

  return {
    originalPrincipalPaise: basePrincipalPaise,
    adjustmentsPaise,
    principalRepaidPaise,
    writtenOffOrForgivenPaise,
    outstandingPrincipalPaise,
    interestTotalPaise,
    progressPct,
    status,
    eventCount: activeEvents.length,
    events: activeEvents,
  };
}

/**
 * VittaMitra Personal Debt Tracker Service.
 * - Integrates every financial debt event directly into the central transactions & ledger_postings stores.
 * - Never maintains a parallel account balance calculation.
 * - Enforces balanced double-entry postings atomically for create, edit, and delete.
 */
export class DebtService {
  constructor(db, repos, services) {
    this.db = db;
    this.repos = repos;
    this.services = services;
  }

  async _resolveInterestCategory(type) {
    const targetName = type === 'income' ? 'Interest Income' : 'Interest Expense';
    const existing = await this.repos.categories.list({ type, includeArchived: true });
    const match = existing.find((c) => c.name.toLowerCase() === targetName.toLowerCase());
    if (match) return match.id;
    const created = await this.repos.categories.createCategory({
      name: targetName,
      type,
      icon: type === 'income' ? '💹' : '💸',
      color: type === 'income' ? '#22c55e' : '#f59e0b',
    });
    return created.id;
  }

  async _writeDebtLedgerTx({
    debtId,
    debtType,
    eventType,
    amountPaise,
    accountId = null,
    date,
    time = '12:00',
    description,
    notes = '',
    familyMemberId = null,
  }) {
    const account = accountId ? await this.repos.accounts.getById(accountId) : null;
    if (accountId && !account) throw new Error('Please select a valid account.');

    const normalizedDate = String(date || toLocalDateString()).slice(0, 10);
    const cleanTime = /^\d{2}:\d{2}$/.test(String(time || '')) ? `${time}:00` : '12:00:00';
    const localTs = `${normalizedDate} ${cleanTime}`;
    const txId = generateUUID();
    const now = nowIsoUtc();

    const rawPostings = buildDebtLedgerPostings({
      transactionId: txId,
      debtId,
      debtType,
      eventType,
      amountPaise,
      account,
    });

    const txRecord = {
      id: txId,
      user_id: null,
      type: 'debt',
      debt_id: debtId,
      debt_event_type: eventType,
      amount_paise: Math.abs(amountPaise),
      date_key: normalizedDate,
      occurred_at_local: localTs,
      category_id: null,
      account_id: account ? account.id : (debtType === 'RECEIVABLE' ? `debt_receivable:${debtId}` : `debt_payable:${debtId}`),
      to_account_id: null,
      description: String(description || '').trim(),
      notes: String(notes || '').trim(),
      family_member_id: familyMemberId || null,
      reference_no: '',
      is_split: false,
      recurring_rule_id: null,
      bill_id: null,
      import_batch_id: null,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    };

    const postingRecords = rawPostings.map((p) => ({
      ...p,
      id: generateUUID(),
      user_id: null,
      occurred_at_local: localTs,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const stores = ['transactions', 'ledger_postings', 'accounts', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').add(txRecord);
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: txRecord.id,
        operation: 'insert',
        version: txRecord.version,
        payload: txRecord,
        retry_count: 0,
        last_error: null,
        queued_at: now,
      });
      for (const p of postingRecords) {
        await this.db.table('ledger_postings').add(p);
        await this.db.table('sync_queue').add({
          table_name: 'ledger_postings',
          record_id: p.id,
          operation: 'insert',
          version: p.version,
          payload: p,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }
      await applyAccountBalanceDeltasInTx(this.db, buildAccountDeltaMap(postingRecords));
    });

    return { transaction: txRecord, postings: postingRecords };
  }

  async _syncDebtStatus(debtId) {
    const debt = await this.repos.debts.getById(debtId);
    if (!debt) return null;
    const events = await this.repos.debts.listEvents(debtId);
    const rec = reconcileDebtFromEvents(debt, events);
    if (debt.status !== rec.status) {
      await this.repos.debts.update(debt.id, { status: rec.status });
    }
    return { ...debt, status: rec.status, reconciliation: rec };
  }

  /**
   * Create a new Debt agreement (Lend Money = RECEIVABLE, Borrow Money = PAYABLE)
   * and atomically post the initial LENT / BORROWED ledger entry.
   */
  async createDebt({
    debt_type,
    counterparty_name,
    counterparty_contact = '',
    amount_rupees,
    amount_paise = null,
    account_id,
    date = toLocalDateString(),
    time = '12:00',
    expected_repayment_date = null,
    interest_rate = null,
    family_member_id = null,
    description = '',
    notes = '',
    idempotency_key = null,
  }) {
    if (![DEBT_TYPES.RECEIVABLE, DEBT_TYPES.PAYABLE].includes(debt_type)) {
      throw new Error('Debt type must be RECEIVABLE or PAYABLE.');
    }
    const cleanName = String(counterparty_name || '').trim();
    if (!cleanName) throw new Error("Person's name is required.");

    const principalPaise =
      amount_paise !== null
        ? Number(amount_paise)
        : parseRupeesToPaise(amount_rupees, { allowZero: false, allowNegative: false });
    if (!Number.isSafeInteger(principalPaise) || principalPaise <= 0) {
      throw new Error('Amount must be greater than ₹0.00.');
    }
    if (!account_id) throw new Error('Please select a source/destination account.');

    if (idempotency_key) {
      const existingEv = await this.repos.debts.findEventByIdempotencyKey(idempotency_key);
      if (existingEv) {
        const existingDebt = await this.getDebtDetail(existingEv.debt_id);
        return { debt: existingDebt, event: existingEv, duplicatePrevented: true };
      }
    }

    const startDate = String(date || toLocalDateString()).slice(0, 10);
    const isLent = debt_type === DEBT_TYPES.RECEIVABLE;
    const eventType = isLent ? DEBT_EVENT_TYPES.LENT : DEBT_EVENT_TYPES.BORROWED;

    const debt = await this.repos.debts.create({
      counterparty_name: cleanName,
      counterparty_contact: String(counterparty_contact || '').trim(),
      debt_type,
      original_principal_paise: principalPaise,
      interest_rate: interest_rate !== null && String(interest_rate).trim() !== '' ? Number(interest_rate) : null,
      start_date: startDate,
      expected_repayment_date: expected_repayment_date || null,
      family_member_id: family_member_id || null,
      description: String(description || '').trim() || `${isLent ? 'Lent to' : 'Borrowed from'} ${cleanName}`,
      notes: String(notes || '').trim(),
      status: DEBT_STATUS.ACTIVE,
      reminder_dismissed: false,
    });

    const { transaction } = await this._writeDebtLedgerTx({
      debtId: debt.id,
      debtType: debt_type,
      eventType,
      amountPaise: principalPaise,
      accountId: account_id,
      date: startDate,
      time,
      description: debt.description,
      notes: debt.notes,
      familyMemberId: family_member_id || null,
    });

    const event = await this.repos.debts.events.create({
      debt_id: debt.id,
      transaction_id: transaction.id,
      interest_transaction_id: null,
      event_type: eventType,
      principal_paise: principalPaise,
      interest_paise: 0,
      account_id,
      event_date: startDate,
      notes: debt.notes,
      idempotency_key: idempotency_key || `${debt.id}:${eventType}:${startDate}:${principalPaise}`,
    });

    const updated = await this._syncDebtStatus(debt.id);
    return { debt: updated, event, transaction };
  }

  /**
   * Record a flexible repayment (full or partial, optional split between principal and interest).
   * - Principal posts as balanced `type: 'debt'` journal entry (no income/expense distortion).
   * - Interest posts atomically as `income` (Interest Income) or `expense` (Interest Expense).
   */
  async recordRepayment(
    debtId,
    {
      account_id,
      principal_rupees = '0',
      principal_paise = null,
      interest_rupees = '0',
      interest_paise = null,
      date = toLocalDateString(),
      time = '12:00',
      notes = '',
      idempotency_key = null,
    }
  ) {
    const debt = await this.repos.debts.getById(debtId);
    if (!debt) throw new Error('Debt record not found.');
    if (!account_id) throw new Error('Please select a bank, cash, or wallet account.');

    if (idempotency_key) {
      const dup = await this.repos.debts.findEventByIdempotencyKey(idempotency_key);
      if (dup) {
        return { event: dup, debt: await this.getDebtDetail(debtId), duplicatePrevented: true };
      }
    }

    const pPaise =
      principal_paise !== null
        ? Number(principal_paise)
        : parseRupeesToPaise(principal_rupees || '0', { allowZero: true, allowNegative: false });
    const iPaise =
      interest_paise !== null
        ? Number(interest_paise)
        : parseRupeesToPaise(interest_rupees || '0', { allowZero: true, allowNegative: false });

    if (pPaise <= 0 && iPaise <= 0) {
      throw new Error('Enter a principal and/or interest amount greater than ₹0.00.');
    }

    const existingEvents = await this.repos.debts.listEvents(debtId);
    const currentRec = reconcileDebtFromEvents(debt, existingEvents);
    if (pPaise > currentRec.outstandingPrincipalPaise) {
      throw new Error('Principal repayment cannot exceed the outstanding principal balance.');
    }

    const isReceivable = debt.debt_type === DEBT_TYPES.RECEIVABLE;
    const eventDate = String(date || toLocalDateString()).slice(0, 10);
    const cleanNotes = String(notes || '').trim();

    let principalTx = null;
    let interestTx = null;
    let eventType;

    if (pPaise > 0) {
      eventType = isReceivable ? DEBT_EVENT_TYPES.PRINCIPAL_RECEIVED : DEBT_EVENT_TYPES.PRINCIPAL_PAID;
      const res = await this._writeDebtLedgerTx({
        debtId: debt.id,
        debtType: debt.debt_type,
        eventType,
        amountPaise: pPaise,
        accountId: account_id,
        date: eventDate,
        time,
        description: `${isReceivable ? 'Repayment from' : 'Repayment to'} ${debt.counterparty_name}`,
        notes: cleanNotes,
        familyMemberId: debt.family_member_id || null,
      });
      principalTx = res.transaction;
    }

    if (iPaise > 0) {
      const intEventType = isReceivable ? DEBT_EVENT_TYPES.INTEREST_RECEIVED : DEBT_EVENT_TYPES.INTEREST_PAID;
      if (!eventType) eventType = intEventType;
      const txType = isReceivable ? 'income' : 'expense';
      const catId = await this._resolveInterestCategory(txType);
      interestTx = await this.services.transactions.createTransaction({
        type: txType,
        amount_paise: iPaise,
        date: eventDate,
        time,
        category_id: catId,
        account_id,
        description: `${isReceivable ? 'Interest received from' : 'Interest paid to'} ${debt.counterparty_name}`,
        notes: cleanNotes || `Debt interest (${debt.description})`,
        family_member_id: debt.family_member_id || null,
      });
      // Tag the regular income/expense transaction with debt metadata
      const curIntTx = await this.db.table('transactions').get(interestTx.id);
      if (curIntTx) {
        await this.db.table('transactions').put({ ...curIntTx, debt_id: debt.id, debt_event_type: intEventType });
      }
    }

    const event = await this.repos.debts.events.create({
      debt_id: debt.id,
      transaction_id: principalTx ? principalTx.id : interestTx.id,
      interest_transaction_id: principalTx && interestTx ? interestTx.id : null,
      event_type: eventType,
      principal_paise: pPaise,
      interest_paise: iPaise,
      account_id,
      event_date: eventDate,
      notes: cleanNotes,
      idempotency_key: idempotency_key || generateUUID(),
    });

    const updatedDebt = await this._syncDebtStatus(debt.id);
    return { debt: updatedDebt, event, principalTx, interestTx };
  }

  /**
   * Record standalone interest received (for receivable) or paid (for payable).
   */
  async recordInterest(debtId, { account_id, interest_rupees, interest_paise = null, date = toLocalDateString(), time = '12:00', notes = '', idempotency_key = null }) {
    return this.recordRepayment(debtId, {
      account_id,
      principal_paise: 0,
      interest_rupees,
      interest_paise,
      date,
      time,
      notes,
      idempotency_key,
    });
  }

  /**
   * Auditable Principal Adjustment or Write-Off / Forgiveness.
   * Balances can never be edited directly without creating an auditable event + balanced posting.
   */
  async recordAdjustmentOrWriteOff(
    debtId,
    {
      event_type, // 'PRINCIPAL_ADJUSTMENT' | 'DEBT_WRITTEN_OFF' | 'DEBT_FORGIVEN'
      amount_rupees,
      amount_paise = null,
      date = toLocalDateString(),
      notes = '',
      idempotency_key = null,
    }
  ) {
    const debt = await this.repos.debts.getById(debtId);
    if (!debt) throw new Error('Debt record not found.');

    if (idempotency_key) {
      const dup = await this.repos.debts.findEventByIdempotencyKey(idempotency_key);
      if (dup) return { event: dup, debt: await this.getDebtDetail(debtId), duplicatePrevented: true };
    }

    const allowNeg = event_type === DEBT_EVENT_TYPES.PRINCIPAL_ADJUSTMENT;
    const amtPaise =
      amount_paise !== null
        ? Number(amount_paise)
        : parseRupeesToPaise(amount_rupees, { allowZero: false, allowNegative: allowNeg });
    if (!Number.isSafeInteger(amtPaise) || amtPaise === 0) {
      throw new Error('Adjustment amount must be non-zero.');
    }

    const eventDate = String(date || toLocalDateString()).slice(0, 10);
    const labelMap = {
      [DEBT_EVENT_TYPES.PRINCIPAL_ADJUSTMENT]: `Principal adjustment (${debt.counterparty_name})`,
      [DEBT_EVENT_TYPES.DEBT_WRITTEN_OFF]: `Debt written off (${debt.counterparty_name})`,
      [DEBT_EVENT_TYPES.DEBT_FORGIVEN]: `Debt forgiven (${debt.counterparty_name})`,
    };

    const { transaction } = await this._writeDebtLedgerTx({
      debtId: debt.id,
      debtType: debt.debt_type,
      eventType: event_type,
      amountPaise: amtPaise,
      accountId: null,
      date: eventDate,
      description: labelMap[event_type] || `Debt adjustment (${debt.counterparty_name})`,
      notes,
      familyMemberId: debt.family_member_id || null,
    });

    const event = await this.repos.debts.events.create({
      debt_id: debt.id,
      transaction_id: transaction.id,
      interest_transaction_id: null,
      event_type,
      principal_paise: amtPaise,
      interest_paise: 0,
      account_id: null,
      event_date: eventDate,
      notes: String(notes || '').trim(),
      idempotency_key: idempotency_key || generateUUID(),
    });

    const updatedDebt = await this._syncDebtStatus(debt.id);
    return { debt: updatedDebt, event, transaction };
  }

  /**
   * Edit descriptive debt metadata ONLY (never alters financial history or outstanding balance).
   */
  async editDebtDetails(debtId, patch) {
    const allowed = {};
    if (patch.counterparty_name !== undefined) {
      const clean = String(patch.counterparty_name).trim();
      if (!clean) throw new Error("Person's name is required.");
      allowed.counterparty_name = clean;
    }
    if (patch.counterparty_contact !== undefined) allowed.counterparty_contact = String(patch.counterparty_contact || '').trim();
    if (patch.expected_repayment_date !== undefined) allowed.expected_repayment_date = patch.expected_repayment_date || null;
    if (patch.interest_rate !== undefined) {
      allowed.interest_rate = patch.interest_rate !== null && String(patch.interest_rate).trim() !== '' ? Number(patch.interest_rate) : null;
    }
    if (patch.family_member_id !== undefined) allowed.family_member_id = patch.family_member_id || null;
    if (patch.description !== undefined) allowed.description = String(patch.description || '').trim();
    if (patch.notes !== undefined) allowed.notes = String(patch.notes || '').trim();
    if (patch.reminder_dismissed !== undefined) allowed.reminder_dismissed = Boolean(patch.reminder_dismissed);

    await this.repos.debts.update(debtId, allowed);
    return this._syncDebtStatus(debtId);
  }

  /**
   * Atomically edit a debt event and update its linked transaction & ledger postings.
   */
  async editDebtEvent(eventId, { principal_paise = null, interest_paise = null, event_date = null, account_id = null, notes = null }) {
    const ev = await this.repos.debts.getEventById(eventId);
    if (!ev) throw new Error('Debt event not found.');
    const debt = await this.repos.debts.getById(ev.debt_id);
    if (!debt) throw new Error('Parent debt not found.');

    const nextDate = event_date ? String(event_date).slice(0, 10) : ev.event_date;
    const nextNotes = notes !== null ? String(notes).trim() : ev.notes;
    const nextPrincipal = principal_paise !== null ? Number(principal_paise) : ev.principal_paise;
    const nextInterest = interest_paise !== null ? Number(interest_paise) : ev.interest_paise;
    const nextAccountId = account_id || ev.account_id;

    // Reverse old linked transactions cleanly
    if (ev.transaction_id) {
      await this.services.transactions.softDeleteTransaction(ev.transaction_id);
    }
    if (ev.interest_transaction_id) {
      await this.services.transactions.softDeleteTransaction(ev.interest_transaction_id);
    }

    const isReceivable = debt.debt_type === DEBT_TYPES.RECEIVABLE;
    let newPrimaryTxId = null;
    let newInterestTxId = null;

    if (nextPrincipal !== 0) {
      const principalEventType =
        ev.event_type === DEBT_EVENT_TYPES.INTEREST_RECEIVED
          ? DEBT_EVENT_TYPES.PRINCIPAL_RECEIVED
          : ev.event_type === DEBT_EVENT_TYPES.INTEREST_PAID
            ? DEBT_EVENT_TYPES.PRINCIPAL_PAID
            : ev.event_type;
      const res = await this._writeDebtLedgerTx({
        debtId: debt.id,
        debtType: debt.debt_type,
        eventType: principalEventType,
        amountPaise: nextPrincipal,
        accountId: nextAccountId,
        date: nextDate,
        description: debt.description,
        notes: nextNotes,
        familyMemberId: debt.family_member_id || null,
      });
      newPrimaryTxId = res.transaction.id;
    }

    if (nextInterest > 0) {
      const txType = isReceivable ? 'income' : 'expense';
      const intEventType = isReceivable ? DEBT_EVENT_TYPES.INTEREST_RECEIVED : DEBT_EVENT_TYPES.INTEREST_PAID;
      const catId = await this._resolveInterestCategory(txType);
      const intTx = await this.services.transactions.createTransaction({
        type: txType,
        amount_paise: nextInterest,
        date: nextDate,
        time: '12:00',
        category_id: catId,
        account_id: nextAccountId,
        description: `${isReceivable ? 'Interest received from' : 'Interest paid to'} ${debt.counterparty_name}`,
        notes: nextNotes,
        family_member_id: debt.family_member_id || null,
      });
      const curIntTx = await this.db.table('transactions').get(intTx.id);
      if (curIntTx) {
        await this.db.table('transactions').put({ ...curIntTx, debt_id: debt.id, debt_event_type: intEventType });
      }
      if (newPrimaryTxId) newInterestTxId = intTx.id;
      else newPrimaryTxId = intTx.id;
    }

    const updatedEvent = await this.repos.debts.events.update(ev.id, {
      transaction_id: newPrimaryTxId,
      interest_transaction_id: newInterestTxId,
      principal_paise: nextPrincipal,
      interest_paise: nextInterest,
      account_id: nextAccountId,
      event_date: nextDate,
      notes: nextNotes,
    });

    const updatedDebt = await this._syncDebtStatus(debt.id);
    return { debt: updatedDebt, event: updatedEvent };
  }

  /**
   * Soft-delete a debt event and atomically reverse its linked ledger transaction(s).
   */
  async deleteDebtEvent(eventId) {
    const ev = await this.repos.debts.getEventById(eventId);
    if (!ev) return null;

    if (ev.transaction_id) {
      await this.services.transactions.softDeleteTransaction(ev.transaction_id);
    }
    if (ev.interest_transaction_id) {
      await this.services.transactions.softDeleteTransaction(ev.interest_transaction_id);
    }
    await this.repos.debts.events.softDelete(ev.id);
    return this._syncDebtStatus(ev.debt_id);
  }

  /**
   * Prevent deletion of a debt if active financial history exists (protects audit trail).
   */
  async deleteDebt(debtId) {
    const activeEvents = await this.repos.debts.listEvents(debtId);
    if (activeEvents.length > 0) {
      throw new Error(
        `Cannot delete this debt while ${activeEvents.length} linked financial event(s) exist. Delete or reverse events first to preserve the audit trail.`
      );
    }
    return this.repos.debts.softDelete(debtId);
  }

  async dismissReminder(debtId) {
    return this.repos.debts.update(debtId, { reminder_dismissed: true });
  }

  async getDebtDetail(debtId, todayKey = toLocalDateString()) {
    const debt = await this.repos.debts.getById(debtId);
    if (!debt) return null;
    const events = await this.repos.debts.listEvents(debtId);
    const rec = reconcileDebtFromEvents(debt, events, todayKey);
    return { ...debt, status: rec.status, reconciliation: rec };
  }

  async getDashboardSummary(filters = {}, todayKey = toLocalDateString()) {
    const [debts, allEvents] = await Promise.all([
      this.repos.debts.listDebts(),
      this.repos.debts.listEvents(),
    ]);

    const eventsByDebt = new Map();
    for (const ev of allEvents) {
      if (!eventsByDebt.has(ev.debt_id)) eventsByDebt.set(ev.debt_id, []);
      eventsByDebt.get(ev.debt_id).push(ev);
    }

    const enrichedAll = debts.map((d) => {
      const rec = reconcileDebtFromEvents(d, eventsByDebt.get(d.id) || [], todayKey);
      return { ...d, status: rec.status, reconciliation: rec };
    });

    let totalReceivablesPaise = 0;
    let totalPayablesPaise = 0;
    let overdueReceivablesPaise = 0;
    let overduePayablesPaise = 0;
    let totalLentPaise = 0;
    let totalBorrowedPaise = 0;
    let totalPrincipalRecoveredPaise = 0;
    let totalPrincipalRepaidPaise = 0;
    const personMap = new Map();
    const reminders = [];

    for (const d of enrichedAll) {
      const r = d.reconciliation;
      if (d.debt_type === DEBT_TYPES.RECEIVABLE) {
        totalLentPaise += r.originalPrincipalPaise;
        totalPrincipalRecoveredPaise += r.principalRepaidPaise;
        totalReceivablesPaise += r.outstandingPrincipalPaise;
        if (r.status === DEBT_STATUS.OVERDUE) overdueReceivablesPaise += r.outstandingPrincipalPaise;
      } else {
        totalBorrowedPaise += r.originalPrincipalPaise;
        totalPrincipalRepaidPaise += r.principalRepaidPaise;
        totalPayablesPaise += r.outstandingPrincipalPaise;
        if (r.status === DEBT_STATUS.OVERDUE) overduePayablesPaise += r.outstandingPrincipalPaise;
      }

      const pKey = d.counterparty_name.toLowerCase();
      if (!personMap.has(pKey)) {
        personMap.set(pKey, { name: d.counterparty_name, receivablePaise: 0, payablePaise: 0, netPaise: 0 });
      }
      const pEntry = personMap.get(pKey);
      if (d.debt_type === DEBT_TYPES.RECEIVABLE) pEntry.receivablePaise += r.outstandingPrincipalPaise;
      else pEntry.payablePaise += r.outstandingPrincipalPaise;
      pEntry.netPaise = pEntry.receivablePaise - pEntry.payablePaise;

      if (r.outstandingPrincipalPaise > 0 && d.expected_repayment_date && !d.reminder_dismissed) {
        reminders.push({
          debt: d,
          isOverdue: d.expected_repayment_date < todayKey,
          dueDate: d.expected_repayment_date,
        });
      }
    }

    reminders.sort((a, b) => a.dueDate.localeCompare(b.dueDate));

    // Apply dashboard filters
    const q = String(filters.search || '').trim().toLowerCase();
    const filtered = enrichedAll.filter((d) => {
      if (filters.direction && filters.direction !== 'all' && d.debt_type !== filters.direction) return false;
      if (filters.status && filters.status !== 'all') {
        if (filters.status === 'active' && ![DEBT_STATUS.ACTIVE, DEBT_STATUS.PARTIALLY_SETTLED, DEBT_STATUS.OVERDUE].includes(d.status)) return false;
        if (filters.status === 'settled' && ![DEBT_STATUS.SETTLED, DEBT_STATUS.WRITTEN_OFF].includes(d.status)) return false;
        if (filters.status === 'overdue' && d.status !== DEBT_STATUS.OVERDUE) return false;
      }
      if (filters.person && d.counterparty_name.toLowerCase() !== filters.person.toLowerCase()) return false;
      if (filters.familyMemberId && d.family_member_id !== filters.familyMemberId) return false;
      if (filters.startDate && d.start_date < filters.startDate) return false;
      if (filters.endDate && d.start_date > filters.endDate) return false;
      if (q) {
        const hay = `${d.counterparty_name} ${d.description || ''} ${d.notes || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const personWise = Array.from(personMap.values())
      .filter((p) => p.receivablePaise > 0 || p.payablePaise > 0)
      .sort((a, b) => Math.abs(b.netPaise) - Math.abs(a.netPaise));

    return {
      debts: filtered,
      allDebts: enrichedAll,
      totalReceivablesPaise,
      totalPayablesPaise,
      netDebtPositionPaise: totalReceivablesPaise - totalPayablesPaise,
      overdueReceivablesPaise,
      overduePayablesPaise,
      totalLentPaise,
      totalBorrowedPaise,
      totalPrincipalRecoveredPaise,
      totalPrincipalRepaidPaise,
      personWise,
      reminders,
    };
  }

  /**
   * Export Debt Register (Excel .xlsx and CSV) with all 10 required columns.
   */
  async buildDebtRegisterRows() {
    const summary = await this.getDashboardSummary();
    const headers = [
      'Debt ID',
      'Counterparty',
      'Debt Type',
      'Original Principal',
      'Principal Repaid',
      'Outstanding Principal',
      'Interest Received/Paid',
      'Start Date',
      'Expected Repayment Date',
      'Status',
    ];
    const rows = summary.allDebts.map((d) => [
      d.id,
      d.counterparty_name,
      d.debt_type,
      paiseToNumber(d.reconciliation.originalPrincipalPaise),
      paiseToNumber(d.reconciliation.principalRepaidPaise),
      paiseToNumber(d.reconciliation.outstandingPrincipalPaise),
      paiseToNumber(d.reconciliation.interestTotalPaise),
      d.start_date || '',
      d.expected_repayment_date || '',
      d.status,
    ]);
    return { headers, rows };
  }

  async exportDebtRegisterXlsx() {
    const { headers, rows } = await this.buildDebtRegisterRows();
    return {
      bytes: writeXlsxWorkbook({ sheetName: 'DebtRegister', headers, rows }),
      rowCount: rows.length,
    };
  }

  async exportDebtRegisterCsv() {
    const { headers, rows } = await this.buildDebtRegisterRows();
    const esc = (v) => {
      const s = v === null || v === undefined ? '' : String(v);
      return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const csv = [headers.map(esc).join(','), ...rows.map((r) => r.map(esc).join(','))].join('\r\n');
    return { csv, rowCount: rows.length };
  }
}

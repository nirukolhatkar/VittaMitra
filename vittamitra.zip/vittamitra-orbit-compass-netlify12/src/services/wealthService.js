import { toLocalDateString } from '../utils/date.js';
import { computeStandardEmiPaise } from '../db/repositories/loanRepository.js';

/**
 * Compute exact annualized XIRR using Newton-Raphson with bisection fallback.
 * @param {Array<{ date: string|Date, amount: number }>} cashflows
 *   Outflows (investments/SIPs) are negative; inflows (redemptions + terminal current value) are positive.
 * @returns {number|null} Annualized return percentage (e.g. 12.45 for 12.45%), or null if undefined.
 */
export function calculateXIRR(cashflows) {
  if (!Array.isArray(cashflows) || cashflows.length < 2) return null;
  const parsed = cashflows
    .map((cf) => ({
      t: cf.date instanceof Date ? cf.date.getTime() : new Date(`${String(cf.date).slice(0, 10)}T00:00:00Z`).getTime(),
      a: Number(cf.amount) || 0,
    }))
    .filter((cf) => !Number.isNaN(cf.t) && cf.a !== 0)
    .sort((x, y) => x.t - y.t);

  if (parsed.length < 2) return null;
  const hasNeg = parsed.some((p) => p.a < 0);
  const hasPos = parsed.some((p) => p.a > 0);
  if (!hasNeg || !hasPos) return null;

  const t0 = parsed[0].t;
  const spanDays = (parsed[parsed.length - 1].t - t0) / 86400000;
  if (spanDays < 1) return null;

  const npv = (rate) => {
    let sum = 0;
    for (const p of parsed) {
      const years = (p.t - t0) / (365 * 86400000);
      sum += p.a / Math.pow(1 + rate, years);
    }
    return sum;
  };

  const dNpv = (rate) => {
    let sum = 0;
    for (const p of parsed) {
      const years = (p.t - t0) / (365 * 86400000);
      if (years === 0) continue;
      sum += (-years * p.a) / Math.pow(1 + rate, years + 1);
    }
    return sum;
  };

  let rate = 0.12;
  for (let i = 0; i < 60; i += 1) {
    const f = npv(rate);
    if (Math.abs(f) < 1e-6) return Number((rate * 100).toFixed(2));
    const df = dNpv(rate);
    if (Math.abs(df) < 1e-10) break;
    const next = rate - f / df;
    if (!Number.isFinite(next) || next <= -0.99 || next > 50) break;
    if (Math.abs(next - rate) < 1e-7) return Number((next * 100).toFixed(2));
    rate = next;
  }

  // Bisection fallback for steep/volatile cashflows
  let low = -0.95;
  let high = 10.0;
  let fLow = npv(low);
  let fHigh = npv(high);
  if (fLow * fHigh > 0) return null;

  for (let i = 0; i < 80; i += 1) {
    const mid = (low + high) / 2;
    const fMid = npv(mid);
    if (Math.abs(fMid) < 1e-5 || Math.abs(high - low) < 1e-7) {
      return Number((mid * 100).toFixed(2));
    }
    if (fLow * fMid <= 0) {
      high = mid;
      fHigh = fMid;
    } else {
      low = mid;
      fLow = fMid;
    }
  }
  return Number((((low + high) / 2) * 100).toFixed(2));
}

function monthsBetween(startDateStr, endDateStr) {
  const s = new Date(`${String(startDateStr).slice(0, 10)}T00:00:00`);
  const e = new Date(`${String(endDateStr).slice(0, 10)}T00:00:00`);
  if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) return 0;
  return (e.getFullYear() - s.getFullYear()) * 12 + (e.getMonth() - s.getMonth()) + (e.getDate() - s.getDate()) / 30.4375;
}

/**
 * Forward projection & What-If simulator for an investment.
 * Supports starting corpus, monthly SIP, annual SIP step-up %, lump-sum top-up,
 * expected annual return %, and years ahead.
 */
export function simulateInvestmentWhatIf({
  currentValuePaise = 0,
  investedSoFarPaise = 0,
  monthlySipPaise = 0,
  extraMonthlySipPaise = 0,
  lumpSumTopUpPaise = 0,
  annualReturnPct = 12,
  annualStepUpPct = 0,
  years = 10,
  goalTargetPaise = 0,
}) {
  const yrs = Math.max(1, Math.min(40, Math.round(Number(years) || 10)));
  const monthlyRate = Math.max(0, Number(annualReturnPct) || 0) / 100 / 12;
  const stepUp = Math.max(0, Number(annualStepUpPct) || 0) / 100;

  let corpus = Math.max(0, Number(currentValuePaise) || 0) + Math.max(0, Number(lumpSumTopUpPaise) || 0);
  let totalInvested = Math.max(0, Number(investedSoFarPaise) || 0) + Math.max(0, Number(lumpSumTopUpPaise) || 0);
  let sip = Math.max(0, Number(monthlySipPaise) || 0) + Math.max(0, Number(extraMonthlySipPaise) || 0);

  const yearlyPoints = [{ year: 0, label: 'Now', corpusPaise: Math.round(corpus), investedPaise: Math.round(totalInvested) }];

  for (let y = 1; y <= yrs; y += 1) {
    for (let m = 1; m <= 12; m += 1) {
      corpus = corpus * (1 + monthlyRate) + sip;
      totalInvested += sip;
    }
    yearlyPoints.push({
      year: y,
      label: `Yr ${y}`,
      corpusPaise: Math.round(corpus),
      investedPaise: Math.round(totalInvested),
    });
    if (stepUp > 0) sip *= 1 + stepUp;
  }

  const finalCorpusPaise = Math.round(corpus);
  const finalInvestedPaise = Math.round(totalInvested);
  const wealthGainedPaise = finalCorpusPaise - finalInvestedPaise;
  const goalGapPaise = goalTargetPaise > 0 ? finalCorpusPaise - goalTargetPaise : 0;

  return {
    years: yrs,
    annualReturnPct: Number(annualReturnPct) || 0,
    finalCorpusPaise,
    finalInvestedPaise,
    wealthGainedPaise,
    goalTargetPaise,
    goalGapPaise,
    onTrackForGoal: goalTargetPaise > 0 ? finalCorpusPaise >= goalTargetPaise : null,
    yearlyPoints,
  };
}

/**
 * Evaluate an investment's ACTUAL standing vs. its ORIGINAL PLAN & GOAL:
 * - Computes where the investment SHOULD be today along its original plan curve
 * - Compares Actual Current Value vs. Planned Value Today (ahead / behind in ₹ and %)
 * - Projects final value at Goal Target Date (at Expected Return and at Actual XIRR)
 * - Calculates Required Monthly SIP to reach the goal target if currently behind
 */
export function evaluateInvestmentGoalPlan(inv, cashflows = [], todayStr = toLocalDateString()) {
  const startStr = inv.start_date || todayStr;
  const elapsedMonths = Math.max(0, monthsBetween(startStr, todayStr));
  const rPlanMonthly = Math.max(0, Number(inv.expected_annual_return_pct) || 0) / 100 / 12;

  // Build XIRR from actual cashflows + terminal current value
  const xirrFlows = [];
  for (const cf of cashflows) {
    if (cf.tx_type === 'buy' || cf.tx_type === 'sip') {
      xirrFlows.push({ date: cf.date_key, amount: -(Number(cf.amount_paise) || 0) });
    } else if (cf.tx_type === 'sell' || cf.tx_type === 'dividend') {
      xirrFlows.push({ date: cf.date_key, amount: Number(cf.amount_paise) || 0 });
    }
  }
  if (xirrFlows.length === 0 && (inv.invested_paise || 0) > 0) {
    xirrFlows.push({ date: startStr, amount: -inv.invested_paise });
  }
  if ((inv.current_value_paise || 0) > 0) {
    xirrFlows.push({ date: todayStr, amount: inv.current_value_paise });
  }
  const actualXirrPct = calculateXIRR(xirrFlows);

  // Expected Planned Value Today: compound each actual buy/sell cashflow at expected_annual_return_pct
  let plannedValueTodayPaise = 0;
  if (cashflows.length > 0) {
    for (const cf of cashflows) {
      const mElapsed = Math.max(0, monthsBetween(cf.date_key, todayStr));
      const factor = Math.pow(1 + rPlanMonthly, mElapsed);
      if (cf.tx_type === 'buy' || cf.tx_type === 'sip') {
        plannedValueTodayPaise += (Number(cf.amount_paise) || 0) * factor;
      } else if (cf.tx_type === 'sell') {
        plannedValueTodayPaise -= (Number(cf.amount_paise) || 0) * factor;
      }
    }
    plannedValueTodayPaise = Math.max(0, Math.round(plannedValueTodayPaise));
  } else {
    plannedValueTodayPaise = Math.round((inv.invested_paise || 0) * Math.pow(1 + rPlanMonthly, elapsedMonths));
  }

  const actualValuePaise = inv.current_value_paise || 0;
  const variancePaise = actualValuePaise - plannedValueTodayPaise;
  const variancePct = plannedValueTodayPaise > 0 ? Number(((variancePaise / plannedValueTodayPaise) * 100).toFixed(1)) : 0;

  let status = 'on_track';
  if (variancePct >= 3) status = 'ahead';
  else if (variancePct <= -3) status = 'behind';

  // Goal projection
  const hasGoal = (inv.goal_target_paise || 0) > 0 && Boolean(inv.goal_target_date);
  let remainingMonths = 0;
  let projectedAtGoalPlanRatePaise = actualValuePaise;
  let projectedAtGoalActualPacePaise = actualValuePaise;
  let requiredMonthlySipPaise = 0;
  let goalProgressPct = 0;

  if (hasGoal) {
    remainingMonths = Math.max(0, Math.round(monthsBetween(todayStr, inv.goal_target_date)));
    goalProgressPct = Math.min(100, Math.round((actualValuePaise / inv.goal_target_paise) * 100));

    const projectFuture = (startVal, sip, monthlyR, nMonths) => {
      if (nMonths <= 0) return startVal;
      if (monthlyR <= 0) return Math.round(startVal + sip * nMonths);
      const pow = Math.pow(1 + monthlyR, nMonths);
      return Math.round(startVal * pow + sip * ((pow - 1) / monthlyR));
    };

    projectedAtGoalPlanRatePaise = projectFuture(
      actualValuePaise,
      inv.monthly_sip_paise || 0,
      rPlanMonthly,
      remainingMonths
    );

    const paceRate = actualXirrPct !== null ? Math.max(-0.5, Math.min(0.6, actualXirrPct / 100)) / 12 : rPlanMonthly;
    projectedAtGoalActualPacePaise = projectFuture(
      actualValuePaise,
      inv.monthly_sip_paise || 0,
      paceRate,
      remainingMonths
    );

    // Solve required monthly SIP at expected plan rate to hit goal_target_paise
    if (remainingMonths > 0) {
      const fvOfCurrent =
        rPlanMonthly > 0
          ? actualValuePaise * Math.pow(1 + rPlanMonthly, remainingMonths)
          : actualValuePaise;
      const shortfall = inv.goal_target_paise - fvOfCurrent;
      if (shortfall > 0) {
        if (rPlanMonthly > 0) {
          const annuityFactor = (Math.pow(1 + rPlanMonthly, remainingMonths) - 1) / rPlanMonthly;
          requiredMonthlySipPaise = Math.ceil(shortfall / annuityFactor);
        } else {
          requiredMonthlySipPaise = Math.ceil(shortfall / remainingMonths);
        }
      }
    }
  }

  const gainPaise = actualValuePaise - (inv.invested_paise || 0);
  const absReturnPct = (inv.invested_paise || 0) > 0 ? Number(((gainPaise / inv.invested_paise) * 100).toFixed(2)) : 0;

  return {
    actualXirrPct,
    absReturnPct,
    gainPaise,
    plannedValueTodayPaise,
    variancePaise,
    variancePct,
    status, // 'ahead' | 'on_track' | 'behind'
    hasGoal,
    remainingMonths,
    goalProgressPct,
    projectedAtGoalPlanRatePaise,
    projectedAtGoalActualPacePaise,
    requiredMonthlySipPaise,
  };
}

/**
 * Loan Amortization & What-If Simulator (Extra Monthly EMI, One-Time Prepayment, Interest Rate Change).
 */
export function simulateLoanWhatIf({
  outstandingPaise,
  interestRatePct,
  emiPaise,
  remainingMonths = 120,
  extraMonthlyEmiPaise = 0,
  prepaymentPaise = 0,
  rateDeltaPct = 0,
}) {
  const runSchedule = (startBal, annualRate, monthlyPay, maxMonths = 600) => {
    let bal = Math.max(0, Math.round(startBal));
    const r = Math.max(0, annualRate) / 100 / 12;
    let totalInterest = 0;
    let months = 0;
    const yearlyBalances = [{ year: 0, label: 'Now', balancePaise: bal }];

    while (bal > 1 && months < maxMonths) {
      const interest = Math.round(bal * r);
      const pay = Math.max(monthlyPay, interest + 100); // Guard against negative amortization
      const principalPaid = Math.min(bal, Math.max(0, pay - interest));
      if (principalPaid <= 0) break;
      bal -= principalPaid;
      totalInterest += interest;
      months += 1;
      if (months % 12 === 0 || bal <= 1) {
        yearlyBalances.push({
          year: Math.ceil(months / 12),
          label: `Yr ${Math.ceil(months / 12)}`,
          balancePaise: Math.max(0, Math.round(bal)),
        });
      }
    }

    return {
      months,
      totalInterestPaise: Math.round(totalInterest),
      totalPaidPaise: Math.round(startBal + totalInterest),
      yearlyBalances,
    };
  };

  const baseEmi =
    emiPaise > 0
      ? emiPaise
      : computeStandardEmiPaise(outstandingPaise, interestRatePct, remainingMonths);

  const baseline = runSchedule(outstandingPaise, interestRatePct, baseEmi);

  const adjustedBal = Math.max(0, outstandingPaise - Math.max(0, prepaymentPaise));
  const adjustedRate = Math.max(0, Number(interestRatePct) + (Number(rateDeltaPct) || 0));
  const adjustedEmi = baseEmi + Math.max(0, extraMonthlyEmiPaise);
  const whatIf = runSchedule(adjustedBal, adjustedRate, adjustedEmi);

  const monthsSaved = Math.max(0, baseline.months - whatIf.months);
  const interestSavedPaise = Math.max(0, baseline.totalInterestPaise - whatIf.totalInterestPaise);

  return {
    baseEmiPaise: baseEmi,
    adjustedEmiPaise: adjustedEmi,
    adjustedRatePct: Number(adjustedRate.toFixed(2)),
    baseline,
    whatIf,
    monthsSaved,
    interestSavedPaise,
  };
}

export class WealthService {
  constructor(repos, services) {
    this.repos = repos;
    this.services = services;
  }

  async getPortfolioSummary(todayStr = toLocalDateString()) {
    const [investments, allCashflows] = await Promise.all([
      this.repos.investments.listAll(),
      this.repos.investments.listTransactions(),
    ]);

    const cfByInv = new Map();
    for (const cf of allCashflows) {
      if (!cfByInv.has(cf.investment_id)) cfByInv.set(cf.investment_id, []);
      cfByInv.get(cf.investment_id).push(cf);
    }

    let totalInvestedPaise = 0;
    let totalCurrentPaise = 0;
    let totalMonthlySipPaise = 0;
    const allPortfolioFlows = [];

    const enriched = investments.map((inv) => {
      const flows = cfByInv.get(inv.id) || [];
      const evalPlan = evaluateInvestmentGoalPlan(inv, flows, todayStr);

      totalInvestedPaise += inv.invested_paise || 0;
      totalCurrentPaise += inv.current_value_paise || 0;
      totalMonthlySipPaise += inv.monthly_sip_paise || 0;

      for (const f of flows) {
        if (f.tx_type === 'buy' || f.tx_type === 'sip') {
          allPortfolioFlows.push({ date: f.date_key, amount: -f.amount_paise });
        } else if (f.tx_type === 'sell' || f.tx_type === 'dividend') {
          allPortfolioFlows.push({ date: f.date_key, amount: f.amount_paise });
        }
      }

      return { ...inv, cashflows: flows, evaluation: evalPlan };
    });

    if (totalCurrentPaise > 0 && allPortfolioFlows.length > 0) {
      allPortfolioFlows.push({ date: todayStr, amount: totalCurrentPaise });
    }
    const portfolioXirrPct = calculateXIRR(allPortfolioFlows);
    const totalGainPaise = totalCurrentPaise - totalInvestedPaise;
    const absReturnPct = totalInvestedPaise > 0 ? Number(((totalGainPaise / totalInvestedPaise) * 100).toFixed(2)) : 0;

    return {
      investments: enriched,
      totalInvestedPaise,
      totalCurrentPaise,
      totalGainPaise,
      absReturnPct,
      portfolioXirrPct,
      totalMonthlySipPaise,
    };
  }

  async getNetWorthSummary(todayStr = toLocalDateString()) {
    const [accounts, portfolio, loans, snapshots, debtSummary] = await Promise.all([
      this.repos.accounts.list({ includeArchived: false }),
      this.getPortfolioSummary(todayStr),
      this.repos.loans.listAll(),
      this.repos.netWorthSnapshots.listAll(),
      this.services.debts
        ? this.services.debts.getDashboardSummary({}, todayStr)
        : Promise.resolve({ totalReceivablesPaise: 0, totalPayablesPaise: 0 }),
    ]);

    let liquidAssetsPaise = 0;
    let creditCardLiabilitiesPaise = 0;
    const assetBreakdown = [];

    for (const acc of accounts) {
      if (acc.type === 'credit_card') {
        const out = Math.max(0, acc.current_balance_paise || 0);
        creditCardLiabilitiesPaise += out;
      } else {
        liquidAssetsPaise += acc.current_balance_paise || 0;
      }
    }

    const activeLoans = loans.filter((l) => l.is_active !== false && (l.outstanding_paise || 0) > 0);
    const loanLiabilitiesPaise = activeLoans.reduce((s, l) => s + (l.outstanding_paise || 0), 0);
    const totalMonthlyEmiPaise = activeLoans.reduce((s, l) => s + (l.emi_paise || 0), 0);

    const totalInvestmentsPaise = portfolio.totalCurrentPaise;
    const totalReceivablesPaise = debtSummary.totalReceivablesPaise || 0;
    const totalPayablesPaise = debtSummary.totalPayablesPaise || 0;
    const totalAssetsPaise = liquidAssetsPaise + totalInvestmentsPaise + totalReceivablesPaise;
    const totalLiabilitiesPaise = creditCardLiabilitiesPaise + loanLiabilitiesPaise + totalPayablesPaise;
    const netWorthPaise = totalAssetsPaise - totalLiabilitiesPaise;

    if (liquidAssetsPaise > 0) assetBreakdown.push({ label: 'Bank, Wallet & Cash', value: liquidAssetsPaise, color: '#38bdf8' });
    if (totalInvestmentsPaise > 0) assetBreakdown.push({ label: 'Investments', value: totalInvestmentsPaise, color: '#22c55e' });
    if (totalReceivablesPaise > 0) assetBreakdown.push({ label: 'Debt Receivables (Lent)', value: totalReceivablesPaise, color: '#a855f7' });
    if (creditCardLiabilitiesPaise > 0) assetBreakdown.push({ label: 'Credit Card Dues', value: creditCardLiabilitiesPaise, color: '#f59e0b' });
    if (loanLiabilitiesPaise > 0) assetBreakdown.push({ label: 'Active Loans', value: loanLiabilitiesPaise, color: '#ef4444' });
    if (totalPayablesPaise > 0) assetBreakdown.push({ label: 'Debt Payables (Borrowed)', value: totalPayablesPaise, color: '#f43f5e' });

    return {
      liquidAssetsPaise,
      totalInvestmentsPaise,
      totalReceivablesPaise,
      totalAssetsPaise,
      creditCardLiabilitiesPaise,
      loanLiabilitiesPaise,
      totalPayablesPaise,
      totalLiabilitiesPaise,
      netWorthPaise,
      totalMonthlyEmiPaise,
      activeLoansCount: activeLoans.length,
      investmentsCount: portfolio.investments.length,
      assetBreakdown,
      snapshots,
    };
  }

  async recordNetWorthSnapshot(todayStr = toLocalDateString()) {
    const nw = await this.getNetWorthSummary(todayStr);
    return this.repos.netWorthSnapshots.upsertSnapshot({
      snapshot_date: todayStr,
      assets_paise: nw.liquidAssetsPaise,
      investments_paise: nw.totalInvestmentsPaise,
      liabilities_paise: nw.totalLiabilitiesPaise,
      net_worth_paise: nw.netWorthPaise,
    });
  }
}


/**
 * Pure Loan Repayment vs. Investment Allocation Simulator (Phase 5 / WS6).
 * Compares Strategy A (Prioritise Loan), Strategy B (Prioritise Investment), and
 * Strategy C (Split Allocation) with equal monthly cash commitment, optional prepayment
 * charges, loan tax shield, investment gains tax, liquidity check, and 3-scenario sensitivity.
 *
 * Strictly mathematical projection — never invents missing DB loan/investment data and
 * explicitly separates guaranteed contractual loan savings from uncertain market returns.
 */
export function simulateLoanVsInvestment({
  outstandingPaise = 0,
  annualLoanRatePct = 0,
  emiPaise = 0,
  remainingMonths = 0,
  existingInvestCorpusPaise = 0,
  existingMonthlySipPaise = 0,
  monthlySurplusPaise = 0,
  lumpSumSurplusPaise = 0,
  horizonYears = null,
  expectedReturnPct = 11,
  splitLoanPct = 50,
  prepaymentPenaltyPct = 0,
  loanTaxBenefitPct = 0,
  investmentTaxRatePct = 12.5,
  reinvestFreedEmi = true,
  liquidCashPaise = null,
  minCashReservePaise = 0,
}) {
  const safeOutstanding = Math.max(0, Math.round(outstandingPaise || 0));
  const safeLoanRate = Math.max(0, Number(annualLoanRatePct) || 0);
  const safeMonthlyLoanRate = safeLoanRate / 100 / 12;
  const safeEmi = Math.max(0, Math.round(emiPaise || 0));
  const safeSurplusMo = Math.max(0, Math.round(monthlySurplusPaise || 0));
  const safeLump = Math.max(0, Math.round(lumpSumSurplusPaise || 0));
  const safePenaltyPct = Math.max(0, Math.min(10, Number(prepaymentPenaltyPct) || 0));
  const safeLoanTaxPct = Math.max(0, Math.min(45, Number(loanTaxBenefitPct) || 0));
  const safeInvTaxPct = Math.max(0, Math.min(45, Number(investmentTaxRatePct) || 0));
  const safeSplitFrac = Math.max(0, Math.min(1, (Number(splitLoanPct) || 50) / 100));
  const safeBaseRet = Math.max(0, Math.min(30, Number(expectedReturnPct) || 0));

  // Estimate baseline loan payoff tenure first to pick default horizon if unspecified
  const runBaselineLoan = () => {
    let bal = safeOutstanding;
    let months = 0;
    let totalInterest = 0;
    let totalTaxShield = 0;
    while (bal > 0 && months < 600) {
      months += 1;
      const interest = Math.round(bal * safeMonthlyLoanRate);
      const shield = Math.round(interest * (safeLoanTaxPct / 100));
      const minPay = Math.max(safeEmi, interest + 100);
      const pay = Math.min(bal + interest, minPay);
      const principal = Math.max(0, pay - interest);
      bal = Math.max(0, bal - principal);
      totalInterest += interest;
      totalTaxShield += shield;
    }
    return {
      months,
      totalInterestPaise: totalInterest,
      totalTaxShieldPaise: totalTaxShield,
      netInterestPaise: Math.max(0, totalInterest - totalTaxShield),
    };
  };

  const baselineLoan = runBaselineLoan();
  const inferredYears = Math.max(1, Math.min(30, Math.ceil((remainingMonths || baselineLoan.months || 60) / 12)));
  const effHorizonYears = Math.max(1, Math.min(30, Number(horizonYears) || inferredYears));
  const horizonMonths = effHorizonYears * 12;

  const runStrategy = (loanFraction, annualReturnPct, label) => {
    const monthlyInvRate = Math.max(0, annualReturnPct) / 100 / 12;
    let loanBal = safeOutstanding;
    let corpus = Math.max(0, Math.round(existingInvestCorpusPaise || 0));
    let totalInvested = corpus;
    let totalInterest = 0;
    let totalTaxShield = 0;
    let totalPrepayCharges = 0;
    let payoffMonth = loanBal === 0 ? 0 : null;

    // t = 0 lump-sum allocation
    if (safeLump > 0) {
      const desiredLoanLump = Math.round(safeLump * loanFraction);
      const cappedLoanLump = Math.min(desiredLoanLump, loanBal);
      const charge = Math.round(cappedLoanLump * (safePenaltyPct / 100));
      const principalCut = Math.min(loanBal, Math.max(0, cappedLoanLump - charge));
      loanBal = Math.max(0, loanBal - principalCut);
      totalPrepayCharges += charge;
      const toInvestLump = Math.max(0, safeLump - cappedLoanLump);
      corpus += toInvestLump;
      totalInvested += toInvestLump;
      if (loanBal === 0 && payoffMonth === null) payoffMonth = 0;
    }

    const yearlyPoints = [
      {
        year: 0,
        loanOutstandingPaise: loanBal,
        grossCorpusPaise: Math.round(corpus),
        netWorthPaise: Math.round(corpus) - loanBal,
      },
    ];

    for (let m = 1; m <= horizonMonths; m += 1) {
      let investContrib = Math.max(0, Math.round(existingMonthlySipPaise || 0));

      if (loanBal > 0) {
        const interest = Math.round(loanBal * safeMonthlyLoanRate);
        const shield = Math.round(interest * (safeLoanTaxPct / 100));
        const desiredExtra = Math.round(safeSurplusMo * loanFraction);
        const extraCharge = Math.round(desiredExtra * (safePenaltyPct / 100));
        const effectiveExtra = Math.max(0, desiredExtra - extraCharge);
        const baseEmi = Math.max(safeEmi, interest + 100);
        const totalBudgetForLoan = baseEmi + effectiveExtra;
        const actualLoanPay = Math.min(loanBal + interest, totalBudgetForLoan);
        const principal = Math.max(0, actualLoanPay - interest);

        loanBal = Math.max(0, loanBal - principal);
        totalInterest += interest;
        totalTaxShield += shield;
        // Charge applies only to actual prepayment above base EMI
        const actualPrepayUsed = Math.max(0, actualLoanPay - baseEmi);
        const actualCharge = actualPrepayUsed > 0 ? Math.round(actualPrepayUsed * (safePenaltyPct / 100)) : 0;
        totalPrepayCharges += actualCharge;

        const unusedCash = Math.max(0, (safeEmi + safeSurplusMo) - actualLoanPay - actualCharge);
        investContrib += unusedCash;
        if (loanBal === 0 && payoffMonth === null) payoffMonth = m;
      } else {
        // Loan fully paid off before horizon end
        investContrib += reinvestFreedEmi
          ? safeEmi + safeSurplusMo
          : Math.round(safeSurplusMo * (1 - loanFraction));
      }

      corpus = corpus * (1 + monthlyInvRate) + investContrib;
      totalInvested += investContrib;

      if (m % 12 === 0 || m === horizonMonths) {
        const gCorpus = Math.round(corpus);
        yearlyPoints.push({
          year: Math.ceil(m / 12),
          loanOutstandingPaise: loanBal,
          grossCorpusPaise: gCorpus,
          netWorthPaise: gCorpus - loanBal,
        });
      }
    }

    const grossCorpusPaise = Math.round(corpus);
    const totalInvestedPaise = Math.round(totalInvested);
    const grossGainsPaise = Math.max(0, grossCorpusPaise - totalInvestedPaise);
    const estimatedInvTaxPaise = Math.round(grossGainsPaise * (safeInvTaxPct / 100));
    const postTaxCorpusPaise = grossCorpusPaise - estimatedInvTaxPaise;
    const endingLoanPaise = Math.round(loanBal);
    const projectedNetWorthPaise = postTaxCorpusPaise - endingLoanPaise;

    // Interest saved vs baseline over the simulated horizon
    const grossInterestSavedPaise = Math.max(0, baselineLoan.totalInterestPaise - totalInterest);
    const netInterestSavedPaise = Math.max(
      0,
      baselineLoan.netInterestPaise - (totalInterest - totalTaxShield) - totalPrepayCharges
    );
    const monthsSaved = payoffMonth !== null ? Math.max(0, baselineLoan.months - payoffMonth) : 0;

    return {
      label,
      loanFraction,
      annualReturnPct,
      payoffMonth,
      monthsSaved,
      endingLoanPaise,
      totalInterestPaidPaise: totalInterest,
      totalTaxShieldPaise: totalTaxShield,
      totalPrepayChargesPaise: totalPrepayCharges,
      grossInterestSavedPaise,
      netInterestSavedPaise,
      totalInvestedPaise,
      grossCorpusPaise,
      estimatedInvTaxPaise,
      postTaxCorpusPaise,
      projectedNetWorthPaise,
      yearlyPoints,
    };
  };

  const strategyA = runStrategy(1, safeBaseRet, 'Prioritise Loan Repayment');
  const strategyB = runStrategy(0, safeBaseRet, 'Prioritise Investment');
  const strategyC = runStrategy(safeSplitFrac, safeBaseRet, `Split (${Math.round(safeSplitFrac * 100)}% Loan / ${Math.round((1 - safeSplitFrac) * 100)}% Invest)`);

  // 3-scenario sensitivity analysis (Conservative -3%, Base, Optimistic +3%)
  const consRet = Math.max(1, Number((safeBaseRet - 3).toFixed(1)));
  const optRet = Math.min(30, Number((safeBaseRet + 3).toFixed(1)));
  const sensitivity = [
    {
      scenario: 'Conservative',
      returnPct: consRet,
      strategyA: runStrategy(1, consRet, 'A').projectedNetWorthPaise,
      strategyB: runStrategy(0, consRet, 'B').projectedNetWorthPaise,
      strategyC: runStrategy(safeSplitFrac, consRet, 'C').projectedNetWorthPaise,
    },
    {
      scenario: 'Base',
      returnPct: safeBaseRet,
      strategyA: strategyA.projectedNetWorthPaise,
      strategyB: strategyB.projectedNetWorthPaise,
      strategyC: strategyC.projectedNetWorthPaise,
    },
    {
      scenario: 'Optimistic',
      returnPct: optRet,
      strategyA: runStrategy(1, optRet, 'A').projectedNetWorthPaise,
      strategyB: runStrategy(0, optRet, 'B').projectedNetWorthPaise,
      strategyC: runStrategy(safeSplitFrac, optRet, 'C').projectedNetWorthPaise,
    },
  ];

  const effectivePostTaxLoanRatePct = Number((safeLoanRate * (1 - safeLoanTaxPct / 100)).toFixed(2));
  const liquidityAfterLumpPaise =
    liquidCashPaise !== null && Number.isSafeInteger(liquidCashPaise)
      ? liquidCashPaise - safeLump
      : null;
  const liquidityWarning =
    safeLump > 0 && liquidityAfterLumpPaise !== null && liquidityAfterLumpPaise < (minCashReservePaise || 0);

  return {
    horizonYears: effHorizonYears,
    effectivePostTaxLoanRatePct,
    baselineLoan,
    strategies: { A: strategyA, B: strategyB, C: strategyC },
    sensitivity,
    liquidityWarning,
    liquidityAfterLumpPaise,
    minCashReservePaise: minCashReservePaise || 0,
    assumptions: {
      expectedReturnPct: safeBaseRet,
      prepaymentPenaltyPct: safePenaltyPct,
      loanTaxBenefitPct: safeLoanTaxPct,
      investmentTaxRatePct: safeInvTaxPct,
      reinvestFreedEmi: Boolean(reinvestFreedEmi),
      splitLoanPct: Math.round(safeSplitFrac * 100),
    },
  };
}

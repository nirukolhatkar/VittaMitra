import { setPageContext } from '../../services/txContextClipboard.js';
import { escapeHtml } from '../../utils/dom.js';
import { getCategoryTransactionCounts, suggestCategoryEmoji } from '../../utils/categoryMatcher.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const viewState = {
  type: 'expense',
  showArchived: false,
};

export async function renderCategoriesView(container, ctx) {
  setPageContext(ctx, { sourceLabel: 'Categories' });
  const { db, repos } = ctx;
  const [tree, txCounts, activeSameType] = await Promise.all([
    repos.categories.listTree({
      type: viewState.type,
      includeArchived: viewState.showArchived,
    }),
    getCategoryTransactionCounts(db),
    repos.categories.list({ type: viewState.type, includeArchived: false }),
  ]);

  const fmtCount = (id) => {
    const n = txCounts.get(id) || 0;
    return `${n.toLocaleString('en-IN')} transaction${n === 1 ? '' : 's'}`;
  };

  container.innerHTML = `
    <div class="stack">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Categories</h2>
          <div class="compass-subtitle">Tap any category to open settings, archive, or reassign</div>
        </div>
      </div>
      <div class="toolbar">
        <div class="segmented" role="tablist" aria-label="Category type">
          <button type="button" data-cat-type="expense" class="${viewState.type === 'expense' ? 'active' : ''}">Expense</button>
          <button type="button" data-cat-type="income" class="${viewState.type === 'income' ? 'active' : ''}">Income</button>
        </div>

        <div class="row-actions">
          <label class="checkbox-row" style="font-size:0.84rem;">
            <input type="checkbox" id="toggle-archived-cats" ${viewState.showArchived ? 'checked' : ''}>
            <span>Show archived</span>
          </label>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-category">+ Add Category</button>
        </div>
      </div>

      ${
        tree.length === 0
          ? `<div class="empty-state">
              <div class="empty-state-icon">🏷️</div>
              <h3 class="empty-state-title">No ${viewState.type} categories</h3>
              <p class="empty-state-text">Create a category to organise your ${viewState.type} records.</p>
            </div>`
          : `<div class="list" id="category-list">
              ${tree
                .map(
                  (cat) => `
                  <div>
                    <div class="list-row grouped-row-clickable" data-open-cat-settings="${cat.id}" role="button" tabindex="0">
                      <div class="list-row-main">
                        <span class="avatar-badge" style="background:${escapeHtml(cat.color)}20; color:${escapeHtml(cat.color)};">
                          ${escapeHtml(cat.icon)}
                        </span>
                        <div>
                          <div class="item-title">
                            ${escapeHtml(cat.name)}
                            ${cat.is_archived ? '<span class="badge badge-muted">Archived</span>' : ''}
                          </div>
                          <div class="item-meta">
                            ${fmtCount(cat.id)}${cat.subcategories.length > 0 ? ` · ${cat.subcategories.length} sub` : ''}${cat.is_default ? ' · Default' : ''}
                          </div>
                        </div>
                      </div>
                      <span class="text-muted" style="font-size:1.2rem; padding-right:4px;" aria-hidden="true">›</span>
                    </div>

                    ${
                      cat.subcategories.length > 0
                        ? `<div class="subcategory-list">
                            ${cat.subcategories
                              .map(
                                (sub) => `
                                <div class="list-row grouped-row-clickable" data-open-cat-settings="${sub.id}" role="button" tabindex="0">
                                  <div class="list-row-main">
                                    <span class="avatar-badge" style="width:32px; height:32px; font-size:0.95rem; background:${escapeHtml(sub.color)}20;">
                                      ${escapeHtml(sub.icon)}
                                    </span>
                                    <div>
                                      <div class="item-title">
                                        ${escapeHtml(sub.name)}
                                        ${sub.is_archived ? '<span class="badge badge-muted">Archived</span>' : ''}
                                      </div>
                                      <div class="item-meta">${fmtCount(sub.id)} · Legacy subcategory of ${escapeHtml(cat.name)}</div>
                                    </div>
                                  </div>
                                  <span class="text-muted" style="font-size:1.15rem; padding-right:4px;" aria-hidden="true">›</span>
                                </div>`
                              )
                              .join('')}
                          </div>`
                        : ''
                    }
                  </div>`
                )
                .join('')}
            </div>`
      }
    </div>
  `;

  container.querySelectorAll('[data-cat-type]').forEach((btn) => {
    btn.addEventListener('click', () => {
      viewState.type = btn.getAttribute('data-cat-type');
      renderCategoriesView(container, ctx);
    });
  });

  container.querySelector('#toggle-archived-cats')?.addEventListener('change', (e) => {
    viewState.showArchived = e.target.checked;
    renderCategoriesView(container, ctx);
  });

  const openCategorySettings = async (existing = null) => {
    const isEdit = Boolean(existing);
    const refs = isEdit ? await repos.categories.countAllReferences(existing.id) : { total: 0 };
    const reassignTargets = isEdit
      ? activeSameType.filter((c) => c.id !== existing.id && !c.is_archived)
      : [];

    openModal({
      title: isEdit ? `${existing.icon || '🏷️'} ${existing.name}` : 'Add Category',
      bodyHtml: `
        <form id="category-form" class="stack" style="gap:12px;">
          <div class="form-group" style="margin:0;">
            <label class="form-label" for="cat-name">Category Name</label>
            <input id="cat-name" name="name" class="form-control" required maxlength="60"
              value="${escapeHtml(existing?.name || '')}" placeholder="e.g. Groceries, Broadband">
          </div>

          <div class="form-row">
            <div class="form-group" style="margin:0;">
              <label class="form-label" for="cat-icon">Icon (Emoji)</label>
              <div style="display:flex; gap:6px;">
                <input id="cat-icon" name="icon" class="form-control" maxlength="4"
                  value="${escapeHtml(existing?.icon || (viewState.type === 'income' ? '💰' : '🏷️'))}">
                <button type="button" class="btn btn-secondary btn-sm" id="btn-suggest-emoji" title="Suggest emoji from name">Auto</button>
              </div>
            </div>
            <div class="form-group" style="margin:0;">
              <label class="form-label" for="cat-color">Colour</label>
              <input id="cat-color" name="color" type="color" class="form-control" style="height:42px; padding:4px;"
                value="${escapeHtml(existing?.color || '#34d399')}">
            </div>
          </div>

          ${
            isEdit && existing.parent_id
              ? `<div class="card" style="padding:10px 12px; background:var(--bg-surface-elevated); display:flex; justify-content:space-between; align-items:center; gap:8px;">
                  <span class="item-meta">Legacy subcategory — promote to top-level for cleaner reports</span>
                  <button type="button" class="btn btn-secondary btn-sm" id="btn-promote-cat">Promote</button>
                </div>`
              : ''
          }

          <div class="modal-footer" style="margin-top:4px;">
            <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save Changes' : 'Create'}</button>
          </div>
        </form>

        ${
          isEdit
            ? `<div class="stack" style="gap:10px; margin-top:16px; padding-top:14px; border-top:1px solid var(--border-subtle);">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
                  <div>
                    <div class="item-title" style="font-size:0.86rem;">${existing.is_archived ? 'Restore Category' : 'Archive Category'}</div>
                    <div class="item-meta">Preserves history while hiding from new entries</div>
                  </div>
                  <button type="button" class="btn btn-secondary btn-sm" id="btn-cat-archive">
                    ${existing.is_archived ? 'Restore' : 'Archive'}
                  </button>
                </div>

                ${
                  refs.total === 0
                    ? `<div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
                        <div>
                          <div class="item-title text-danger" style="font-size:0.86rem;">Delete Category</div>
                          <div class="item-meta">No linked transactions or budgets</div>
                        </div>
                        <button type="button" class="btn btn-danger btn-sm" id="btn-cat-delete">Delete</button>
                      </div>`
                    : `<div class="stack" style="gap:8px; padding:10px 12px; background:var(--bg-surface-elevated); border-radius:var(--radius-md);">
                        <div class="item-title" style="font-size:0.84rem;">Reassign &amp; Delete (${refs.total.toLocaleString('en-IN')} linked record${refs.total === 1 ? '' : 's'})</div>
                        <div class="item-meta">To delete without losing history, move linked records to another active category first:</div>
                        ${
                          reassignTargets.length > 0
                            ? `<div style="display:flex; gap:8px; flex-wrap:wrap;">
                                <select id="cat-reassign-target" class="form-control" style="flex:1; min-width:150px;">
                                  ${reassignTargets.map((t) => `<option value="${t.id}">${escapeHtml(t.icon)} ${escapeHtml(t.name)}</option>`).join('')}
                                </select>
                                <button type="button" class="btn btn-danger btn-sm" id="btn-cat-reassign-delete">Reassign &amp; Delete</button>
                              </div>`
                            : `<div class="item-meta">Create another active ${existing.type} category first to enable reassignment.</div>`
                        }
                      </div>`
                }
              </div>`
            : ''
        }
      `,
      onMount: (panel, close) => {
        const form = panel.querySelector('#category-form');
        const nameInput = panel.querySelector('#cat-name');
        const iconInput = panel.querySelector('#cat-icon');

        panel.querySelector('#btn-suggest-emoji')?.addEventListener('click', () => {
          iconInput.value = suggestCategoryEmoji(nameInput.value, existing ? existing.type : viewState.type);
        });

        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          const payload = {
            name: fd.get('name'),
            type: existing ? existing.type : viewState.type,
            parent_id: existing ? existing.parent_id : null,
            icon: fd.get('icon') || suggestCategoryEmoji(fd.get('name'), existing ? existing.type : viewState.type),
            color: fd.get('color') || '#34d399',
          };
          try {
            if (isEdit) {
              await repos.categories.updateCategory(existing.id, payload);
              showToast('Category updated');
            } else {
              await repos.categories.createCategory(payload);
              showToast('Category created');
            }
            close();
            renderCategoriesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });

        panel.querySelector('#btn-promote-cat')?.addEventListener('click', async () => {
          try {
            await repos.categories.updateCategory(existing.id, { parent_id: null });
            close();
            showToast(`"${existing.name}" promoted to top-level category`);
            renderCategoriesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });

        panel.querySelector('#btn-cat-archive')?.addEventListener('click', async () => {
          try {
            await repos.categories.setArchived(existing.id, !existing.is_archived);
            close();
            showToast(existing.is_archived ? 'Category restored' : 'Category archived');
            renderCategoriesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });

        panel.querySelector('#btn-cat-delete')?.addEventListener('click', async () => {
          try {
            await repos.categories.deleteCategorySafe(existing.id);
            close();
            renderCategoriesView(container, ctx);
            showToast('Category deleted', {
              actionLabel: 'Undo',
              onAction: async () => {
                await repos.categories.restore(existing.id);
                renderCategoriesView(container, ctx);
                showToast('Category restored');
              },
            });
          } catch (err) {
            showToast(err.message, { type: 'error', durationMs: 4200 });
          }
        });

        panel.querySelector('#btn-cat-reassign-delete')?.addEventListener('click', async () => {
          const targetId = panel.querySelector('#cat-reassign-target')?.value;
          if (!targetId) return;
          try {
            const summary = await repos.categories.reassignAndDeleteCategory(existing.id, targetId);
            close();
            showToast(`Reassigned ${summary.transactions + summary.splits} transaction(s) and deleted "${existing.name}"`);
            renderCategoriesView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error', durationMs: 4200 });
          }
        });
      },
    });
  };

  container.querySelector('#btn-add-category')?.addEventListener('click', () => openCategorySettings());

  container.querySelectorAll('[data-open-cat-settings]').forEach((tile) => {
    const open = async () => {
      const cat = await repos.categories.getById(tile.getAttribute('data-open-cat-settings'));
      if (cat) openCategorySettings(cat);
    };
    tile.addEventListener('click', open);
    tile.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        open();
      }
    });
  });
}

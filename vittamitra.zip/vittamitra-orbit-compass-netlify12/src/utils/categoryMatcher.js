/**
 * Offline Canonical Category Matcher, Emoji Suggester & Performant Transaction Counter (Phase 3 / WS2).
 */

const CATEGORY_SYNONYMS = {
  'eating out': 'food dining',
  'dining out': 'food dining',
  'restaurant': 'food dining',
  'restaurants': 'food dining',
  'food': 'food dining',
  'food delivery': 'food dining',
  'grocery': 'groceries',
  'supermarket': 'groceries',
  'petrol': 'fuel',
  'diesel': 'fuel',
  'gas': 'fuel',
  'medical': 'health',
  'healthcare': 'health',
  'pharmacy': 'health',
  'medicine': 'health',
  'doctor': 'health',
  'hospital': 'health',
  'utility': 'bills utilities',
  'utilities': 'bills utilities',
  'electricity': 'bills utilities',
  'broadband': 'bills utilities',
  'internet': 'bills utilities',
  'wifi': 'bills utilities',
  'cab': 'transport',
  'taxi': 'transport',
  'auto': 'transport',
  'metro': 'transport',
  'commute': 'transport',
  'movie': 'entertainment',
  'ott': 'entertainment',
  'streaming': 'entertainment',
  'house rent': 'rent',
  'emi': 'loan',
  'emi loan': 'loan',
  'loan emi': 'loan',
  'salary': 'salary',
  'payroll': 'salary',
  'wages': 'salary',
  'refund': 'refunds',
  'cashback': 'refunds',
};

const EMOJI_KEYWORDS = [
  [/grocer|supermarket|mart|veggie|vegetable|fruit|milk|kirana/, '🛒'],
  [/food|dining|restaurant|cafe|coffee|tea|snack|lunch|dinner|breakfast|swiggy|zomato|eat/, '🍽️'],
  [/fuel|petrol|diesel|cng|ev charg/, '⛽'],
  [/transport|cab|uber|ola|rapido|auto|metro|bus|train|commute|parking|toll/, '🚕'],
  [/travel|flight|hotel|vacation|trip|holiday|air/, '✈️'],
  [/rent|housing|society|maintenance|lease/, '🏠'],
  [/electric|power|water|utility|utilities|bill|gas cylinder|piped gas|broadband|wifi|internet/, '💡'],
  [/mobile|phone|recharge|telecom|dth/, '📱'],
  [/health|medical|doctor|hospital|pharmacy|medicine|dental|clinic|lab/, '🏥'],
  [/education|school|college|tuition|course|book|exam|fee/, '🎓'],
  [/insurance|lic|policy|premium|term plan/, '🛡️'],
  [/emi|loan|mortgage|interest|credit card/, '🏦'],
  [/invest|sip|mutual fund|stock|equity|ppf|epf|nps|gold|fd|rd/, '📈'],
  [/shop|cloth|apparel|fashion|amazon|flipkart|myntra|electronics|gadget/, '🛍️'],
  [/entertain|movie|cinema|netflix|spotify|prime|ott|game|concert/, '🎬'],
  [/gym|fitness|sport|yoga|workout/, '🏋️'],
  [/salon|spa|groom|hair|beauty|personal care/, '💇'],
  [/pet|vet|dog|cat/, '🐾'],
  [/kid|child|baby|toy|daycare/, '🧸'],
  [/gift|wedding|festival|celebrat|party/, '🎁'],
  [/charity|donat|temple|ngo/, '🤝'],
  [/tax|gst|tds|itr/, '🧾'],
  [/bank charge|fee|penalty|atm/, '🏧'],
  [/repair|plumb|carpent|hardware|appliance|home/, '🔧'],
  [/salary|payroll|wage|paycheck/, '💼'],
  [/business|freelance|consult|client|invoice/, '🏢'],
  [/dividend|interest|yield|capital gain/, '💹'],
  [/refund|cashback|reimburse|rebate/, '↩️'],
  [/bonus|incentive|award/, '🏆'],
];

/**
 * Normalizes a category name for case-, whitespace-, punctuation-, and simple-plural-insensitive matching.
 */
export function normalizeCategoryKey(rawName) {
  let s = String(rawName || '')
    .toLowerCase()
    .replace(/[&/_\-.,]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!s) return '';
  const words = s.split(' ').map((w) => {
    if (w.length > 4 && w.endsWith('ies')) return `${w.slice(0, -3)}y`;
    if (w.length > 4 && w.endsWith('es') && !w.endsWith('fees')) return w.slice(0, -2);
    if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss')) return w.slice(0, -1);
    return w;
  });
  return words.join(' ');
}

/**
 * Deterministic offline emoji suggestion for a new category name.
 */
export function suggestCategoryEmoji(name, type = 'expense') {
  const lower = String(name || '').toLowerCase();
  for (const [pattern, emoji] of EMOJI_KEYWORDS) {
    if (pattern.test(lower)) return emoji;
  }
  return type === 'income' ? '💰' : '🏷️';
}

/**
 * Formats a clean title-cased display name for a newly suggested category.
 */
export function suggestCategoryName(rawName) {
  const cleaned = String(rawName || '').replace(/\s+/g, ' ').trim();
  if (!cleaned) return '';
  // Preserve user casing if already mixed-case; title-case all-lower or all-upper inputs
  if (cleaned === cleaned.toLowerCase() || cleaned === cleaned.toUpperCase()) {
    return cleaned.replace(/\b[a-z]/g, (ch) => ch.toUpperCase());
  }
  return cleaned;
}

/**
 * Matches imported category names against existing VittaMitra categories (same type),
 * avoiding duplicates from case, spacing, punctuation, pluralization, or common synonyms.
 */
export function proposeCategoryMappings(importedCategories, existingCategories) {
  const byType = { expense: [], income: [] };
  for (const c of existingCategories || []) {
    if (c.deleted_at) continue;
    if (c.type === 'expense' || c.type === 'income') byType[c.type].push(c);
  }

  const seenSource = new Set();
  const proposals = [];

  for (const item of importedCategories || []) {
    const rawName = String(item?.name || '').trim();
    const type = item?.type === 'income' ? 'income' : 'expense';
    if (!rawName) continue;
    const dedupKey = `${type}|${rawName.toLowerCase()}`;
    if (seenSource.has(dedupKey)) continue;
    seenSource.add(dedupKey);

    const pool = byType[type];
    const lowerRaw = rawName.toLowerCase();
    const normRaw = normalizeCategoryKey(rawName);
    const synRaw = CATEGORY_SYNONYMS[lowerRaw] || CATEGORY_SYNONYMS[normRaw] || null;

    // 1. Exact case-insensitive trimmed match (prefer active over archived)
    let exact = pool.find((c) => !c.is_archived && c.name.trim().toLowerCase() === lowerRaw)
      || pool.find((c) => c.name.trim().toLowerCase() === lowerRaw);

    if (exact) {
      proposals.push({
        sourceKey: dedupKey,
        sourceName: rawName,
        type,
        matchType: 'exact',
        matchedCategoryId: exact.id,
        matchedCategoryName: exact.name,
        matchedCategoryIcon: exact.icon || '🏷️',
        isArchivedMatch: Boolean(exact.is_archived),
        suggestedName: exact.name,
        suggestedIcon: exact.icon || '🏷️',
      });
      continue;
    }

    // 2. Normalized key or synonym match (prefer active over archived)
    const findSuggested = (candidates) =>
      candidates.find((c) => {
        const cn = normalizeCategoryKey(c.name);
        if (cn && cn === normRaw) return true;
        if (synRaw && (cn === normalizeCategoryKey(synRaw) || c.name.toLowerCase().includes(synRaw.split(' ')[0]))) {
          return true;
        }
        return false;
      });

    const activePool = pool.filter((c) => !c.is_archived);
    const suggested = findSuggested(activePool) || findSuggested(pool);

    if (suggested) {
      proposals.push({
        sourceKey: dedupKey,
        sourceName: rawName,
        type,
        matchType: 'suggested',
        matchedCategoryId: suggested.id,
        matchedCategoryName: suggested.name,
        matchedCategoryIcon: suggested.icon || '🏷️',
        isArchivedMatch: Boolean(suggested.is_archived),
        suggestedName: suggested.name,
        suggestedIcon: suggested.icon || '🏷️',
      });
      continue;
    }

    // 3. Genuinely new category — suggest clean name + emoji
    const cleanName = suggestCategoryName(rawName);
    proposals.push({
      sourceKey: dedupKey,
      sourceName: rawName,
      type,
      matchType: 'new',
      matchedCategoryId: null,
      matchedCategoryName: null,
      matchedCategoryIcon: null,
      isArchivedMatch: false,
      suggestedName: cleanName,
      suggestedIcon: suggestCategoryEmoji(cleanName, type),
    });
  }

  return proposals;
}

/**
 * Single-pass O(T + S) count of linked non-deleted transactions (including split legs) per category_id.
 */
export async function getCategoryTransactionCounts(db) {
  const counts = new Map();
  const [txs, splits] = await Promise.all([
    db.table('transactions').toArray(),
    db.table('transaction_splits').toArray(),
  ]);
  for (const tx of txs) {
    if (tx.deleted_at || !tx.category_id) continue;
    counts.set(tx.category_id, (counts.get(tx.category_id) || 0) + 1);
  }
  const seenSplitTxCat = new Set();
  for (const sp of splits) {
    if (sp.deleted_at || !sp.category_id) continue;
    const key = `${sp.transaction_id}|${sp.category_id}`;
    if (seenSplitTxCat.has(key)) continue;
    seenSplitTxCat.add(key);
    counts.set(sp.category_id, (counts.get(sp.category_id) || 0) + 1);
  }
  return counts;
}

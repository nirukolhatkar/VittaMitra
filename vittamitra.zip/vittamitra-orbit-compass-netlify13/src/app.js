import { escapeHtml } from './utils/dom.js';
import { db, initializeDatabase } from './db/database.js';
import { SettingsRepository } from './db/repositories/settingsRepository.js';
import { CategoryRepository } from './db/repositories/categoryRepository.js';
import { AccountRepository } from './db/repositories/accountRepository.js';
import { FamilyRepository } from './db/repositories/familyRepository.js';
import { TagRepository } from './db/repositories/tagRepository.js';
import { FavoriteRepository } from './db/repositories/favoriteRepository.js';
import { AttachmentRepository } from './db/repositories/attachmentRepository.js';
import { BudgetRepository } from './db/repositories/budgetRepository.js';
import { BillRepository } from './db/repositories/billRepository.js';
import { RecurringRepository } from './db/repositories/recurringRepository.js';
import { InvestmentRepository } from './db/repositories/investmentRepository.js';
import { LoanRepository, NetWorthSnapshotRepository } from './db/repositories/loanRepository.js';
import { DebtRepository } from './db/repositories/debtRepository.js';
import { StatementImportRepository } from './db/repositories/statementImportRepository.js';
import { TransactionService } from './services/transactionService.js';
import { ImportExportService } from './services/importExportService.js';
import { BudgetService } from './services/budgetService.js';
import { AnalyticsService } from './services/analyticsService.js';
import { BillsRecurringService } from './services/billsRecurringService.js';
import { CashFlowReadinessService } from './services/cashFlowReadinessService.js';
import { JourneyEngine } from './services/journeyEngine.js';
import { TutorialManager } from './services/tutorialManager.js';
import { DebtService } from './services/debtService.js';
import { WealthService } from './services/wealthService.js';
import { StatementUploadService } from './services/statementUploadService.js';
import { StatementNormalisationService } from './services/statementNormalisationService.js';
import { StatementCategorisationService } from './services/statementCategorisationService.js';
import { StatementReconciliationService } from './services/statementReconciliationService.js';
import { StatementReviewService } from './services/statementReviewService.js';
import { StatementLedgerCommitService } from './services/statementLedgerCommitService.js';
import { GoogleDriveBackupService, isScheduledBackupDue } from './services/backupScheduleService.js';
import { applyTheme } from './services/themeService.js';
import { requestPersistentStorage } from './services/storageService.js';
import {
  openAddTransactionWithContext,
  openGlobalSearchModal,
  pasteClipboardToContext,
} from './services/txContextClipboard.js';
import { Router } from './router.js';
import { closeModal } from './ui/components/modal.js';
import { showToast } from './ui/components/toast.js';
import { renderHomeView } from './ui/views/homeView.js';
import { renderTransactionsView } from './ui/views/transactionsView.js';
import { renderAddTransactionView } from './ui/views/addTransactionView.js';
import { renderAnalysisView } from './ui/views/analysisView.js';
import { renderBudgetsView } from './ui/views/budgetsView.js';
import { renderBillsView } from './ui/views/billsView.js';
import { renderDebtsView } from './ui/views/debtsView.js';
import { renderMoreView } from './ui/views/moreView.js';
import { renderCategoriesView } from './ui/views/categoriesView.js';
import { renderAccountsView } from './ui/views/accountsView.js';
import { renderAccountDetailView } from './ui/views/accountDetailView.js';
import { renderFamilyView } from './ui/views/familyView.js';
import { renderTagsView } from './ui/views/tagsView.js';
import { renderTagDetailView } from './ui/views/tagDetailView.js';
import { renderCategoryDetailView } from './ui/views/categoryDetailView.js';
import { renderImportExportView } from './ui/views/importExportView.js';
import { renderStatementImportView } from './ui/views/statementImportView.js';
import { renderCategorisationRulesView } from './ui/views/categorisationRulesView.js';
import { renderSettingsView } from './ui/views/settingsView.js';
import { renderInvestmentsView } from './ui/views/investmentsView.js';
import { renderNetWorthView } from './ui/views/netWorthView.js';
import { renderWelcomeView } from './ui/views/welcomeView.js';
import { renderJourneyView } from './ui/views/journeyView.js';

window.__PFM_DEFERRED_INSTALL__ = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  window.__PFM_DEFERRED_INSTALL__ = e;
});

function updateNetworkBadge() {
  const badge = document.getElementById('network-badge');
  if (!badge) return;
  const online = navigator.onLine;
  badge.classList.toggle('hidden', online);
  badge.classList.toggle('status-online', online);
  badge.classList.toggle('status-offline', !online);
  const text = badge.querySelector('.status-text');
  if (text) text.textContent = online ? 'Online' : 'Offline';
}

async function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js', { scope: './' });
    } catch (err) {
      console.warn('Service Worker registration failed:', err);
    }
  }
}

async function bootstrap() {
  updateNetworkBadge();
  window.addEventListener('online', updateNetworkBadge);
  window.addEventListener('offline', updateNetworkBadge);

  await initializeDatabase(db);

  const repos = {
    settings: new SettingsRepository(db),
    categories: new CategoryRepository(db),
    accounts: new AccountRepository(db),
    family: new FamilyRepository(db),
    tags: new TagRepository(db),
    favorites: new FavoriteRepository(db),
    attachments: new AttachmentRepository(db),
    budgets: new BudgetRepository(db),
    bills: new BillRepository(db),
    recurring: new RecurringRepository(db),
    investments: new InvestmentRepository(db),
    loans: new LoanRepository(db),
    netWorthSnapshots: new NetWorthSnapshotRepository(db),
    debts: new DebtRepository(db),
    statementImport: new StatementImportRepository(db),
  };

  const services = {
    transactions: new TransactionService(db, repos),
  };
  services.importExport = new ImportExportService(db, repos, services);
  services.budgets = new BudgetService(repos, services);
  services.analytics = new AnalyticsService(repos, services);
  services.billsRecurring = new BillsRecurringService(repos, services);
  services.cashFlow = new CashFlowReadinessService(db, repos, services);
  services.journey = new JourneyEngine(db, repos, services);
  services.tutorials = new TutorialManager(repos, services);
  services.debts = new DebtService(db, repos, services);
  services.wealth = new WealthService(repos, services);
  services.statementUpload = new StatementUploadService(repos);
  services.statementNormalisation = new StatementNormalisationService(db, repos);
  services.statementCategorisation = new StatementCategorisationService(db, repos);
  services.statementReconciliation = new StatementReconciliationService(db, repos);
  services.statementReview = new StatementReviewService(db, repos, services);
  services.statementCommit = new StatementLedgerCommitService(db, repos, services);
  services.googleDrive = new GoogleDriveBackupService();

  const settings = await repos.settings.getSettings();
  applyTheme(settings.theme || 'system');

  requestPersistentStorage();
  registerServiceWorker();

  const now = new Date();
  const state = {
    selectedYear: now.getFullYear(),
    selectedMonth: now.getMonth(),
    txDraft: null,
    selectedTagId: null,
    selectedCategoryId: null,
    selectedDebtId: null,
    selectedAccountId: null,
    focusSearch: false,
    ieTab: null,
    clipboardTx: null,
    pageContext: null,
  };

  const routes = {
    home: { title: 'VittaMitra', render: renderHomeView },
    transactions: { title: 'Ledger & Calendar', render: renderTransactionsView },
    analysis: { title: 'Insights', render: renderAnalysisView },
    accounts: { title: 'Accounts', render: renderAccountsView },
    'account-detail': { title: 'Account', parentRoute: 'accounts', navGroup: 'accounts', render: renderAccountDetailView },
    more: { title: 'More', render: renderMoreView },
    'add-transaction': {
      title: 'New Transaction',
      parentRoute: 'home',
      navGroup: 'home',
      render: renderAddTransactionView,
    },
    debts: { title: 'Debt Tracker', parentRoute: 'more', navGroup: 'more', render: renderDebtsView },
    bills: { title: 'Bills & Recurring', parentRoute: 'more', navGroup: 'more', render: renderBillsView },
    budgets: { title: 'Budgets', parentRoute: 'more', navGroup: 'more', render: renderBudgetsView },
    categories: { title: 'Categories', parentRoute: 'more', navGroup: 'more', render: renderCategoriesView },
    family: { title: 'Family Members', parentRoute: 'more', navGroup: 'more', render: renderFamilyView },
    tags: { title: 'Tags', parentRoute: 'more', navGroup: 'more', render: renderTagsView },
    'tag-detail': { title: 'Tag Analytics', parentRoute: 'tags', navGroup: 'more', render: renderTagDetailView },
    'category-detail': { title: 'Category Analytics', parentRoute: 'analysis', navGroup: 'analysis', render: renderCategoryDetailView },
    'import-export': { title: 'Import & Export', parentRoute: 'more', navGroup: 'more', render: renderImportExportView },
    'statement-import': { title: 'Smart Statement Import', parentRoute: 'more', navGroup: 'more', render: renderStatementImportView },
    'categorisation-rules': { title: 'My Categorisation Rules', parentRoute: 'statement-import', navGroup: 'more', render: renderCategorisationRulesView },
    investments: { title: 'Investments & Loans', parentRoute: 'more', navGroup: 'more', render: renderInvestmentsView },
    networth: { title: 'Net Worth', parentRoute: 'more', navGroup: 'more', render: renderNetWorthView },
    journey: { title: 'Financial Journey', parentRoute: 'more', navGroup: 'more', render: renderJourneyView },
    welcome: { title: 'Welcome to VittaMitra', render: renderWelcomeView },
    settings: { title: 'Settings', parentRoute: 'more', navGroup: 'more', render: renderSettingsView },
  };

  const router = new Router(routes, {
    onBeforeNavigate: () => closeModal(),
  });

  const ctx = {
    db,
    router,
    repos,
    services,
    state,
    refreshCurrentView: () => router.resolve(ctx),
    navigateTo: (routeKey) => {
      const safe = routeKey && routes[routeKey] ? routeKey : 'home';
      return router.navigate(safe, ctx);
    },
  };
  window.__PFM_APP__ = ctx;

  // Universal Add Transaction triggers (topbar, sidebar, Compass bottom pill, mobile bottom dock)
  ['topbar-add-btn', 'sidebar-add-btn', 'compass-add-btn', 'bottom-add-btn'].forEach((id) => {
    document.getElementById(id)?.addEventListener('click', () => {
      openAddTransactionWithContext(ctx);
    });
  });

  // Universal Search triggers (topbar, sidebar, mobile bottom dock)
  ['topbar-search-btn', 'sidebar-search-btn', 'bottom-search-btn'].forEach((id) => {
    document.getElementById(id)?.addEventListener('click', () => {
      openGlobalSearchModal(ctx);
    });
  });

  // User pinch-zoom preserved for WCAG 2.1 AA 1.4.4 accessibility

  // Keyboard shortcuts: "/" for global search, Ctrl/Cmd+V for context-aware paste
  window.addEventListener('keydown', (e) => {
    const tag = (document.activeElement?.tagName || '').toLowerCase();
    const isTyping = tag === 'input' || tag === 'textarea' || tag === 'select' || document.activeElement?.isContentEditable;
    if (isTyping) return;

    if (e.key === '/' && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();
      openGlobalSearchModal(ctx);
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v' && state.clipboardTx) {
      e.preventDefault();
      pasteClipboardToContext(ctx);
    }
  });

  try {
    const rawHash = (window.location.hash || '').replace(/^#\/?/, '').split('?')[0];
    if ((!rawHash || rawHash === 'home') && (await services.journey.shouldShowFirstLaunch())) {
      router._suppressNextHashChange = true;
      window.location.hash = '#/welcome';
    }
  } catch {
    // Fail-safe: never block normal app launch
  }

  await router.start(ctx);

  try {
    const autoPosted = await services.billsRecurring.processAutoPostRules();
    if (autoPosted > 0) {
      showToast(`Auto-posted ${autoPosted} recurring transaction${autoPosted === 1 ? '' : 's'}`);
      await router.resolve(ctx);
    }
  } catch (err) {
    console.warn('Auto-post recurring check failed:', err);
  }

  setTimeout(async () => {
    try {
      const autoRes = await services.googleDrive.tryAutoBackupIfDue(settings, repos, services.importExport);
      if (autoRes.status === 'uploaded') {
        showToast('☁️ Auto-backed up to Google Drive');
      } else if (autoRes.status === 'needs_reconnect') {
        showToast('☁️ Scheduled Drive backup due — tap to sync', {
          durationMs: 7000,
          actionLabel: 'Sync Drive',
          onAction: () => {
            state.ieTab = 'backup';
            window.location.hash = '#/import-export';
          },
        });
      } else if (autoRes.status === 'disabled' && isScheduledBackupDue(settings)) {
        showToast(`Scheduled ${settings.backup_schedule} backup is due`, {
          durationMs: 7000,
          actionLabel: 'Backup Now',
          onAction: () => {
            state.ieTab = 'backup';
            window.location.hash = '#/import-export';
          },
        });
      }
    } catch {
      // Never block app usage
    }
  }, 700);
}

bootstrap().catch((err) => {
  console.error('Failed to start VittaMitra:', err);
  const main = document.getElementById('app-main');
  if (main) {
    main.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <h2 class="empty-state-title">Unable to initialize local database</h2>
        <p class="empty-state-text">${escapeHtml(err?.message || 'Unexpected startup error')}</p>
      </div>
    `;
  }
});

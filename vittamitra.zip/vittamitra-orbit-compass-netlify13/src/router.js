import { renderClipboardBar, setPageContext } from './services/txContextClipboard.js';
import { openSheet } from './ui/components/modal.js';

/**
 * Hash-based SPA router with dynamic routeHistory[] back-stack, unsaved-draft
 * navigation guard, active navigation highlighting, and contextual action syncing.
 */

const ORBIT_ROUTES = new Set(['home', 'add-transaction']);

export class Router {
  constructor(routes, { onBeforeNavigate } = {}) {
    this.routes = routes;
    this.onBeforeNavigate = onBeforeNavigate;
    this.history = [];
    this.currentRouteKey = null;
    this._dirtyGuard = null;
    this._bypassGuardOnce = false;
    this._suppressNextHashChange = false;
    this._renderToken = 0;
  }

  setDirtyGuard(fn) {
    this._dirtyGuard = typeof fn === 'function' ? fn : null;
  }

  clearDirtyGuard() {
    this._dirtyGuard = null;
  }

  getCurrentRouteKey() {
    const raw = (window.location.hash || '#/home').replace(/^#\/?/, '').split('?')[0];
    return this.routes[raw] ? raw : 'home';
  }

  getBackTarget(fallbackParent) {
    for (let i = this.history.length - 1; i >= 0; i -= 1) {
      const prev = this.history[i];
      if (prev && prev !== this.currentRouteKey) return prev;
    }
    return fallbackParent || 'home';
  }

  /**
   * Programmatically navigate to a route without firing a duplicate hashchange resolve.
   */
  navigate(routeKey, ctx) {
    const safe = routeKey && this.routes[routeKey] ? routeKey : 'home';
    const target = `#/${safe}`;
    if (typeof window !== 'undefined' && window.location.hash !== target) {
      this._suppressNextHashChange = true;
      window.location.hash = target;
    }
    return this.resolve(ctx);
  }

  async resolve(ctx) {
    const key = this.getCurrentRouteKey();
    const route = this.routes[key];
    if (!route) return;

    // Intercept accidental navigation away from a dirty form (e.g. Add Transaction)
    if (
      !this._bypassGuardOnce &&
      this.currentRouteKey &&
      this.currentRouteKey !== key &&
      typeof this._dirtyGuard === 'function' &&
      this._dirtyGuard()
    ) {
      const stayRoute = this.currentRouteKey;
      const targetRoute = key;
      this._bypassGuardOnce = true;
      if (typeof window !== 'undefined' && window.location.hash !== `#/${stayRoute}`) {
        this._suppressNextHashChange = true;
        window.location.hash = `#/${stayRoute}`;
      }
      this._bypassGuardOnce = false;

      openSheet({
        title: 'Discard unsaved entry?',
        bodyHtml: `
          <div class="stack" style="gap:12px;">
            <p class="item-meta" style="margin:0; font-size:0.9rem;">
              You have unsaved changes in this transaction. Leaving now will discard them.
            </p>
            <div style="display:flex; gap:10px;">
              <button type="button" class="btn btn-secondary" style="flex:1;" data-modal-close>Keep editing</button>
              <button type="button" class="btn btn-danger" style="flex:1;" id="btn-confirm-discard-route">Discard</button>
            </div>
          </div>
        `,
        onMount: (panel, close) => {
          panel.querySelector('#btn-confirm-discard-route')?.addEventListener('click', () => {
            this.clearDirtyGuard();
            this._bypassGuardOnce = true;
            close();
            this.navigate(targetRoute, ctx);
          });
        },
      });
      return;
    }
    this._bypassGuardOnce = false;

    const token = ++this._renderToken;
    const isRouteChange = this.currentRouteKey !== key;
    const savedScrollY = !isRouteChange && typeof window !== 'undefined' ? window.scrollY : 0;
    if (this.currentRouteKey && isRouteChange) {
      this.history.push(this.currentRouteKey);
      if (this.history.length > 20) this.history.shift();
    }
    this.currentRouteKey = key;
    this.clearDirtyGuard();

    if (typeof this.onBeforeNavigate === 'function') {
      this.onBeforeNavigate(key, route);
    }

    const design = ORBIT_ROUTES.has(key) ? 'orbit' : 'compass';
    document.documentElement.setAttribute('data-design', design);
    document.documentElement.setAttribute('data-route-active', key);

    const hideTopbarActions = key === 'add-transaction' || key === 'welcome';
    document.getElementById('topbar-search-btn')?.classList.toggle('hidden', hideTopbarActions);
    document.getElementById('topbar-add-btn')?.classList.toggle('hidden', hideTopbarActions);

    const titleEl = document.getElementById('topbar-title');
    if (titleEl) titleEl.textContent = route.title;

    const backBtn = document.getElementById('topbar-back');
    if (backBtn) {
      if (route.parentRoute) {
        backBtn.classList.remove('hidden');
        backBtn.onclick = () => {
          const prev = this.history.pop();
          const target = prev && prev !== key ? prev : route.parentRoute;
          this.navigate(target, ctx);
        };
      } else {
        backBtn.classList.add('hidden');
        backBtn.onclick = null;
      }
    }

    const activeNavKey = route.navGroup || key;
    document.querySelectorAll('[data-route]').forEach((el) => {
      const target = el.getAttribute('data-route');
      el.classList.toggle('active', target === key || target === activeNavKey);
    });

    // Clear stale page context before rendering the next route
    setPageContext(ctx, null);

    const main = document.getElementById('app-main');
    if (main) {
      await route.render(main, ctx);
    }

    // Abort post-render side effects if a newer navigation superseded this render
    if (token !== this._renderToken) return;

    if (typeof window !== 'undefined') {
      if (isRouteChange) {
        window.scrollTo(0, 0);
      } else if (savedScrollY > 0) {
        window.scrollTo(0, savedScrollY);
      }
    }

    renderClipboardBar(ctx);

    // Phase D: Contextual Feature Tour trigger (?) + deferred non-blocking first-visit check
    try {
      const tourBtn = document.getElementById('topbar-tour-btn');
      const tour = ctx.services?.tutorials?.getTourForRoute?.(key) || null;
      if (tourBtn) {
        if (tour && key !== 'welcome') {
          tourBtn.classList.remove('hidden');
          tourBtn.onclick = () => ctx.services.tutorials.openTour(tour.id, { isFirstVisit: false });
        } else {
          tourBtn.classList.add('hidden');
          tourBtn.onclick = null;
        }
      }
      if (tour && key !== 'welcome') {
        setTimeout(() => {
          if (token !== this._renderToken) return;
          ctx.services?.tutorials?.maybeShowFirstVisit?.(tour.id).catch(() => {});
        }, 280);
      }
    } catch {
      // Fail-safe: tour errors never interrupt navigation
    }
  }

  start(ctx) {
    window.addEventListener('hashchange', () => {
      if (this._suppressNextHashChange) {
        this._suppressNextHashChange = false;
        return;
      }
      this.resolve(ctx);
    });
    if (!window.location.hash) {
      this._suppressNextHashChange = true;
      window.location.hash = '#/home';
    }
    return this.resolve(ctx);
  }
}

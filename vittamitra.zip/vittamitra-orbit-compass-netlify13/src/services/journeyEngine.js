import { nowIsoUtc, toLocalDateString } from '../utils/date.js';

/**
 * VittaMitra Financial Journey Engine (Atomic Habits Edition).
 *
 * - Purely local, offline-first, fail-safe behavioral progress engine.
 * - Persists inside existing `settings.journey_state` (Schema v9 untouched; auto-included in JSON/ZIP backups).
 * - Flexible progression: no calendar-week gating; adapts to real user state & readiness.
 * - Performance-safe: O(1) table counts + indexed `month_key` query only when needed (zero full-table scans).
 * - Meaningful rewards: at most once per local calendar day; never resets on missed days; never rewards screen opens.
 * - Backup is optional: never blocks Week 4 identity; tracked as a separate recommended data-protection milestone.
 */

export const JOURNEY_LEVELS = [
  { level: 1, name: 'Beginner', minXp: 0 },
  { level: 2, name: 'Money Explorer', minXp: 150 },
  { level: 3, name: 'Habit Builder', minXp: 350 },
  { level: 4, name: 'Financial Planner', minXp: 600 },
  { level: 5, name: 'Money Master', minXp: 900 },
];

export const STARTING_BALANCE_STATUS = {
  NO_ACCOUNTS: 'no_accounts',
  NOT_ESTABLISHED: 'not_established',
  CONFIRMED_ZERO: 'confirmed_zero',
  NON_ZERO: 'non_zero',
};

export const DAILY_HABIT_XP = 10;

export const JOURNEY_IDENTITIES = [
  {
    id: 'week1_awareness',
    order: 1,
    theme: 'Awareness',
    suggestedWindow: 'Week 1',
    statement: 'I know where my money goes.',
    requirement: 'Add an account, establish or confirm starting balances, and record your first real transaction.',
  },
  {
    id: 'week2_intentional',
    order: 2,
    theme: 'Intentional Spending',
    suggestedWindow: 'Week 2',
    statement: 'I make conscious spending decisions.',
    requirement: 'Set up a budget or recurring bill and complete a weekly summary check-in.',
  },
  {
    id: 'week3_prepared',
    order: 3,
    theme: 'Preparedness',
    suggestedWindow: 'Week 3',
    statement: 'I plan before money problems arise.',
    requirement: 'Review your Net Worth snapshot (loans & investments are optional).',
  },
  {
    id: 'week4_confidence',
    order: 4,
    theme: 'Confidence',
    suggestedWindow: 'Week 4',
    statement: 'I understand and manage my financial position.',
    requirement: 'Complete your first 30-day financial review (backups stay optional and recommended).',
  },
];

export const JOURNEY_MISSIONS = [
  {
    id: 'add_account',
    order: 1,
    stage: 'Awareness',
    identityId: 'week1_awareness',
    title: 'Map where your money sits today',
    why: 'Add your everyday bank, cash, or card so VittaMitra mirrors real life.',
    route: 'accounts',
    ctaLabel: 'Add Account',
    xp: 100,
    optional: false,
  },
  {
    id: 'set_balances',
    order: 2,
    stage: 'Awareness',
    identityId: 'week1_awareness',
    title: 'Start cleanly from today’s balance',
    why: 'Enter today’s real balance (or confirm ₹0) so you never have to backfill old history.',
    route: 'accounts',
    ctaLabel: 'Check Balances',
    xp: 100,
    optional: false,
  },
  {
    id: 'first_transaction',
    order: 3,
    stage: 'Awareness',
    identityId: 'week1_awareness',
    title: 'Record one real expense or income',
    why: 'A 5-second entry starts the awareness habit without changing everything overnight.',
    route: 'add-transaction',
    ctaLabel: 'Add Transaction',
    xp: 100,
    optional: false,
  },
  {
    id: 'understand_categories',
    order: 4,
    stage: 'Awareness',
    identityId: 'week1_awareness',
    title: 'See where your money goes',
    why: 'Categorising a few entries reveals your real weekly spending pattern.',
    route: 'categories',
    ctaLabel: 'Explore Categories',
    xp: 75,
    optional: true,
  },
  {
    id: 'first_budget',
    order: 5,
    stage: 'Intentional Spending',
    identityId: 'week2_intentional',
    title: 'Set one calm spending boundary',
    why: 'Pick one category you care about and let VittaMitra nudge you early.',
    route: 'budgets',
    ctaLabel: 'Create Budget',
    xp: 100,
    optional: true,
  },
  {
    id: 'setup_bills_recurring',
    order: 6,
    stage: 'Intentional Spending',
    identityId: 'week2_intentional',
    title: 'Put recurring bills on your radar',
    why: 'Add rent, EMIs, or salary once so upcoming dates never surprise you.',
    route: 'bills',
    ctaLabel: 'Set Up Bills',
    xp: 100,
    optional: true,
  },
  {
    id: 'weekly_summary',
    order: 7,
    stage: 'Intentional Spending',
    identityId: 'week2_intentional',
    title: 'Take a 2-minute weekly check-in',
    why: 'Pause once a week to notice what felt worth spending on.',
    route: 'analysis',
    ctaLabel: 'Open Summary',
    xp: 75,
    optional: true,
  },
  {
    id: 'understand_net_worth',
    order: 8,
    stage: 'Preparedness',
    identityId: 'week3_prepared',
    title: 'See your full financial picture',
    why: 'Compare what you own and owe in one calm snapshot.',
    route: 'networth',
    ctaLabel: 'View Net Worth',
    xp: 75,
    optional: true,
  },
  {
    id: 'explore_loans_investments',
    order: 9,
    stage: 'Preparedness',
    identityId: 'week3_prepared',
    title: 'Track loans or investments (only if relevant)',
    why: 'Skip freely if you don’t hold EMIs or SIPs right now—nothing is forced.',
    route: 'investments',
    ctaLabel: 'Explore Wealth',
    xp: 100,
    optional: true,
  },
  {
    id: 'first_monthly_review',
    order: 10,
    stage: 'Confidence',
    identityId: 'week4_confidence',
    title: 'Complete your first 30-day review',
    why: 'Review your monthly cash flow and budgets to lock in a sustainable routine.',
    route: 'journey',
    ctaLabel: 'Start Review',
    xp: 175,
    optional: true,
  },
];

export const JOURNEY_ACHIEVEMENTS = [
  { id: 'first_account', title: 'First Account Added', description: 'Mapped your first real financial account.', xp: 25, category: 'habit' },
  { id: 'starting_balance', title: 'Starting Balance Established', description: 'Aligned VittaMitra with today’s real balances.', xp: 25, category: 'habit' },
  { id: 'first_transaction', title: 'First Transaction Recorded', description: 'Started your awareness habit with one real entry.', xp: 25, category: 'habit' },
  { id: 'seven_active_days', title: 'Seven Active Recording Days', description: 'Recorded transactions on 7 distinct calendar days (never resets).', xp: 100, category: 'habit' },
  { id: 'first_budget', title: 'First Budget Created', description: 'Set your first calm monthly spending boundary.', xp: 25, category: 'habit' },
  { id: 'first_weekly_review', title: 'First Weekly Check-in', description: 'Completed a 2-minute weekly spending review.', xp: 50, category: 'habit' },
  { id: 'first_monthly_review', title: 'First 30-Day Review', description: 'Completed your first full financial review.', xp: 100, category: 'habit' },
  { id: 'first_backup', title: 'Safety Net Secured', description: 'Recommended data-protection milestone: created an offline or Drive backup.', xp: 50, category: 'data_protection' },
];

export function createDefaultJourneyState(now = nowIsoUtc()) {
  return {
    version: 1,
    welcome_completed: false,
    onboarding_skipped: false,
    reminders_paused: false,
    dismissed_welcome_back_date: null,
    started_at: now,
    xp: 0,
    completed_missions: {}, // { [missionId]: isoTimestamp }
    skipped_missions: {},   // { [missionId]: isoTimestamp }
    achievements: {},       // { [achievementId]: isoTimestamp }
    earned_identities: {},  // { [identityId]: isoTimestamp }
    seen_tutorials: {},     // { [featureKey]: isoTimestamp }
    confirmed_zero_balance: false,
    confirmed_zero_balance_at: null,
    net_worth_confirmed: false,
    metrics: {
      account_setup_at: null,
      first_tx_at: null,
      active_recording_dates: [], // unique YYYY-MM-DD strings (non-consecutive)
      weekly_reviews_completed: 0,
      monthly_reviews_completed: 0,
      last_active_date: null,
    },
  };
}

export function resolveJourneyLevel(xp = 0) {
  const safeXp = Math.max(0, Number(xp) || 0);
  let current = JOURNEY_LEVELS[0];
  let next = JOURNEY_LEVELS[1] || null;
  for (let i = 0; i < JOURNEY_LEVELS.length; i += 1) {
    if (safeXp >= JOURNEY_LEVELS[i].minXp) {
      current = JOURNEY_LEVELS[i];
      next = JOURNEY_LEVELS[i + 1] || null;
    }
  }
  const xpIntoLevel = safeXp - current.minXp;
  const xpSpan = next ? next.minXp - current.minXp : 1;
  const progressPct = next ? Math.min(100, Math.round((xpIntoLevel / xpSpan) * 100)) : 100;
  return {
    level: current.level,
    name: current.name,
    xp: safeXp,
    nextLevelName: next ? next.name : null,
    nextLevelXp: next ? next.minXp : null,
    xpToNext: next ? Math.max(0, next.minXp - safeXp) : 0,
    progressPct,
  };
}

/**
 * Strictly distinguishes:
 * - no_accounts: user has not added any account yet
 * - non_zero: at least one account has a non-zero opening balance or a balance adjustment exists
 * - confirmed_zero: user explicitly confirmed ₹0 starting balances
 * - not_established: accounts exist with ₹0/empty opening balance and NO explicit confirmation
 */
export function resolveStartingBalanceStatus(accounts = [], hasAdjustment = false, jState = null) {
  if (!Array.isArray(accounts) || accounts.length === 0) {
    return STARTING_BALANCE_STATUS.NO_ACCOUNTS;
  }
  const hasNonZero = accounts.some((a) => Number(a.opening_balance_paise || 0) !== 0);
  if (hasNonZero || hasAdjustment) {
    return STARTING_BALANCE_STATUS.NON_ZERO;
  }
  if (jState && jState.confirmed_zero_balance === true) {
    return STARTING_BALANCE_STATUS.CONFIRMED_ZERO;
  }
  return STARTING_BALANCE_STATUS.NOT_ESTABLISHED;
}

/**
 * Computes whole calendar days elapsed since the last recorded activity date.
 * Returns 0 if no previous date exists or date is today/future.
 */
export function getReturnGapDays(lastActiveDate, todayKey = toLocalDateString()) {
  if (!lastActiveDate || !/^\d{4}-\d{2}-\d{2}$/.test(String(lastActiveDate))) return 0;
  if (!todayKey || !/^\d{4}-\d{2}-\d{2}$/.test(String(todayKey))) return 0;
  const [y1, m1, d1] = String(lastActiveDate).split('-').map(Number);
  const [y2, m2, d2] = String(todayKey).split('-').map(Number);
  const t1 = Date.UTC(y1, m1 - 1, d1);
  const t2 = Date.UTC(y2, m2 - 1, d2);
  return Math.max(0, Math.round((t2 - t1) / 86400000));
}

export class JourneyEngine {
  constructor(db, repos, services) {
    this.db = db;
    this.repos = repos;
    this.services = services;
  }

  async getState() {
    try {
      const settings = await this.repos.settings.getSettings();
      const raw = settings?.journey_state;
      const base = createDefaultJourneyState();
      if (!raw || typeof raw !== 'object') return base;
      return {
        ...base,
        ...raw,
        reminders_paused: Boolean(raw.reminders_paused),
        dismissed_welcome_back_date: raw.dismissed_welcome_back_date || null,
        completed_missions: { ...(raw.completed_missions || {}) },
        skipped_missions: { ...(raw.skipped_missions || {}) },
        achievements: { ...(raw.achievements || {}) },
        earned_identities: { ...(raw.earned_identities || {}) },
        seen_tutorials: { ...(raw.seen_tutorials || {}) },
        metrics: {
          ...base.metrics,
          ...(raw.metrics || {}),
          active_recording_dates: Array.isArray(raw.metrics?.active_recording_dates)
            ? [...raw.metrics.active_recording_dates]
            : [],
        },
      };
    } catch {
      return createDefaultJourneyState();
    }
  }

  async _saveState(nextState) {
    try {
      await this.repos.settings.updateSettings({ journey_state: nextState });
    } catch {
      // Fail-safe: never block core app usage
    }
    return nextState;
  }

  async shouldShowFirstLaunch() {
    try {
      const st = await this.getState();
      if (st.welcome_completed || st.onboarding_skipped) return false;
      const [accCount, txCount] = await Promise.all([
        this.db.table('accounts').count(),
        this.db.table('transactions').count(),
      ]);
      // Existing users with accounts or transactions bypass welcome automatically
      if (accCount > 0 || txCount > 0) return false;
      return true;
    } catch {
      return false;
    }
  }

  async markWelcomeCompleted({ skipped = false } = {}) {
    try {
      const st = await this.getState();
      st.welcome_completed = true;
      if (skipped) st.onboarding_skipped = true;
      return await this._saveState(st);
    } catch {
      return createDefaultJourneyState();
    }
  }

  async setRemindersPaused(paused) {
    try {
      const st = await this.getState();
      st.reminders_paused = Boolean(paused);
      return await this._saveState(st);
    } catch {
      return createDefaultJourneyState();
    }
  }

  async dismissWelcomeBackToday(todayKey = toLocalDateString()) {
    try {
      const st = await this.getState();
      st.dismissed_welcome_back_date = String(todayKey).slice(0, 10);
      return await this._saveState(st);
    } catch {
      return createDefaultJourneyState();
    }
  }

  async skipMission(missionId) {
    try {
      const m = JOURNEY_MISSIONS.find((x) => x.id === missionId);
      if (!m || !m.optional) return this.getState();
      const st = await this.getState();
      if (!st.completed_missions[missionId]) {
        st.skipped_missions[missionId] = nowIsoUtc();
        await this._saveState(st);
      }
      return st;
    } catch {
      return createDefaultJourneyState();
    }
  }

  async unskipMission(missionId) {
    try {
      const st = await this.getState();
      if (st.skipped_missions[missionId]) {
        delete st.skipped_missions[missionId];
        await this._saveState(st);
      }
      return st;
    } catch {
      return createDefaultJourneyState();
    }
  }

  /**
   * Records a real transaction day at most ONCE per local calendar day.
   * Never awards additional XP for repeated same-day entries or screen opens.
   */
  async recordActiveRecordingDate(dateKey = toLocalDateString()) {
    try {
      const cleanDate = String(dateKey || toLocalDateString()).slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(cleanDate)) {
        return { recorded: false, isNewDay: false, activeDaysCount: 0, xpAwarded: 0 };
      }
      const st = await this.getState();
      const alreadyRecorded = st.metrics.active_recording_dates.includes(cleanDate);
      if (alreadyRecorded) {
        return {
          recorded: false,
          isNewDay: false,
          activeDaysCount: st.metrics.active_recording_dates.length,
          xpAwarded: 0,
        };
      }

      st.metrics.active_recording_dates.push(cleanDate);
      st.metrics.active_recording_dates.sort();
      if (st.metrics.active_recording_dates.length > 365) {
        st.metrics.active_recording_dates = st.metrics.active_recording_dates.slice(-365);
      }
      if (!st.metrics.last_active_date || cleanDate > st.metrics.last_active_date) {
        st.metrics.last_active_date = cleanDate;
      }
      if (!st.metrics.first_tx_at) st.metrics.first_tx_at = nowIsoUtc();

      st.xp = (st.xp || 0) + DAILY_HABIT_XP;
      await this._saveState(st);

      return {
        recorded: true,
        isNewDay: true,
        activeDaysCount: st.metrics.active_recording_dates.length,
        xpAwarded: DAILY_HABIT_XP,
      };
    } catch {
      return { recorded: false, isNewDay: false, activeDaysCount: 0, xpAwarded: 0 };
    }
  }

  async markWeeklyReviewComplete() {
    try {
      const st = await this.getState();
      st.metrics.weekly_reviews_completed = (st.metrics.weekly_reviews_completed || 0) + 1;
      await this._saveState(st);
      return await this.evaluateProgress();
    } catch {
      return null;
    }
  }

  async markMonthlyReviewComplete() {
    try {
      const st = await this.getState();
      st.metrics.monthly_reviews_completed = (st.metrics.monthly_reviews_completed || 0) + 1;
      await this._saveState(st);
      return await this.evaluateProgress();
    } catch {
      return null;
    }
  }

  async confirmNetWorthReviewed() {
    try {
      const st = await this.getState();
      st.net_worth_confirmed = true;
      await this._saveState(st);
      return await this.evaluateProgress();
    } catch {
      return null;
    }
  }

  async confirmZeroStartingBalance() {
    try {
      const st = await this.getState();
      st.confirmed_zero_balance = true;
      st.confirmed_zero_balance_at = nowIsoUtc();
      await this._saveState(st);
      return await this.evaluateProgress();
    } catch {
      return null;
    }
  }

  /**
   * Performance-safe, idempotent evaluation using O(1) counts + indexed `month_key` query
   * ONLY when needed (zero full-table transaction scans, even on 15k-100k ledgers).
   */
  async evaluateProgress({ todayKey = toLocalDateString() } = {}) {
    const st = await this.getState();
    const now = nowIsoUtc();
    const curMonthKey = String(todayKey).slice(0, 7);

    const safeCount = async (tbl) => {
      try {
        return await this.db.table(tbl).count();
      } catch {
        return 0;
      }
    };

    const [
      settings,
      accounts,
      txTotalCount,
      budgetCount,
      billCount,
      recurringCount,
      loanCount,
      investmentCount,
      nwSnapCount,
    ] = await Promise.all([
      this.repos.settings.getSettings().catch(() => ({})),
      this.repos.accounts.list({ includeArchived: false }).catch(() => []),
      safeCount('transactions'),
      safeCount('budgets'),
      safeCount('bills'),
      safeCount('recurring_rules'),
      safeCount('loans'),
      safeCount('investments'),
      safeCount('net_worth_snapshots'),
    ]);

    const hasAccounts = accounts.length > 0;
    const hasNonZeroOpening = accounts.some((a) => Number(a.opening_balance_paise || 0) !== 0);

    // Only touch the indexed `month_key` slice when we still need to verify
    // balance adjustment or early categorisation (never full-scans 15k-100k rows).
    let hasAdjustment = false;
    let categorizedCount = 0;
    const distinctCats = new Set();
    const activeDatesSet = new Set(st.metrics.active_recording_dates || []);

    const needsMonthSlice =
      txTotalCount > 0 &&
      ((!st.completed_missions.set_balances && !hasNonZeroOpening && !st.confirmed_zero_balance) ||
        (!st.completed_missions.understand_categories && txTotalCount < 10));

    if (needsMonthSlice) {
      try {
        const monthTxs = await this.db
          .table('transactions')
          .where('month_key')
          .equals(curMonthKey)
          .toArray();
        for (const tx of monthTxs) {
          if (tx.deleted_at) continue;
          if (tx.type === 'BALANCE_ADJUSTMENT') {
            hasAdjustment = true;
            continue;
          }
          if (tx.date_key) activeDatesSet.add(String(tx.date_key).slice(0, 10));
          if ((tx.type === 'expense' || tx.type === 'income') && tx.category_id) {
            categorizedCount += 1;
            distinctCats.add(tx.category_id);
          }
        }
      } catch {
        // Fail-safe: skip indexed slice if unavailable
      }
    }

    const startingBalanceStatus = resolveStartingBalanceStatus(accounts, hasAdjustment, st);
    const hasBalanceEstablished =
      startingBalanceStatus === STARTING_BALANCE_STATUS.NON_ZERO ||
      startingBalanceStatus === STARTING_BALANCE_STATUS.CONFIRMED_ZERO;

    const hasRegularTx = txTotalCount > 0 && (!hasAdjustment || txTotalCount > 1);
    const hasCategorisation = (categorizedCount >= 3 && distinctCats.size >= 2) || txTotalCount >= 10;
    const hasBudget = budgetCount > 0;
    const hasBillsOrRecurring = billCount + recurringCount > 0;
    const hasWeeklyReview = (st.metrics.weekly_reviews_completed || 0) > 0;
    const hasNetWorth = hasAccounts && (nwSnapCount > 0 || Boolean(st.net_worth_confirmed));
    const hasLoansOrInvestments = loanCount + investmentCount > 0;
    const hasMonthlyReview = (st.metrics.monthly_reviews_completed || 0) > 0;
    const hasBackup = Boolean(settings?.last_backup_at || settings?.gdrive_last_backup_at);

    const missionTruth = {
      add_account: hasAccounts,
      set_balances: hasBalanceEstablished,
      first_transaction: hasRegularTx,
      understand_categories: hasCategorisation,
      first_budget: hasBudget,
      setup_bills_recurring: hasBillsOrRecurring,
      weekly_summary: hasWeeklyReview,
      understand_net_worth: hasNetWorth,
      explore_loans_investments: hasLoansOrInvestments,
      first_monthly_review: hasMonthlyReview,
    };

    const achievementTruth = {
      first_account: hasAccounts,
      starting_balance: hasBalanceEstablished,
      first_transaction: hasRegularTx,
      seven_active_days: activeDatesSet.size >= 7,
      first_budget: hasBudget,
      first_weekly_review: hasWeeklyReview,
      first_monthly_review: hasMonthlyReview,
      first_backup: hasBackup,
    };

    // Identity milestones: real actions only (never screen opens; backup is NOT required for Week 4)
    const identityTruth = {
      week1_awareness: hasAccounts && hasBalanceEstablished && hasRegularTx,
      week2_intentional: (hasBudget || hasBillsOrRecurring) && hasWeeklyReview,
      week3_prepared: hasNetWorth,
      week4_confidence: hasMonthlyReview,
    };

    let changed = false;
    const newlyCompletedMissions = [];
    const newlyUnlockedAchievements = [];
    const newlyEarnedIdentities = [];

    if (activeDatesSet.size !== st.metrics.active_recording_dates.length) {
      st.metrics.active_recording_dates = Array.from(activeDatesSet).sort().slice(-365);
      const latest = st.metrics.active_recording_dates[st.metrics.active_recording_dates.length - 1];
      if (latest && (!st.metrics.last_active_date || latest > st.metrics.last_active_date)) {
        st.metrics.last_active_date = latest;
      }
      changed = true;
    }
    if (hasAccounts && !st.metrics.account_setup_at) {
      st.metrics.account_setup_at = now;
      changed = true;
    }
    if (hasRegularTx && !st.metrics.first_tx_at) {
      st.metrics.first_tx_at = now;
      changed = true;
    }

    for (const m of JOURNEY_MISSIONS) {
      if (missionTruth[m.id] && !st.completed_missions[m.id]) {
        st.completed_missions[m.id] = now;
        delete st.skipped_missions[m.id];
        st.xp = (st.xp || 0) + m.xp;
        newlyCompletedMissions.push(m);
        changed = true;
      }
    }

    for (const ach of JOURNEY_ACHIEVEMENTS) {
      if (achievementTruth[ach.id] && !st.achievements[ach.id]) {
        st.achievements[ach.id] = now;
        st.xp = (st.xp || 0) + ach.xp;
        newlyUnlockedAchievements.push(ach);
        changed = true;
      }
    }

    for (const ident of JOURNEY_IDENTITIES) {
      if (identityTruth[ident.id] && !st.earned_identities[ident.id]) {
        st.earned_identities[ident.id] = now;
        newlyEarnedIdentities.push(ident);
        changed = true;
      }
    }

    if (changed) {
      await this._saveState(st);
    }

    const levelInfo = resolveJourneyLevel(st.xp);
    const nextMission =
      JOURNEY_MISSIONS.find(
        (m) => !st.completed_missions[m.id] && !st.skipped_missions[m.id]
      ) || null;
    const coreComplete = Boolean(
      st.completed_missions.add_account &&
        st.completed_missions.set_balances &&
        st.completed_missions.first_transaction
    );

    // Current identity: highest earned identity, or Week 1 target if none earned yet
    let activeIdentity = JOURNEY_IDENTITIES[0];
    let earnedIdentityCount = 0;
    for (const ident of JOURNEY_IDENTITIES) {
      if (st.earned_identities[ident.id]) {
        activeIdentity = ident;
        earnedIdentityCount += 1;
      }
    }

    const returnGapDays = getReturnGapDays(st.metrics.last_active_date, todayKey);
    const showWelcomeBack =
      returnGapDays >= 3 &&
      !st.reminders_paused &&
      st.dismissed_welcome_back_date !== String(todayKey).slice(0, 10);

    return {
      state: st,
      levelInfo,
      nextMission,
      coreComplete,
      startingBalanceStatus,
      hasBackup,
      activeIdentity,
      earnedIdentityCount,
      completedCount: Object.keys(st.completed_missions).length,
      totalMissions: JOURNEY_MISSIONS.length,
      activeRecordingDays: st.metrics.active_recording_dates.length,
      returnGapDays,
      showWelcomeBack,
      newlyCompletedMissions,
      newlyUnlockedAchievements,
      newlyEarnedIdentities,
    };
  }
}

import { nowIsoUtc } from '../utils/date.js';
import { escapeHtml } from '../utils/dom.js';
import { openSheet } from '../ui/components/modal.js';
import { showToast } from '../ui/components/toast.js';

/**
 * VittaMitra Contextual Feature Tour Manager (Phase D).
 *
 * - Reusable, offline-first, fail-safe contextual guides for 13 core features.
 * - Persists seen status inside existing `settings.journey_state.seen_tutorials` (zero schema bump).
 * - Respects `reminders_paused`: suppresses automatic first-visit sheets when paused, while manual `?` replay always works.
 * - Never awards Journey mission completion merely for reading a tour.
 */

export const FEATURE_TOURS = [
  {
    id: 'accounts',
    route: 'accounts',
    title: 'Accounts',
    what: 'Tracks your real bank accounts, cash wallets, and credit cards in one reconciled ledger.',
    why: 'Mirroring your real accounts lets VittaMitra keep exact balances automatically.',
    how: 'Tap + Add Account, enter today’s real balance (or confirm ₹0), and use Reconcile if a bank statement differs.',
    dataNeeded: 'Account name, type (bank, cash, or credit card), and today’s starting balance.',
    insight: 'Live available cash vs. credit card outstanding across every account.',
  },
  {
    id: 'transactions',
    route: 'transactions',
    title: 'Transactions & Ledger',
    what: 'Lists every income, expense, transfer, and split entry with fast search and filters.',
    why: 'One clean ledger makes it easy to spot patterns or edit any entry in seconds.',
    how: 'Tap any transaction row to edit it, use the search bar to filter by note/merchant, or switch between List and Calendar.',
    dataNeeded: 'Amount, account, and category (date defaults to today).',
    insight: 'Exact day-by-day spending history and reconciled totals for any filter or budget.',
  },
  {
    id: 'calendar',
    route: 'transactions',
    title: 'Calendar View',
    what: 'Displays daily net income and spending across the month on an interactive calendar grid.',
    why: 'Seeing busy spending days visually makes habits obvious without reading long lists.',
    how: 'Switch to the Calendar tab inside Ledger & Calendar and tap any date to review or add entries for that day.',
    dataNeeded: 'Your regular dated transactions (nothing extra required).',
    insight: 'No-spend days, weekend vs. weekday patterns, and daily net cash movement.',
  },
  {
    id: 'categories',
    route: 'categories',
    title: 'Categories',
    what: 'Groups your income and expenses into clean, customisable categories and subcategories.',
    why: 'Clear categories turn raw rupee numbers into understandable lifestyle choices.',
    how: 'Tap any category tile to edit its name, icon, or archive it—or reassign entries safely before deleting.',
    dataNeeded: 'Just pick a category when saving a transaction (18 expense & 8 income defaults are preloaded).',
    insight: 'Where your money actually flows each week and month.',
  },
  {
    id: 'budgets',
    route: 'budgets',
    title: 'Budgets',
    what: 'Sets calm monthly spending boundaries per category or tag with optional carry-forward.',
    why: 'Early nudges help you adjust mid-month instead of feeling surprised at month-end.',
    how: 'Create a budget for one category you care about, then tap the Spent amount anytime to inspect or edit contributing entries.',
    dataNeeded: 'Target category (or tag) and monthly limit in rupees.',
    insight: 'Exact budget used vs. remaining rupees, reconciled down to the paisa.',
  },
  {
    id: 'bills',
    route: 'bills',
    title: 'Bills, Recurring & Cash Flow Readiness',
    what: 'Tracks upcoming bills, recurring income/EMIs, and date-wise 7/15/30-day Cash Flow Readiness.',
    why: 'Prevents mid-month surprises when rent, credit card bills, or EMIs fall due before salary.',
    how: 'Add recurring bills once, mark paid in one tap, and check the Readiness tab for upcoming balance dips.',
    dataNeeded: 'Bill name, amount, due date, and repeat frequency.',
    insight: 'Date-wise projected balance curve and early shortfall or reserve-breach alerts.',
  },
  {
    id: 'analysis',
    route: 'analysis',
    title: 'Reports & Insights',
    what: 'Summarises spending, income, trends, and category breakdowns by month, year, or Indian Financial Year.',
    why: 'A 2-minute weekly or monthly review turns tracking into conscious financial decisions.',
    how: 'Pick Month, Year, or FY (1 Apr – 31 Mar) and tap any category bar to drill into its entries.',
    dataNeeded: 'Categorised income and expense entries.',
    insight: 'Savings rate, top spending drivers, and period-over-period trends.',
  },
  {
    id: 'networth',
    route: 'networth',
    title: 'Net Worth',
    what: 'Combines your liquid accounts, investments, and debts/loans into one long-term wealth snapshot.',
    why: 'Monthly spending fluctuates—net worth shows whether your overall position is steadily strengthening.',
    how: 'Review your Assets vs. Liabilities summary and save periodic snapshots to track long-term direction.',
    dataNeeded: 'Your accounts, plus any optional investments or loans you choose to track.',
    insight: 'True net financial position (Assets minus Liabilities) over time.',
  },
  {
    id: 'loans',
    route: 'investments',
    title: 'Loans & EMIs',
    what: 'Tracks home, vehicle, or personal loans alongside principal remaining, interest rate, and EMI schedule.',
    why: 'Seeing remaining interest cost clearly helps you decide when prepayments actually help.',
    how: 'Open Investments & Loans → Loans tab to add an active loan, log EMIs, or jump into Loan vs. Invest comparisons.',
    dataNeeded: 'Outstanding principal, interest rate, and monthly EMI (skip freely if you have no loans).',
    insight: 'Remaining tenure, total interest left, and prepayment impact.',
  },
  {
    id: 'investments',
    route: 'investments',
    title: 'Investments',
    what: 'Tracks mutual funds, SIPs, FDs, stocks, and goals with XIRR return calculations.',
    why: 'Keeps long-term wealth building visible alongside everyday cash flow.',
    how: 'Add holdings inside Investments & Loans and update current value periodically to refresh XIRR.',
    dataNeeded: 'Invested amount, current value, and dates (optional—skip if not applicable).',
    insight: 'Portfolio value, unrealised gain/loss, XIRR, and goal progress.',
  },
  {
    id: 'whatif',
    route: 'investments',
    title: 'What-If Lab (Loan vs. Invest)',
    what: 'Compares prepaying a loan vs. investing surplus cash across return, tax, and penalty assumptions.',
    why: 'Lets you test big financial decisions calmly with math before committing real money.',
    how: 'Open Investments & Loans → What-If Lab → Loan vs. Invest, enter surplus cash, and compare Strategies A, B, and C.',
    dataNeeded: 'Loan rate/tenure, expected return, tax rate, and surplus amount.',
    insight: 'Net wealth difference, sensitivity range, and emergency-fund safety check.',
  },
  {
    id: 'statement-import',
    route: 'statement-import',
    title: 'Smart Statement & UPI Import',
    what: 'Imports bank CSV/Excel/PDF statements and UPI screenshots 100% locally on your device.',
    why: 'Saves manual entry when catching up on bank or credit card activity without uploading files to any server.',
    how: 'Upload a statement or UPI screenshot, review matched categories and duplicates, then approve to post to your ledger.',
    dataNeeded: 'A bank CSV, Excel, PDF statement, or UPI payment screenshot.',
    insight: 'Staged review with duplicate detection and personal auto-categorisation rules.',
  },
  {
    id: 'import-export',
    route: 'import-export',
    title: 'Backup & Restore',
    what: 'Exports your entire ledger, receipts, and journey progress into a single portable .zip or .json file (or Google Drive).',
    why: 'Protects your offline-first data if you switch phones or clear browser storage.',
    how: 'Tap Download ZIP Backup periodically, or connect optional Google Drive sync. Restore anytime in one tap.',
    dataNeeded: 'No extra data required—everything in VittaMitra is packaged automatically.',
    insight: 'Last backup timestamp and complete device-independent data safety.',
  },
];

const TOUR_BY_ID = new Map(FEATURE_TOURS.map((t) => [t.id, t]));
const PRIMARY_TOUR_BY_ROUTE = new Map();
for (const t of FEATURE_TOURS) {
  if (!PRIMARY_TOUR_BY_ROUTE.has(t.route)) {
    PRIMARY_TOUR_BY_ROUTE.set(t.route, t);
  }
}

export class TutorialManager {
  constructor(repos, services) {
    this.repos = repos;
    this.services = services;
    this._activeSheetOpen = false;
  }

  listTours() {
    return FEATURE_TOURS;
  }

  getTour(tourId) {
    return TOUR_BY_ID.get(tourId) || null;
  }

  getTourForRoute(routeKey) {
    return PRIMARY_TOUR_BY_ROUTE.get(routeKey) || null;
  }

  async isTourSeen(tourId) {
    try {
      const st = await this.services.journey.getState();
      return Boolean(st?.seen_tutorials?.[tourId]);
    } catch {
      return true;
    }
  }

  async markTourSeen(tourId) {
    try {
      const st = await this.services.journey.getState();
      if (!st.seen_tutorials) st.seen_tutorials = {};
      if (!st.seen_tutorials[tourId]) {
        st.seen_tutorials[tourId] = nowIsoUtc();
        await this.services.journey._saveState(st);
      }
      return st;
    } catch {
      return null;
    }
  }

  async resetAllTours() {
    try {
      const st = await this.services.journey.getState();
      st.seen_tutorials = {};
      await this.services.journey._saveState(st);
      return st;
    } catch {
      return null;
    }
  }

  /**
   * Automatically shows a feature's contextual guide on FIRST visit only,
   * unless the user has already seen it or paused Journey reminders.
   */
  async maybeShowFirstVisit(tourId) {
    try {
      const tour = this.getTour(tourId);
      if (!tour || this._activeSheetOpen) return false;
      const st = await this.services.journey.getState();
      if (st.reminders_paused) return false;
      if (st.seen_tutorials?.[tour.id]) return false;
      this.openTour(tour.id, { isFirstVisit: true });
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Opens a short, contextual bottom sheet for any of the 13 features.
   * Safe to call manually via `?` button or Journey Hub even when reminders are paused.
   */
  openTour(tourId, { isFirstVisit = false } = {}) {
    try {
      const tour = this.getTour(tourId);
      if (!tour) return false;
      this._activeSheetOpen = true;

      openSheet({
        title: `Guide: ${tour.title}`,
        bodyHtml: `
          <div class="stack tour-sheet-body" style="gap:10px;">
            <div class="tour-item">
              <div class="tour-label">What it does</div>
              <div class="tour-text">${escapeHtml(tour.what)}</div>
            </div>
            <div class="tour-item">
              <div class="tour-label">Why it matters</div>
              <div class="tour-text">${escapeHtml(tour.why)}</div>
            </div>
            <div class="tour-item">
              <div class="tour-label">How to use it</div>
              <div class="tour-text">${escapeHtml(tour.how)}</div>
            </div>
            <div class="tour-item">
              <div class="tour-label">What data is needed</div>
              <div class="tour-text">${escapeHtml(tour.dataNeeded)}</div>
            </div>
            <div class="tour-item">
              <div class="tour-label">What insight you get</div>
              <div class="tour-text">${escapeHtml(tour.insight)}</div>
            </div>
            <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:6px;">
              <button type="button" class="btn btn-primary" style="flex:1;" id="btn-tour-got-it">Got it</button>
              ${isFirstVisit ? `<button type="button" class="btn btn-ghost btn-sm" id="btn-tour-pause">Pause auto-guides</button>` : ''}
            </div>
          </div>
        `,
        onMount: (panel, close) => {
          // Mark seen immediately on open/dismiss so it never nags twice
          this.markTourSeen(tour.id).catch(() => {});

          panel.querySelector('#btn-tour-got-it')?.addEventListener('click', () => {
            this._activeSheetOpen = false;
            close();
          });

          panel.querySelector('#btn-tour-pause')?.addEventListener('click', async () => {
            this._activeSheetOpen = false;
            await this.services.journey.setRemindersPaused(true);
            close();
            showToast('Auto-guides paused. Tap ? anytime to view a guide.');
          });
        },
        onClose: () => {
          this._activeSheetOpen = false;
        },
      });
      return true;
    } catch {
      this._activeSheetOpen = false;
      return false;
    }
  }
}

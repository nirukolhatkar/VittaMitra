import { escapeHtml } from '../../utils/dom.js';
import { AccountRepository } from '../../db/repositories/accountRepository.js';
import { formatDisplayINR, formatINR, getAdaptiveAmountClass } from '../../utils/money.js';
import { formatRelativeDate, getFinancialYearInfo, getMonthLabel, shiftMonth, toLocalDateString } from '../../utils/date.js';
import {
  bindTransactionLongPress,
  openGlobalSearchModal,
  setPageContext,
} from '../../services/txContextClipboard.js';

function getGreeting() {
  const hr = new Date().getHours();
  if (hr < 12) return 'Good morning';
  if (hr < 17) return 'Good afternoon';
  return 'Good evening';
}

function homeMaskOrFormat(paise, show, displayMode = 'full', maxChars = 11) {
  if (!show) return '*****';
  return displayMode === 'full'
    ? formatINR(paise)
    : formatDisplayINR(paise, { mode: displayMode, context: 'home', maxChars });
}

function getDaysLeftInMonth(year, month) {
  const now = new Date();
  const totalDays = new Date(year, month + 1, 0).getDate();
  if (now.getFullYear() === year && now.getMonth() === month) {
    return Math.max(0, totalDays - now.getDate());
  }
  return null;
}

export async function renderHomeView(container, ctx) {
  const { state, repos, services } = ctx;
  const [settings, monthly, categories, accounts, favorites, frequent, budgets, bills, cashFlowReadiness, journeyProgress] =
    await Promise.all([
      repos.settings.getSettings(),
      services.transactions.getMonthlySummary(state.selectedYear, state.selectedMonth),
      repos.categories.list({ includeArchived: true }),
      repos.accounts.list({ includeArchived: false }),
      repos.favorites.list(),
      services.transactions.getFrequentTransactions(7, 5),
      services.budgets.evaluateMonthBudgets(state.selectedYear, state.selectedMonth).catch(() => ({ budgets: [] })),
      (typeof repos.bills.listAll === 'function' ? repos.bills.listAll() : Promise.resolve([])).catch(() => []),
      services.cashFlow ? services.cashFlow.evaluateReadiness({ horizonDays: 15 }).catch(() => null) : Promise.resolve(null),
      services.journey ? services.journey.evaluateProgress().catch(() => null) : Promise.resolve(null),
    ]);
  const balanceSummary = AccountRepository.summarizeAccounts(accounts);

  const catMap = new Map(categories.map((c) => [c.id, c]));
  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const showBalances = settings.show_balances !== false;
  const displayMode = settings.amount_display_mode || 'auto';
  const expenseStr = homeMaskOrFormat(monthly.expensePaise, showBalances, displayMode, 11);
  const incomeStr = homeMaskOrFormat(monthly.incomePaise, showBalances, displayMode, 11);
  const expenseSizeCls = getAdaptiveAmountClass(expenseStr, 'home');
  const incomeSizeCls = getAdaptiveAmountClass(incomeStr, 'home');
  const fy = getFinancialYearInfo(
    state.selectedYear,
    state.selectedMonth,
    settings.financial_year_start_month || 4
  );
  const monthLabel = getMonthLabel(state.selectedYear, state.selectedMonth);
  const shortMonth = monthLabel.split(' ')[0].slice(0, 3) + ' ' + state.selectedYear;
  const recentFive = monthly.transactions.slice(0, 5);
  const availNeg = balanceSummary.totalAvailableBalancePaise < 0;

  setPageContext(ctx, {
    route: 'home',
    label: 'Today',
    shortLabel: '',
    overrides: {},
  });

  // Carry-Forward Balance as of end of previous month
  const prevMonthEndDate = new Date(state.selectedYear, state.selectedMonth, 0);
  const prevMonthEndKey = `${prevMonthEndDate.getFullYear()}-${String(prevMonthEndDate.getMonth() + 1).padStart(2, '0')}-${String(prevMonthEndDate.getDate()).padStart(2, '0')}`;
  const availAssetAccounts = accounts.filter((a) => a.type !== 'credit_card' && a.include_in_available_balance !== false);
  const prevBalanceMap = await repos.accounts.getReconciledBalancesAsOf(availAssetAccounts, prevMonthEndKey).catch(() => new Map());
  let carryForwardPaise = 0;
  for (const a of availAssetAccounts) {
    carryForwardPaise += prevBalanceMap.get(a.id) || 0;
  }
  const netCashFlowWithCarryPaise = carryForwardPaise + monthly.incomePaise - monthly.expensePaise;

  // Donut Chart: Spending as % of Budget (when set) or Spending / (Income + Carry Forward)
  const budgetList = Array.isArray(budgets?.budgets) ? budgets.budgets : [];
  const totalBudgetPaise = budgetList.reduce((s, b) => s + (b.effectiveBudgetPaise || b.baseBudgetPaise || 0), 0);
  const hasBudget = totalBudgetPaise > 0;
  const availableFundsPaise = monthly.incomePaise + carryForwardPaise;
  const showDonut = hasBudget || availableFundsPaise > 0 || monthly.expensePaise > 0;
  let rawPct = 0;
  let ringRatio = 0;
  let donutSubtitle = hasBudget ? 'of budget' : 'of funds';
  let donutIsOver = false;
  if (hasBudget) {
    rawPct = Math.round((monthly.expensePaise / totalBudgetPaise) * 100);
    ringRatio = Math.min(1, Math.max(0, monthly.expensePaise / totalBudgetPaise));
    donutIsOver = rawPct > 100;
  } else if (availableFundsPaise > 0) {
    rawPct = Math.round((monthly.expensePaise / availableFundsPaise) * 100);
    ringRatio = Math.min(1, Math.max(0, monthly.expensePaise / availableFundsPaise));
    donutIsOver = rawPct > 100;
  } else if (monthly.expensePaise > 0) {
    rawPct = 100;
    ringRatio = 1;
    donutSubtitle = 'overdrawn';
    donutIsOver = true;
  }
  const circumference = 2 * Math.PI * 46;
  const dashOffset = Math.round(circumference * (1 - ringRatio));
  const daysLeft = getDaysLeftInMonth(state.selectedYear, state.selectedMonth);

  const balanceAccounts = accounts.filter((a) => a.type !== 'credit_card');
  const nowLocal = new Date();
  const todayMidnight = new Date(nowLocal.getFullYear(), nowLocal.getMonth(), nowLocal.getDate()).getTime();
  const MS_PER_DAY = 86400000;
  const dueSoonBills = bills
    .filter((b) => b.is_active !== false && b.status !== 'paid' && b.due_date)
    .map((b) => {
      const parts = String(b.due_date).slice(0, 10).split('-').map(Number);
      if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return null;
      const dueMidnight = new Date(parts[0], parts[1] - 1, parts[2]).getTime();
      const diff = Math.round((dueMidnight - todayMidnight) / MS_PER_DAY);
      return { ...b, daysUntil: diff };
    })
    .filter((b) => b && b.daysUntil <= 14)
    .sort((a, b) => a.daysUntil - b.daysUntil)
    .slice(0, 3);

  container.innerHTML = `
    <div class="stack" style="gap:16px;">
      <!-- Clean Greeting Row (no duplicate VittaMitra H1) -->
      <div class="toolbar" style="padding:2px 0;">
        <div style="font-size:1.05rem; font-weight:600; color:var(--text-primary);">${getGreeting()}</div>
        <div class="row-actions" style="gap:8px;">
          <span class="fy-badge">${fy.label}</span>
          <button type="button" class="icon-btn" id="btn-home-eye" aria-label="Toggle balance visibility" title="Toggle balance visibility">
            ${showBalances ? '👁️' : '🙈'}
          </button>
        </div>
      </div>

      ${
        cashFlowReadiness && (cashFlowReadiness.overallStatus === 'shortfall' || cashFlowReadiness.overallStatus === 'reserve_breach')
          ? `<button type="button" id="btn-home-cf-alert" class="alert-banner ${cashFlowReadiness.overallStatus === 'shortfall' ? 'alert-danger' : 'alert-warning'}" style="width:100%; text-align:left; padding:10px 14px; border-radius:var(--radius-md); cursor:pointer;">
              <div style="flex:1; min-width:0;">
                <div style="font-weight:700; font-size:0.86rem;">
                  ${cashFlowReadiness.overallStatus === 'shortfall' ? '🚨 Upcoming cash shortfall' : '⚠️ Upcoming reserve breach'} (${cashFlowReadiness.horizonDays}d)
                </div>
                <div style="font-size:0.78rem; opacity:0.95;">
                  ${escapeHtml((cashFlowReadiness.shortfalls[0] || cashFlowReadiness.reserveBreaches[0])?.obligation || 'Upcoming obligation')} on ${escapeHtml(cashFlowReadiness.lowestProjectedDate)} · Tap to review ›
                </div>
              </div>
            </button>`
          : ''
      }

      ${
        journeyProgress && journeyProgress.showWelcomeBack
          ? `<section class="card home-welcome-back" aria-label="Welcome back">
              <div class="home-welcome-back-head">
                <strong>Welcome back — your progress is right where you left it.</strong>
                <button type="button" class="btn btn-ghost btn-sm" id="btn-home-dismiss-wb" aria-label="Dismiss welcome back">✕</button>
              </div>
              <p class="item-meta" style="margin:4px 0 10px;">
                Missing a few days never erases your habit. Start calmly with one simple action today.
              </p>
              <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button type="button" class="btn btn-primary btn-sm" id="btn-home-wb-log">Log today’s expense</button>
                <a href="#/accounts" class="btn btn-secondary btn-sm">Check balances</a>
              </div>
            </section>`
          : ''
      }

      ${
        journeyProgress && !journeyProgress.state?.reminders_paused
          ? `<section class="card home-journey-strip" aria-label="Financial progress">
              <div class="home-journey-top">
                <div>
                  <div class="home-journey-kicker">
                    Level ${journeyProgress.levelInfo.level} · ${escapeHtml(journeyProgress.levelInfo.name)} · ${journeyProgress.activeRecordingDays} active day${journeyProgress.activeRecordingDays === 1 ? '' : 's'}
                  </div>
                  <div class="home-journey-identity">
                    ${journeyProgress.earnedIdentityCount > 0
                      ? `“${escapeHtml(journeyProgress.activeIdentity.statement)}”`
                      : escapeHtml(journeyProgress.nextMission ? journeyProgress.nextMission.title : 'Continue your financial habit')}
                  </div>
                </div>
                <a href="#/journey" class="btn btn-ghost btn-sm">Journey ›</a>
              </div>
              ${journeyProgress.nextMission
                ? `<div class="home-journey-next">
                    <span class="item-meta">Next: ${escapeHtml(journeyProgress.nextMission.title)}</span>
                    <button type="button" class="btn btn-secondary btn-sm" data-home-journey-go="${escapeHtml(journeyProgress.nextMission.route)}">${escapeHtml(journeyProgress.nextMission.ctaLabel)}</button>
                  </div>`
                : ''}
            </section>`
          : ''
      }

      <!-- Primary Financial Summary Card -->
      <section class="card" style="padding:18px; border-radius:var(--radius-lg);" aria-label="Monthly cash flow overview">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; margin-bottom:14px;">
          <span style="font-size:0.95rem; font-weight:600; color:var(--text-primary);">
            ${hasBudget ? 'Budget & cash flow' : 'Monthly cash flow'}
          </span>
          <div class="month-pill" aria-label="Month navigation">
            <button type="button" id="btn-prev-month" aria-label="Previous month">‹</button>
            <span class="month-pill-label" id="dashboard-month-label">${shortMonth}</span>
            <button type="button" id="btn-next-month" aria-label="Next month">›</button>
          </div>
        </div>

        <div style="display:flex; align-items:center; justify-content:space-between; gap:16px;">
          <div style="flex:1; min-width:0;">
            <div style="font-size:0.8rem; font-weight:500; color:var(--text-secondary);">Available Balance</div>
            <div class="${availNeg ? 'text-danger' : ''}" style="font-size:clamp(1.35rem, 5.2vw, 1.75rem); font-weight:700; font-variant-numeric:tabular-nums; letter-spacing:-0.02em; margin-top:4px; overflow-wrap:anywhere;">
              ${homeMaskOrFormat(balanceSummary.totalAvailableBalancePaise, showBalances)}
            </div>
            <div style="font-size:0.78rem; color:var(--text-secondary); margin-top:6px;">
              Carry forward <strong style="color:var(--text-primary);">${homeMaskOrFormat(carryForwardPaise, showBalances)}</strong>${daysLeft !== null ? ` · ${daysLeft}d left` : ''}
            </div>
          </div>

          ${
            showDonut
              ? `<svg width="92" height="92" viewBox="0 0 112 112" role="img" aria-label="${rawPct} percent utilization" style="flex:none;">
                  <circle cx="56" cy="56" r="46" fill="none" stroke="var(--border-subtle)" stroke-width="8"></circle>
                  <circle cx="56" cy="56" r="46" fill="none"
                    stroke="${donutIsOver ? 'var(--danger)' : 'var(--accent)'}"
                    stroke-width="8" stroke-linecap="round"
                    stroke-dasharray="${Math.round(circumference)}"
                    stroke-dashoffset="${dashOffset}"
                    transform="rotate(-90 56 56)"></circle>
                  <text x="56" y="54" text-anchor="middle" font-size="16" font-weight="700" fill="var(--text-primary)">${Math.min(rawPct, 999)}%</text>
                  <text x="56" y="70" text-anchor="middle" font-size="9.5" fill="var(--text-secondary)">${donutSubtitle}</text>
                </svg>`
              : ''
          }
        </div>

        <div class="home-cashflow-row">
          <div class="home-cashflow-cell">
            <div class="home-cashflow-label">Spending</div>
            <div id="metric-month-expense" class="home-cashflow-val text-danger ${expenseSizeCls}" title="${showBalances ? formatINR(monthly.expensePaise) : ''}">
              ${expenseStr}
            </div>
          </div>
          <div class="home-cashflow-cell home-cashflow-cell-right">
            <div class="home-cashflow-label">Income</div>
            <div id="metric-month-income" class="home-cashflow-val text-success ${incomeSizeCls}" title="${showBalances ? formatINR(monthly.incomePaise) : ''}">
              ${incomeStr}
            </div>
          </div>
        </div>

        <div class="hero-footer-pill" style="margin-top:12px; padding:10px 12px; gap:8px;">
          <div style="min-width:0;">
            <div style="font-size:0.8rem; font-weight:600; color:var(--text-primary);">Net Cash Flow</div>
            <div style="font-size:0.72rem; color:var(--text-secondary);">Income + Carry Forward</div>
          </div>
          <strong class="${netCashFlowWithCarryPaise < 0 ? 'text-danger' : 'text-success'}" style="font-size:clamp(0.98rem, 4vw, 1.12rem); font-variant-numeric:tabular-nums; text-align:right; overflow-wrap:anywhere;">
            ${homeMaskOrFormat(netCashFlowWithCarryPaise, showBalances)}
          </strong>
        </div>
      </section>

      <!-- Account Balances Strip -->
      <section class="stack" style="gap:10px;">
        <div class="section-heading">
          <span class="section-heading-left">Balances</span>
          <a href="#/accounts" id="metric-available-balance" style="font-size:0.86rem; font-weight:600; font-variant-numeric:tabular-nums; color:${availNeg ? 'var(--danger)' : 'var(--accent-ink)'};">
            ${homeMaskOrFormat(balanceSummary.totalAvailableBalancePaise, showBalances)} ›
          </a>
        </div>
        ${
          balanceAccounts.length === 0
            ? `<div class="card" style="padding:14px 16px;">
                <div class="item-meta">No accounts yet. <a href="#/accounts" style="color:var(--accent-ink); font-weight:600;">Add your first account →</a></div>
              </div>`
            : `<div class="orbit-balance-strip">
                ${balanceAccounts
                  .map((acc) => {
                    const bal = acc.current_balance_paise ?? acc.opening_balance_paise ?? 0;
                    return `
                      <button type="button" class="orbit-balance-card" style="text-align:left;" data-orbit-acc="${acc.id}">
                        <div class="item-meta" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(acc.name)}</div>
                        <div class="${bal < 0 ? 'text-danger' : ''}" style="font-size:1.05rem; font-weight:700; font-variant-numeric:tabular-nums; margin-top:4px;">
                          ${homeMaskOrFormat(bal, showBalances)}
                        </div>
                      </button>`;
                  })
                  .join('')}
              </div>`
        }
      </section>

      <!-- Due Soon Bills -->
      ${
        dueSoonBills.length > 0
          ? `<section class="stack" style="gap:10px;">
              <div class="section-heading">
                <span class="section-heading-left">Due soon</span>
                <a href="#/bills" style="color:var(--accent-ink); font-size:0.84rem; font-weight:600;">Manage ›</a>
              </div>
              <div class="grouped-card">
                ${dueSoonBills
                  .map(
                    (bill) => `
                    <div class="grouped-row">
                      <div class="list-row-main" style="flex:1; min-width:0;">
                        <span class="avatar-badge">🧾</span>
                        <div style="min-width:0;">
                          <div class="item-title">${escapeHtml(bill.name)}</div>
                          <div class="item-meta ${bill.daysUntil < 0 ? 'text-danger' : ''}">${
                            bill.daysUntil < 0
                              ? `Overdue by ${Math.abs(bill.daysUntil)} day${Math.abs(bill.daysUntil) === 1 ? '' : 's'}`
                              : bill.daysUntil === 0
                                ? 'Due today'
                                : bill.daysUntil === 1
                                  ? 'Due tomorrow'
                                  : `Due in ${bill.daysUntil} days`
                          } · ${escapeHtml(String(bill.due_date || '').slice(0, 10))}</div>
                        </div>
                      </div>
                      <strong style="font-variant-numeric:tabular-nums;">${homeMaskOrFormat(bill.amount_paise || 0, showBalances)}</strong>
                    </div>`
                  )
                  .join('')}
              </div>
            </section>`
          : ''
      }

      <!-- Quick & Favourites -->
      ${
        favorites.length > 0 || frequent.length > 0
          ? `<section class="stack" style="gap:10px;">
              <div class="section-heading">
                <span class="section-heading-left">Quick &amp; Favourites</span>
                <span class="item-meta">One-tap prefill</span>
              </div>
              <div class="quick-strip">
                ${favorites
                  .map(
                    (fav) => `
                    <button type="button" class="quick-pill" data-home-fav="${fav.id}">
                      <span style="font-size:1rem; color:var(--warning);">★</span>
                      <div>
                        <div class="item-title" style="font-size:0.84rem;">${escapeHtml(fav.name)}</div>
                        <div class="item-meta">${homeMaskOrFormat(fav.amount_paise, showBalances)}</div>
                      </div>
                    </button>`
                  )
                  .join('')}
                ${frequent
                  .map((item, idx) => {
                    const tx = item.sample;
                    const cat = tx.category_id ? catMap.get(tx.category_id) : null;
                    const label = tx.description || cat?.name || tx.type;
                    return `
                      <button type="button" class="quick-pill" data-home-freq="${idx}">
                        <span style="font-size:1rem;">${escapeHtml(cat?.icon || '⚡')}</span>
                        <div>
                          <div class="item-title" style="font-size:0.84rem;">${escapeHtml(label)}</div>
                          <div class="item-meta">${homeMaskOrFormat(tx.amount_paise, showBalances)} · ${item.count}×</div>
                        </div>
                      </button>`;
                  })
                  .join('')}
              </div>
            </section>`
          : ''
      }

      <!-- Recent Transactions -->
      <section class="stack" style="gap:10px;">
        <div class="section-heading">
          <span class="section-heading-left">Recent Transactions</span>
          <a href="#/transactions" style="color:var(--accent-ink); font-size:0.84rem; font-weight:600;">See all ›</a>
        </div>
        ${
          recentFive.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🧾</div>
                <div class="empty-state-title">No transactions in ${shortMonth}</div>
                <div class="empty-state-text">Tap <strong>+ Add</strong> above to record your first entry.</div>
              </div>`
            : `<div class="grouped-card">
                ${recentFive
                  .map((tx) => {
                    const cat = tx.category_id ? catMap.get(tx.category_id) : null;
                    const srcAcc = accMap.get(tx.account_id);
                    const dstAcc = tx.to_account_id ? accMap.get(tx.to_account_id) : null;
                    const icon = tx.type === 'BALANCE_ADJUSTMENT' ? '⚖️' : tx.type === 'transfer' ? '⇄' : tx.type === 'debt' ? '🤝' : cat?.icon || '🧾';
                    const title = tx.description || (tx.type === 'transfer' ? 'Transfer' : cat?.name || 'Transaction');
                    const sub =
                      tx.type === 'transfer'
                        ? `${srcAcc?.name || 'Account'} → ${dstAcc?.name || 'Account'}`
                        : `${srcAcc?.name || 'Account'}`;
                    const amtClass =
                      tx.type === 'income' ? 'text-success' : tx.type === 'expense' ? 'text-danger' : 'text-secondary';
                    const prefix = tx.type === 'income' ? '+' : tx.type === 'expense' ? '−' : '';
                    return `
                      <div class="grouped-row grouped-row-clickable" data-home-edit-tx="${tx.id}">
                        <div class="list-row-main" style="flex:1; min-width:0;">
                          <span class="avatar-badge">${escapeHtml(icon)}</span>
                          <div style="min-width:0;">
                            <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(title)}</div>
                            <div class="item-meta">${escapeHtml(sub)}</div>
                          </div>
                        </div>
                        <div class="tx-amt-col">
                          <strong class="${amtClass}" style="font-variant-numeric:tabular-nums;">
                            ${showBalances ? `${prefix}${formatINR(tx.amount_paise)}` : '*****'}
                          </strong>
                          <span class="tx-date-sub">${escapeHtml(formatRelativeDate(tx.date_key))}</span>
                        </div>
                      </div>`;
                  })
                  .join('')}
              </div>`
        }
      </section>
    </div>
  `;

  container.querySelector('#btn-home-cf-alert')?.addEventListener('click', () => {
    state.billsTab = 'readiness';
    if (typeof ctx.navigateTo === 'function') ctx.navigateTo('bills');
    else window.location.hash = '#/bills';
  });

  container.querySelector('#btn-home-dismiss-wb')?.addEventListener('click', async () => {
    try {
      await services.journey?.dismissWelcomeBackToday();
    } catch {
      // Fail-safe
    }
    renderHomeView(container, ctx);
  });

  container.querySelector('#btn-home-wb-log')?.addEventListener('click', () => {
    state.txDraft = { type: 'expense', date: toLocalDateString(), returnRoute: 'home' };
    if (typeof ctx.navigateTo === 'function') ctx.navigateTo('add-transaction');
    else window.location.hash = '#/add-transaction';
  });

  container.querySelectorAll('[data-home-journey-go]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const route = btn.getAttribute('data-home-journey-go') || 'journey';
      if (typeof ctx.navigateTo === 'function') ctx.navigateTo(route);
      else window.location.hash = `#/${route}`;
    });
  });

  container.querySelector('#btn-home-eye')?.addEventListener('click', async () => {
    await repos.settings.updateSettings({ show_balances: !showBalances });
    renderHomeView(container, ctx);
  });

  container.querySelector('#btn-prev-month')?.addEventListener('click', () => {
    const next = shiftMonth(state.selectedYear, state.selectedMonth, -1);
    state.selectedYear = next.year;
    state.selectedMonth = next.month;
    renderHomeView(container, ctx);
  });

  container.querySelector('#btn-next-month')?.addEventListener('click', () => {
    const next = shiftMonth(state.selectedYear, state.selectedMonth, 1);
    state.selectedYear = next.year;
    state.selectedMonth = next.month;
    renderHomeView(container, ctx);
  });

  container.querySelectorAll('[data-orbit-acc]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedAccountId = btn.getAttribute('data-orbit-acc');
      window.location.hash = '#/account-detail';
    });
  });

  container.querySelectorAll('[data-home-edit-tx]').forEach((row) => {
    row.addEventListener('click', () => {
      state.txDraft = { editId: row.getAttribute('data-home-edit-tx'), returnRoute: 'home' };
      window.location.hash = '#/add-transaction';
    });
  });

  bindTransactionLongPress(container, ctx, {
    selector: '[data-home-edit-tx]',
    attr: 'data-home-edit-tx',
    onRefresh: () => renderHomeView(container, ctx),
  });

  container.querySelectorAll('[data-home-fav]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const fav = await repos.favorites.getById(btn.getAttribute('data-home-fav'));
      if (!fav) return;
      state.txDraft = {
        type: fav.type,
        amount_paise: fav.amount_paise,
        category_id: fav.category_id,
        account_id: fav.account_id,
        to_account_id: fav.to_account_id,
        description: fav.description || fav.name,
        family_member_id: fav.family_member_id,
        tag_ids: fav.tag_ids,
        date: toLocalDateString(),
        returnRoute: 'home',
      };
      window.location.hash = '#/add-transaction';
    });
  });

  container.querySelectorAll('[data-home-freq]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-home-freq'));
      const item = frequent[idx];
      if (!item) return;
      const tx = item.sample;
      state.txDraft = {
        type: tx.type,
        amount_paise: tx.amount_paise,
        category_id: tx.category_id,
        account_id: tx.account_id,
        to_account_id: tx.to_account_id,
        description: tx.description,
        family_member_id: tx.family_member_id,
        tag_ids: tx.tag_ids,
        date: toLocalDateString(),
        returnRoute: 'home',
      };
      window.location.hash = '#/add-transaction';
    });
  });
}

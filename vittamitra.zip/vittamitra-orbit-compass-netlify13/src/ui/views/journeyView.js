import { escapeHtml } from '../../utils/dom.js';
import { formatINR } from '../../utils/money.js';
import { openSheet } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import {
  JOURNEY_ACHIEVEMENTS,
  JOURNEY_IDENTITIES,
  JOURNEY_MISSIONS,
  STARTING_BALANCE_STATUS,
} from '../../services/journeyEngine.js';

const THEME_ORDER = ['Awareness', 'Intentional Spending', 'Preparedness', 'Confidence'];

/**
 * VittaMitra Financial Journey Hub (#/journey).
 *
 * Displays:
 * - Mastery level, XP bar, cumulative Active Days (never resets on missed days)
 * - Four Financial Identity milestones (earned only via real ledger actions; backup is optional)
 * - Single Next Recommended Action spotlight with explicit 3-state starting balance status
 * - Flexible 10-mission roadmap grouped by habit theme (no calendar-week gating)
 * - Meaningful Achievements + separate Recommended Data-Protection milestone
 * - Pause / Resume Journey Reminders toggle
 */
export async function renderJourneyView(container, ctx) {
  const { services, repos, navigateTo } = ctx;

  let progress;
  try {
    progress = await services.journey.evaluateProgress();
  } catch (err) {
    container.innerHTML = `
      <div class="card">
        <div class="item-title">Financial Journey temporarily unavailable</div>
        <p class="item-meta" style="margin-top:6px;">${escapeHtml(err?.message || 'Unable to load progress right now.')}</p>
        <a href="#/home" class="btn btn-primary btn-sm" style="margin-top:10px;">Go to Dashboard</a>
      </div>
    `;
    return;
  }

  const {
    state: jState,
    levelInfo,
    nextMission,
    startingBalanceStatus,
    hasBackup,
    activeIdentity,
    earnedIdentityCount,
    completedCount,
    totalMissions,
    activeRecordingDays,
    newlyCompletedMissions,
    newlyUnlockedAchievements,
    newlyEarnedIdentities,
  } = progress;

  const unlockedAchCount = Object.keys(jState.achievements || {}).length;
  const celebrationItems = [
    ...(newlyEarnedIdentities || []).map((id) => `Identity earned: “${id.statement}”`),
    ...newlyCompletedMissions.map((m) => `Habit step complete: ${m.title} (+${m.xp} XP)`),
    ...newlyUnlockedAchievements.map((a) => `Milestone unlocked: ${a.title} (+${a.xp} XP)`),
  ];

  const balanceStatusNote = () => {
    if (startingBalanceStatus === STARTING_BALANCE_STATUS.NOT_ESTABLISHED) {
      return `<div class="journey-balance-note">Status: <strong>Starting balance not yet established</strong> — enter today’s real balance on Accounts, or explicitly confirm ₹0 below.</div>`;
    }
    if (startingBalanceStatus === STARTING_BALANCE_STATUS.CONFIRMED_ZERO) {
      return `<div class="journey-balance-note is-ok">Status: <strong>Confirmed ₹0 starting balance</strong></div>`;
    }
    return '';
  };

  const buildSpotlightSecondaryAction = (mission) => {
    if (!mission) return '';
    if (mission.id === 'set_balances' && startingBalanceStatus === STARTING_BALANCE_STATUS.NOT_ESTABLISHED) {
      return `<button type="button" class="btn btn-secondary btn-sm" id="btn-journey-confirm-zero">Confirm ₹0 starting balance</button>`;
    }
    if (mission.id === 'weekly_summary') {
      return `<button type="button" class="btn btn-secondary btn-sm" id="btn-journey-weekly-review">Complete Weekly Check-in</button>`;
    }
    if (mission.id === 'understand_net_worth') {
      return `<button type="button" class="btn btn-secondary btn-sm" id="btn-journey-confirm-nw">Mark Net Worth Reviewed</button>`;
    }
    return '';
  };

  const spotlightHtml = nextMission
    ? `
      <section class="card journey-spotlight" aria-label="Next recommended action">
        <div class="journey-spotlight-top">
          <span class="journey-stage-pill">${escapeHtml(nextMission.stage)} · Step ${nextMission.order} of ${totalMissions}</span>
          <span class="journey-xp-pill">+${nextMission.xp} XP</span>
        </div>
        <h2 class="journey-spotlight-title">${escapeHtml(nextMission.title)}</h2>
        <p class="journey-spotlight-why">${escapeHtml(nextMission.why)}</p>
        ${nextMission.id === 'set_balances' ? balanceStatusNote() : ''}
        <div class="journey-spotlight-actions">
          ${nextMission.id === 'first_monthly_review'
            ? `<button type="button" class="btn btn-primary" id="btn-journey-monthly-review">Start 30-Day Review</button>`
            : `<button type="button" class="btn btn-primary" data-journey-go="${escapeHtml(nextMission.route)}">${escapeHtml(nextMission.ctaLabel)}</button>`
          }
          ${buildSpotlightSecondaryAction(nextMission)}
          ${nextMission.optional
            ? `<button type="button" class="btn btn-ghost btn-sm" data-journey-skip="${escapeHtml(nextMission.id)}">Skip for now</button>`
            : ''}
        </div>
      </section>
    `
    : `
      <section class="card journey-spotlight journey-spotlight-done" aria-label="Journey milestone summary">
        <div class="journey-spotlight-top">
          <span class="journey-stage-pill">All Active Steps Complete</span>
          <span class="journey-xp-pill">${levelInfo.xp} XP</span>
        </div>
        <h2 class="journey-spotlight-title">You’ve built a calm, sustainable money habit.</h2>
        <p class="journey-spotlight-why">
          Keep your clarity effortless with quick weekly check-ins and a 30-day review whenever it suits you.
        </p>
        <div class="journey-spotlight-actions">
          <button type="button" class="btn btn-primary" id="btn-journey-monthly-review">Run Monthly Review</button>
          <a href="#/home" class="btn btn-secondary">Back to Dashboard</a>
        </div>
      </section>
    `;

  const identitiesHtml = JOURNEY_IDENTITIES.map((ident) => {
    const earnedAt = jState.earned_identities?.[ident.id];
    const earned = Boolean(earnedAt);
    return `
      <div class="card journey-identity-card ${earned ? 'is-earned' : ''}">
        <div class="journey-identity-head">
          <span class="journey-identity-tag">${escapeHtml(ident.theme)}</span>
          <span class="badge-pill ${earned ? 'badge-success' : ''}">${earned ? 'Earned ✓' : 'In progress'}</span>
        </div>
        <div class="journey-identity-quote">“${escapeHtml(ident.statement)}”</div>
        <div class="journey-identity-req">${escapeHtml(ident.requirement)}</div>
      </div>
    `;
  }).join('');

  // Flexible roadmap grouped by habit theme (zero calendar-week locks)
  const stagesHtml = THEME_ORDER.map((theme) => {
    const stageMissions = JOURNEY_MISSIONS.filter((m) => m.stage === theme);
    if (!stageMissions.length) return '';
    const rows = stageMissions
      .map((m) => {
        const isDone = Boolean(jState.completed_missions[m.id]);
        const isSkipped = !isDone && Boolean(jState.skipped_missions[m.id]);
        const isCurrent = nextMission && nextMission.id === m.id;
        const statusClass = isDone
          ? 'is-done'
          : isCurrent
            ? 'is-current'
            : isSkipped
              ? 'is-skipped'
              : 'is-upcoming';
        const statusIcon = isDone ? '✓' : isCurrent ? '→' : isSkipped ? '–' : String(m.order);
        const statusText = isDone
          ? 'Completed'
          : isCurrent
            ? 'Recommended next'
            : isSkipped
              ? 'Skipped'
              : m.optional
                ? 'Optional · Open anytime'
                : 'Core step';

        return `
          <div class="grouped-row journey-mission-row ${statusClass}">
            <div class="journey-mission-left">
              <span class="journey-step-dot ${statusClass}" aria-hidden="true">${statusIcon}</span>
              <div style="min-width:0;">
                <div class="item-title">${escapeHtml(m.title)}</div>
                <div class="item-meta">
                  ${statusText} · +${m.xp} XP
                </div>
              </div>
            </div>
            <div class="journey-mission-right">
              ${isDone
                ? `<span class="badge-pill badge-success">Done</span>`
                : isSkipped
                  ? `<button type="button" class="btn btn-ghost btn-sm" data-journey-unskip="${escapeHtml(m.id)}">Resume</button>`
                  : m.id === 'first_monthly_review'
                    ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-roadmap-monthly-review">Review</button>`
                    : `<button type="button" class="btn btn-secondary btn-sm" data-journey-go="${escapeHtml(m.route)}">Open</button>`
              }
            </div>
          </div>
        `;
      })
      .join('');

    return `
      <div class="journey-stage-block">
        <div class="journey-stage-label">${escapeHtml(theme)}</div>
        <div class="grouped-card">${rows}</div>
      </div>
    `;
  }).join('');

  const achievementsHtml = JOURNEY_ACHIEVEMENTS.map((ach) => {
    const unlockedAt = jState.achievements[ach.id];
    const unlocked = Boolean(unlockedAt);
    const dateLabel = unlocked ? String(unlockedAt).slice(0, 10) : `+${ach.xp} XP`;
    return `
      <div class="card journey-ach-card ${unlocked ? 'is-unlocked' : 'is-locked'}">
        <div class="journey-ach-head">
          <span class="journey-ach-icon" aria-hidden="true">${unlocked ? '★' : '○'}</span>
          <span class="journey-ach-meta">${escapeHtml(dateLabel)}</span>
        </div>
        <div class="journey-ach-title">${escapeHtml(ach.title)}</div>
        <div class="journey-ach-desc">${escapeHtml(ach.description)}</div>
      </div>
    `;
  }).join('');

  const remindersPaused = Boolean(jState.reminders_paused);

  container.innerHTML = `
    <div class="stack">
      ${celebrationItems.length > 0 ? `
        <div class="card journey-celebration-banner" role="status" aria-live="polite">
          <div class="journey-celebration-title">Habit Progress Recognised</div>
          <ul class="journey-celebration-list">
            ${celebrationItems.map((msg) => `<li>${escapeHtml(msg)}</li>`).join('')}
          </ul>
        </div>
      ` : ''}

      <section class="card journey-hero" aria-label="Financial Journey level and progress">
        <div class="journey-hero-top">
          <div>
            <div class="journey-level-kicker">Level ${levelInfo.level} of 5 · ${escapeHtml(activeIdentity.theme)}</div>
            <h1 class="journey-level-name">${escapeHtml(levelInfo.name)}</h1>
          </div>
          <div class="journey-xp-total">
            <strong>${levelInfo.xp}</strong>
            <span>XP</span>
          </div>
        </div>

        <div class="journey-xp-bar" role="progressbar" aria-valuenow="${levelInfo.progressPct}" aria-valuemin="0" aria-valuemax="100">
          <div class="journey-xp-fill" style="width:${levelInfo.progressPct}%;"></div>
        </div>
        <div class="journey-xp-caption">
          ${levelInfo.nextLevelName
            ? `${levelInfo.xpToNext} XP to ${escapeHtml(levelInfo.nextLevelName)}`
            : 'Top mastery level reached'}
        </div>

        <div class="journey-stat-strip">
          <div class="journey-stat-cell">
            <div class="journey-stat-val">${completedCount}/${totalMissions}</div>
            <div class="journey-stat-lbl">Steps</div>
          </div>
          <div class="journey-stat-cell">
            <div class="journey-stat-val">${activeRecordingDays}</div>
            <div class="journey-stat-lbl">Active Days</div>
          </div>
          <div class="journey-stat-cell">
            <div class="journey-stat-val">${earnedIdentityCount}/4</div>
            <div class="journey-stat-lbl">Identities</div>
          </div>
        </div>
        <div class="item-meta" style="margin-top:8px;">
          Active days are cumulative (counted once per calendar day)—missing a day never resets your progress.
        </div>
      </section>

      ${spotlightHtml}

      <div class="section-heading">
        <span class="section-heading-left">Financial Identity Milestones (${earnedIdentityCount}/4)</span>
      </div>
      <section class="journey-identity-grid" aria-label="Financial identity milestones">
        ${identitiesHtml}
      </section>

      <div class="section-heading">
        <span class="section-heading-left">Flexible Habit Roadmap</span>
        <span class="item-meta">No calendar locks · move at your pace</span>
      </div>
      <div class="stack" style="gap:12px;">
        ${stagesHtml}
      </div>

      <section class="card journey-backup-card" aria-label="Optional data protection recommendation">
        <div class="list-row-main" style="justify-content:space-between; width:100%;">
          <div>
            <div class="item-title">Recommended: Protect Your Ledger</div>
            <div class="item-meta">
              ${hasBackup
                ? 'Offline or Google Drive backup recorded. Your data safety net is active.'
                : 'Optional data-protection milestone (+50 XP)—never required to earn identity milestones.'}
            </div>
          </div>
          <a href="#/import-export" class="btn btn-secondary btn-sm">${hasBackup ? 'Manage' : 'Backup'}</a>
        </div>
      </section>

      <div class="section-heading">
        <span class="section-heading-left">Achievements (${unlockedAchCount}/${JOURNEY_ACHIEVEMENTS.length})</span>
      </div>
      <section class="journey-ach-grid" aria-label="Financial Journey achievements">
        ${achievementsHtml}
      </section>

      ${services.tutorials ? `
        <div class="section-heading">
          <span class="section-heading-left">Feature Guides (${services.tutorials.listTours().length})</span>
          <span class="item-meta">Tap any guide to open</span>
        </div>
        <section class="card" aria-label="Contextual feature guides">
          <div class="journey-tour-chips">
            ${services.tutorials.listTours().map((t) => {
              const seen = Boolean(jState.seen_tutorials?.[t.id]);
              return `<button type="button" class="chip-btn ${seen ? 'selected' : ''}" data-open-tour="${escapeHtml(t.id)}">${seen ? '✓ ' : '? '}${escapeHtml(t.title)}</button>`;
            }).join('')}
          </div>
        </section>
      ` : ''}

      <section class="card" aria-label="Journey reminder preferences">
        <div class="journey-pref-row">
          <div>
            <div class="item-title">Contextual Journey Reminders</div>
            <div class="item-meta">
              ${remindersPaused
                ? 'Paused — Home nudges and welcome-back banners are hidden. Your progress stays saved.'
                : 'Active — shows calm next-action cues on Home. Pause anytime.'}
            </div>
          </div>
          <button type="button" id="btn-journey-toggle-reminders" class="btn btn-secondary btn-sm">
            ${remindersPaused ? 'Resume' : 'Pause'}
          </button>
        </div>
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:12px; padding-top:12px; border-top:1px solid var(--border-subtle); flex-wrap:wrap;">
          <div class="item-meta">Want to revisit the welcome story?</div>
          <a href="#/welcome" class="btn btn-ghost btn-sm">View Welcome Intro</a>
        </div>
      </section>
    </div>
  `;

  container.querySelectorAll('[data-journey-go]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const route = btn.getAttribute('data-journey-go') || 'home';
      navigateTo(route);
    });
  });

  container.querySelectorAll('[data-journey-skip]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-journey-skip');
      if (!id) return;
      await services.journey.skipMission(id);
      showToast('Step skipped — you can resume it anytime.');
      renderJourneyView(container, ctx);
    });
  });

  container.querySelectorAll('[data-journey-unskip]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-journey-unskip');
      if (!id) return;
      await services.journey.unskipMission(id);
      showToast('Step added back to your active path.');
      renderJourneyView(container, ctx);
    });
  });

  container.querySelector('#btn-journey-confirm-zero')?.addEventListener('click', async () => {
    await services.journey.confirmZeroStartingBalance();
    showToast('₹0 starting balance confirmed (+100 XP)');
    renderJourneyView(container, ctx);
  });

  container.querySelector('#btn-journey-weekly-review')?.addEventListener('click', async () => {
    await services.journey.markWeeklyReviewComplete();
    showToast('Weekly check-in completed (+75 XP)');
    renderJourneyView(container, ctx);
  });

  container.querySelector('#btn-journey-confirm-nw')?.addEventListener('click', async () => {
    await services.journey.confirmNetWorthReviewed();
    showToast('Net worth milestone completed (+75 XP)');
    renderJourneyView(container, ctx);
  });

  container.querySelectorAll('[data-open-tour]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const tid = btn.getAttribute('data-open-tour');
      if (tid) services.tutorials?.openTour(tid, { isFirstVisit: false });
    });
  });

  container.querySelector('#btn-journey-toggle-reminders')?.addEventListener('click', async () => {
    const nextPaused = !remindersPaused;
    await services.journey.setRemindersPaused(nextPaused);
    showToast(
      nextPaused
        ? 'Journey reminders paused. Progress remains available here anytime.'
        : 'Journey reminders resumed.'
    );
    renderJourneyView(container, ctx);
  });

  const openMonthlyReviewSheet = async () => {
    const now = new Date();
    const [monthly, budgets, nw] = await Promise.all([
      services.transactions.getMonthlySummary(now.getFullYear(), now.getMonth()).catch(() => ({ incomePaise: 0, expensePaise: 0 })),
      repos.budgets.listAll().catch(() => []),
      services.wealth.getNetWorthSummary().catch(() => ({ netWorthPaise: 0 })),
    ]);
    const netPaise = (monthly.incomePaise || 0) - (monthly.expensePaise || 0);

    openSheet({
      title: '30-Day Financial Review',
      bodyHtml: `
        <div class="stack" style="gap:12px;">
          <p class="item-meta" style="margin:0;">
            Take 60 seconds to review your current month’s pulse and reinforce your financial routine.
          </p>
          <div class="grouped-card">
            <div class="grouped-row">
              <span class="item-meta">This Month Income</span>
              <strong class="text-success">${formatINR(monthly.incomePaise || 0)}</strong>
            </div>
            <div class="grouped-row">
              <span class="item-meta">This Month Expense</span>
              <strong class="text-danger">${formatINR(monthly.expensePaise || 0)}</strong>
            </div>
            <div class="grouped-row">
              <span class="item-meta">Net Monthly Cash Flow</span>
              <strong class="${netPaise >= 0 ? 'text-success' : 'text-danger'}">${netPaise >= 0 ? '+' : ''}${formatINR(netPaise)}</strong>
            </div>
            <div class="grouped-row">
              <span class="item-meta">Current Net Worth</span>
              <strong>${formatINR(nw.netWorthPaise || 0)}</strong>
            </div>
            <div class="grouped-row">
              <span class="item-meta">Active Budgets</span>
              <strong>${budgets.length}</strong>
            </div>
            <div class="grouped-row">
              <span class="item-meta">Backup (Optional)</span>
              <strong class="${hasBackup ? 'text-success' : 'text-muted'}">${hasBackup ? 'Secured' : 'Optional'}</strong>
            </div>
          </div>
          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" style="flex:1;" id="btn-confirm-monthly-review">Complete Review</button>
          </div>
        </div>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#btn-confirm-monthly-review')?.addEventListener('click', async () => {
          await services.journey.markMonthlyReviewComplete();
          close();
          showToast('30-Day financial review completed!');
          renderJourneyView(container, ctx);
        });
      },
    });
  };

  container.querySelector('#btn-journey-monthly-review')?.addEventListener('click', openMonthlyReviewSheet);
  container.querySelector('#btn-roadmap-monthly-review')?.addEventListener('click', openMonthlyReviewSheet);
}

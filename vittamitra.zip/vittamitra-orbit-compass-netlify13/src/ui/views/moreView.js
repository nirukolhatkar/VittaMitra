import { svgIcon } from '../components/icons.js';
import { applyTheme } from '../../services/themeService.js';
import { getStorageDiagnostics } from '../../services/storageService.js';
import { formatINR } from '../../utils/money.js';

export async function renderMoreView(container, ctx) {
  const { db, repos, services } = ctx;
  const [settings, categories, family, tags, txCount, budgets, categorizedBills, dueRecurring, nw, debtSummary, diag, journeyProgress] = await Promise.all([
    repos.settings.getSettings(),
    repos.categories.list({ includeArchived: false }),
    repos.family.list({ includeInactive: false }),
    repos.tags.list({ includeArchived: false }),
    db.table('transactions').count(),
    repos.budgets.listAll(),
    services.billsRecurring.getBillsCategorized(),
    services.billsRecurring.getDueRecurringRules(),
    services.wealth.getNetWorthSummary(),
    services.debts.getDashboardSummary(),
    getStorageDiagnostics(db),
    services.journey ? services.journey.evaluateProgress().catch(() => null) : Promise.resolve(null),
  ]);

  const show = settings.show_balances !== false;
  const overdueCount = categorizedBills.overdue.length;
  const upcomingCount = categorizedBills.upcoming.length;
  const dueRecCount = dueRecurring.length;
  const billsSub = overdueCount > 0
    ? `${overdueCount} overdue · ${upcomingCount} upcoming`
    : dueRecCount > 0
      ? `${dueRecCount} recurring due`
      : `${upcomingCount} upcoming`;

  const driveSub = settings.gdrive_connected
    ? `Auto-backup ${settings.gdrive_auto_upload !== false ? 'ON' : 'paused'} · ${settings.gdrive_last_backup_at ? String(settings.gdrive_last_backup_at).slice(0, 10) : 'Connected'}`
    : 'Single-file .zip backup with receipts & Drive sync';

  const debtNet = debtSummary.netDebtPositionPaise;
  const debtSub = debtSummary.allDebts.length > 0
    ? (show ? `Net ${debtNet >= 0 ? '+' : ''}${formatINR(debtNet)}` : `${debtSummary.allDebts.length} active`)
    : 'Lent & Borrowed';

  const curTheme = settings.theme || 'system';

  container.innerHTML = `
    <div class="stack">
      <div class="card">
        <div class="list-row-main" style="justify-content:space-between;">
          <div class="list-row-main">
            <span class="brand-mark">₹</span>
            <div>
              <div class="item-title">VittaMitra</div>
              <div class="item-meta">
                Offline-first PWA · ${diag.online ? 'Online' : 'Offline'} · ${txCount.toLocaleString('en-IN')} entries
              </div>
            </div>
          </div>
          <a href="#/import-export" class="btn btn-secondary btn-sm">Backup</a>
        </div>
        <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-top:12px; padding-top:12px; border-top:1px solid var(--border-subtle);">
          <span class="item-meta" style="font-weight:600;">Appearance</span>
          <div class="segmented" role="group" aria-label="Theme preference" style="width:auto;">
            ${['system', 'light', 'dark'].map((mode) => {
              const label = mode === 'system' ? 'Auto' : mode === 'light' ? 'Light' : 'Dark';
              return `<button type="button" data-quick-theme="${mode}" class="${curTheme === mode ? 'active' : ''}" aria-pressed="${curTheme === mode ? 'true' : 'false'}" style="min-height:36px; padding:0 12px;">${label}</button>`;
            }).join('')}
          </div>
        </div>
      </div>

      <div class="grouped-card">
        <a href="#/journey" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="avatar-badge">${svgIcon('compass', 18)}</span>
            <div>
              <div class="item-title">Financial Journey</div>
              <div class="item-meta">${journeyProgress
                ? `Level ${journeyProgress.levelInfo.level} · ${journeyProgress.levelInfo.name} · ${journeyProgress.completedCount}/${journeyProgress.totalMissions} missions (${journeyProgress.levelInfo.xp} XP)`
                : 'Guided 30-day habits, milestones & achievements'}</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
      </div>

      <div class="section-heading">
        <span class="section-heading-left">Import &amp; Backup</span>
      </div>
      <div class="grouped-card">
        <a href="#/statement-import" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="avatar-badge">${svgIcon('upload', 18)}</span>
            <div>
              <div class="item-title">Smart Statement &amp; UPI Import</div>
              <div class="item-meta">PDF, CSV, Excel &amp; UPI screenshots locally on device</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
        <a href="#/import-export" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="avatar-badge">${svgIcon('cloud', 18)}</span>
            <div>
              <div class="item-title">Backup (.zip), Google Drive &amp; Excel</div>
              <div class="item-meta">${driveSub}</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
      </div>

      <div class="section-heading">
        <span class="section-heading-left">Planning &amp; Wealth</span>
      </div>
      <section class="grid-2" aria-label="Planning and wealth modules">
        <a href="#/debts" class="tile-card">
          <span class="tile-icon">${svgIcon('handshake', 20)}</span>
          <div>
            <div class="tile-title">Debt Tracker</div>
            <div class="tile-sub">${debtSub}</div>
          </div>
        </a>

        <a href="#/bills" class="tile-card">
          <span class="tile-icon">${svgIcon('calendar', 20)}</span>
          <div>
            <div class="tile-title">Bills &amp; Recurring</div>
            <div class="tile-sub ${overdueCount > 0 ? 'text-danger' : ''}">${billsSub}</div>
          </div>
        </a>

        <a href="#/budgets" class="tile-card">
          <span class="tile-icon">${svgIcon('target', 20)}</span>
          <div>
            <div class="tile-title">Budgets</div>
            <div class="tile-sub">${budgets.length} active</div>
          </div>
        </a>

        <a href="#/investments" class="tile-card">
          <span class="tile-icon">${svgIcon('trending', 20)}</span>
          <div>
            <div class="tile-title">Investments &amp; Loans</div>
            <div class="tile-sub">${nw.investmentsCount} inv · ${nw.activeLoansCount} loans</div>
          </div>
        </a>

        <a href="#/networth" class="tile-card">
          <span class="tile-icon">${svgIcon('gem', 20)}</span>
          <div>
            <div class="tile-title">Net Worth</div>
            <div class="tile-sub">${show ? formatINR(nw.netWorthPaise) : '*****'}</div>
          </div>
        </a>

        <a href="#/categorisation-rules" class="tile-card">
          <span class="tile-icon">${svgIcon('sparkles', 20)}</span>
          <div>
            <div class="tile-title">Auto-Rules</div>
            <div class="tile-sub">Personal categorisation</div>
          </div>
        </a>
      </section>

      <div class="section-heading">
        <span class="section-heading-left">Organise &amp; System</span>
      </div>
      <div class="grouped-card">
        <a href="#/categories" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="more-row-icon">${svgIcon('tag', 18)}</span>
            <div>
              <div class="item-title">Categories</div>
              <div class="item-meta">${categories.length} active</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
        <a href="#/tags" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="more-row-icon">${svgIcon('hash', 18)}</span>
            <div>
              <div class="item-title">Tags</div>
              <div class="item-meta">${tags.length} active</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
        <a href="#/family" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="more-row-icon">${svgIcon('users', 18)}</span>
            <div>
              <div class="item-title">Family Members</div>
              <div class="item-meta">${family.length} active profile${family.length === 1 ? '' : 's'}</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
        <a href="#/settings" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="more-row-icon">${svgIcon('shield', 18)}</span>
            <div>
              <div class="item-title">Settings &amp; Data Health</div>
              <div class="item-meta">INR, FY 1 Apr – 31 Mar, Storage &amp; Recovery Self-Test</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
      </div>
    </div>
  `;

  container.querySelectorAll('[data-quick-theme]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const nextTheme = btn.getAttribute('data-quick-theme') || 'system';
      await repos.settings.updateSettings({ theme: nextTheme });
      applyTheme(nextTheme);
      renderMoreView(container, ctx);
    });
  });
}

import { escapeHtml } from '../../utils/dom.js';
import { formatDisplayINR, formatINR, getAdaptiveAmountClass } from '../../utils/money.js';
import { formatTagDisplay } from '../../utils/normalize.js';
import { formatRelativeDate, getMonthLabel, shiftMonth, toLocalDateString } from '../../utils/date.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { openAdjustBalanceModal } from './accountDetailView.js';
import { bindTransactionLongPress, copyTransactionToClipboard, formatShortContextDate, pasteClipboardToContext, setPageContext } from '../../services/txContextClipboard.js';

const txViewState = {
  mode: 'list', // 'list' | 'calendar'
  search: '',
  calSearch: '',
  periodTab: 'ym', // 'ym' | 'range'
  years: [], // ['2026', '2025']
  months: [], // ['2026-11', '2026-10']
  startDate: '',
  endDate: '',
  type: 'all',
  categoryIds: [],
  categoryMode: 'include', // 'include' | 'exclude'
  accountIds: [],
  accountMode: 'include', // 'include' | 'exclude'
  tagIds: [],
  tagMode: 'any', // 'any' | 'all' | 'exclude'
  familyIds: [],
  familyMode: 'include', // 'include' | 'exclude'
  sort: 'desc',
  bulkMode: false,
  selectedIds: new Set(),
  pageSize: 25,
  selectedCalDate: toLocalDateString(),
  budgetDrilldown: null,
};

function countActiveFilters() {
  let n = 0;
  if (txViewState.years.length) n += 1;
  if (txViewState.months.length) n += 1;
  if (txViewState.startDate || txViewState.endDate) n += 1;
  if (txViewState.type !== 'all') n += 1;
  if (txViewState.categoryIds.length) n += 1;
  if (txViewState.accountIds.length) n += 1;
  if (txViewState.tagIds.length) n += 1;
  if (txViewState.familyIds.length) n += 1;
  return n;
}



export async function renderTransactionsView(container, ctx) {
  const { repos, services, state } = ctx;
  if (state.txListPreset) {
    Object.assign(txViewState, {
      mode: 'list',
      search: '',
      years: [],
      months: [],
      startDate: '',
      endDate: '',
      type: 'all',
      categoryIds: [],
      categoryMode: 'include',
      accountIds: [],
      accountMode: 'include',
      tagIds: [],
      tagMode: 'any',
      familyIds: [],
      familyMode: 'include',
      pageSize: 25,
      budgetDrilldown: null,
      ...state.txListPreset,
    });
    state.txListPreset = null;
  }
  const [settings, accounts, categories, tags, family, favorites] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.list({ includeArchived: true }),
    repos.categories.list({ includeArchived: true }),
    repos.tags.list({ includeArchived: true }),
    repos.family.list({ includeInactive: true }),
    repos.favorites.list(),
  ]);

  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const catMap = new Map(categories.map((c) => [c.id, c]));
  const tagMap = new Map(tags.map((t) => [t.id, t]));
  const famMap = new Map(family.map((f) => [f.id, f]));
  const showBalances = settings.show_balances !== false;
  const displayMode = settings.amount_display_mode || 'auto';

  const renderTxRow = (tx, { copyDate = null, copyLabel = '' } = {}) => {
    const srcAcc = accMap.get(tx.account_id);
    const dstAcc = tx.to_account_id ? accMap.get(tx.to_account_id) : null;
    const cat = tx.category_id ? catMap.get(tx.category_id) : null;
    const fam = tx.family_member_id ? famMap.get(tx.family_member_id) : null;
    const icon = tx.type === 'BALANCE_ADJUSTMENT' ? '⚖️' : tx.type === 'transfer' ? '⇄' : tx.type === 'debt' ? '🤝' : cat?.icon || '🧾';
    const title = tx.description || (tx.type === 'BALANCE_ADJUSTMENT' ? 'Balance Adjustment' : tx.type === 'transfer' ? 'Transfer' : tx.type === 'debt' ? `Debt (${tx.debt_event_type || 'Event'})` : cat?.name || 'Transaction');
    const subParts = [];
    if (tx.type === 'transfer') {
      subParts.push(`${srcAcc?.name || 'Account'} → ${dstAcc?.name || 'Account'}`);
    } else if (tx.type === 'BALANCE_ADJUSTMENT') {
      subParts.push(`Balance Adjustment · ${tx.adjustment_direction === 'increase' ? 'Increase' : 'Decrease'}`);
      if (srcAcc) subParts.push(srcAcc.name);
    } else if (tx.type === 'debt') {
      subParts.push(`Debt · ${tx.debt_event_type || 'Entry'}`);
      if (srcAcc) subParts.push(srcAcc.name);
    } else {
      if (cat) subParts.push(cat.name);
      if (srcAcc) subParts.push(srcAcc.name);
    }
    if (fam) subParts.push(fam.name);
    if (copyLabel) {
      subParts.push(formatRelativeDate(tx.date_key));
    } else {
      const txTime = (tx.occurred_at_local || '').slice(11, 16);
      if (txTime) subParts.push(txTime);
    }

    const txTagsHtml = (tx.tag_ids || [])
      .map((tid) => tagMap.get(tid))
      .filter(Boolean)
      .map((t) => `<span class="badge badge-muted">${escapeHtml(formatTagDisplay(t))}</span>`)
      .join(' ');

    const amtClass =
      tx.type === 'income' || (tx.type === 'BALANCE_ADJUSTMENT' && (tx.adjustment_delta_paise || 0) > 0)
        ? 'text-success'
        : tx.type === 'expense' || (tx.type === 'BALANCE_ADJUSTMENT' && (tx.adjustment_delta_paise || 0) < 0)
          ? 'text-danger'
          : 'text-muted';
    const amtPrefix = tx.type === 'income' || (tx.type === 'BALANCE_ADJUSTMENT' && (tx.adjustment_delta_paise || 0) > 0) ? '+' : tx.type === 'expense' || (tx.type === 'BALANCE_ADJUSTMENT' && (tx.adjustment_delta_paise || 0) < 0) ? '−' : '';
    const amtText = showBalances ? `${amtPrefix}${formatINR(tx.amount_paise)}` : '*****';

    return `
      <div class="grouped-row grouped-row-clickable" data-tx-row="${tx.id}" data-edit-tx="${tx.id}" style="cursor:pointer;">
        <div class="list-row-main" style="flex:1; min-width:0;">
          ${
            txViewState.bulkMode && !copyLabel
              ? `<input type="checkbox" data-bulk-check="${tx.id}" ${txViewState.selectedIds.has(tx.id) ? 'checked' : ''} onclick="event.stopPropagation()">`
              : ''
          }
          <span class="avatar-badge">${escapeHtml(icon)}</span>
          <div style="min-width:0;">
            <div class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${escapeHtml(title)}
            </div>
            <div class="item-meta">${escapeHtml(subParts.join(' · '))}</div>
            ${txTagsHtml ? `<div style="margin-top:4px; display:flex; flex-wrap:wrap; gap:4px;">${txTagsHtml}</div>` : ''}
          </div>
        </div>
        <div class="row-actions">
          <div style="text-align:right;">
            <div class="item-title ${amtClass}" style="font-variant-numeric:tabular-nums;">${amtText}</div>
          </div>
          ${
            copyLabel
              ? `<button type="button" class="btn btn-primary btn-sm" data-copy-tx="${tx.id}" data-copy-date="${copyDate || ''}" title="Copy to ${escapeHtml(copyDate || '')}">⧉ ${escapeHtml(copyLabel)}</button>`
              : ''
          }
        </div>
      </div>
    `;
  };

  /**
   * Advanced Inclusion/Exclusion Filter Sheet (inspired by user's screenshot).
   */
  const openFilterModal = () => {
    const draft = {
      periodTab: txViewState.periodTab,
      years: new Set(txViewState.years),
      months: new Set(txViewState.months),
      startDate: txViewState.startDate,
      endDate: txViewState.endDate,
      type: txViewState.type,
      categoryIds: new Set(txViewState.categoryIds),
      categoryMode: txViewState.categoryMode,
      accountIds: new Set(txViewState.accountIds),
      accountMode: txViewState.accountMode,
      tagIds: new Set(txViewState.tagIds),
      tagMode: txViewState.tagMode,
      familyIds: new Set(txViewState.familyIds),
      familyMode: txViewState.familyMode,
      sort: txViewState.sort,
    };

    const now = new Date();
    const yearPills = [now.getFullYear(), now.getFullYear() - 1, now.getFullYear() - 2].map(String);
    const recentMonthPills = [];
    for (let i = 0; i < 6; i += 1) {
      const m = shiftMonth(now.getFullYear(), now.getMonth(), -i);
      const val = `${m.year}-${String(m.month + 1).padStart(2, '0')}`;
      const label = `${getMonthLabel(m.year, m.month).slice(0, 3)} ${String(m.year).slice(-2)}`;
      recentMonthPills.push({ val, label });
    }

    const renderModalBody = (panel, close) => {
      const visibleCats =
        draft.type === 'transfer'
          ? []
          : draft.type === 'expense'
            ? categories.filter((c) => c.type === 'expense')
            : draft.type === 'income'
              ? categories.filter((c) => c.type === 'income')
              : categories;

      const body = panel.querySelector('.modal-body');
      body.innerHTML = `
        <div class="stack" style="gap:0;">
          <div class="filter-section">
            <div class="filter-header-row">
              <div class="segmented">
                <button type="button" data-f-ptab="ym" class="${draft.periodTab === 'ym' ? 'active' : ''}">Year / Month</button>
                <button type="button" data-f-ptab="range" class="${draft.periodTab === 'range' ? 'active' : ''}">Date Range</button>
              </div>
            </div>
            ${
              draft.periodTab === 'ym'
                ? `<div class="chip-picker">
                    <button type="button" class="chip-btn ${draft.years.size === 0 && draft.months.size === 0 ? 'selected' : ''}" id="f-ym-all">All / Full</button>
                    ${yearPills
                      .map(
                        (y) =>
                          `<button type="button" class="chip-btn ${draft.years.has(y) ? 'selected' : ''}" data-f-year="${y}">${y}</button>`
                      )
                      .join('')}
                    ${recentMonthPills
                      .map(
                        (mp) =>
                          `<button type="button" class="chip-btn ${draft.months.has(mp.val) ? 'selected' : ''}" data-f-month="${mp.val}">${mp.label}</button>`
                      )
                      .join('')}
                  </div>`
                : `<div class="form-row">
                    <div class="form-group" style="margin-bottom:0;">
                      <label class="form-label">From</label>
                      <input type="date" id="f-start" class="form-control" value="${escapeHtml(draft.startDate)}">
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                      <label class="form-label">To</label>
                      <input type="date" id="f-end" class="form-control" value="${escapeHtml(draft.endDate)}">
                    </div>
                  </div>`
            }
          </div>

          <div class="filter-section">
            <div class="filter-header-row">
              <div class="row-actions">
                <span class="filter-title">Category</span>
                <select id="f-cat-mode" class="filter-inline-select">
                  <option value="include" ${draft.categoryMode === 'include' ? 'selected' : ''}>Includes</option>
                  <option value="exclude" ${draft.categoryMode === 'exclude' ? 'selected' : ''}>Excludes</option>
                </select>
              </div>
              <button type="button" class="btn btn-secondary btn-sm" id="f-cat-all">
                ${draft.categoryIds.size === visibleCats.length && visibleCats.length > 0 ? 'Clear' : 'Select all'}
              </button>
            </div>
            <div class="segmented" style="width:100%; justify-content:space-between; margin-bottom:10px;">
              <button type="button" style="flex:1;" data-f-type="all" class="${draft.type === 'all' ? 'active' : ''}">All</button>
              <button type="button" style="flex:1;" data-f-type="expense" class="${draft.type === 'expense' ? 'active' : ''}">Spending</button>
              <button type="button" style="flex:1;" data-f-type="income" class="${draft.type === 'income' ? 'active' : ''}">Income</button>
              <button type="button" style="flex:1;" data-f-type="transfer" class="${draft.type === 'transfer' ? 'active' : ''}">Transfer</button>
            </div>
            <div class="chip-picker">
              ${draft.type === 'transfer'
                ? '<span class="item-meta">Transfers do not have categories. Filter transfers by Payment Mode, Tags, or Period below.</span>'
                : visibleCats
                    .map((c) => {
                      const sel = draft.categoryIds.has(c.id);
                      const cls = sel ? (draft.categoryMode === 'exclude' ? 'excluded' : 'selected') : '';
                      return `<button type="button" class="chip-btn ${cls}" data-f-cat="${c.id}">${escapeHtml(c.icon)} ${escapeHtml(c.name)}</button>`;
                    })
                    .join('')}
            </div>
          </div>

          <div class="filter-section">
            <div class="filter-header-row">
              <div class="row-actions">
                <span class="filter-title">Payment Mode</span>
                <select id="f-acc-mode" class="filter-inline-select">
                  <option value="include" ${draft.accountMode === 'include' ? 'selected' : ''}>Includes</option>
                  <option value="exclude" ${draft.accountMode === 'exclude' ? 'selected' : ''}>Excludes</option>
                </select>
              </div>
              <button type="button" class="btn btn-secondary btn-sm" id="f-acc-all">
                ${draft.accountIds.size === accounts.length && accounts.length > 0 ? 'Clear' : 'Select all'}
              </button>
            </div>
            <div class="chip-picker">
              ${accounts
                .map((a) => {
                  const sel = draft.accountIds.has(a.id);
                  const cls = sel ? (draft.accountMode === 'exclude' ? 'excluded' : 'selected') : '';
                  return `<button type="button" class="chip-btn ${cls}" data-f-acc="${a.id}">${escapeHtml(a.name)}</button>`;
                })
                .join('')}
            </div>
          </div>

          <div class="filter-section">
            <div class="filter-header-row">
              <div class="row-actions">
                <span class="filter-title">Tags</span>
                <select id="f-tag-mode" class="filter-inline-select">
                  <option value="any" ${draft.tagMode === 'any' ? 'selected' : ''}>Includes any</option>
                  <option value="all" ${draft.tagMode === 'all' ? 'selected' : ''}>Includes all</option>
                  <option value="exclude" ${draft.tagMode === 'exclude' ? 'selected' : ''}>Excludes</option>
                </select>
              </div>
              <button type="button" class="btn btn-secondary btn-sm" id="f-tag-all">
                ${draft.tagIds.size === tags.length && tags.length > 0 ? 'Clear' : 'Select all'}
              </button>
            </div>
            <div class="chip-picker">
              ${
                tags.length === 0
                  ? '<span class="item-meta">No tags created yet.</span>'
                  : tags
                      .map((t) => {
                        const sel = draft.tagIds.has(t.id);
                        const cls = sel ? (draft.tagMode === 'exclude' ? 'excluded' : 'selected') : '';
                        return `<button type="button" class="chip-btn ${cls}" data-f-tag="${t.id}">${escapeHtml(formatTagDisplay(t))}</button>`;
                      })
                      .join('')
              }
            </div>
          </div>

          <div class="filter-section">
            <div class="filter-header-row">
              <div class="row-actions">
                <span class="filter-title">Family Member</span>
                <select id="f-fam-mode" class="filter-inline-select">
                  <option value="include" ${draft.familyMode === 'include' ? 'selected' : ''}>Includes</option>
                  <option value="exclude" ${draft.familyMode === 'exclude' ? 'selected' : ''}>Excludes</option>
                </select>
              </div>
            </div>
            <div class="chip-picker">
              ${family
                .map((f) => {
                  const sel = draft.familyIds.has(f.id);
                  const cls = sel ? (draft.familyMode === 'exclude' ? 'excluded' : 'selected') : '';
                  return `<button type="button" class="chip-btn ${cls}" data-f-fam="${f.id}">${escapeHtml(f.icon)} ${escapeHtml(f.name)}</button>`;
                })
                .join('')}
            </div>
          </div>

          <div class="filter-section">
            <div class="filter-header-row">
              <span class="filter-title">Sort Order</span>
              <select id="f-sort" class="filter-inline-select">
                <option value="desc" ${draft.sort === 'desc' ? 'selected' : ''}>Newest first</option>
                <option value="asc" ${draft.sort === 'asc' ? 'selected' : ''}>Oldest first</option>
                <option value="amount_desc" ${draft.sort === 'amount_desc' ? 'selected' : ''}>Highest amount</option>
                <option value="amount_asc" ${draft.sort === 'amount_asc' ? 'selected' : ''}>Lowest amount</option>
              </select>
            </div>
          </div>

          <div class="modal-footer" style="justify-content:space-between;">
            <button type="button" class="btn btn-secondary btn-sm" id="f-reset">Reset All</button>
            <button type="button" class="btn btn-primary" id="f-apply">Apply Filters</button>
          </div>
        </div>
      `;

      body.querySelectorAll('[data-f-ptab]').forEach((b) => {
        b.addEventListener('click', () => {
          draft.periodTab = b.getAttribute('data-f-ptab');
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-ym-all')?.addEventListener('click', () => {
        draft.years.clear();
        draft.months.clear();
        renderModalBody(panel, close);
      });
      body.querySelectorAll('[data-f-year]').forEach((b) => {
        b.addEventListener('click', () => {
          const y = b.getAttribute('data-f-year');
          if (draft.years.has(y)) draft.years.delete(y);
          else draft.years.add(y);
          renderModalBody(panel, close);
        });
      });
      body.querySelectorAll('[data-f-month]').forEach((b) => {
        b.addEventListener('click', () => {
          const m = b.getAttribute('data-f-month');
          if (draft.months.has(m)) draft.months.delete(m);
          else draft.months.add(m);
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-start')?.addEventListener('change', (e) => { draft.startDate = e.target.value; });
      body.querySelector('#f-end')?.addEventListener('change', (e) => { draft.endDate = e.target.value; });
      body.querySelectorAll('[data-f-type]').forEach((b) => {
        b.addEventListener('click', () => {
          draft.type = b.getAttribute('data-f-type');
          if (draft.type === 'transfer') draft.categoryIds.clear();
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-cat-mode')?.addEventListener('change', (e) => {
        draft.categoryMode = e.target.value;
        renderModalBody(panel, close);
      });
      body.querySelector('#f-cat-all')?.addEventListener('click', () => {
        if (draft.categoryIds.size === visibleCats.length) draft.categoryIds.clear();
        else visibleCats.forEach((c) => draft.categoryIds.add(c.id));
        renderModalBody(panel, close);
      });
      body.querySelectorAll('[data-f-cat]').forEach((b) => {
        b.addEventListener('click', () => {
          const id = b.getAttribute('data-f-cat');
          if (draft.categoryIds.has(id)) draft.categoryIds.delete(id);
          else draft.categoryIds.add(id);
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-acc-mode')?.addEventListener('change', (e) => {
        draft.accountMode = e.target.value;
        renderModalBody(panel, close);
      });
      body.querySelector('#f-acc-all')?.addEventListener('click', () => {
        if (draft.accountIds.size === accounts.length) draft.accountIds.clear();
        else accounts.forEach((a) => draft.accountIds.add(a.id));
        renderModalBody(panel, close);
      });
      body.querySelectorAll('[data-f-acc]').forEach((b) => {
        b.addEventListener('click', () => {
          const id = b.getAttribute('data-f-acc');
          if (draft.accountIds.has(id)) draft.accountIds.delete(id);
          else draft.accountIds.add(id);
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-tag-mode')?.addEventListener('change', (e) => {
        draft.tagMode = e.target.value;
        renderModalBody(panel, close);
      });
      body.querySelector('#f-tag-all')?.addEventListener('click', () => {
        if (draft.tagIds.size === tags.length) draft.tagIds.clear();
        else tags.forEach((t) => draft.tagIds.add(t.id));
        renderModalBody(panel, close);
      });
      body.querySelectorAll('[data-f-tag]').forEach((b) => {
        b.addEventListener('click', () => {
          const id = b.getAttribute('data-f-tag');
          if (draft.tagIds.has(id)) draft.tagIds.delete(id);
          else draft.tagIds.add(id);
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-fam-mode')?.addEventListener('change', (e) => {
        draft.familyMode = e.target.value;
        renderModalBody(panel, close);
      });
      body.querySelectorAll('[data-f-fam]').forEach((b) => {
        b.addEventListener('click', () => {
          const id = b.getAttribute('data-f-fam');
          if (draft.familyIds.has(id)) draft.familyIds.delete(id);
          else draft.familyIds.add(id);
          renderModalBody(panel, close);
        });
      });
      body.querySelector('#f-sort')?.addEventListener('change', (e) => { draft.sort = e.target.value; });

      body.querySelector('#f-reset')?.addEventListener('click', () => {
        Object.assign(txViewState, {
          years: [],
          months: [],
          startDate: '',
          endDate: '',
          type: 'all',
          categoryIds: [],
          categoryMode: 'include',
          accountIds: [],
          accountMode: 'include',
          tagIds: [],
          tagMode: 'any',
          familyIds: [],
          familyMode: 'include',
          sort: 'desc',
        });
        close();
        renderTransactionsView(container, ctx);
      });

      body.querySelector('#f-apply')?.addEventListener('click', () => {
        Object.assign(txViewState, {
          periodTab: draft.periodTab,
          years: draft.periodTab === 'ym' ? Array.from(draft.years) : [],
          months: draft.periodTab === 'ym' ? Array.from(draft.months) : [],
          startDate: draft.periodTab === 'range' ? draft.startDate : '',
          endDate: draft.periodTab === 'range' ? draft.endDate : '',
          type: draft.type,
          categoryIds: Array.from(draft.categoryIds),
          categoryMode: draft.categoryMode,
          accountIds: Array.from(draft.accountIds),
          accountMode: draft.accountMode,
          tagIds: Array.from(draft.tagIds),
          tagMode: draft.tagMode,
          familyIds: Array.from(draft.familyIds),
          familyMode: draft.familyMode,
          sort: draft.sort,
          pageSize: 25,
        });
        close();
        renderTransactionsView(container, ctx);
      });
    };

    openModal({
      title: 'Filter',
      bodyHtml: '',
      onMount: (panel, close) => renderModalBody(panel, close),
    });
  };

  const bindRowHandlers = (rootEl, refreshFn) => {
    rootEl.querySelectorAll('[data-bulk-check]').forEach((cb) => {
      cb.addEventListener('change', () => {
        const id = cb.getAttribute('data-bulk-check');
        if (cb.checked) txViewState.selectedIds.add(id);
        else txViewState.selectedIds.delete(id);
        refreshFn();
      });
    });

    rootEl.querySelector('#btn-bulk-delete')?.addEventListener('click', async () => {
      const ids = Array.from(txViewState.selectedIds);
      const undoTokens = await services.transactions.bulkSoftDelete(ids);
      txViewState.selectedIds.clear();
      txViewState.bulkMode = false;
      await refreshFn();
      showToast(`Deleted ${undoTokens.length} transaction${undoTokens.length === 1 ? '' : 's'}`, {
        actionLabel: 'Undo',
        onAction: async () => {
          await services.transactions.restoreBulkTransactions(undoTokens);
          await refreshFn();
          showToast('Deleted transactions restored');
        },
      });
    });

    rootEl.querySelectorAll('[data-edit-tx]').forEach((el) => {
      el.addEventListener('click', async (e) => {
        if (e.target.closest('[data-bulk-check], [data-copy-tx], button, input')) return;
        const txId = el.getAttribute('data-edit-tx');
        const txObj = await services.transactions.getTransactionById(txId);
        if (txObj && txObj.type === 'BALANCE_ADJUSTMENT') {
          openAdjustBalanceModal(ctx, txObj.account_id, {
            existingAdjustment: txObj,
            onSaved: () => refreshFn(),
          });
          return;
        }
        if (txObj && txObj.debt_id) {
          state.selectedDebtId = txObj.debt_id;
          window.location.hash = '#/debts';
          return;
        }
        state.txDraft = { editId: txId, returnRoute: 'transactions' };
        window.location.hash = '#/add-transaction';
      });
    });

    // Context-aware Copy (copies to clipboard) OR direct Paste onto Calendar date when copyDate is set
    rootEl.querySelectorAll('[data-copy-tx]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const txId = btn.getAttribute('data-copy-tx');
        const copyDate = btn.getAttribute('data-copy-date') || null;
        if (copyDate) {
          setPageContext(ctx, {
            route: 'transactions',
            label: `Calendar · ${formatShortContextDate(copyDate)}`,
            shortLabel: formatShortContextDate(copyDate),
            overrides: { date: copyDate },
          });
          await pasteClipboardToContext(ctx, { txId });
        } else {
          await copyTransactionToClipboard(ctx, txId);
        }
      });
    });

    rootEl.querySelectorAll('[data-del-tx]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const undoToken = await services.transactions.softDeleteTransaction(btn.getAttribute('data-del-tx'));
        await refreshFn();
        if (undoToken) {
          showToast('Transaction deleted', {
            actionLabel: 'Undo',
            onAction: async () => {
              await services.transactions.restoreTransaction(undoToken);
              await refreshFn();
              showToast('Transaction restored');
            },
          });
        }
      });
    });

    if (!txViewState.bulkMode) {
      bindTransactionLongPress(rootEl, ctx, {
        selector: '[data-tx-row]',
        attr: 'data-tx-row',
        onRefresh: refreshFn,
      });
    }

    rootEl.querySelector('#btn-load-more')?.addEventListener('click', () => {
      txViewState.pageSize += 25;
      refreshFn();
    });
  };

  if (txViewState.mode === 'calendar') {
    const calShort = formatShortContextDate(txViewState.selectedCalDate);
    setPageContext(ctx, {
      route: 'transactions',
      label: `Calendar · ${calShort}`,
      shortLabel: calShort,
      overrides: { date: txViewState.selectedCalDate },
      onPasteRefresh: () => renderTransactionsView(container, ctx),
    });
    const monthTxs = await services.transactions.listTransactions({
      monthYear: { year: state.selectedYear, month: state.selectedMonth },
    });

    const byDate = new Map();
    for (const tx of monthTxs) {
      if (!byDate.has(tx.date_key)) byDate.set(tx.date_key, { expense: 0, income: 0, items: [] });
      const b = byDate.get(tx.date_key);
      if (tx.type === 'expense') b.expense += tx.amount_paise;
      if (tx.type === 'income') b.income += tx.amount_paise;
      b.items.push(tx);
    }

    const spendDays = Array.from(byDate.values()).filter((d) => d.expense > 0);
    const avgDailySpend =
      spendDays.length > 1
        ? spendDays.reduce((s, d) => s + d.expense, 0) / spendDays.length
        : Infinity;

    const firstDay = new Date(state.selectedYear, state.selectedMonth, 1);
    const daysInMonth = new Date(state.selectedYear, state.selectedMonth + 1, 0).getDate();
    const weekStart = Number(settings.week_start_day ?? 1);
    const offset = (firstDay.getDay() - weekStart + 7) % 7;

    const weekdayLabels =
      weekStart === 1
        ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        : weekStart === 6
          ? ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri']
          : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const cells = [];
    for (let i = 0; i < offset; i += 1) cells.push('<div class="cal-cell empty"></div>');
    for (let d = 1; d <= daysInMonth; d += 1) {
      const key = `${state.selectedYear}-${String(state.selectedMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const info = byDate.get(key);
      const isSelected = txViewState.selectedCalDate === key;
      const isHigh = info && info.expense > avgDailySpend * 1.5;
      const dayNet = info ? (info.income - info.expense) : 0;
      const dayCount = info ? info.items.length : 0;
      const netCls = dayNet > 0 ? 'text-success' : dayNet < 0 ? 'text-danger' : 'text-secondary';
      const hasFlow = Boolean(info && (info.income > 0 || info.expense > 0));
      const netStr = dayNet !== 0
        ? (showBalances
            ? `${dayNet > 0 ? '+' : '−'}${formatDisplayINR(Math.abs(dayNet), { mode: displayMode, context: 'calendar', maxChars: 6 })}`
            : '•••')
        : (hasFlow ? '±0' : '');
      const calAmtSizeCls = netStr ? getAdaptiveAmountClass(netStr, 'calendar') : '';
      cells.push(`
        <button type="button" class="cal-cell ${isSelected ? 'selected' : ''} ${isHigh ? 'high-spend' : ''}" data-cal-day="${key}">
          <span class="cal-day-num">${d}</span>
          ${netStr ? `<div class="cal-net-amt ${netCls} ${calAmtSizeCls}">${netStr}</div>` : '<div class="cal-net-amt">&nbsp;</div>'}
          <div class="cal-dot-row">
            ${dayCount > 0 ? '<span class="cal-dot"></span>' : ''}
            ${dayCount > 1 ? '<span class="cal-dot" style="opacity:0.55;"></span>' : ''}
          </div>
        </button>
      `);
    }

    const dayItems = byDate.get(txViewState.selectedCalDate)?.items || [];

    container.innerHTML = `
      <div class="stack">
        <div class="toolbar">
          <div class="segmented">
            <button type="button" data-tx-mode="list">List</button>
            <button type="button" data-tx-mode="calendar" class="active">Calendar</button>
          </div>
          <div class="month-pill">
            <button type="button" id="cal-prev">‹</button>
            <span class="month-pill-label">${getMonthLabel(state.selectedYear, state.selectedMonth)}</span>
            <button type="button" id="cal-next">›</button>
          </div>
        </div>

        <div class="card" style="padding:12px;">
          <div class="calendar-weekdays">${weekdayLabels.map((w) => `<span>${w}</span>`).join('')}</div>
          <div class="calendar-grid">${cells.join('')}</div>
        </div>

        <div class="toolbar">
          <div>
            <div class="item-title">${escapeHtml(formatRelativeDate(txViewState.selectedCalDate))}</div>
            <div class="item-meta">${dayItems.length} transaction${dayItems.length === 1 ? '' : 's'}</div>
          </div>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-on-cal-date">+ Add on this date</button>
        </div>

        <!-- Non-blurring Calendar-level Search to copy any past transaction directly onto selected date -->
        <div class="search-bar-row">
          <input id="cal-copy-search" type="search" class="search-input-pill"
            placeholder="🔍 Search past tx to copy to ${escapeHtml(txViewState.selectedCalDate)}…"
            value="${escapeHtml(txViewState.calSearch)}">
          ${txViewState.calSearch ? `<button type="button" class="btn btn-secondary btn-sm" id="cal-copy-clear">Clear</button>` : ''}
        </div>
        <div id="cal-copy-results"></div>

        ${
          favorites.length > 0
            ? `<div class="quick-strip">
                ${favorites
                  .map(
                    (fav) => `
                    <button type="button" class="quick-pill" data-cal-fav="${fav.id}">
                      <span>★</span>
                      <div>
                        <div class="item-title" style="font-size:0.8rem;">${escapeHtml(fav.name)}</div>
                        <div class="item-meta">${formatINR(fav.amount_paise)}</div>
                      </div>
                    </button>`
                  )
                  .join('')}
              </div>`
            : ''
        }

        ${
          dayItems.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-title">No transactions on ${escapeHtml(txViewState.selectedCalDate)}</div>
                <p class="empty-state-text">Tap "+ Add on this date", search a past entry above to copy it here, or pick a favourite.</p>
              </div>`
            : `<div class="grouped-card" id="cal-day-list">${dayItems.map((tx) => renderTxRow(tx, { copyDate: txViewState.selectedCalDate })).join('')}</div>`
        }
      </div>
    `;

    const calDayList = container.querySelector('#cal-day-list');
    if (calDayList) {
      bindRowHandlers(calDayList, () => renderTransactionsView(container, ctx));
    }

    const calCopyResultsEl = container.querySelector('#cal-copy-results');
    const renderCalCopySearchResults = async () => {
      const q = txViewState.calSearch.trim();
      if (!q) {
        calCopyResultsEl.innerHTML = '';
        return;
      }
      const matches = await services.transactions.listTransactions({ search: q, sort: 'desc' });
      const top = matches.slice(0, 12);
      if (top.length === 0) {
        calCopyResultsEl.innerHTML = `<div class="card" style="padding:10px 12px;"><span class="item-meta">No past transactions match "${escapeHtml(q)}".</span></div>`;
        return;
      }
      calCopyResultsEl.innerHTML = `
        <div class="stack" style="gap:6px;">
          <div class="item-meta" style="padding:0 4px;">
            Tap <strong>⧉ Paste</strong> to copy any match onto <strong>${escapeHtml(txViewState.selectedCalDate)}</strong> (${matches.length} found)
          </div>
          <div class="grouped-card">
            ${top.map((tx) => renderTxRow(tx, { copyDate: txViewState.selectedCalDate, copyLabel: 'Paste' })).join('')}
          </div>
        </div>
      `;
      bindRowHandlers(calCopyResultsEl, () => renderTransactionsView(container, ctx));
    };

    await renderCalCopySearchResults();

    const calSearchInput = container.querySelector('#cal-copy-search');
    let calSearchTimer = null;
    let calSearchToken = 0;
    calSearchInput?.addEventListener('input', (e) => {
      txViewState.calSearch = e.target.value;
      if (calSearchTimer) clearTimeout(calSearchTimer);
      const token = ++calSearchToken;
      calSearchTimer = setTimeout(() => {
        if (token !== calSearchToken) return;
        renderCalCopySearchResults(); // Updates only #cal-copy-results so keyboard never blurs!
      }, 150);
    });
    container.querySelector('#cal-copy-clear')?.addEventListener('click', () => {
      txViewState.calSearch = '';
      renderTransactionsView(container, ctx);
    });

    container.querySelector('#cal-prev')?.addEventListener('click', () => {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, -1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
      renderTransactionsView(container, ctx);
    });
    container.querySelector('#cal-next')?.addEventListener('click', () => {
      const next = shiftMonth(state.selectedYear, state.selectedMonth, 1);
      state.selectedYear = next.year;
      state.selectedMonth = next.month;
      renderTransactionsView(container, ctx);
    });
    container.querySelectorAll('[data-cal-day]').forEach((btn) => {
      btn.addEventListener('click', () => {
        txViewState.selectedCalDate = btn.getAttribute('data-cal-day');
        renderTransactionsView(container, ctx);
      });
    });
    container.querySelector('#btn-add-on-cal-date')?.addEventListener('click', () => {
      state.txDraft = { date: txViewState.selectedCalDate, returnRoute: 'transactions' };
      window.location.hash = '#/add-transaction';
    });
    container.querySelectorAll('[data-cal-fav]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const fav = await repos.favorites.getById(btn.getAttribute('data-cal-fav'));
        if (!fav) return;
        state.txDraft = {
          type: fav.type,
          amount_paise: fav.amount_paise,
          category_id: fav.category_id,
          account_id: fav.account_id,
          to_account_id: fav.to_account_id,
          description: fav.description || fav.name,
          family_member_id: fav.family_member_id,
          tag_ids: fav.tag_ids,
          date: txViewState.selectedCalDate,
          returnRoute: 'transactions',
        };
        window.location.hash = '#/add-transaction';
      });
    });
  } else {
    // List Mode — set context-aware overrides from any single active filter
    const listOv = {};
    const listLabels = [];
    if (txViewState.accountIds.length === 1 && txViewState.accountMode === 'include') {
      listOv.account_id = txViewState.accountIds[0];
      const aObj = accMap.get(listOv.account_id);
      if (aObj) listLabels.push(aObj.name);
    }
    if (txViewState.categoryIds.length === 1 && txViewState.categoryMode === 'include') {
      listOv.category_id = txViewState.categoryIds[0];
      const cObj = catMap.get(listOv.category_id);
      if (cObj) {
        listLabels.push(cObj.name);
        listOv.type = cObj.type;
      }
    }
    if (txViewState.tagIds.length === 1 && txViewState.tagMode !== 'exclude') {
      listOv.add_tag_id = txViewState.tagIds[0];
      const tObj = tagMap.get(listOv.add_tag_id);
      if (tObj) listLabels.push(formatTagDisplay(tObj));
    }
    if (txViewState.familyIds.length === 1 && txViewState.familyMode === 'include') {
      listOv.family_member_id = txViewState.familyIds[0];
      const fObj = famMap.get(listOv.family_member_id);
      if (fObj) listLabels.push(fObj.name);
    }
    if (txViewState.startDate) {
      listOv.date = txViewState.startDate;
      listLabels.push(formatShortContextDate(txViewState.startDate));
    }
    setPageContext(ctx, {
      route: 'transactions',
      label: listLabels.length ? listLabels.join(' · ') : 'Ledger',
      shortLabel: listLabels[0] ? listLabels[0].slice(0, 12) : '',
      accountName: listOv.account_id ? accMap.get(listOv.account_id)?.name : undefined,
      categoryName: listOv.category_id ? catMap.get(listOv.category_id)?.name : undefined,
      tagName: listOv.add_tag_id ? formatTagDisplay(tagMap.get(listOv.add_tag_id)) : undefined,
      familyName: listOv.family_member_id ? famMap.get(listOv.family_member_id)?.name : undefined,
      overrides: listOv,
      onPasteRefresh: () => renderTransactionsView(container, ctx),
    });
    // List Mode — keep search input mounted so mobile keyboard NEVER closes while typing!
    const filterCount = countActiveFilters();

    container.innerHTML = `
      <div class="stack">
        <div class="toolbar">
          <div class="segmented">
            <button type="button" data-tx-mode="list" class="active">List</button>
            <button type="button" data-tx-mode="calendar">Calendar</button>
          </div>
          <div class="row-actions">
            <button type="button" class="btn btn-secondary btn-sm" id="btn-filtered-insights" title="View Insights on filtered transactions">📊 Insights</button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-toggle-bulk">
              ${txViewState.bulkMode ? 'Done' : 'Select'}
            </button>
          </div>
        </div>

        <div class="search-bar-row">
          <input id="tx-search-input" type="search" class="search-input-pill"
            placeholder="🔍 Search transactions, notes, reference…" value="${escapeHtml(txViewState.search)}">
          <button type="button" class="btn btn-secondary btn-sm" id="btn-open-filters" aria-label="Open filters">
            ☰ Filter${filterCount > 0 ? ` (${filterCount})` : ''}
          </button>
        </div>

        <div id="tx-results-container" class="stack"></div>
      </div>
    `;

    const resultsEl = container.querySelector('#tx-results-container');
    let listRenderToken = 0;

    const renderResultsOnly = async () => {
      const myToken = ++listRenderToken;
      const drill = txViewState.budgetDrilldown;
      let allFiltered;
      let drilldownTotalPaise = 0;

      if (drill && !txViewState.search.trim() && services.budgets?.getContributingTransactionsForBudget) {
        const res = await services.budgets.getContributingTransactionsForBudget(
          drill.budgetId,
          drill.year,
          drill.month
        );
        if (myToken !== listRenderToken) return;
        drilldownTotalPaise = res.totalSpentPaise;
        allFiltered = res.items.map(({ tx, contributedPaise }) =>
          tx.is_split && contributedPaise !== tx.amount_paise
            ? { ...tx, amount_paise: contributedPaise, description: `${tx.description || 'Split transaction'} (budget share)` }
            : tx
        );
      } else {
        allFiltered = await services.transactions.listTransactions({
          search: txViewState.search,
          years: txViewState.years,
          months: txViewState.months,
          startDate: txViewState.startDate || null,
          endDate: txViewState.endDate || null,
          type: txViewState.type,
          categoryIds: txViewState.categoryIds,
          categoryMode: txViewState.categoryMode,
          accountIds: txViewState.accountIds,
          accountMode: txViewState.accountMode,
          tagIds: txViewState.tagIds,
          tagMode: txViewState.tagMode,
          familyIds: txViewState.familyIds,
          familyMode: txViewState.familyMode,
          sort: txViewState.sort,
        });
        if (myToken !== listRenderToken) return;
        if (drill) {
          drilldownTotalPaise = allFiltered.reduce((sum, tx) => sum + (tx.amount_paise || 0), 0);
        }
      }

      const drillBannerHtml = drill
        ? `<div class="card" style="padding:12px 14px; display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
            <div>
              <div class="item-title">🎯 ${escapeHtml(drill.label)} · ${escapeHtml(drill.monthLabel || drill.periodKey)}</div>
              <div class="item-meta">
                ${allFiltered.length} contributing transaction${allFiltered.length === 1 ? '' : 's'} · Total Spent: <strong class="text-danger">${showBalances ? formatINR(drilldownTotalPaise) : '*****'}</strong>
              </div>
            </div>
            <div class="row-actions" style="gap:6px;">
              <button type="button" class="btn btn-secondary btn-sm" id="btn-back-to-budgets">← Budgets</button>
              <button type="button" class="btn btn-ghost btn-sm" id="btn-clear-drilldown">Clear</button>
            </div>
          </div>`
        : '';

      const visible = allFiltered.slice(0, txViewState.pageSize);
      let filteredSpending = 0;
      let filteredIncome = 0;
      for (const tx of allFiltered) {
        if (tx.type === 'expense') filteredSpending += tx.amount_paise;
        else if (tx.type === 'income') filteredIncome += tx.amount_paise;
      }
      const filteredNet = filteredIncome - filteredSpending;
      const summaryCardHtml = `
        <section class="hero-card" style="padding:14px 16px;" aria-label="Filtered transactions summary">
          <div class="hero-split" style="margin-bottom:10px;">
            <div>
              <div class="hero-stat-label text-danger">SPENDING</div>
              <div class="hero-stat-value" style="font-size:1.38rem;">${showBalances ? formatINR(filteredSpending) : '*****'}</div>
            </div>
            <div class="hero-split-right">
              <div class="hero-stat-label text-success">INCOME</div>
              <div class="hero-stat-value" style="font-size:1.38rem;">${showBalances ? formatINR(filteredIncome) : '*****'}</div>
            </div>
          </div>
          <div class="hero-footer-pill" style="padding:9px 12px;">
            <span class="text-muted">Net Balance (${allFiltered.length} txn${allFiltered.length === 1 ? '' : 's'})</span>
            <strong class="${filteredNet < 0 ? 'text-danger' : 'text-success'}" style="font-variant-numeric:tabular-nums;">
              ${showBalances ? formatINR(filteredNet) : '*****'}
            </strong>
          </div>
        </section>`;
      const hasMore = allFiltered.length > visible.length;

      const groups = [];
      const groupMap = new Map();
      for (const tx of visible) {
        if (!groupMap.has(tx.date_key)) {
          const g = { date: tx.date_key, expense: 0, income: 0, items: [] };
          groupMap.set(tx.date_key, g);
          groups.push(g);
        }
        const g = groupMap.get(tx.date_key);
        if (tx.type === 'expense') g.expense += tx.amount_paise;
        if (tx.type === 'income') g.income += tx.amount_paise;
        g.items.push(tx);
      }

      resultsEl.innerHTML = `
        ${drillBannerHtml}
        ${
          txViewState.bulkMode && txViewState.selectedIds.size > 0
            ? `<div class="toolbar card" style="padding:10px 14px;">
                <span class="item-title">${txViewState.selectedIds.size} selected</span>
                <button type="button" class="btn btn-danger btn-sm" id="btn-bulk-delete">Delete Selected</button>
              </div>`
            : ''
        }
        ${
          groups.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🧾</div>
                <h3 class="empty-state-title">No matching transactions</h3>
                <p class="empty-state-text">Adjust your search or filters, or tap + to log a transaction.</p>
              </div>`
            : groups
                .map(
                  (g) => `
                  <section class="stack" style="gap:6px;">
                    <div class="date-group-header">
                      <span>${escapeHtml(g.date)}</span>
                      <span>
                        ${g.income > 0 ? `<span class="text-success">+${showBalances ? formatINR(g.income) : '***'}</span> ` : ''}
                        ${g.expense > 0 ? `<span class="text-danger">-${showBalances ? formatINR(g.expense) : '***'}</span>` : ''}
                      </span>
                    </div>
                    <div class="grouped-card">${g.items.map((tx) => renderTxRow(tx)).join('')}</div>
                  </section>`
                )
                .join('')
        }
        ${
          hasMore
            ? `<button type="button" class="btn btn-secondary" id="btn-load-more">Load more (${allFiltered.length - visible.length} remaining)</button>`
            : ''
        }
      `;

      resultsEl.querySelector('#btn-back-to-budgets')?.addEventListener('click', () => {
        txViewState.budgetDrilldown = null;
        if (typeof ctx.navigateTo === 'function') ctx.navigateTo('budgets');
        else window.location.hash = '#/budgets';
      });
      resultsEl.querySelector('#btn-clear-drilldown')?.addEventListener('click', () => {
        txViewState.budgetDrilldown = null;
        txViewState.months = [];
        txViewState.type = 'all';
        txViewState.categoryIds = [];
        txViewState.tagIds = [];
        renderTransactionsView(container, ctx);
      });
      bindRowHandlers(resultsEl, renderResultsOnly);
    };

    await renderResultsOnly();

    const searchInput = container.querySelector('#tx-search-input');
    let searchDebounceTimer = null;
    searchInput?.addEventListener('input', (e) => {
      txViewState.search = e.target.value;
      txViewState.pageSize = 25;
      if (searchDebounceTimer) clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(() => {
        renderResultsOnly(); // Only updates #tx-results-container; never blurs keyboard!
      }, 150);
    });

    if (state.focusSearch && searchInput) {
      state.focusSearch = false;
      searchInput.focus();
    }

    container.querySelector('#btn-open-filters')?.addEventListener('click', openFilterModal);
    container.querySelector('#btn-list-add-tx')?.addEventListener('click', () => {
      state.txDraft = null;
      window.location.hash = '#/add-transaction';
    });
    container.querySelector('#btn-filtered-insights')?.addEventListener('click', () => {
      const parts = [];
      if (txViewState.search.trim()) parts.push(`"${txViewState.search.trim()}"`);
      if (txViewState.categoryIds.length) {
        parts.push(txViewState.categoryIds.map((id) => catMap.get(id)?.name).filter(Boolean).join(', '));
      }
      if (txViewState.tagIds.length) {
        parts.push(txViewState.tagIds.map((id) => tagMap.get(id) ? formatTagDisplay(tagMap.get(id)) : '').filter(Boolean).join(', '));
      }
      if (txViewState.accountIds.length) {
        parts.push(txViewState.accountIds.map((id) => accMap.get(id)?.name).filter(Boolean).join(', '));
      }
      if (txViewState.familyIds.length) {
        parts.push(txViewState.familyIds.map((id) => famMap.get(id)?.name).filter(Boolean).join(', '));
      }
      state.analysisFilter = {
        label: parts.join(' · ') || 'Filtered Transactions',
        search: txViewState.search.trim(),
        categoryIds: [...txViewState.categoryIds],
        categoryMode: txViewState.categoryMode,
        accountIds: [...txViewState.accountIds],
        accountMode: txViewState.accountMode,
        tagIds: [...txViewState.tagIds],
        tagMode: txViewState.tagMode,
        familyIds: [...txViewState.familyIds],
        familyMode: txViewState.familyMode,
        type: txViewState.type,
        startDate: txViewState.startDate || '',
        endDate: txViewState.endDate || '',
        years: [...txViewState.years],
        months: [...txViewState.months],
      };
      if (typeof ctx.navigateTo === 'function') ctx.navigateTo('analysis');
      else window.location.hash = '#/analysis';
    });

    container.querySelector('#btn-toggle-bulk')?.addEventListener('click', () => {
      txViewState.bulkMode = !txViewState.bulkMode;
      txViewState.selectedIds.clear();
      renderTransactionsView(container, ctx);
    });
  }

  container.querySelectorAll('[data-tx-mode]').forEach((btn) => {
    btn.addEventListener('click', () => {
      txViewState.mode = btn.getAttribute('data-tx-mode');
      renderTransactionsView(container, ctx);
    });
  });
}

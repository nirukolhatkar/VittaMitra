import { escapeHtml } from '../../utils/dom.js';
import { svgIcon } from '../components/icons.js';

/**
 * VittaMitra Financial Journey — Atomic Habits Inspired First-Launch Welcome (#/welcome).
 *
 * Central philosophy:
 * "You don't need to become financially disciplined overnight. You need to build small habits
 *  that gradually make you better with money."
 *
 * Uses compounding purely as an analogy for habit consistency (never implying 1% daily wealth growth).
 */
export async function renderWelcomeView(container, ctx) {
  const { services, navigateTo } = ctx;

  let levelName = 'Beginner';
  let completedCount = 0;
  let totalMissions = 10;
  try {
    const progress = await services.journey?.evaluateProgress();
    if (progress) {
      levelName = progress.levelInfo?.name || 'Beginner';
      completedCount = progress.completedCount || 0;
      totalMissions = progress.totalMissions || 10;
    }
  } catch {
    // Fail-safe: welcome remains usable even if journey evaluation fails
  }

  const isReturningPreview = completedCount > 0;

  container.innerHTML = `
    <div class="welcome-shell">
      <div class="welcome-hero card">
        <div class="welcome-badge">
          ${svgIcon('compass', 15)}
          <span>VittaMitra Financial Journey</span>
        </div>

        <h1 class="welcome-title">
          You don’t need a financial transformation today. You need one small habit.
        </h1>

        <p class="welcome-lead">
          Recording today’s expense, understanding where your money goes, saving a little consistently,
          and making one better decision at a time can change your financial future.
        </p>

        <figure class="welcome-curve-figure" aria-label="Illustration of small consistent habits gradually building financial clarity">
          <svg viewBox="0 0 340 132" width="100%" class="welcome-curve-svg" role="img" aria-hidden="true">
            <line x1="16" y1="108" x2="324" y2="108" stroke="currentColor" stroke-opacity="0.16" stroke-width="1"/>
            <line x1="16" y1="68" x2="324" y2="68" stroke="currentColor" stroke-opacity="0.09" stroke-width="1"/>
            <path d="M 22 102 C 52 54, 82 40, 114 48 C 148 56, 190 92, 248 98 C 282 101, 304 102, 318 102"
                  fill="none" stroke="currentColor" stroke-opacity="0.32" stroke-width="1.8" stroke-dasharray="4 4"/>
            <path d="M 22 102 C 94 98, 156 84, 214 58 C 258 38, 290 22, 316 14"
                  fill="none" stroke="var(--accent)" stroke-width="3.2" stroke-linecap="round"/>
            <circle cx="54" cy="99" r="3.8" fill="var(--bg-surface)" stroke="var(--accent)" stroke-width="2.2"/>
            <circle cx="148" cy="83" r="3.8" fill="var(--bg-surface)" stroke="var(--accent)" stroke-width="2.2"/>
            <circle cx="240" cy="45" r="3.8" fill="var(--bg-surface)" stroke="var(--accent)" stroke-width="2.2"/>
            <circle cx="316" cy="14" r="4.5" fill="var(--accent)"/>
            <text x="22" y="124" fill="currentColor" fill-opacity="0.6" font-size="10.5">Day 1</text>
            <text x="168" y="124" text-anchor="middle" fill="currentColor" fill-opacity="0.6" font-size="10.5">Small daily habits</text>
            <text x="318" y="124" text-anchor="end" fill="var(--accent-ink)" font-size="10.5" font-weight="700">Lasting clarity</text>
            <text x="312" y="92" text-anchor="end" fill="currentColor" fill-opacity="0.55" font-size="9.5">Sudden overhaul</text>
          </svg>
          <figcaption class="welcome-curve-caption">
            Small actions repeated calmly build lasting financial awareness—no overnight overhaul needed.
          </figcaption>
        </figure>

        <div class="welcome-pillars" role="list">
          <div class="welcome-pillar" role="listitem">
            <span class="welcome-pillar-icon">${svgIcon('sparkles', 18)}</span>
            <div>
              <div class="welcome-pillar-title">You don’t need to be a financial expert</div>
              <div class="welcome-pillar-sub">Plain-language guidance built for everyday life, never intimidating jargon.</div>
            </div>
          </div>

          <div class="welcome-pillar" role="listitem">
            <span class="welcome-pillar-icon">${svgIcon('target', 18)}</span>
            <div>
              <div class="welcome-pillar-title">Start with your current account balances</div>
              <div class="welcome-pillar-sub">You don’t need to enter years of historical transactions or change all your habits today.</div>
            </div>
          </div>

          <div class="welcome-pillar" role="listitem">
            <span class="welcome-pillar-icon">${svgIcon('trending', 18)}</span>
            <div>
              <div class="welcome-pillar-title">Take one small action at a time</div>
              <div class="welcome-pillar-sub">Your progress is never erased when you miss a day. Skip anything that doesn’t apply.</div>
            </div>
          </div>

          <div class="welcome-pillar" role="listitem">
            <span class="welcome-pillar-icon">${svgIcon('shield', 18)}</span>
            <div>
              <div class="welcome-pillar-title">Private &amp; offline-first on your device</div>
              <div class="welcome-pillar-sub">Your financial records stay under your control, online or offline.</div>
            </div>
          </div>
        </div>

        <div class="welcome-actions">
          <button type="button" id="btn-welcome-start" class="btn btn-primary welcome-cta">
            ${isReturningPreview ? 'Continue My Financial Journey' : 'Start My Financial Journey'}
          </button>
          <button type="button" id="btn-welcome-skip" class="btn btn-ghost welcome-skip">
            ${isReturningPreview ? 'Back to Dashboard' : 'I’ll explore on my own'}
          </button>
        </div>

        ${isReturningPreview ? `
          <div class="welcome-footnote">
            Currently ${escapeHtml(levelName)} · ${completedCount} of ${totalMissions} missions completed
          </div>
        ` : `
          <div class="welcome-footnote">
            One small step at a time—about 2 minutes to map your first account.
          </div>
        `}
      </div>
    </div>
  `;

  container.querySelector('#btn-welcome-start')?.addEventListener('click', async () => {
    try {
      await services.journey?.markWelcomeCompleted({ skipped: false });
    } catch {
      // Fail-safe
    }
    navigateTo('journey');
  });

  container.querySelector('#btn-welcome-skip')?.addEventListener('click', async () => {
    try {
      await services.journey?.markWelcomeCompleted({ skipped: true });
    } catch {
      // Fail-safe
    }
    navigateTo('home');
  });
}

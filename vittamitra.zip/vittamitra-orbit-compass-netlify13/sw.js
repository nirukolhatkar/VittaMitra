/**
 * Offline-first Service Worker for Personal Finance Manager (VittaMitra Debt Tracker Release).
 */

const CACHE_NAME = 'pfm-shell-v9.47.0';
const OCR_ASSET_CACHE = 'pfm-ocr-assets-v2';

const APP_SHELL_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './assets/favicon.svg',
  './assets/icon-192.png',
  './assets/icon-512.png',
  './css/tokens.css',
  './css/base.css',
  './css/components.css',
  './vendor/dexie.js',
  './vendor/xlsx-lite.js',
  './src/app.js',
  './src/router.js',
  './src/constants/accountTypes.js',
  './src/constants/defaultSeeds.js',
  './src/utils/uuid.js',
  './src/utils/money.js',
  './src/utils/categoryMatcher.js',
  './src/utils/date.js',
  './src/utils/normalize.js',
  './src/utils/dom.js',
  './src/utils/colors.js',
  './src/db/database.js',
  './src/db/repositories/baseRepository.js',
  './src/db/repositories/settingsRepository.js',
  './src/db/repositories/categoryRepository.js',
  './src/db/repositories/accountRepository.js',
  './src/db/repositories/familyRepository.js',
  './src/db/repositories/tagRepository.js',
  './src/db/repositories/favoriteRepository.js',
  './src/db/repositories/attachmentRepository.js',
  './src/db/repositories/budgetRepository.js',
  './src/db/repositories/billRepository.js',
  './src/db/repositories/recurringRepository.js',
  './src/db/repositories/investmentRepository.js',
  './src/db/repositories/loanRepository.js',
  './src/db/repositories/debtRepository.js',
  './src/db/repositories/statementImportRepository.js',
  './src/services/ledgerRules.js',
  './src/services/transactionService.js',
  './src/services/importExportService.js',
  './src/services/budgetService.js',
  './src/services/analyticsService.js',
  './src/services/billsRecurringService.js',
  './src/services/cashFlowReadinessService.js',
  './src/services/journeyEngine.js',
  './src/services/tutorialManager.js',
  './src/services/debtService.js',
  './src/services/wealthService.js',
  './src/services/statementUploadService.js',
  './src/services/localOcrEngine.js',
  './src/services/localPdfEngine.js',
  './src/services/upiScreenshotParser.js',
  './src/services/statementExtractionService.js',
  './src/services/statementNormalisationService.js',
  './src/services/statementCategorisationService.js',
  './src/services/statementReconciliationService.js',
  './src/services/statementReviewService.js',
  './src/services/statementLedgerCommitService.js',
  './src/services/backupScheduleService.js',
  './src/services/migrationRecoveryService.js',
  './src/services/storageService.js',
  './src/services/themeService.js',
  './src/services/txContextClipboard.js',
  './src/ui/components/toast.js',
  './src/ui/components/modal.js',
  './src/ui/components/charts.js',
  './src/ui/components/icons.js',
  './src/ui/views/homeView.js',
  './src/ui/views/transactionsView.js',
  './src/ui/views/addTransactionView.js',
  './src/ui/views/analysisView.js',
  './src/ui/views/budgetsView.js',
  './src/ui/views/billsView.js',
  './src/ui/views/debtsView.js',
  './src/ui/views/moreView.js',
  './src/ui/views/categoriesView.js',
  './src/ui/views/accountDetailView.js',
  './src/ui/views/accountsView.js',
  './src/ui/views/familyView.js',
  './src/ui/views/tagsView.js',
  './src/ui/views/tagDetailView.js',
  './src/ui/views/categoryDetailView.js',
  './src/ui/views/importExportView.js',
  './src/ui/views/statementImportView.js',
  './src/ui/views/categorisationRulesView.js',
  './src/ui/views/investmentsView.js',
  './src/ui/views/netWorthView.js',
  './src/ui/views/welcomeView.js',
  './src/ui/views/journeyView.js',
  './src/ui/views/settingsView.js',
];

async function precacheAssetWithRetry(cache, asset) {
  try {
    await cache.add(asset);
    return true;
  } catch {
    try {
      await cache.add(asset);
      return true;
    } catch {
      return false;
    }
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) =>
        Promise.allSettled(
          APP_SHELL_ASSETS.map((asset) => precacheAssetWithRetry(cache, asset))
        )
      )
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k !== CACHE_NAME && k !== OCR_ASSET_CACHE).map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const reqUrl = event.request.url || '';
  if (event.request.method === 'GET' && (reqUrl.includes('/vendor/ocr/') || reqUrl.includes('/vendor/pdfjs/'))) {
    event.respondWith(
      caches.open(OCR_ASSET_CACHE).then(async (cache) => {
        const hit = await cache.match(event.request);
        if (hit) return hit;
        const resp = await fetch(event.request);
        if (resp && resp.ok) cache.put(event.request, resp.clone());
        return resp;
      })
    );
    return;
  }
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(request, { ignoreSearch: true }).then((cached) => {
      if (cached) return cached;

      return fetch(request)
        .then(async (response) => {
          if (request.mode === 'navigate' && response && response.status === 404) {
            const fallback = await caches.match('./index.html');
            if (fallback) return fallback;
          }
          if (response && response.status === 200 && response.type === 'basic') {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        })
        .catch(() => {
          if (request.mode === 'navigate') {
            return caches.match('./index.html');
          }
          return new Response('Offline', { status: 503, statusText: 'Offline' });
        });
    })
  );
});

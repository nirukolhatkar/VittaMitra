import {
  ACCOUNT_TYPES,
  ACCOUNT_TYPE_ORDER,
  getAccountTypeMeta,
} from '../../constants/accountTypes.js';
import { AccountRepository } from '../../db/repositories/accountRepository.js';
import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString } from '../../utils/money.js';
import { formatRelativeDate, toLocalDateString } from '../../utils/date.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { bindTransactionLongPress, copyTransactionToClipboard, pasteClipboardToContext, setPageContext } from '../../services/txContextClipboard.js';

function accountsMaskOrFormat(paise, showBalances) {
  if (!showBalances) return '*****';
  return formatINR(paise);
}

export async function renderAccountsView(container, ctx) {
  const { repos, services, state } = ctx;
  const [settings, grouped, summary] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.listGrouped(),
    repos.accounts.getBalanceSummary(),
  ]);

  const showBalances = settings.show_balances !== false;
  const ccMode = settings.credit_card_display_mode || 'available_credit';
  const ccSummaryValue =
    ccMode === 'available_credit'
      ? summary.totalAvailableCreditPaise
      : summary.totalCreditCardLiabilityPaise;
  const ccSummaryLabel =
    ccMode === 'available_credit' ? 'Available Credit' : 'Total Outstanding';
  const availNeg = summary.totalAvailableBalancePaise < 0;

  container.innerHTML = `
    <div class="stack" style="gap:12px;">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Accounts</h2>
          <div class="compass-subtitle">Balances reconciled from your transactions</div>
        </div>
        <div class="row-actions" style="gap:8px;">
          <label class="switch" aria-label="Show balance" title="Show or mask balances">
            <input type="checkbox" id="toggle-show-balance" ${showBalances ? 'checked' : ''}>
            <span class="switch-track"></span>
          </label>
          <button type="button" class="btn btn-secondary btn-sm" id="btn-add-account">+ Account</button>
        </div>
      </div>

      <section class="compass-summary-row" aria-label="Account summary">
        <div>
          <div class="item-meta">Available</div>
          <div class="compass-summary-val ${availNeg ? 'text-danger' : ''}" id="metric-available-balance">
            ${accountsMaskOrFormat(summary.totalAvailableBalancePaise, showBalances)}
          </div>
          <div class="metric-note">Bank, Wallet &amp; Cash</div>
        </div>

        <div>
          <div class="item-meta" id="cc-summary-label">${ccSummaryLabel}</div>
          <div class="compass-summary-val" id="metric-cc-summary" style="color:${ccMode === 'outstanding' && ccSummaryValue > 0 ? 'var(--accent)' : 'var(--text-primary)'};">
            ${accountsMaskOrFormat(ccSummaryValue, showBalances)}
          </div>
          <div class="cc-mode-toggle" role="tablist" aria-label="Credit card balance view" style="margin-top:4px;">
            <button type="button" data-cc-mode="available_credit" class="${ccMode === 'available_credit' ? 'active' : ''}">Avail Credit</button>
            <button type="button" data-cc-mode="outstanding" class="${ccMode === 'outstanding' ? 'active' : ''}">Outstanding</button>
          </div>
        </div>
      </section>

      ${
        summary.activeCount === 0
          ? `<div class="empty-state">
              <div class="empty-state-icon">🏛️</div>
              <h3 class="empty-state-title">No accounts added yet</h3>
              <p class="empty-state-text">
                Add your Bank Accounts (e.g. IDFC First Savings), Credit Cards (e.g. Kiwi Yes Bank),
                Wallets (e.g. Sodexo), or Cash.
              </p>
              <button type="button" class="btn btn-primary" id="btn-empty-add-account">+ Add first account</button>
            </div>`
          : grouped.groups
              .filter((g) => g.items.length > 0)
              .map(
                (group) => `
                <section class="stack" style="gap:6px;">
                  <div class="compass-gh">
                    <b>${escapeHtml(group.meta.pluralLabel)}</b>
                    <span class="item-meta" style="font-variant-numeric:tabular-nums; font-weight:700;">
                      ${(() => {
                        const isCCGroup = group.meta.code === 'credit_card';
                        const grpSum = group.items.reduce((s, a) => {
                          if (isCCGroup) {
                            const cc = AccountRepository.getCreditCardMetrics(a);
                            return s + (ccMode === 'available_credit' ? cc.availableCreditPaise : cc.outstandingPaise);
                          }
                          return s + (a.current_balance_paise ?? a.opening_balance_paise ?? 0);
                        }, 0);
                        return accountsMaskOrFormat(grpSum, showBalances) + (isCCGroup && ccMode === 'outstanding' ? ' due' : '');
                      })()}
                    </span>
                  </div>

                  <div class="grouped-card">
                    ${group.items
                      .map((acc) => {
                        const isCC = group.meta.code === 'credit_card';
                        let displayPaise = acc.current_balance_paise ?? acc.opening_balance_paise ?? 0;
                        let subNote = acc.institution || group.meta.label;
                        let valueClass = '';

                        if (isCC) {
                          const cc = AccountRepository.getCreditCardMetrics(acc);
                          displayPaise =
                            ccMode === 'available_credit' ? cc.availableCreditPaise : cc.outstandingPaise;
                          if (ccMode === 'available_credit') {
                            subNote = cc.limitPaise
                              ? `Limit ${accountsMaskOrFormat(cc.limitPaise, showBalances)}`
                              : 'Set credit limit to track available credit';
                          } else {
                            subNote =
                              cc.overpaymentCreditPaise > 0
                                ? `No dues (Credit balance ${accountsMaskOrFormat(cc.overpaymentCreditPaise, showBalances)})`
                                : 'Total outstanding';
                            if (displayPaise > 0) valueClass = 'text-danger';
                          }
                        } else if (displayPaise < 0) {
                          // Highlight negative balance in red for non-credit-card accounts
                          valueClass = 'text-danger';
                        }

                        return `
                          <div class="grouped-row grouped-row-clickable" data-open-account="${acc.id}">
                            <div style="min-width:0;">
                              <div class="item-title">${escapeHtml(acc.name)}</div>
                              <div class="item-meta">${escapeHtml(subNote)}</div>
                            </div>
                            <div class="row-actions">
                              <span class="item-title ${valueClass}" style="font-variant-numeric:tabular-nums;">
                                ${accountsMaskOrFormat(displayPaise, showBalances)}
                              </span>
                              <span class="text-muted">›</span>
                            </div>
                          </div>
                        `;
                      })
                      .join('')}
                  </div>
                </section>
              `
              )
              .join('')
      }

      <details class="accordion">
        <summary>
          <span>🗂️ Archived Accounts (${grouped.archived.length})</span>
          <span class="text-muted">⌄</span>
        </summary>
        ${
          grouped.archived.length === 0
            ? `<div style="padding:0 16px 14px;" class="item-meta">No archived accounts.</div>`
            : `<div class="grouped-card" style="border:none; border-top:1px solid var(--border-subtle); border-radius:0;">
                ${grouped.archived
                  .map(
                    (acc) => `
                    <div class="grouped-row">
                      <div>
                        <div class="item-title">${escapeHtml(acc.name)}</div>
                        <div class="item-meta">${escapeHtml(getAccountTypeMeta(acc.type).label)} · Archived</div>
                      </div>
                      <button type="button" class="btn btn-secondary btn-sm" data-restore-account="${acc.id}">Restore</button>
                    </div>`
                  )
                  .join('')}
              </div>`
        }
      </details>
    </div>
  `;

  container.querySelector('#toggle-show-balance')?.addEventListener('change', async (e) => {
    await repos.settings.updateSettings({ show_balances: e.target.checked });
    renderAccountsView(container, ctx);
  });

  container.querySelectorAll('[data-cc-mode]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const mode = btn.getAttribute('data-cc-mode');
      await repos.settings.updateSettings({ credit_card_display_mode: mode });
      renderAccountsView(container, ctx);
    });
  });

  const openAccountForm = (existing = null) => {
    const isEdit = Boolean(existing);
    const selectedType = existing ? getAccountTypeMeta(existing.type).code : 'bank_account';
    const isCC = selectedType === 'credit_card';

    const typeOptions = ACCOUNT_TYPE_ORDER.map((code) => {
      const t = ACCOUNT_TYPES[code];
      return `<option value="${t.code}" ${t.code === selectedType ? 'selected' : ''}>${t.icon} ${t.label}</option>`;
    }).join('');

    const defaultInclude = existing
      ? existing.include_in_available_balance
      : getAccountTypeMeta(selectedType).defaultIncludeInAvailableBalance;

    openModal({
      title: isEdit ? 'Edit Account' : 'Add Account',
      bodyHtml: `
        <form id="account-form">
          <div class="form-group">
            <label class="form-label" for="acc-name">Account Name</label>
            <input id="acc-name" name="name" class="form-control" required maxlength="80"
              value="${escapeHtml(existing?.name || '')}" placeholder="e.g. IDFC First Savings, Kiwi Yes Bank">
            <div class="form-help">Leading and trailing whitespace is automatically trimmed.</div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="acc-type">Account Type</label>
              <select id="acc-type" name="type" class="form-control">${typeOptions}</select>
            </div>
            <div class="form-group">
              <label class="form-label" for="acc-balance" id="acc-balance-label">
                ${isCC ? 'Opening Outstanding (₹)' : 'Opening Balance (₹)'}
              </label>
              <input id="acc-balance" name="opening_balance_rupees" class="form-control" inputmode="decimal"
                value="${existing ? paiseToDecimalString(isCC ? Math.max(0, existing.opening_balance_paise || 0) : existing.opening_balance_paise || 0) : '0'}" required>
            </div>
          </div>

          <div class="form-group ${isCC ? '' : 'hidden'}" id="cc-limit-group">
            <label class="form-label" for="acc-limit">Credit Limit (₹)</label>
            <input id="acc-limit" name="credit_limit_rupees" class="form-control" inputmode="decimal"
              value="${existing && existing.credit_limit_paise ? paiseToDecimalString(existing.credit_limit_paise) : ''}"
              placeholder="e.g. 150000 (used to calculate Available Credit)">
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="acc-institution">Institution (optional)</label>
              <input id="acc-institution" name="institution" class="form-control" maxlength="60"
                value="${escapeHtml(existing?.institution || '')}" placeholder="e.g. IDFC First Bank">
            </div>
            <div class="form-group">
              <label class="form-label" for="acc-id">Last 4 digits / ID (optional)</label>
              <input id="acc-id" name="identifier_masked" class="form-control" maxlength="20"
                value="${escapeHtml(existing?.identifier_masked || '')}" placeholder="e.g. XX4821">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="acc-date">Opening Date</label>
            <input id="acc-date" name="opening_date" type="date" class="form-control"
              value="${escapeHtml(existing?.opening_date || toLocalDateString())}">
          </div>

          <div class="form-group">
            <label class="checkbox-row">
              <input type="checkbox" id="acc-include-avail" name="include_in_available_balance" ${defaultInclude ? 'checked' : ''}>
              <span>Include in Available Balance</span>
            </label>
            <div class="form-help">Credit cards are excluded from Available Balance by default.</div>
          </div>

          <div class="modal-footer" style="justify-content:space-between; flex-wrap:wrap;">
            ${
              isEdit
                ? `<div class="row-actions">
                    <button type="button" class="btn btn-secondary btn-sm" id="btn-modal-archive">Archive</button>
                    <button type="button" class="btn btn-danger btn-sm" id="btn-modal-delete">Delete</button>
                  </div>`
                : '<div></div>'
            }
            <div class="row-actions">
              <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
              <button type="submit" class="btn btn-primary">${isEdit ? 'Save' : 'Create'}</button>
            </div>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        const typeSelect = panel.querySelector('#acc-type');
        const includeCheckbox = panel.querySelector('#acc-include-avail');
        const balanceLabel = panel.querySelector('#acc-balance-label');
        const ccLimitGroup = panel.querySelector('#cc-limit-group');

        typeSelect.addEventListener('change', () => {
          const meta = getAccountTypeMeta(typeSelect.value);
          const nowCC = meta.code === 'credit_card';
          if (!isEdit) includeCheckbox.checked = meta.defaultIncludeInAvailableBalance;
          balanceLabel.textContent = nowCC ? 'Opening Outstanding (₹)' : 'Opening Balance (₹)';
          ccLimitGroup.classList.toggle('hidden', !nowCC);
        });

        panel.querySelector('#btn-modal-archive')?.addEventListener('click', async () => {
          await repos.accounts.setArchived(existing.id, true);
          showToast('Account archived');
          close();
          renderAccountsView(container, ctx);
        });

        panel.querySelector('#btn-modal-delete')?.addEventListener('click', async () => {
          await repos.accounts.softDelete(existing.id);
          close();
          renderAccountsView(container, ctx);
          showToast(`Account "${existing.name}" deleted`, {
            actionLabel: 'Undo',
            onAction: async () => {
              await repos.accounts.restore(existing.id);
              renderAccountsView(container, ctx);
              showToast('Account restored');
            },
          });
        });

        const form = panel.querySelector('#account-form');
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(form);
          const payload = {
            name: fd.get('name'),
            type: fd.get('type'),
            institution: fd.get('institution'),
            identifier_masked: fd.get('identifier_masked'),
            opening_balance_rupees: fd.get('opening_balance_rupees'),
            credit_limit_rupees: fd.get('credit_limit_rupees') || '',
            opening_date: fd.get('opening_date'),
            include_in_available_balance: includeCheckbox.checked,
          };
          try {
            if (isEdit) {
              await repos.accounts.updateAccount(existing.id, payload);
              showToast('Account updated');
            } else {
              await repos.accounts.createAccount(payload);
              showToast('Account created');
            }
            close();
            renderAccountsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  /**
   * Account Detail & Reconciliation Modal:
   * - "As on date" date picker recalculating balance excluding all future transactions
   * - Tap any transaction to Edit, one-tap Copy (without opening details), or Delete (with Undo)
   */
  const openAccountDetail = async (accountId, initialAsOfDate = toLocalDateString()) => {
    let asOfDate = initialAsOfDate;

    const renderDetailContent = async (panel, close) => {
      const acc = await repos.accounts.getReconciledAccountAsOf(accountId, asOfDate);
      if (!acc) return;
      setPageContext(ctx, {
        route: 'accounts',
        label: acc.name,
        shortLabel: acc.name.slice(0, 12),
        accountName: acc.name,
        overrides: { account_id: acc.id, date: asOfDate },
        onPasteRefresh: async () => {
          await renderDetailContent(panel, close);
          renderAccountsView(container, ctx);
        },
      });
      const txsUpToDate = await services.transactions.listTransactions({
        accountId: acc.id,
        endDate: asOfDate,
      });
      const visibleTxs = txsUpToDate.slice(0, 15);
      const meta = getAccountTypeMeta(acc.type);
      const isCC = meta.code === 'credit_card';
      const cc = isCC ? AccountRepository.getCreditCardMetrics(acc) : null;
      const assetNeg = !isCC && acc.current_balance_paise < 0;

      const body = panel.querySelector('.modal-body');
      body.innerHTML = `
        <div class="stack">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="acc-reconcile-date">Balance As On Date (excludes future transactions)</label>
            <input id="acc-reconcile-date" type="date" class="form-control" value="${escapeHtml(asOfDate)}">
          </div>

          <div class="grid-2">
            <div class="metric-card">
              <div class="metric-label">${isCC ? 'Outstanding as on date' : 'Balance as on date'}</div>
              <div class="metric-value ${isCC ? (cc.outstandingPaise > 0 ? 'text-danger' : '') : (assetNeg ? 'text-danger' : 'text-success')}" id="acc-asof-balance">
                ${accountsMaskOrFormat(isCC ? cc.outstandingPaise : acc.current_balance_paise, showBalances)}
              </div>
            </div>
            <div class="metric-card">
              <div class="metric-label">${isCC ? 'Available Credit' : 'Opening Balance'}</div>
              <div class="metric-value">
                ${accountsMaskOrFormat(isCC ? cc.availableCreditPaise : acc.opening_balance_paise || 0, showBalances)}
              </div>
            </div>
          </div>

          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
              <span class="item-title">Account History (up to ${escapeHtml(asOfDate)})</span>
              <span class="item-meta">${txsUpToDate.length} txn${txsUpToDate.length === 1 ? '' : 's'}</span>
            </div>
            ${
              visibleTxs.length === 0
                ? `<div class="item-meta">No transactions on or before ${escapeHtml(asOfDate)}.</div>`
                : `<div class="grouped-card">
                    ${visibleTxs
                      .map((tx) => {
                        const amtClass =
                          tx.type === 'income' ? 'text-success' : tx.type === 'expense' ? 'text-danger' : 'text-muted';
                        return `
                          <div class="grouped-row" style="padding:10px 12px;">
                            <div style="flex:1; min-width:0; cursor:pointer;" data-acc-edit-tx="${tx.id}">
                              <div class="item-title" style="font-size:0.84rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                ${escapeHtml(tx.description || tx.type)}
                              </div>
                              <div class="item-meta">${escapeHtml(tx.type)} · Tap to edit</div>
                            </div>
                            <div class="tx-amt-col">
                              <strong class="${amtClass}" style="font-variant-numeric:tabular-nums; font-size:0.85rem;">
                                ${accountsMaskOrFormat(tx.amount_paise, showBalances)}
                              </strong>
                              <span class="tx-date-sub">${escapeHtml(formatRelativeDate(tx.date_key))}</span>
                            </div>
                          </div>`;
                      })
                      .join('')}
                  </div>`
            }
          </div>

          <div class="modal-footer" style="justify-content:space-between; flex-wrap:wrap;">
            <div class="row-actions">
              <button type="button" class="btn btn-primary btn-sm" id="btn-acc-add-tx">+ Add</button>
              ${state.clipboardTx ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-acc-paste-tx">📋 Paste to ${escapeHtml(acc.name.slice(0, 12))}</button>` : ''}
            </div>
            <div class="row-actions">
              <button type="button" class="btn btn-secondary btn-sm" id="btn-acc-edit">Edit Account</button>
              <button type="button" class="btn btn-secondary btn-sm" data-modal-close>Close</button>
            </div>
          </div>
        </div>
      `;

      body.querySelector('#acc-reconcile-date')?.addEventListener('change', (e) => {
        if (e.target.value) {
          asOfDate = e.target.value;
          renderDetailContent(panel, close);
        }
      });

      body.querySelectorAll('[data-acc-edit-tx]').forEach((el) => {
        el.addEventListener('click', () => {
          const txId = el.getAttribute('data-acc-edit-tx');
          close();
          state.txDraft = { editId: txId };
          window.location.hash = '#/add-transaction';
        });
      });

      bindTransactionLongPress(body, ctx, {
        selector: '[data-acc-edit-tx]',
        attr: 'data-acc-edit-tx',
        onBeforeAction: () => close(),
        onRefresh: () => renderAccountsView(container, ctx),
      });

      body.querySelectorAll('[data-acc-copy-tx]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          await copyTransactionToClipboard(ctx, btn.getAttribute('data-acc-copy-tx'));
          await renderDetailContent(panel, close);
        });
      });

      body.querySelector('#btn-acc-paste-tx')?.addEventListener('click', async () => {
        close();
        await pasteClipboardToContext(ctx);
      });

      body.querySelectorAll('[data-acc-del-tx]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const undoToken = await services.transactions.softDeleteTransaction(btn.getAttribute('data-acc-del-tx'));
          await renderDetailContent(panel, close);
          renderAccountsView(container, ctx);
          if (undoToken) {
            showToast('Transaction deleted', {
              actionLabel: 'Undo',
              onAction: async () => {
                await services.transactions.restoreTransaction(undoToken);
                renderAccountsView(container, ctx);
                showToast('Transaction restored');
              },
            });
          }
        });
      });

      body.querySelector('#btn-acc-edit')?.addEventListener('click', () => {
        close();
        openAccountForm(acc);
      });

      body.querySelector('#btn-acc-add-tx')?.addEventListener('click', () => {
        close();
        state.txDraft = { account_id: acc.id, date: asOfDate };
        window.location.hash = '#/add-transaction';
      });
    };

    const accInit = await repos.accounts.getById(accountId);
    if (!accInit) return;
    const metaInit = getAccountTypeMeta(accInit.type);

    openModal({
      title: `${metaInit.icon} ${accInit.name}`,
      bodyHtml: '<div class="loading-state">Loading account ledger…</div>',
      onMount: (panel, close) => {
        renderDetailContent(panel, close);
      },
    });
  };

  container.querySelector('#btn-add-account')?.addEventListener('click', () => openAccountForm());
  container.querySelector('#btn-empty-add-account')?.addEventListener('click', () => openAccountForm());

  container.querySelectorAll('[data-open-account]').forEach((row) => {
    row.addEventListener('click', () => openAccountDetail(row.getAttribute('data-open-account')));
  });

  container.querySelectorAll('[data-restore-account]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await repos.accounts.setArchived(btn.getAttribute('data-restore-account'), false);
      showToast('Account restored');
      renderAccountsView(container, ctx);
    });
  });

  if (state.selectedAccountId) {
    const targetAccId = state.selectedAccountId;
    state.selectedAccountId = null;
    openAccountDetail(targetAccId);
  }
}

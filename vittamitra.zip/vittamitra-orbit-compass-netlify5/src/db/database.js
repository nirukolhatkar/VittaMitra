import Dexie from '../../vendor/dexie.js';
import {
  DEFAULT_EXPENSE_CATEGORIES,
  DEFAULT_FAMILY_MEMBERS,
  DEFAULT_INCOME_CATEGORIES,
  DEFAULT_SETTINGS,
} from '../constants/defaultSeeds.js';
import { generateUUID } from '../utils/uuid.js';
import { nowIsoUtc } from '../utils/date.js';

export const DB_NAME = 'PersonalFinanceManagerDB';
export const DB_SCHEMA_VERSION = 7;

const V4_STORES = {
  settings: 'id, user_id, updated_at, deleted_at',
  categories: 'id, user_id, type, parent_id, name, is_archived, deleted_at, updated_at',
  accounts: 'id, user_id, type, account_class, normalized_key, is_archived, deleted_at, updated_at',
  family_members: 'id, user_id, name, is_active, deleted_at, updated_at',
  tags: 'id, user_id, &normalized_key, is_archived, deleted_at, updated_at',
  transactions:
    'id, user_id, type, date_key, occurred_at_local, category_id, account_id, to_account_id, family_member_id, import_batch_id, debt_id, deleted_at, updated_at',
  ledger_postings:
    'id, user_id, transaction_id, account_id, account_class, posting_role, occurred_at_local, deleted_at, updated_at',
  transaction_tags: 'id, user_id, transaction_id, tag_id, deleted_at, updated_at',
  transaction_splits: 'id, user_id, transaction_id, category_id, deleted_at, updated_at',
  favorite_templates: 'id, user_id, type, sort_order, deleted_at, updated_at',
  attachments: 'id, user_id, transaction_id, local_blob_key, deleted_at, updated_at',
  import_batches: 'id, user_id, filename, imported_at, deleted_at, updated_at',
  budgets: 'id, user_id, scope_type, scope_id, period_month, is_recurring, deleted_at, updated_at',
  attachment_blobs: 'id, mime_type, size_bytes, created_at',
  sync_queue: '++seq, table_name, record_id, operation, queued_at',
  sync_meta: 'key, updated_at',
};

const V5_STORES = {
  ...V4_STORES,
  bills: 'id, user_id, due_date, status, category_id, account_id, frequency, deleted_at, updated_at',
  recurring_rules: 'id, user_id, type, next_due_date, frequency, is_active, auto_post, deleted_at, updated_at',
};

const V6_STORES = {
  ...V5_STORES,
  investments: 'id, user_id, asset_type, name, goal_name, start_date, deleted_at, updated_at',
  investment_transactions: 'id, user_id, investment_id, date_key, tx_type, deleted_at, updated_at',
  loans: 'id, user_id, loan_type, name, start_date, is_active, deleted_at, updated_at',
  net_worth_snapshots: 'id, user_id, snapshot_date, deleted_at, updated_at',
};

const V7_STORES = {
  ...V6_STORES,
  debts: 'id, user_id, counterparty_name, debt_type, status, start_date, expected_repayment_date, family_member_id, deleted_at, updated_at',
  debt_events: 'id, user_id, debt_id, transaction_id, interest_transaction_id, event_type, event_date, idempotency_key, deleted_at, updated_at',
};

export function createDatabase(dbName = DB_NAME) {
  const db = new Dexie(dbName);

  db.version(1).stores({
    settings: V4_STORES.settings,
    categories: V4_STORES.categories,
    accounts: V4_STORES.accounts,
    family_members: V4_STORES.family_members,
    tags: V4_STORES.tags,
    attachment_blobs: V4_STORES.attachment_blobs,
    sync_queue: V4_STORES.sync_queue,
    sync_meta: V4_STORES.sync_meta,
  });

  db.version(2).stores({
    ...V4_STORES,
    import_batches: null,
    budgets: null,
  });

  db.version(3).stores({
    ...V4_STORES,
    budgets: null,
  });

  db.version(4).stores(V4_STORES);

  // Version 5 (Phase 4 — Bills, Reminders & Recurring Transactions)
  db.version(5).stores(V5_STORES);

  // Version 6 (Phase 5 — Investments, Goal Tracking, XIRR, Loans & Net Worth)
  db.version(6).stores(V6_STORES);

  // Version 7 (VittaMitra Personal Debt Tracker — Debts & Debt Events)
  db.version(DB_SCHEMA_VERSION).stores(V7_STORES);

  return db;
}

export const db = createDatabase();

export async function initializeDatabase(database = db) {
  await database.open();
  const now = nowIsoUtc();

  const existingSettings = await database.settings.get(DEFAULT_SETTINGS.id);
  if (!existingSettings) {
    await database.settings.put({
      ...DEFAULT_SETTINGS,
      backup_schedule: 'weekly', // 'off' | 'daily' | 'weekly' | 'monthly'
      last_backup_at: null,
      gdrive_client_id: '',
      gdrive_last_backup_at: null,
      user_id: null,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    });
  }

  const categoryCount = await database.categories.count();
  if (categoryCount === 0) {
    const seededCategories = [
      ...DEFAULT_EXPENSE_CATEGORIES.map((cat, idx) => ({
        id: generateUUID(),
        user_id: null,
        name: cat.name,
        type: 'expense',
        parent_id: null,
        icon: cat.icon,
        color: cat.color,
        is_default: true,
        is_archived: false,
        sort_order: idx + 1,
        created_at: now,
        updated_at: now,
        version: 1,
        deleted_at: null,
      })),
      ...DEFAULT_INCOME_CATEGORIES.map((cat, idx) => ({
        id: generateUUID(),
        user_id: null,
        name: cat.name,
        type: 'income',
        parent_id: null,
        icon: cat.icon,
        color: cat.color,
        is_default: true,
        is_archived: false,
        sort_order: idx + 1,
        created_at: now,
        updated_at: now,
        version: 1,
        deleted_at: null,
      })),
    ];
    await database.categories.bulkAdd(seededCategories);
  }

  const familyCount = await database.family_members.count();
  if (familyCount === 0) {
    const seededFamily = DEFAULT_FAMILY_MEMBERS.map((member) => ({
      id: generateUUID(),
      user_id: null,
      name: member.name,
      relationship: member.relationship,
      icon: member.icon,
      is_active: member.is_active,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));
    await database.family_members.bulkAdd(seededFamily);
  }

  const deviceMeta = await database.sync_meta.get('device_info');
  if (!deviceMeta) {
    await database.sync_meta.put({
      key: 'device_info',
      device_id: generateUUID(),
      last_sync_at: null,
      sync_status: 'offline_only',
      updated_at: now,
    });
  }

  return database;
}

import {
  excelSerialToLocalDateTime,
  readXlsxWorkbook,
  writeXlsxWorkbook,
} from '../../vendor/xlsx-lite.js';
import { generateUUID } from '../utils/uuid.js';
import { nowIsoUtc } from '../utils/date.js';
import { paiseToNumber, parseRupeesToPaise } from '../utils/money.js';
import { formatTagsForExport, normalizeAccountName, parseTagList } from '../utils/normalize.js';
import { buildLedgerPostings } from './ledgerRules.js';

export const STANDARD_SHEET_NAME = 'Sheet1';
export const STANDARD_HEADERS = Object.freeze([
  'Date',
  'Category',
  'Amount',
  'Note',
  'Type',
  'Payment mode',
  'To payment mode',
  'Tags',
]);

const BACKUP_TABLES = [
  'settings',
  'categories',
  'accounts',
  'family_members',
  'tags',
  'transactions',
  'ledger_postings',
  'transaction_tags',
  'transaction_splits',
  'favorite_templates',
  'attachments',
  'import_batches',
  'budgets',
  'bills',
  'recurring_rules',
  'investments',
  'investment_transactions',
  'loans',
  'net_worth_snapshots',
  'debts',
  'debt_events',
];

const CHUNK_SIZE = 500;

function yieldToUI() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

export function parseImportDateCell(raw) {
  if (raw === null || raw === undefined || raw === '') return null;
  if (typeof raw === 'object' && raw.__excelDate && raw.formatted) {
    return raw.formatted;
  }
  if (typeof raw === 'number' && Number.isFinite(raw) && raw > 20000 && raw < 90000) {
    return excelSerialToLocalDateTime(raw);
  }
  const s = String(raw).trim();
  if (!s) return null;

  let m = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  if (m) {
    const [, y, mo, d, hh = '00', mm = '00', ss = '00'] = m;
    return `${y}-${mo.padStart(2, '0')}-${d.padStart(2, '0')} ${hh.padStart(2, '0')}:${mm}:${ss}`;
  }

  m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  if (m) {
    const [, d, mo, y, hh = '00', mm = '00', ss = '00'] = m;
    return `${y}-${mo.padStart(2, '0')}-${d.padStart(2, '0')} ${hh.padStart(2, '0')}:${mm}:${ss}`;
  }

  return null;
}

function parseImportType(raw) {
  const s = String(raw || '').trim().toLowerCase();
  if (s === 'expense') return 'expense';
  if (s === 'income') return 'income';
  if (s === 'transfer') return 'transfer';
  return null;
}

export function parseCsvText(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    const next = text[i + 1];
    if (inQuotes) {
      if (ch === '"' && next === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      row.push(field);
      field = '';
    } else if (ch === '\r' && next === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
      i += 1;
    } else if (ch === '\n' || ch === '\r') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += ch;
    }
  }
  if (field !== '' || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.some((cell) => String(cell).trim() !== ''));
}

export class ImportExportService {
  constructor(db, repos, services) {
    this.db = db;
    this.repos = repos;
    this.services = services;
    this._importInFlight = false;
  }

  get isImporting() {
    return this._importInFlight;
  }

  async parseWorkbookBuffer(arrayBuffer) {
    return readXlsxWorkbook(arrayBuffer);
  }

  /**
   * Analyze a 2D array of sheet rows (row 0 = headers) against the current database.
   * Supports large files (15,000–1,00,000+ rows) with periodic UI yields and optional progress callback.
   */
  async buildImportPreview({
    sheetRows,
    filename = 'import.xlsx',
    sheetName = STANDARD_SHEET_NAME,
    onProgress = null,
  }) {
    if (!Array.isArray(sheetRows) || sheetRows.length === 0) {
      throw new Error('The selected worksheet is empty.');
    }

    const rawHeaders = sheetRows[0].map((h) => String(h ?? '').trim());
    const headerIndex = new Map();
    rawHeaders.forEach((h, idx) => headerIndex.set(h.toLowerCase(), idx));

    const missingHeaders = STANDARD_HEADERS.filter((h) => !headerIndex.has(h.toLowerCase()));
    if (missingHeaders.length > 0) {
      throw new Error(
        `Missing required columns: ${missingHeaders.join(', ')}. Expected exact 8 columns: ${STANDARD_HEADERS.join(' | ')}`
      );
    }

    const colIdx = {
      date: headerIndex.get('date'),
      category: headerIndex.get('category'),
      amount: headerIndex.get('amount'),
      note: headerIndex.get('note'),
      type: headerIndex.get('type'),
      paymentMode: headerIndex.get('payment mode'),
      toPaymentMode: headerIndex.get('to payment mode'),
      tags: headerIndex.get('tags'),
    };

    const [categories, accounts, existingTxs] = await Promise.all([
      this.repos.categories.list({ includeArchived: true }),
      this.repos.accounts.list({ includeArchived: true }),
      this.services.transactions.listTransactions(),
    ]);

    const catLookup = new Map();
    for (const c of categories) {
      catLookup.set(`${c.type}|${c.name.trim().toLowerCase()}`, c);
    }
    const accLookup = new Map();
    const accIdToNormKey = new Map();
    for (const a of accounts) {
      accLookup.set(a.normalized_key, a);
      accIdToNormKey.set(a.id, a.normalized_key);
    }

    const existingSigSet = new Set();
    for (const tx of existingTxs) {
      const src = accIdToNormKey.get(tx.account_id) || '';
      const dst = tx.to_account_id ? accIdToNormKey.get(tx.to_account_id) || '' : '';
      existingSigSet.add(
        `${String(tx.occurred_at_local || '').slice(0, 16)}|${tx.amount_paise}|${tx.type}|${src}|${dst}|${(tx.description || '').trim().toLowerCase()}`
      );
    }

    const unknownCategories = new Map();
    const unknownAccounts = new Map();
    const whitespaceWarnings = [];
    const parsedRows = [];
    const totalDataRows = sheetRows.length - 1;

    for (let r = 1; r < sheetRows.length; r += 1) {
      if (r % 2000 === 0) {
        if (onProgress) onProgress({ phase: 'Validating', done: r, total: totalDataRows });
        await yieldToUI();
      }

      const cells = sheetRows[r] || [];
      let allBlank = true;
      for (let i = 0; i < 8; i += 1) {
        if (cells[i] !== null && cells[i] !== undefined && String(cells[i]).trim() !== '') {
          allBlank = false;
          break;
        }
      }
      if (allBlank) continue;

      const errors = [];
      const warnings = [];

      const occurredAtLocal = parseImportDateCell(cells[colIdx.date]);
      if (!occurredAtLocal) errors.push(`Invalid Date: "${cells[colIdx.date] ?? ''}"`);

      const type = parseImportType(cells[colIdx.type]);
      if (!type) errors.push(`Unknown Type: "${cells[colIdx.type] ?? ''}"`);

      let amountPaise = null;
      try {
        amountPaise = parseRupeesToPaise(cells[colIdx.amount], { allowNegative: false });
        if (amountPaise <= 0) errors.push('Amount must be greater than 0');
      } catch (err) {
        errors.push(err.message);
      }

      const note = cells[colIdx.note] === null || cells[colIdx.note] === undefined ? '' : String(cells[colIdx.note]);

      const srcNorm = normalizeAccountName(cells[colIdx.paymentMode]);
      if (!srcNorm.name) {
        errors.push('Payment mode (source account) is required');
      } else {
        if (srcNorm.wasTrimmed) {
          const msg = `Row ${r + 1}: Trimmed whitespace in Payment mode ("${srcNorm.original}" → "${srcNorm.name}")`;
          warnings.push(msg);
          whitespaceWarnings.push(msg);
        }
        if (!accLookup.has(srcNorm.normalized_key) && !unknownAccounts.has(srcNorm.normalized_key)) {
          const suggestedType = /card|credit/i.test(srcNorm.name)
            ? 'credit_card'
            : /cash/i.test(srcNorm.name)
              ? 'cash'
              : /wallet|pay|sodexo|fasttag/i.test(srcNorm.name)
                ? 'wallet'
                : 'bank_account';
          unknownAccounts.set(srcNorm.normalized_key, { name: srcNorm.name, suggestedType });
        }
      }

      const dstNorm = normalizeAccountName(cells[colIdx.toPaymentMode]);
      if (dstNorm.name && dstNorm.wasTrimmed) {
        const msg = `Row ${r + 1}: Trimmed whitespace in To payment mode ("${dstNorm.original}" → "${dstNorm.name}")`;
        warnings.push(msg);
        whitespaceWarnings.push(msg);
      }
      if (type === 'transfer') {
        if (!dstNorm.name) {
          errors.push('To payment mode (destination account) is required for Transfer');
        } else if (dstNorm.normalized_key === srcNorm.normalized_key) {
          errors.push('Source and destination payment modes cannot be identical');
        } else if (!accLookup.has(dstNorm.normalized_key) && !unknownAccounts.has(dstNorm.normalized_key)) {
          const suggestedType = /card|credit/i.test(dstNorm.name)
            ? 'credit_card'
            : /cash/i.test(dstNorm.name)
              ? 'cash'
              : /wallet|pay|sodexo|fasttag/i.test(dstNorm.name)
                ? 'wallet'
                : 'bank_account';
          unknownAccounts.set(dstNorm.normalized_key, { name: dstNorm.name, suggestedType });
        }
      }

      const catName = String(cells[colIdx.category] ?? '').trim();
      let matchedCategory = null;
      if (type === 'expense' || type === 'income') {
        if (!catName) {
          errors.push('Category is required for Expense/Income');
        } else {
          const cKey = `${type}|${catName.toLowerCase()}`;
          matchedCategory = catLookup.get(cKey) || null;
          if (!matchedCategory && !unknownCategories.has(cKey)) {
            unknownCategories.set(cKey, { name: catName, type });
          }
        }
      }

      // Bifurcates every '#' into separate normalized tags
      const parsedTags = parseTagList(cells[colIdx.tags]);

      let isPossibleDuplicate = false;
      if (errors.length === 0 && occurredAtLocal && amountPaise && type) {
        const sig = `${occurredAtLocal.slice(0, 16)}|${amountPaise}|${type}|${srcNorm.normalized_key}|${type === 'transfer' ? dstNorm.normalized_key : ''}|${note.trim().toLowerCase()}`;
        if (existingSigSet.has(sig)) {
          isPossibleDuplicate = true;
          warnings.push('Possible duplicate of an existing transaction');
        }
      }

      parsedRows.push({
        rowNumber: r + 1,
        occurred_at_local: occurredAtLocal,
        date_key: occurredAtLocal ? occurredAtLocal.slice(0, 10) : null,
        categoryName: catName,
        categoryMatched: Boolean(matchedCategory),
        amount_paise: amountPaise,
        note,
        type,
        paymentMode: srcNorm.name,
        toPaymentMode: type === 'transfer' ? dstNorm.name : '',
        tags: parsedTags,
        isValid: errors.length === 0,
        isPossibleDuplicate,
        errors,
        warnings,
        // Default: include valid non-duplicates; user can toggle duplicates individually or in bulk
        include: errors.length === 0 && !isPossibleDuplicate,
      });
    }

    return {
      filename,
      sheetName,
      totalRows: parsedRows.length,
      validCount: parsedRows.filter((r) => r.isValid).length,
      invalidCount: parsedRows.filter((r) => !r.isValid).length,
      duplicateCount: parsedRows.filter((r) => r.isPossibleDuplicate).length,
      unknownCategories: Array.from(unknownCategories.values()),
      unknownAccounts: Array.from(unknownAccounts.values()),
      whitespaceWarnings,
      rows: parsedRows,
    };
  }

  /**
   * High-throughput chunked bulk import (500 rows per atomic IndexedDB transaction).
   * - Protected by `_importInFlight` lock so accidental double-taps cannot create duplicates.
   * - Stamps every transaction with `import_batch_id` so the entire batch can be rolled back in one tap.
   * - Reports live progress via `onProgress({ phase, done, total })`.
   */
  async commitImport(
    preview,
    { createUnknownCategories = false, createUnknownAccounts = false, onProgress = null } = {}
  ) {
    if (this._importInFlight) {
      throw new Error('An import is already in progress. Please wait for it to finish.');
    }
    this._importInFlight = true;

    try {
      const batchId = generateUUID();
      const now = nowIsoUtc();

      const [categories, accounts, tags] = await Promise.all([
        this.repos.categories.list({ includeArchived: true }),
        this.repos.accounts.list({ includeArchived: true }),
        this.repos.tags.list({ includeArchived: true }),
      ]);

      const catMap = new Map(categories.map((c) => [`${c.type}|${c.name.trim().toLowerCase()}`, c]));
      const accMap = new Map(accounts.map((a) => [a.normalized_key, a]));
      const tagMap = new Map(tags.map((t) => [t.normalized_key, t]));

      // 1. Create confirmed unknown categories once upfront
      if (createUnknownCategories && preview.unknownCategories.length > 0) {
        if (onProgress) onProgress({ phase: 'Creating categories', done: 0, total: preview.unknownCategories.length });
        for (const uc of preview.unknownCategories) {
          const key = `${uc.type}|${uc.name.trim().toLowerCase()}`;
          if (!catMap.has(key)) {
            const created = await this.repos.categories.createCategory({
              name: uc.name,
              type: uc.type,
              icon: uc.type === 'income' ? '💰' : '🏷️',
            });
            catMap.set(key, created);
          }
        }
      }

      // 2. Create confirmed unknown accounts once upfront
      if (createUnknownAccounts && preview.unknownAccounts.length > 0) {
        if (onProgress) onProgress({ phase: 'Creating accounts', done: 0, total: preview.unknownAccounts.length });
        for (const ua of preview.unknownAccounts) {
          const norm = normalizeAccountName(ua.name);
          if (!accMap.has(norm.normalized_key)) {
            const created = await this.repos.accounts.createAccount({
              name: norm.name,
              type: ua.suggestedType || 'bank_account',
              opening_balance_paise: 0,
            });
            accMap.set(norm.normalized_key, created);
          }
        }
      }

      // 3. Collect and pre-create all unique new tags once upfront (prevents race/duplicate tag errors!)
      const selectedRows = preview.rows.filter((r) => r.include && r.isValid);
      const newTagsToCreate = new Map();
      for (const row of selectedRows) {
        for (const t of row.tags) {
          if (!tagMap.has(t.normalized_key) && !newTagsToCreate.has(t.normalized_key)) {
            newTagsToCreate.set(t.normalized_key, t.name);
          }
        }
      }

      if (newTagsToCreate.size > 0) {
        if (onProgress) onProgress({ phase: 'Creating tags', done: 0, total: newTagsToCreate.size });
        for (const [, tagName] of newTagsToCreate.entries()) {
          const created = await this.repos.tags.createTag({ name: tagName });
          tagMap.set(created.normalized_key, created);
        }
      }

      // 4. Chunked bulkAdd of transactions + ledger_postings + transaction_tags
      let importedCount = 0;
      let skippedCount = preview.rows.length - selectedRows.length;
      const commitErrors = [];

      const txBatch = [];
      const postingBatch = [];
      const tagLinkBatch = [];

      const flushChunk = async () => {
        if (txBatch.length === 0) return;
        const stores = ['transactions', 'ledger_postings', 'transaction_tags'];
        await this.db.transaction('rw', stores, async () => {
          await this.db.table('transactions').bulkAdd(txBatch);
          if (postingBatch.length > 0) await this.db.table('ledger_postings').bulkAdd(postingBatch);
          if (tagLinkBatch.length > 0) await this.db.table('transaction_tags').bulkAdd(tagLinkBatch);
        });
        importedCount += txBatch.length;
        txBatch.length = 0;
        postingBatch.length = 0;
        tagLinkBatch.length = 0;
      };

      for (let i = 0; i < selectedRows.length; i += 1) {
        const row = selectedRows[i];
        const srcAcc = accMap.get(normalizeAccountName(row.paymentMode).normalized_key);
        if (!srcAcc) {
          skippedCount += 1;
          commitErrors.push(`Row ${row.rowNumber}: Account "${row.paymentMode}" not found`);
          continue;
        }

        let dstAcc = null;
        if (row.type === 'transfer') {
          dstAcc = accMap.get(normalizeAccountName(row.toPaymentMode).normalized_key);
          if (!dstAcc) {
            skippedCount += 1;
            commitErrors.push(`Row ${row.rowNumber}: Destination account "${row.toPaymentMode}" not found`);
            continue;
          }
        }

        let cat = null;
        if (row.type === 'expense' || row.type === 'income') {
          cat = catMap.get(`${row.type}|${row.categoryName.trim().toLowerCase()}`);
          if (!cat) {
            skippedCount += 1;
            commitErrors.push(`Row ${row.rowNumber}: Category "${row.categoryName}" not found`);
            continue;
          }
        }

        const txId = generateUUID();
        txBatch.push({
          id: txId,
          user_id: null,
          type: row.type,
          amount_paise: row.amount_paise,
          date_key: row.date_key,
          occurred_at_local: row.occurred_at_local,
          category_id: cat ? cat.id : null,
          account_id: srcAcc.id,
          to_account_id: dstAcc ? dstAcc.id : null,
          description: String(row.note || '').trim(),
          notes: '',
          family_member_id: null,
          reference_no: '',
          is_split: false,
          recurring_rule_id: null,
          bill_id: null,
          import_batch_id: batchId,
          created_at: now,
          updated_at: now,
          version: 1,
          deleted_at: null,
        });

        const postings = buildLedgerPostings({
          transactionId: txId,
          type: row.type,
          amountPaise: row.amount_paise,
          sourceAccount: srcAcc,
          destinationAccount: dstAcc,
        });
        for (const p of postings) {
          postingBatch.push({
            ...p,
            id: generateUUID(),
            user_id: null,
            occurred_at_local: row.occurred_at_local,
            created_at: now,
            updated_at: now,
            version: 1,
            deleted_at: null,
          });
        }

        const seenTagIds = new Set();
        for (const t of row.tags) {
          const tagRec = tagMap.get(t.normalized_key);
          if (tagRec && !seenTagIds.has(tagRec.id)) {
            seenTagIds.add(tagRec.id);
            tagLinkBatch.push({
              id: generateUUID(),
              user_id: null,
              transaction_id: txId,
              tag_id: tagRec.id,
              created_at: now,
              updated_at: now,
              version: 1,
              deleted_at: null,
            });
          }
        }

        if (txBatch.length >= CHUNK_SIZE) {
          await flushChunk();
          if (onProgress) {
            onProgress({ phase: 'Importing', done: importedCount, total: selectedRows.length });
          }
          await yieldToUI();
        }
      }

      await flushChunk();
      if (onProgress) {
        onProgress({ phase: 'Finalising', done: importedCount, total: selectedRows.length });
      }

      const batchRecord = {
        id: batchId,
        user_id: null,
        filename: preview.filename,
        sheet_name: preview.sheetName,
        imported_at: now,
        total_rows: preview.totalRows,
        imported_rows: importedCount,
        skipped_rows: skippedCount,
        error_count: preview.invalidCount + commitErrors.length,
        errors: commitErrors.slice(0, 50),
        rolled_back_at: null,
        created_at: now,
        updated_at: now,
        version: 1,
        deleted_at: null,
      };

      try {
        await this.db.table('import_batches').add(batchRecord);
      } catch {
        // Ignore on minimal test doubles
      }

      return { importedCount, skippedCount, commitErrors, batchRecord };
    } finally {
      this._importInFlight = false;
    }
  }

  /**
   * Roll back an entire import batch in chunked IndexedDB transactions (soft-deletes all
   * transactions, ledger postings, and tag links created by that batch).
   */
  async rollbackImportBatch(batchId, { onProgress = null } = {}) {
    const now = nowIsoUtc();
    const allTxs = await this.db.table('transactions').toArray();
    const targetTxs = allTxs.filter((tx) => !tx.deleted_at && tx.import_batch_id === batchId);
    const targetTxIdSet = new Set(targetTxs.map((tx) => tx.id));

    if (targetTxIdSet.size === 0) {
      const batch = await this.db.table('import_batches').get(batchId);
      if (batch) {
        await this.db.table('import_batches').put({ ...batch, rolled_back_at: now, updated_at: now });
      }
      return { removedCount: 0 };
    }

    const [allPostings, allTags] = await Promise.all([
      this.db.table('ledger_postings').toArray(),
      this.db.table('transaction_tags').toArray(),
    ]);

    const targetPostings = allPostings.filter((p) => !p.deleted_at && targetTxIdSet.has(p.transaction_id));
    const targetTagLinks = allTags.filter((t) => !t.deleted_at && targetTxIdSet.has(t.transaction_id));

    for (let i = 0; i < targetTxs.length; i += CHUNK_SIZE) {
      const slice = targetTxs.slice(i, i + CHUNK_SIZE).map((tx) => ({
        ...tx,
        deleted_at: now,
        updated_at: now,
        version: (tx.version || 1) + 1,
      }));
      await this.db.table('transactions').bulkPut(slice);
      if (onProgress) onProgress({ phase: 'Rolling back transactions', done: Math.min(i + CHUNK_SIZE, targetTxs.length), total: targetTxs.length });
      await yieldToUI();
    }

    for (let i = 0; i < targetPostings.length; i += CHUNK_SIZE) {
      const slice = targetPostings.slice(i, i + CHUNK_SIZE).map((p) => ({
        ...p,
        deleted_at: now,
        updated_at: now,
        version: (p.version || 1) + 1,
      }));
      await this.db.table('ledger_postings').bulkPut(slice);
      await yieldToUI();
    }

    for (let i = 0; i < targetTagLinks.length; i += CHUNK_SIZE) {
      const slice = targetTagLinks.slice(i, i + CHUNK_SIZE).map((t) => ({
        ...t,
        deleted_at: now,
        updated_at: now,
        version: (t.version || 1) + 1,
      }));
      await this.db.table('transaction_tags').bulkPut(slice);
      await yieldToUI();
    }

    const batch = await this.db.table('import_batches').get(batchId);
    if (batch) {
      await this.db.table('import_batches').put({
        ...batch,
        rolled_back_at: now,
        updated_at: now,
        version: (batch.version || 1) + 1,
      });
    }

    return { removedCount: targetTxs.length };
  }

  /**
   * Scan active transactions for exact duplicates (identical timestamp to minute, amount, type,
   * source/dest account, category, and description) — keeps the earliest entry and returns IDs of extras.
   */
  async findExactDuplicateTransactionIds() {
    const txs = await this.services.transactions.listTransactions({ sort: 'asc' });
    const seen = new Set();
    const duplicateIds = [];

    for (const tx of txs) {
      const sig = `${String(tx.occurred_at_local || '').slice(0, 16)}|${tx.amount_paise}|${tx.type}|${tx.account_id}|${tx.to_account_id || ''}|${tx.category_id || ''}|${(tx.description || '').trim().toLowerCase()}`;
      if (seen.has(sig)) {
        duplicateIds.push(tx.id);
      } else {
        seen.add(sig);
      }
    }
    return duplicateIds;
  }

  /**
   * Remove exact duplicate transactions in chunked batches (soft-delete + reverse postings).
   */
  async removeExactDuplicateTransactions({ onProgress = null } = {}) {
    const dupIds = await this.findExactDuplicateTransactionIds();
    if (dupIds.length === 0) return { removedCount: 0 };

    const dupSet = new Set(dupIds);
    const now = nowIsoUtc();
    const [allTxs, allPostings, allTags] = await Promise.all([
      this.db.table('transactions').toArray(),
      this.db.table('ledger_postings').toArray(),
      this.db.table('transaction_tags').toArray(),
    ]);

    const targetTxs = allTxs.filter((t) => !t.deleted_at && dupSet.has(t.id));
    const targetPostings = allPostings.filter((p) => !p.deleted_at && dupSet.has(p.transaction_id));
    const targetTagLinks = allTags.filter((t) => !t.deleted_at && dupSet.has(t.transaction_id));

    for (let i = 0; i < targetTxs.length; i += CHUNK_SIZE) {
      const slice = targetTxs.slice(i, i + CHUNK_SIZE).map((t) => ({
        ...t,
        deleted_at: now,
        updated_at: now,
        version: (t.version || 1) + 1,
      }));
      await this.db.table('transactions').bulkPut(slice);
      if (onProgress) onProgress({ phase: 'Removing duplicates', done: Math.min(i + CHUNK_SIZE, targetTxs.length), total: targetTxs.length });
      await yieldToUI();
    }

    for (let i = 0; i < targetPostings.length; i += CHUNK_SIZE) {
      const slice = targetPostings.slice(i, i + CHUNK_SIZE).map((p) => ({
        ...p,
        deleted_at: now,
        updated_at: now,
        version: (p.version || 1) + 1,
      }));
      await this.db.table('ledger_postings').bulkPut(slice);
      await yieldToUI();
    }

    for (let i = 0; i < targetTagLinks.length; i += CHUNK_SIZE) {
      const slice = targetTagLinks.slice(i, i + CHUNK_SIZE).map((t) => ({
        ...t,
        deleted_at: now,
        updated_at: now,
        version: (t.version || 1) + 1,
      }));
      await this.db.table('transaction_tags').bulkPut(slice);
      await yieldToUI();
    }

    return { removedCount: targetTxs.length };
  }

  /**
   * Clear all transactions, postings, tag links, and import history (keeps accounts, categories, and settings)
   * or wipe everything for a clean re-import.
   */
  async clearTransactionsOnly() {
    for (const tblName of ['transactions', 'ledger_postings', 'transaction_tags', 'transaction_splits', 'import_batches']) {
      try {
        await this.db.table(tblName).clear();
      } catch {
        // Ignore if absent
      }
    }
  }

  async exportStandardXlsx(filters = {}) {
    const [txs, categories, accounts, tags] = await Promise.all([
      this.services.transactions.listTransactions(filters),
      this.repos.categories.list({ includeArchived: true }),
      this.repos.accounts.list({ includeArchived: true }),
      this.repos.tags.list({ includeArchived: true }),
    ]);

    const catMap = new Map(categories.map((c) => [c.id, c]));
    const accMap = new Map(accounts.map((a) => [a.id, a]));
    const tagMap = new Map(tags.map((t) => [t.id, t]));
    const typeLabel = (t) => (t === 'income' ? 'Income' : t === 'transfer' ? 'Transfer' : 'Expense');

    const rows = txs.map((tx) => {
      const catName = tx.type === 'debt' ? (tx.debt_event_type || 'Debt') : (tx.category_id ? catMap.get(tx.category_id)?.name || '' : '');
      const srcName = accMap.get(tx.account_id)?.name || '';
      const dstName = tx.to_account_id ? accMap.get(tx.to_account_id)?.name || '' : '';
      const tagObjs = (tx.tag_ids || []).map((id) => tagMap.get(id)).filter(Boolean);
      const tagsCell = formatTagsForExport(tagObjs);

      return [
        { type: 'date', value: tx.occurred_at_local },
        catName,
        { type: 'number', value: paiseToNumber(tx.amount_paise) },
        tx.description || '',
        typeLabel(tx.type),
        srcName,
        tx.type === 'transfer' ? dstName : '',
        tagsCell,
      ];
    });

    return {
      bytes: writeXlsxWorkbook({
        sheetName: STANDARD_SHEET_NAME,
        headers: [...STANDARD_HEADERS],
        rows,
      }),
      rowCount: rows.length,
    };
  }

  async exportStandardCsv(filters = {}) {
    const [txs, categories, accounts, tags] = await Promise.all([
      this.services.transactions.listTransactions(filters),
      this.repos.categories.list({ includeArchived: true }),
      this.repos.accounts.list({ includeArchived: true }),
      this.repos.tags.list({ includeArchived: true }),
    ]);

    const catMap = new Map(categories.map((c) => [c.id, c]));
    const accMap = new Map(accounts.map((a) => [a.id, a]));
    const tagMap = new Map(tags.map((t) => [t.id, t]));
    const csvCell = (val) => {
      const s = val === null || val === undefined ? '' : String(val);
      return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };

    const lines = [STANDARD_HEADERS.map(csvCell).join(',')];
    for (const tx of txs) {
      const catName = tx.type === 'debt' ? (tx.debt_event_type || 'Debt') : (tx.category_id ? catMap.get(tx.category_id)?.name || '' : '');
      const srcName = accMap.get(tx.account_id)?.name || '';
      const dstName = tx.to_account_id ? accMap.get(tx.to_account_id)?.name || '' : '';
      const tagObjs = (tx.tag_ids || []).map((id) => tagMap.get(id)).filter(Boolean);
      const typeLabel = tx.type === 'income' ? 'Income' : tx.type === 'transfer' ? 'Transfer' : tx.type === 'debt' ? 'Debt' : 'Expense';

      lines.push(
        [
          (tx.occurred_at_local || '').slice(0, 16),
          catName,
          paiseToNumber(tx.amount_paise),
          tx.description || '',
          typeLabel,
          srcName,
          tx.type === 'transfer' ? dstName : '',
          formatTagsForExport(tagObjs),
        ]
          .map(csvCell)
          .join(',')
      );
    }

    return { csv: lines.join('\r\n'), rowCount: txs.length };
  }

  async exportCompleteJsonBackup() {
    const tables = {};
    for (const name of BACKUP_TABLES) {
      try {
        tables[name] = await this.db.table(name).toArray();
      } catch {
        tables[name] = [];
      }
    }

    return {
      format: 'personal-finance-manager-backup',
      schema_version: 7,
      exported_at: nowIsoUtc(),
      tables,
    };
  }

  async restoreCompleteJsonBackup(backupObj) {
    if (!backupObj || backupObj.format !== 'personal-finance-manager-backup' || !backupObj.tables) {
      throw new Error('Invalid backup file format.');
    }

    for (const name of BACKUP_TABLES) {
      const rows = backupObj.tables[name];
      if (!Array.isArray(rows)) continue;
      const tbl = this.db.table(name);
      if (tbl.clear) await tbl.clear();
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        await tbl.bulkPut(rows.slice(i, i + CHUNK_SIZE));
        await yieldToUI();
      }
    }

    return {
      restoredAt: nowIsoUtc(),
      counts: Object.fromEntries(
        BACKUP_TABLES.map((name) => [name, Array.isArray(backupObj.tables[name]) ? backupObj.tables[name].length : 0])
      ),
    };
  }

  async listImportBatches() {
    try {
      const all = await this.db.table('import_batches').toArray();
      return all
        .filter((b) => !b.deleted_at)
        .sort((a, b) => String(b.imported_at || '').localeCompare(String(a.imported_at || '')));
    } catch {
      return [];
    }
  }
}

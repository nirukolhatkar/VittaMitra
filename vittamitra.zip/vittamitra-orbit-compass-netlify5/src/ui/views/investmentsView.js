import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString, parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';
import { INVESTMENT_ASSET_TYPES } from '../../db/repositories/investmentRepository.js';
import { LOAN_TYPES, computeStandardEmiPaise } from '../../db/repositories/loanRepository.js';
import { simulateInvestmentWhatIf, simulateLoanWhatIf } from '../../services/wealthService.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { bindChartTooltips } from '../components/charts.js';

const invViewState = {
  tab: 'investments', // 'investments' | 'whatif' | 'loans'
  whatIfTarget: 'portfolio', // 'portfolio' | investmentId | 'custom'
  whatIfYears: 10,
  whatIfReturnPct: 12,
  whatIfExtraSipRupees: 0,
  whatIfStepUpPct: 5,
  whatIfLumpSumRupees: 0,
  whatIfCustomStartRupees: 100000,
  whatIfCustomSipRupees: 10000,
  whatIfCustomGoalRupees: 2500000,
};

function compactInrShort(paise) {
  const r = Math.abs(paise) / 100;
  const sign = paise < 0 ? '-' : '';
  if (r >= 10000000) return `${sign}₹${(r / 10000000).toFixed(2)}Cr`;
  if (r >= 100000) return `${sign}₹${(r / 100000).toFixed(2)}L`;
  if (r >= 1000) return `${sign}₹${(r / 1000).toFixed(1)}k`;
  return `${sign}₹${Math.round(r)}`;
}

function renderProjectionSvg(points, { goalTargetPaise = 0, showBalances = true, primaryColor = '#22c55e', secondaryColor = '#38bdf8', secondaryLabel = 'Invested', primaryLabel = 'Projected Value' } = {}) {
  if (!points || points.length < 2) return '';
  const w = 340;
  const h = 164;
  const padL = 48;
  const padR = 14;
  const padT = 16;
  const padB = 26;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const maxVal = Math.max(
    1,
    goalTargetPaise || 0,
    ...points.map((p) => Math.max(p.primary || 0, p.secondary || 0))
  );

  const xAt = (i) => padL + (i / (points.length - 1)) * plotW;
  const yAt = (v) => padT + plotH - (Math.max(0, v) / maxVal) * plotH;

  const primaryPath = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${xAt(i).toFixed(1)},${yAt(p.primary).toFixed(1)}`).join(' ');
  const secondaryPath = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${xAt(i).toFixed(1)},${yAt(p.secondary).toFixed(1)}`).join(' ');

  const yTicks = [0, 0.5, 1].map((t) => {
    const val = maxVal * t;
    const y = yAt(val);
    return `
      <line x1="${padL}" y1="${y.toFixed(1)}" x2="${w - padR}" y2="${y.toFixed(1)}" stroke="var(--border-subtle)" stroke-dasharray="2 3"/>
      <text x="${padL - 5}" y="${(y + 3).toFixed(1)}" text-anchor="end" fill="var(--text-muted)" font-size="9">${showBalances ? escapeHtml(compactInrShort(val)) : '***'}</text>
    `;
  });

  const goalLine =
    goalTargetPaise > 0
      ? `<line x1="${padL}" y1="${yAt(goalTargetPaise).toFixed(1)}" x2="${w - padR}" y2="${yAt(goalTargetPaise).toFixed(1)}" stroke="#f59e0b" stroke-width="1.4" stroke-dasharray="4 3"/>
         <text x="${w - padR}" y="${(yAt(goalTargetPaise) - 4).toFixed(1)}" text-anchor="end" fill="#f59e0b" font-size="9" font-weight="600">Goal ${showBalances ? escapeHtml(compactInrShort(goalTargetPaise)) : '***'}</text>`
      : '';

  const step = Math.max(1, Math.ceil(points.length / 6));
  const xLabels = points
    .filter((_, i) => i === 0 || i === points.length - 1 || i % step === 0)
    .map((p) => {
      const idx = points.indexOf(p);
      return `<text x="${xAt(idx).toFixed(1)}" y="${h - 6}" text-anchor="middle" fill="var(--text-muted)" font-size="9">${escapeHtml(p.label)}</text>`;
    });

  const dots = points.map((p, i) => {
    const valText = showBalances ? formatINR(p.primary) : '*****';
    const subText = showBalances ? `${secondaryLabel}: ${formatINR(p.secondary)}` : '';
    return `<circle cx="${xAt(i).toFixed(1)}" cy="${yAt(p.primary).toFixed(1)}" r="4" fill="${primaryColor}" stroke="var(--bg-surface)" stroke-width="1.2" style="cursor:pointer;"
      data-tip-title="${escapeHtml(p.label)} (${escapeHtml(primaryLabel)})" data-tip-value="${escapeHtml(valText)}" data-tip-sub="${escapeHtml(subText)}">
      <title>${escapeHtml(p.label)}: ${escapeHtml(valText)}</title>
    </circle>`;
  });

  return `
    <div class="chart-box">
      <div class="chart-tooltip hidden"></div>
      <svg viewBox="0 0 ${w} ${h}" width="100%" style="max-height:175px; display:block;">
        ${yTicks.join('')}
        ${goalLine}
        <path d="${secondaryPath}" fill="none" stroke="${secondaryColor}" stroke-width="1.8" stroke-dasharray="4 3"/>
        <path d="${primaryPath}" fill="none" stroke="${primaryColor}" stroke-width="2.4" stroke-linejoin="round"/>
        ${dots.join('')}
        ${xLabels.join('')}
      </svg>
      <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap; font-size:0.74rem; margin-top:4px;">
        <span style="color:${primaryColor};">● ${escapeHtml(primaryLabel)}</span>
        <span style="color:${secondaryColor};">┅ ${escapeHtml(secondaryLabel)}</span>
        ${goalTargetPaise > 0 ? `<span style="color:#f59e0b;">┅ Goal Target</span>` : ''}
      </div>
    </div>
  `;
}

export async function renderInvestmentsView(container, ctx) {
  const { repos, services } = ctx;
  const [settings, portfolio, loans] = await Promise.all([
    repos.settings.getSettings(),
    services.wealth.getPortfolioSummary(),
    repos.loans.listAll(),
  ]);

  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');

  const tabBar = `
    <div class="segmented" style="width:100%; justify-content:space-between;">
      <button type="button" style="flex:1;" data-inv-tab="investments" class="${invViewState.tab === 'investments' ? 'active' : ''}">Investments</button>
      <button type="button" style="flex:1;" data-inv-tab="whatif" class="${invViewState.tab === 'whatif' ? 'active' : ''}">What-If Lab</button>
      <button type="button" style="flex:1;" data-inv-tab="loans" class="${invViewState.tab === 'loans' ? 'active' : ''}">Loans</button>
    </div>
  `;

  // ---------- Modals ----------
  const openInvestmentModal = (existing = null) => {
    const isEdit = Boolean(existing);
    openModal({
      title: isEdit ? 'Edit Investment & Goal' : 'Add Investment & Goal Plan',
      bodyHtml: `
        <form id="inv-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Investment Name</label>
              <input name="name" class="form-control" required maxlength="60"
                value="${escapeHtml(existing?.name || '')}" placeholder="e.g. Nifty 50 Index SIP">
            </div>
            <div class="form-group">
              <label class="form-label">Asset Type</label>
              <select name="asset_type" class="form-control">
                ${INVESTMENT_ASSET_TYPES.map((t) => `<option value="${t.key}" ${(existing?.asset_type || 'mutual_fund') === t.key ? 'selected' : ''}>${t.icon} ${t.label}</option>`).join('')}
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Invested So Far (₹)</label>
              <input name="invested_rupees" class="form-control" inputmode="decimal" required
                value="${existing ? paiseToDecimalString(existing.invested_paise) : ''}" placeholder="100000">
            </div>
            <div class="form-group">
              <label class="form-label">Current Value (₹)</label>
              <input name="current_value_rupees" class="form-control" inputmode="decimal" required
                value="${existing ? paiseToDecimalString(existing.current_value_paise) : ''}" placeholder="115000">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Monthly SIP (₹)</label>
              <input name="monthly_sip_rupees" class="form-control" inputmode="decimal"
                value="${existing ? paiseToDecimalString(existing.monthly_sip_paise) : '0'}" placeholder="10000">
            </div>
            <div class="form-group">
              <label class="form-label">Expected Return (% p.a.)</label>
              <input name="expected_annual_return_pct" type="number" step="0.1" class="form-control" required
                value="${existing?.expected_annual_return_pct ?? 12}">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Start Date (Original Plan Start)</label>
            <input name="start_date" type="date" class="form-control" required
              value="${escapeHtml(existing?.start_date || toLocalDateString())}">
          </div>

          <div class="card" style="background:var(--bg-surface-elevated); padding:10px; margin-bottom:12px;">
            <div class="item-title" style="font-size:0.84rem; margin-bottom:8px;">🎯 Original Goal Plan (Optional)</div>
            <div class="form-group" style="margin-bottom:8px;">
              <label class="form-label">Goal Name</label>
              <input name="goal_name" class="form-control" maxlength="60"
                value="${escapeHtml(existing?.goal_name || '')}" placeholder="e.g. Daughter's Higher Education, Retirement">
            </div>
            <div class="form-row">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Target Amount (₹)</label>
                <input name="goal_target_rupees" class="form-control" inputmode="decimal"
                  value="${existing?.goal_target_paise ? paiseToDecimalString(existing.goal_target_paise) : ''}" placeholder="2500000">
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Target Date</label>
                <input name="goal_target_date" type="date" class="form-control"
                  value="${escapeHtml(existing?.goal_target_date || '')}">
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">${isEdit ? 'Save Changes' : 'Save Investment'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#inv-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            if (isEdit) {
              await repos.investments.update(existing.id, {
                name: String(fd.get('name')).trim(),
                asset_type: fd.get('asset_type'),
                invested_paise: parseRupeesToPaise(fd.get('invested_rupees') || '0', { allowZero: true, allowNegative: false }),
                current_value_paise: parseRupeesToPaise(fd.get('current_value_rupees') || '0', { allowZero: true, allowNegative: false }),
                monthly_sip_paise: parseRupeesToPaise(fd.get('monthly_sip_rupees') || '0', { allowZero: true, allowNegative: false }),
                expected_annual_return_pct: Number(fd.get('expected_annual_return_pct')) || 0,
                start_date: fd.get('start_date'),
                goal_name: String(fd.get('goal_name') || '').trim(),
                goal_target_paise: fd.get('goal_target_rupees')
                  ? parseRupeesToPaise(fd.get('goal_target_rupees'), { allowZero: true, allowNegative: false })
                  : 0,
                goal_target_date: fd.get('goal_target_date') || '',
              });
              showToast('Investment updated');
            } else {
              await repos.investments.createInvestment({
                name: fd.get('name'),
                asset_type: fd.get('asset_type'),
                invested_rupees: fd.get('invested_rupees'),
                current_value_rupees: fd.get('current_value_rupees'),
                monthly_sip_rupees: fd.get('monthly_sip_rupees'),
                expected_annual_return_pct: fd.get('expected_annual_return_pct'),
                start_date: fd.get('start_date'),
                goal_name: fd.get('goal_name'),
                goal_target_rupees: fd.get('goal_target_rupees') || '0',
                goal_target_date: fd.get('goal_target_date'),
              });
              showToast('Investment added');
            }
            close();
            renderInvestmentsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openCashflowModal = (inv) => {
    openModal({
      title: `Update: ${inv.name}`,
      bodyHtml: `
        <form id="inv-cf-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Entry Type</label>
              <select name="tx_type" class="form-control">
                <option value="sip">SIP / Add Investment</option>
                <option value="valuation">Update Current Value Only</option>
                <option value="sell">Redeem / Withdraw</option>
                <option value="dividend">Dividend Received</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Date</label>
              <input name="date_key" type="date" class="form-control" required value="${toLocalDateString()}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Amount (₹)</label>
            <input name="amount_rupees" class="form-control" inputmode="decimal" required
              value="${inv.monthly_sip_paise ? paiseToDecimalString(inv.monthly_sip_paise) : ''}" placeholder="10000">
          </div>
          <div class="form-group">
            <label class="form-label">Latest Total Current Value (₹, optional)</label>
            <input name="new_current_value_rupees" class="form-control" inputmode="decimal"
              placeholder="Leave blank to auto-adjust from ${paiseToDecimalString(inv.current_value_paise)}">
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Record Entry</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#inv-cf-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await repos.investments.addCashflow(inv.id, {
              tx_type: fd.get('tx_type'),
              date_key: fd.get('date_key'),
              amount_rupees: fd.get('amount_rupees'),
              new_current_value_rupees: fd.get('new_current_value_rupees') || null,
            });
            showToast('Investment updated & XIRR recalculated');
            close();
            renderInvestmentsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openLoanModal = (existing = null) => {
    const isEdit = Boolean(existing);
    openModal({
      title: isEdit ? 'Edit Loan' : 'Add Loan',
      bodyHtml: `
        <form id="loan-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Loan Name</label>
              <input name="name" class="form-control" required maxlength="60"
                value="${escapeHtml(existing?.name || '')}" placeholder="e.g. SBI Home Loan">
            </div>
            <div class="form-group">
              <label class="form-label">Loan Type</label>
              <select name="loan_type" class="form-control">
                ${LOAN_TYPES.map((t) => `<option value="${t.key}" ${(existing?.loan_type || 'home_loan') === t.key ? 'selected' : ''}>${t.icon} ${t.label}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Original Principal (₹)</label>
              <input name="principal_rupees" class="form-control" inputmode="decimal" required
                value="${existing ? paiseToDecimalString(existing.principal_paise) : ''}" placeholder="4000000">
            </div>
            <div class="form-group">
              <label class="form-label">Current Outstanding (₹)</label>
              <input name="outstanding_rupees" class="form-control" inputmode="decimal"
                value="${existing ? paiseToDecimalString(existing.outstanding_paise) : ''}" placeholder="Same as principal">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Interest Rate (% p.a.)</label>
              <input name="interest_rate_pct" type="number" step="0.05" class="form-control" required
                value="${existing?.interest_rate_pct ?? 8.5}">
            </div>
            <div class="form-group">
              <label class="form-label">Remaining Months</label>
              <input name="remaining_months" type="number" min="1" max="480" class="form-control" required
                value="${existing?.remaining_months ?? 180}">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Monthly EMI (₹, blank = auto)</label>
              <input name="emi_rupees" class="form-control" inputmode="decimal"
                value="${existing ? paiseToDecimalString(existing.emi_paise) : ''}" placeholder="Auto-calculated">
            </div>
            <div class="form-group">
              <label class="form-label">Start Date</label>
              <input name="start_date" type="date" class="form-control" value="${escapeHtml(existing?.start_date || toLocalDateString())}">
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">${isEdit ? 'Save Loan' : 'Add Loan'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#loan-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            if (isEdit) {
              const outPaise = parseRupeesToPaise(fd.get('outstanding_rupees') || fd.get('principal_rupees'), { allowZero: true, allowNegative: false });
              const rate = Number(fd.get('interest_rate_pct')) || 0;
              const rem = Math.max(1, Number(fd.get('remaining_months')) || 12);
              const emiPaise = fd.get('emi_rupees')
                ? parseRupeesToPaise(fd.get('emi_rupees'), { allowZero: false, allowNegative: false })
                : computeStandardEmiPaise(outPaise, rate, rem);
              await repos.loans.update(existing.id, {
                name: String(fd.get('name')).trim(),
                loan_type: fd.get('loan_type'),
                principal_paise: parseRupeesToPaise(fd.get('principal_rupees'), { allowZero: false, allowNegative: false }),
                outstanding_paise: outPaise,
                interest_rate_pct: rate,
                remaining_months: rem,
                emi_paise: emiPaise,
                start_date: fd.get('start_date'),
                is_active: outPaise > 0,
              });
              showToast('Loan updated');
            } else {
              await repos.loans.createLoan({
                name: fd.get('name'),
                loan_type: fd.get('loan_type'),
                principal_rupees: fd.get('principal_rupees'),
                outstanding_rupees: fd.get('outstanding_rupees'),
                interest_rate_pct: fd.get('interest_rate_pct'),
                tenure_months: fd.get('remaining_months'),
                remaining_months: fd.get('remaining_months'),
                emi_rupees: fd.get('emi_rupees'),
                start_date: fd.get('start_date'),
              });
              showToast('Loan added');
            }
            close();
            renderInvestmentsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openLoanWhatIfModal = (loan) => {
    const simState = { extraEmi: 0, prepay: 0, rateDelta: 0 };
    openModal({
      title: `🔮 Loan What-If: ${loan.name}`,
      bodyHtml: `
        <div class="stack" style="gap:10px;">
          <div class="form-row">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Extra Monthly EMI (₹)</label>
              <input id="lw-extra-emi" type="number" step="500" min="0" class="form-control" value="0">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">One-Time Prepay (₹)</label>
              <input id="lw-prepay" type="number" step="10000" min="0" class="form-control" value="0">
            </div>
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Interest Rate Change (<span id="lw-rate-label">${loan.interest_rate_pct}%</span>)</label>
            <input id="lw-rate" type="range" min="-2" max="2" step="0.25" value="0" style="width:100%;">
          </div>
          <div id="lw-output"></div>
        </div>
      `,
      onMount: (panel) => {
        const outEl = panel.querySelector('#lw-output');
        const rateLbl = panel.querySelector('#lw-rate-label');

        const updateLoanSim = () => {
          const res = simulateLoanWhatIf({
            outstandingPaise: loan.outstanding_paise,
            interestRatePct: loan.interest_rate_pct,
            emiPaise: loan.emi_paise,
            remainingMonths: loan.remaining_months,
            extraMonthlyEmiPaise: Math.round((Number(simState.extraEmi) || 0) * 100),
            prepaymentPaise: Math.round((Number(simState.prepay) || 0) * 100),
            rateDeltaPct: Number(simState.rateDelta) || 0,
          });

          rateLbl.textContent = `${res.adjustedRatePct}% (${simState.rateDelta >= 0 ? '+' : ''}${simState.rateDelta}%)`;

          const maxLen = Math.max(res.baseline.yearlyBalances.length, res.whatIf.yearlyBalances.length);
          const pts = [];
          for (let i = 0; i < maxLen; i += 1) {
            const bPt = res.baseline.yearlyBalances[Math.min(i, res.baseline.yearlyBalances.length - 1)];
            const wPt = res.whatIf.yearlyBalances[Math.min(i, res.whatIf.yearlyBalances.length - 1)];
            pts.push({
              label: i === 0 ? 'Now' : `Yr ${i}`,
              primary: wPt.balancePaise,
              secondary: bPt.balancePaise,
            });
          }

          const yrsSaved = (res.monthsSaved / 12).toFixed(1);
          outEl.innerHTML = `
            <div class="grid-2" style="gap:8px; margin-bottom:10px;">
              <div class="metric-card" style="padding:10px;">
                <div class="metric-label">Interest Saved</div>
                <div class="item-title text-success">${fmt(res.interestSavedPaise)}</div>
                <div class="item-meta">Base interest: ${fmt(res.baseline.totalInterestPaise)}</div>
              </div>
              <div class="metric-card" style="padding:10px;">
                <div class="metric-label">Time Saved</div>
                <div class="item-title text-success">${res.monthsSaved} mos (${yrsSaved} yrs)</div>
                <div class="item-meta">Payoff in ${res.whatIf.months} mos</div>
              </div>
            </div>
            ${renderProjectionSvg(pts, {
              showBalances: show,
              primaryColor: '#22c55e',
              secondaryColor: '#ef4444',
              primaryLabel: 'What-If Balance',
              secondaryLabel: 'Original Balance',
            })}
          `;
          bindChartTooltips(outEl);
        };

        panel.querySelector('#lw-extra-emi').addEventListener('input', (e) => {
          simState.extraEmi = Number(e.target.value) || 0;
          updateLoanSim();
        });
        panel.querySelector('#lw-prepay').addEventListener('input', (e) => {
          simState.prepay = Number(e.target.value) || 0;
          updateLoanSim();
        });
        panel.querySelector('#lw-rate').addEventListener('input', (e) => {
          simState.rateDelta = Number(e.target.value) || 0;
          updateLoanSim();
        });
        updateLoanSim();
      },
    });
  };

  // ---------- Render Active Tab ----------
  if (invViewState.tab === 'investments') {
    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <section class="hero-card">
          <div class="toolbar" style="margin-bottom:6px;">
            <span class="hero-label">Portfolio Value</span>
            <button type="button" class="btn btn-primary btn-sm" id="btn-add-inv">+ Add Investment</button>
          </div>
          <div class="hero-balance">${fmt(portfolio.totalCurrentPaise)}</div>
          <div class="grid-3" style="margin-top:10px; gap:8px;">
            <div>
              <div class="item-meta">Invested</div>
              <div class="item-title" style="font-size:0.86rem;">${fmt(portfolio.totalInvestedPaise)}</div>
            </div>
            <div>
              <div class="item-meta">Total Gain</div>
              <div class="item-title ${portfolio.totalGainPaise >= 0 ? 'text-success' : 'text-danger'}" style="font-size:0.86rem;">
                ${portfolio.totalGainPaise >= 0 ? '+' : ''}${fmt(portfolio.totalGainPaise)} (${portfolio.absReturnPct}%)
              </div>
            </div>
            <div>
              <div class="item-meta">XIRR (p.a.)</div>
              <div class="item-title" style="font-size:0.86rem; color:var(--accent);">
                ${portfolio.portfolioXirrPct !== null ? `${portfolio.portfolioXirrPct}%` : '—'}
              </div>
            </div>
          </div>
        </section>

        ${
          portfolio.investments.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">📈</div>
                <h3 class="empty-state-title">No investments tracked yet</h3>
                <p class="empty-state-text">Add your Mutual Funds, SIPs, Stocks, FDs, PPF, or Gold with an optional Goal Plan to track Actual vs. Planned growth and run What-If forecasts.</p>
                <button type="button" class="btn btn-primary" id="btn-empty-add-inv">+ Add First Investment</button>
              </div>`
            : portfolio.investments
                .map((inv) => {
                  const ev = inv.evaluation;
                  const meta = INVESTMENT_ASSET_TYPES.find((t) => t.key === inv.asset_type) || INVESTMENT_ASSET_TYPES[0];
                  const statusBadge =
                    ev.status === 'ahead'
                      ? `<span class="badge" style="background:rgba(34,197,94,0.16); color:#22c55e;">Ahead of Plan (+${ev.variancePct}%)</span>`
                      : ev.status === 'behind'
                        ? `<span class="badge" style="background:rgba(239,68,68,0.16); color:#ef4444;">Behind Plan (${ev.variancePct}%)</span>`
                        : `<span class="badge badge-muted">On Track (${ev.variancePct >= 0 ? '+' : ''}${ev.variancePct}%)</span>`;

                  return `
                    <article class="card stack" style="gap:10px;">
                      <div class="toolbar" style="align-items:flex-start;">
                        <div class="list-row-main">
                          <span class="avatar-badge">${meta.icon}</span>
                          <div>
                            <div class="item-title">${escapeHtml(inv.name)}</div>
                            <div class="item-meta">
                              ${meta.label} · Plan ${inv.expected_annual_return_pct}% p.a.
                              ${inv.monthly_sip_paise ? ` · SIP ${fmt(inv.monthly_sip_paise)}/mo` : ''}
                            </div>
                          </div>
                        </div>
                        ${statusBadge}
                      </div>

                      <div class="grid-3" style="gap:8px;">
                        <div class="metric-card" style="padding:8px;">
                          <div class="metric-label">Actual Now</div>
                          <div class="item-title" style="font-size:0.86rem;">${fmt(inv.current_value_paise)}</div>
                          <div class="item-meta">Inv: ${fmt(inv.invested_paise)}</div>
                        </div>
                        <div class="metric-card" style="padding:8px;">
                          <div class="metric-label">Planned Today</div>
                          <div class="item-title" style="font-size:0.86rem;">${fmt(ev.plannedValueTodayPaise)}</div>
                          <div class="item-meta ${ev.variancePaise >= 0 ? 'text-success' : 'text-danger'}">
                            ${ev.variancePaise >= 0 ? '+' : ''}${fmt(ev.variancePaise)}
                          </div>
                        </div>
                        <div class="metric-card" style="padding:8px;">
                          <div class="metric-label">Actual XIRR</div>
                          <div class="item-title" style="font-size:0.86rem; color:var(--accent);">
                            ${ev.actualXirrPct !== null ? `${ev.actualXirrPct}%` : `${ev.absReturnPct}%`}
                          </div>
                          <div class="item-meta">Target ${inv.expected_annual_return_pct}%</div>
                        </div>
                      </div>

                      ${
                        ev.hasGoal
                          ? `<div class="card" style="background:var(--bg-surface-elevated); padding:10px;">
                              <div class="toolbar" style="margin-bottom:4px;">
                                <span class="item-title" style="font-size:0.82rem;">🎯 ${escapeHtml(inv.goal_name || 'Goal')} (${escapeHtml(inv.goal_target_date)})</span>
                                <span class="item-meta"><strong>${ev.goalProgressPct}%</strong> of ${fmt(inv.goal_target_paise)}</span>
                              </div>
                              <div class="progress-track" style="height:6px; margin-bottom:6px;">
                                <div class="progress-fill" style="width:${ev.goalProgressPct}%;"></div>
                              </div>
                              <div class="item-meta" style="line-height:1.45;">
                                Projected at Plan (${inv.expected_annual_return_pct}%): <strong>${fmt(ev.projectedAtGoalPlanRatePaise)}</strong>
                                ${
                                  ev.projectedAtGoalPlanRatePaise < inv.goal_target_paise
                                    ? `<br><span class="text-danger">Shortfall: ${fmt(inv.goal_target_paise - ev.projectedAtGoalPlanRatePaise)} · Need ${fmt(ev.requiredMonthlySipPaise)}/mo SIP to reach goal.</span>`
                                    : `<br><span class="text-success">On pace to exceed goal by ${fmt(ev.projectedAtGoalPlanRatePaise - inv.goal_target_paise)}.</span>`
                                }
                              </div>
                            </div>`
                          : ''
                      }

                      <div style="display:flex; gap:6px; flex-wrap:wrap;">
                        <button type="button" class="btn btn-primary btn-sm" data-cf-inv="${inv.id}">+ Log SIP / Value</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-whatif-inv="${inv.id}">🔮 What-If</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-edit-inv="${inv.id}">Edit</button>
                        <button type="button" class="btn btn-danger btn-sm" data-del-inv="${inv.id}">🗑</button>
                      </div>
                    </article>
                  `;
                })
                .join('')
        }
      </div>
    `;

    container.querySelector('#btn-add-inv')?.addEventListener('click', () => openInvestmentModal(null));
    container.querySelector('#btn-empty-add-inv')?.addEventListener('click', () => openInvestmentModal(null));
    container.querySelectorAll('[data-cf-inv]').forEach((b) => {
      b.addEventListener('click', () => {
        const inv = portfolio.investments.find((i) => i.id === b.getAttribute('data-cf-inv'));
        if (inv) openCashflowModal(inv);
      });
    });
    container.querySelectorAll('[data-whatif-inv]').forEach((b) => {
      b.addEventListener('click', () => {
        const inv = portfolio.investments.find((i) => i.id === b.getAttribute('data-whatif-inv'));
        if (inv) {
          invViewState.whatIfTarget = inv.id;
          invViewState.whatIfReturnPct = inv.expected_annual_return_pct || 12;
          invViewState.whatIfExtraSipRupees = 0;
          invViewState.whatIfLumpSumRupees = 0;
          invViewState.tab = 'whatif';
          renderInvestmentsView(container, ctx);
        }
      });
    });
    container.querySelectorAll('[data-edit-inv]').forEach((b) => {
      b.addEventListener('click', () => {
        const inv = portfolio.investments.find((i) => i.id === b.getAttribute('data-edit-inv'));
        if (inv) openInvestmentModal(inv);
      });
    });
    container.querySelectorAll('[data-del-inv]').forEach((b) => {
      b.addEventListener('click', async () => {
        await repos.investments.softDelete(b.getAttribute('data-del-inv'));
        showToast('Investment removed');
        renderInvestmentsView(container, ctx);
      });
    });
  } else if (invViewState.tab === 'whatif') {
    const selectedInv = portfolio.investments.find((i) => i.id === invViewState.whatIfTarget) || null;
    const isCustom = invViewState.whatIfTarget === 'custom' || (invViewState.whatIfTarget === 'portfolio' && portfolio.investments.length === 0);

    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <section class="card stack" style="gap:10px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Simulate For</label>
            <select id="wi-target" class="form-control">
              <option value="portfolio" ${invViewState.whatIfTarget === 'portfolio' ? 'selected' : ''}>Entire Portfolio (${fmt(portfolio.totalCurrentPaise)})</option>
              ${portfolio.investments
                .map((i) => `<option value="${i.id}" ${invViewState.whatIfTarget === i.id ? 'selected' : ''}>${escapeHtml(i.name)} (${fmt(i.current_value_paise)})</option>`)
                .join('')}
              <option value="custom" ${isCustom ? 'selected' : ''}>Custom What-If Scenario</option>
            </select>
          </div>

          ${
            isCustom
              ? `<div class="form-row">
                  <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Starting Amount (₹)</label>
                    <input id="wi-custom-start" type="number" step="5000" min="0" class="form-control" value="${invViewState.whatIfCustomStartRupees}">
                  </div>
                  <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Monthly SIP (₹)</label>
                    <input id="wi-custom-sip" type="number" step="500" min="0" class="form-control" value="${invViewState.whatIfCustomSipRupees}">
                  </div>
                </div>
                <div class="form-group" style="margin-bottom:0;">
                  <label class="form-label">Goal Target (₹, optional)</label>
                  <input id="wi-custom-goal" type="number" step="50000" min="0" class="form-control" value="${invViewState.whatIfCustomGoalRupees}">
                </div>`
              : ''
          }

          <div class="form-row">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Years Ahead: <strong id="wi-yrs-lbl">${invViewState.whatIfYears} yrs</strong></label>
              <input id="wi-years" type="range" min="1" max="30" value="${invViewState.whatIfYears}" style="width:100%;">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Return p.a.: <strong id="wi-ret-lbl">${invViewState.whatIfReturnPct}%</strong></label>
              <input id="wi-return" type="range" min="4" max="24" step="0.5" value="${invViewState.whatIfReturnPct}" style="width:100%;">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Extra Monthly SIP (₹)</label>
              <input id="wi-extra-sip" type="number" step="500" min="0" class="form-control" value="${invViewState.whatIfExtraSipRupees}">
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label">Annual SIP Step-Up (%)</label>
              <input id="wi-stepup" type="number" step="1" min="0" max="25" class="form-control" value="${invViewState.whatIfStepUpPct}">
            </div>
          </div>

          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">One-Time Lump-Sum Top-Up Today (₹)</label>
            <input id="wi-lumpsum" type="number" step="10000" min="0" class="form-control" value="${invViewState.whatIfLumpSumRupees}">
          </div>
        </section>

        <div id="wi-results-slot" class="stack"></div>
      </div>
    `;

    const resultsSlot = container.querySelector('#wi-results-slot');
    const renderWhatIfOutput = () => {
      const baseCur = isCustom
        ? Math.round(invViewState.whatIfCustomStartRupees * 100)
        : selectedInv
          ? selectedInv.current_value_paise
          : portfolio.totalCurrentPaise;
      const baseInv = isCustom
        ? Math.round(invViewState.whatIfCustomStartRupees * 100)
        : selectedInv
          ? selectedInv.invested_paise
          : portfolio.totalInvestedPaise;
      const baseSip = isCustom
        ? Math.round(invViewState.whatIfCustomSipRupees * 100)
        : selectedInv
          ? selectedInv.monthly_sip_paise
          : portfolio.totalMonthlySipPaise;
      const goalTarget = isCustom
        ? Math.round(invViewState.whatIfCustomGoalRupees * 100)
        : selectedInv
          ? selectedInv.goal_target_paise || 0
          : portfolio.investments.reduce((s, i) => s + (i.goal_target_paise || 0), 0);

      const sim = simulateInvestmentWhatIf({
        currentValuePaise: baseCur,
        investedSoFarPaise: baseInv,
        monthlySipPaise: baseSip,
        extraMonthlySipPaise: Math.round(invViewState.whatIfExtraSipRupees * 100),
        lumpSumTopUpPaise: Math.round(invViewState.whatIfLumpSumRupees * 100),
        annualReturnPct: invViewState.whatIfReturnPct,
        annualStepUpPct: invViewState.whatIfStepUpPct,
        years: invViewState.whatIfYears,
        goalTargetPaise: goalTarget,
      });

      const chartPts = sim.yearlyPoints.map((pt) => ({
        label: pt.label,
        primary: pt.corpusPaise,
        secondary: pt.investedPaise,
      }));

      resultsSlot.innerHTML = `
        <section class="card stack" style="gap:10px;">
          <div class="grid-3" style="gap:8px;">
            <div class="metric-card" style="padding:10px;">
              <div class="metric-label">After ${sim.years} Yrs</div>
              <div class="item-title text-success" style="font-size:0.95rem;">${fmt(sim.finalCorpusPaise)}</div>
            </div>
            <div class="metric-card" style="padding:10px;">
              <div class="metric-label">Total Invested</div>
              <div class="item-title" style="font-size:0.95rem;">${fmt(sim.finalInvestedPaise)}</div>
            </div>
            <div class="metric-card" style="padding:10px;">
              <div class="metric-label">Wealth Gained</div>
              <div class="item-title" style="font-size:0.95rem; color:var(--accent);">${fmt(sim.wealthGainedPaise)}</div>
            </div>
          </div>

          ${
            goalTarget > 0
              ? `<div class="card" style="background:var(--bg-surface-elevated); padding:10px;">
                  <div class="item-title" style="font-size:0.84rem;">
                    🎯 Goal Target: ${fmt(goalTarget)} —
                    <span class="${sim.onTrackForGoal ? 'text-success' : 'text-danger'}">
                      ${sim.onTrackForGoal ? `Surplus +${fmt(sim.goalGapPaise)}` : `Shortfall ${fmt(Math.abs(sim.goalGapPaise))}`}
                    </span>
                  </div>
                </div>`
              : ''
          }

          ${renderProjectionSvg(chartPts, {
            goalTargetPaise: goalTarget,
            showBalances: show,
            primaryColor: '#22c55e',
            secondaryColor: '#38bdf8',
            primaryLabel: 'Projected Corpus',
            secondaryLabel: 'Total Invested',
          })}
        </section>
      `;
      bindChartTooltips(resultsSlot);
    };

    renderWhatIfOutput();

    container.querySelector('#wi-target')?.addEventListener('change', (e) => {
      invViewState.whatIfTarget = e.target.value;
      renderInvestmentsView(container, ctx);
    });
    container.querySelector('#wi-years')?.addEventListener('input', (e) => {
      invViewState.whatIfYears = Number(e.target.value) || 10;
      container.querySelector('#wi-yrs-lbl').textContent = `${invViewState.whatIfYears} yrs`;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-return')?.addEventListener('input', (e) => {
      invViewState.whatIfReturnPct = Number(e.target.value) || 12;
      container.querySelector('#wi-ret-lbl').textContent = `${invViewState.whatIfReturnPct}%`;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-extra-sip')?.addEventListener('input', (e) => {
      invViewState.whatIfExtraSipRupees = Number(e.target.value) || 0;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-stepup')?.addEventListener('input', (e) => {
      invViewState.whatIfStepUpPct = Number(e.target.value) || 0;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-lumpsum')?.addEventListener('input', (e) => {
      invViewState.whatIfLumpSumRupees = Number(e.target.value) || 0;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-custom-start')?.addEventListener('input', (e) => {
      invViewState.whatIfCustomStartRupees = Number(e.target.value) || 0;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-custom-sip')?.addEventListener('input', (e) => {
      invViewState.whatIfCustomSipRupees = Number(e.target.value) || 0;
      renderWhatIfOutput();
    });
    container.querySelector('#wi-custom-goal')?.addEventListener('input', (e) => {
      invViewState.whatIfCustomGoalRupees = Number(e.target.value) || 0;
      renderWhatIfOutput();
    });
  } else {
    // Loans Tab
    const activeLoans = loans.filter((l) => l.is_active !== false && (l.outstanding_paise || 0) > 0);
    const totalOut = activeLoans.reduce((s, l) => s + (l.outstanding_paise || 0), 0);
    const totalEmi = activeLoans.reduce((s, l) => s + (l.emi_paise || 0), 0);

    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <section class="hero-card">
          <div class="toolbar" style="margin-bottom:6px;">
            <span class="hero-label">Total Loan Outstanding</span>
            <button type="button" class="btn btn-primary btn-sm" id="btn-add-loan">+ Add Loan</button>
          </div>
          <div class="hero-balance text-danger">${fmt(totalOut)}</div>
          <div class="grid-2" style="margin-top:10px; gap:8px;">
            <div>
              <div class="item-meta">Monthly EMI Burden</div>
              <div class="item-title">${fmt(totalEmi)}/mo</div>
            </div>
            <div>
              <div class="item-meta">Active Loans</div>
              <div class="item-title">${activeLoans.length}</div>
            </div>
          </div>
        </section>

        ${
          loans.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🏡</div>
                <h3 class="empty-state-title">No loans added</h3>
                <p class="empty-state-text">Track Home, Car, or Personal Loans and run What-If prepayment &amp; interest rate simulations to see how many years and lakhs of interest you can save.</p>
                <button type="button" class="btn btn-primary" id="btn-empty-add-loan">+ Add First Loan</button>
              </div>`
            : loans
                .map((loan) => {
                  const meta = LOAN_TYPES.find((t) => t.key === loan.loan_type) || LOAN_TYPES[0];
                  const baseSim = simulateLoanWhatIf({
                    outstandingPaise: loan.outstanding_paise,
                    interestRatePct: loan.interest_rate_pct,
                    emiPaise: loan.emi_paise,
                    remainingMonths: loan.remaining_months,
                  });
                  const paidPct =
                    loan.principal_paise > 0
                      ? Math.min(100, Math.max(0, Math.round(((loan.principal_paise - loan.outstanding_paise) / loan.principal_paise) * 100)))
                      : 0;

                  return `
                    <article class="card stack" style="gap:10px;">
                      <div class="toolbar">
                        <div class="list-row-main">
                          <span class="avatar-badge">${meta.icon}</span>
                          <div>
                            <div class="item-title">${escapeHtml(loan.name)}</div>
                            <div class="item-meta">${meta.label} · ${loan.interest_rate_pct}% p.a. · EMI ${fmt(loan.emi_paise)}/mo</div>
                          </div>
                        </div>
                        <span class="badge badge-liability">${paidPct}% paid</span>
                      </div>

                      <div class="progress-track" style="height:6px;">
                        <div class="progress-fill" style="width:${paidPct}%; background:var(--accent);"></div>
                      </div>

                      <div class="grid-3" style="gap:8px;">
                        <div class="metric-card" style="padding:8px;">
                          <div class="metric-label">Outstanding</div>
                          <div class="item-title text-danger" style="font-size:0.86rem;">${fmt(loan.outstanding_paise)}</div>
                        </div>
                        <div class="metric-card" style="padding:8px;">
                          <div class="metric-label">Rem. Interest</div>
                          <div class="item-title" style="font-size:0.86rem;">${fmt(baseSim.baseline.totalInterestPaise)}</div>
                        </div>
                        <div class="metric-card" style="padding:8px;">
                          <div class="metric-label">Payoff Left</div>
                          <div class="item-title" style="font-size:0.86rem;">${(baseSim.baseline.months / 12).toFixed(1)} yrs</div>
                        </div>
                      </div>

                      <div style="display:flex; gap:6px; flex-wrap:wrap;">
                        <button type="button" class="btn btn-primary btn-sm" data-whatif-loan="${loan.id}">🔮 What-If Prepay</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-edit-loan="${loan.id}">Edit</button>
                        <button type="button" class="btn btn-danger btn-sm" data-del-loan="${loan.id}">🗑</button>
                      </div>
                    </article>
                  `;
                })
                .join('')
        }
      </div>
    `;

    container.querySelector('#btn-add-loan')?.addEventListener('click', () => openLoanModal(null));
    container.querySelector('#btn-empty-add-loan')?.addEventListener('click', () => openLoanModal(null));
    container.querySelectorAll('[data-whatif-loan]').forEach((b) => {
      b.addEventListener('click', () => {
        const loan = loans.find((l) => l.id === b.getAttribute('data-whatif-loan'));
        if (loan) openLoanWhatIfModal(loan);
      });
    });
    container.querySelectorAll('[data-edit-loan]').forEach((b) => {
      b.addEventListener('click', () => {
        const loan = loans.find((l) => l.id === b.getAttribute('data-edit-loan'));
        if (loan) openLoanModal(loan);
      });
    });
    container.querySelectorAll('[data-del-loan]').forEach((b) => {
      b.addEventListener('click', async () => {
        await repos.loans.softDelete(b.getAttribute('data-del-loan'));
        showToast('Loan removed');
        renderInvestmentsView(container, ctx);
      });
    });
  }

  container.querySelectorAll('[data-inv-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      invViewState.tab = btn.getAttribute('data-inv-tab');
      renderInvestmentsView(container, ctx);
    });
  });
}

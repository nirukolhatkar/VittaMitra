import { applyTheme } from '../../services/themeService.js';
import {
  formatBytes,
  getStorageDiagnostics,
  requestPersistentStorage,
} from '../../services/storageService.js';
import {
  runIntegrityAudit,
  runIsolatedMigrationAndRecoveryTest,
} from '../../services/migrationRecoveryService.js';
import { parseCsvText, STANDARD_SHEET_NAME } from '../../services/importExportService.js';
import { formatINR } from '../../utils/money.js';
import { getFinancialYearInfo } from '../../utils/date.js';
import { escapeHtml } from '../../utils/dom.js';
import { showToast } from '../components/toast.js';

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const WEEKDAYS = [
  { value: 1, label: 'Monday' },
  { value: 0, label: 'Sunday' },
  { value: 6, label: 'Saturday' },
];

export async function renderSettingsView(container, ctx) {
  const { db, repos, services } = ctx;
  const [settings, diag] = await Promise.all([
    repos.settings.getSettings(),
    getStorageDiagnostics(db),
  ]);

  const now = new Date();
  const fyPreview = getFinancialYearInfo(
    now.getFullYear(),
    now.getMonth(),
    settings.financial_year_start_month || 4
  );

  container.innerHTML = `
    <div class="stack">
      <div class="compass-header">
        <div>
          <h2 class="compass-title">Settings</h2>
          <div class="compass-subtitle">Appearance, financial year, backup, and data controls</div>
        </div>
      </div>
      <section class="card">
        <div class="card-header">
          <div>
            <h2 class="card-title">Regional &amp; Display Preferences</h2>
            <p class="card-subtitle">Saved locally to IndexedDB and included in JSON / Google Drive backups</p>
          </div>
        </div>

        <form id="settings-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="set-currency">Default Currency</label>
              <select id="set-currency" name="currency" class="form-control">
                <option value="INR" ${settings.currency === 'INR' ? 'selected' : ''}>INR (₹ — Indian Rupee)</option>
              </select>
              <div class="form-help">Indian number format preview: <strong>${formatINR(12500000)}</strong></div>
            </div>

            <div class="form-group">
              <label class="form-label" for="set-theme">Appearance</label>
              <div class="segmented" role="radiogroup" aria-label="Appearance theme" style="width:100%; justify-content:space-between; margin-bottom:6px;">
                <button type="button" style="flex:1;" data-quick-theme="light" class="${settings.theme === 'light' ? 'active' : ''}">☀️ Light</button>
                <button type="button" style="flex:1;" data-quick-theme="dark" class="${settings.theme === 'dark' ? 'active' : ''}">🌙 Dark</button>
                <button type="button" style="flex:1;" data-quick-theme="system" class="${(!settings.theme || settings.theme === 'system') ? 'active' : ''}">💻 System</button>
              </div>
              <select id="set-theme" name="theme" class="form-control hidden">
                <option value="system" ${(!settings.theme || settings.theme === 'system') ? 'selected' : ''}>System default</option>
                <option value="light" ${settings.theme === 'light' ? 'selected' : ''}>Light</option>
                <option value="dark" ${settings.theme === 'dark' ? 'selected' : ''}>Dark</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="set-fy">Financial Year Start Month</label>
              <select id="set-fy" name="financial_year_start_month" class="form-control">
                ${MONTHS.map(
                  (m, idx) =>
                    `<option value="${idx + 1}" ${Number(settings.financial_year_start_month) === idx + 1 ? 'selected' : ''}>${m}</option>`
                ).join('')}
              </select>
              <div class="form-help">Current period: <strong>${fyPreview.label}</strong> (${fyPreview.startDate} to ${fyPreview.endDate})</div>
            </div>

            <div class="form-group">
              <label class="form-label" for="set-week">Week Start Day</label>
              <select id="set-week" name="week_start_day" class="form-control">
                ${WEEKDAYS.map(
                  (d) =>
                    `<option value="${d.value}" ${Number(settings.week_start_day) === d.value ? 'selected' : ''}>${d.label}</option>`
                ).join('')}
              </select>
            </div>
          </div>

          <div style="display:flex; justify-content:flex-end;">
            <button type="submit" class="btn btn-primary" id="btn-save-settings">Save Preferences</button>
          </div>
        </form>
      </section>

      <section class="card">
        <div class="card-header">
          <div>
            <h2 class="card-title">Offline &amp; Local Storage Status</h2>
            <p class="card-subtitle">IndexedDB persistence, Service Worker cache, and attachment limits</p>
          </div>
          <div class="row-actions">
            ${window.__PFM_DEFERRED_INSTALL__ ? '<button type="button" class="btn btn-primary btn-sm" id="btn-install-pwa">📲 Install App</button>' : ''}
            <button type="button" class="btn btn-secondary btn-sm" id="btn-request-persist">
              Request Persistent Storage
            </button>
          </div>
        </div>

        <div class="list">
          <div class="list-row">
            <div class="item-title">Network Connectivity</div>
            <span class="badge ${diag.online ? 'badge-asset' : 'badge-liability'}">
              ${diag.online ? 'Online' : 'Offline Mode'}
            </span>
          </div>
          <div class="list-row">
            <div class="item-title">Service Worker (Offline Launch)</div>
            <span class="badge ${diag.swControlled ? 'badge-asset' : 'badge-muted'}">
              ${diag.swControlled ? 'Active & Caching App Shell' : 'Registered (reload if first visit)'}
            </span>
          </div>
          <div class="list-row">
            <div class="item-title">Browser Persistent Storage</div>
            <span class="badge ${diag.persisted ? 'badge-asset' : 'badge-muted'}">
              ${diag.persisted ? 'Granted' : 'Best-effort'}
            </span>
          </div>
          <div class="list-row">
            <div class="item-title">Local Storage Used / Quota</div>
            <span class="item-meta">${formatBytes(diag.usageBytes)} / ${formatBytes(diag.quotaBytes)}</span>
          </div>
          <div class="list-row">
            <div class="item-title">Attachment Per-File Limit</div>
            <span class="item-meta">5.00 MB (stored in dedicated local blob store)</span>
          </div>
          <div class="list-row">
            <div class="item-title">Cloud Backup Mode</div>
            <span class="badge ${settings.gdrive_connected ? 'badge-asset' : 'badge-muted'}">
              ${settings.gdrive_connected ? 'Google Drive Linked' : 'Local Only (Link Drive in Backup)'}
            </span>
          </div>
        </div>
      </section>

      <section class="card stack" style="gap:12px;">
        <div>
          <h2 class="card-title">🛡️ Phase 8 — Data Integrity &amp; Migration Recovery Self-Test</h2>
          <p class="card-subtitle">
            Verify live ledger integrity or run a non-destructive migration &amp; disaster-recovery test on your actual historical <code>.xlsx</code> / <code>.csv</code> file inside a temporary sandbox database (never modifies your live data).
          </p>
        </div>

        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button type="button" class="btn btn-secondary btn-sm" id="btn-run-integrity">🔍 Run Live Integrity Audit</button>
          <a href="#/import-export" class="btn btn-secondary btn-sm">☁️ Manage Drive Backup</a>
        </div>
        <div id="integrity-report-slot"></div>

        <div class="card" style="background:var(--bg-surface-elevated); padding:12px;">
          <label class="form-label" for="migration-test-file">Test Migration &amp; Recovery on Your Historical File (.xlsx / .csv)</label>
          <input id="migration-test-file" type="file" accept=".xlsx,.csv" class="form-control" style="padding:6px; font-size:0.82rem;">
          <div id="migration-test-progress" class="item-meta" style="margin-top:6px;"></div>
          <div id="migration-test-report" style="margin-top:8px;"></div>
        </div>
      </section>
    </div>
  `;

  container.querySelectorAll('[data-quick-theme]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const nextTheme = btn.getAttribute('data-quick-theme');
      const sel = container.querySelector('#set-theme');
      if (sel) sel.value = nextTheme;
      applyTheme(nextTheme);
      await repos.settings.updateSettings({ theme: nextTheme });
      showToast(`Theme set to ${nextTheme.charAt(0).toUpperCase() + nextTheme.slice(1)}`);
      renderSettingsView(container, ctx);
    });
  });

  container.querySelector('#settings-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const theme = fd.get('theme');
    await repos.settings.updateSettings({
      currency: fd.get('currency'),
      theme,
      financial_year_start_month: Number(fd.get('financial_year_start_month')),
      week_start_day: Number(fd.get('week_start_day')),
    });
    applyTheme(theme);
    showToast('Settings saved');
    renderSettingsView(container, ctx);
  });

  container.querySelector('#btn-install-pwa')?.addEventListener('click', async () => {
    const promptEvt = window.__PFM_DEFERRED_INSTALL__;
    if (!promptEvt) return;
    promptEvt.prompt();
    const { outcome } = await promptEvt.userChoice;
    window.__PFM_DEFERRED_INSTALL__ = null;
    showToast(outcome === 'accepted' ? 'App installation started' : 'Install dismissed');
    renderSettingsView(container, ctx);
  });

  container.querySelector('#btn-request-persist')?.addEventListener('click', async () => {
    const res = await requestPersistentStorage();
    showToast(
      res.persisted
        ? 'Persistent storage granted'
        : 'Browser kept best-effort storage (install PWA to improve persistence)'
    );
    renderSettingsView(container, ctx);
  });

  container.querySelector('#btn-run-integrity')?.addEventListener('click', async () => {
    const slot = container.querySelector('#integrity-report-slot');
    const audit = await runIntegrityAudit(db, repos);
    slot.innerHTML = `
      <div class="grouped-card">
        ${audit.checks
          .map(
            (c) => `
          <div class="grouped-row" style="padding:8px 12px;">
            <div>
              <div class="item-title" style="font-size:0.84rem;">${c.passed ? '✅' : '❌'} ${escapeHtml(c.name)}</div>
              <div class="item-meta">${escapeHtml(c.detail)}</div>
            </div>
          </div>`
          )
          .join('')}
      </div>
    `;
    showToast(audit.passed ? 'All integrity checks passed' : 'Issues found — review report', {
      type: audit.passed ? 'info' : 'error',
    });
  });

  container.querySelector('#migration-test-file')?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const progEl = container.querySelector('#migration-test-progress');
    const repEl = container.querySelector('#migration-test-report');
    progEl.textContent = `Reading ${file.name}…`;
    repEl.innerHTML = '';

    try {
      let sheetRows;
      let sheetName = STANDARD_SHEET_NAME;
      if (file.name.toLowerCase().endsWith('.csv')) {
        sheetRows = parseCsvText(await file.text());
      } else {
        const wb = await services.importExport.parseWorkbookBuffer(await file.arrayBuffer());
        sheetName = wb.sheetNames.includes(STANDARD_SHEET_NAME) ? STANDARD_SHEET_NAME : wb.sheetNames[0];
        sheetRows = wb.sheets[sheetName];
      }

      const report = await runIsolatedMigrationAndRecoveryTest({
        sheetRows,
        filename: file.name,
        sheetName,
        onProgress: ({ phase }) => {
          progEl.textContent = phase;
        },
      });

      progEl.textContent = `${report.passed ? '✅ PASSED' : '❌ FAILED'} in ${(report.durationMs / 1000).toFixed(1)}s (${report.importedRows.toLocaleString('en-IN')} rows verified, sandbox DB cleaned up)`;
      repEl.innerHTML = `
        <div class="grouped-card">
          ${report.steps
            .map(
              (s) => `
            <div class="grouped-row" style="padding:8px 12px;">
              <div>
                <div class="item-title" style="font-size:0.82rem;">${s.passed ? '✅' : '❌'} ${escapeHtml(s.name)}</div>
                <div class="item-meta">${escapeHtml(s.detail)}</div>
              </div>
            </div>`
            )
            .join('')}
        </div>
      `;
    } catch (err) {
      progEl.textContent = `Error: ${err.message}`;
      showToast(err.message, { type: 'error' });
    }
  });
}

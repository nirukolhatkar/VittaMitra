/**
 * Default seed data for Phase 1 initialization.
 */

export const MAX_ATTACHMENT_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB initial limit

export const DEFAULT_SETTINGS = Object.freeze({
  id: 'app-settings',
  app_name: 'Personal Finance Manager',
  currency: 'INR',
  locale: 'en-IN',
  financial_year_start_month: 4, // 1 April to 31 March
  week_start_day: 1, // Monday
  theme: 'dark', // Dark-first modern mobile UI ('dark' | 'light' | 'system')
  show_balances: true, // Privacy toggle (masks amounts as ***** when false)
  credit_card_display_mode: 'available_credit', // 'available_credit' | 'outstanding'
  default_account_id: null,
  default_expense_category_id: null,
  default_income_category_id: null,
  budget_carry_forward: false,
  cloud_sync_enabled: false,
  attachment_max_bytes: MAX_ATTACHMENT_SIZE_BYTES,
  pin_enabled: false,
  pin_hash: null,
});

export const DEFAULT_EXPENSE_CATEGORIES = Object.freeze([
  { name: 'Food and groceries', icon: '🛒', color: '#34d399' },
  { name: 'Dining out', icon: '🍽️', color: '#fb923c' },
  { name: 'Housing / rent', icon: '🏠', color: '#60a5fa' },
  { name: 'Utilities', icon: '💡', color: '#facc15' },
  { name: 'Transport', icon: '🚕', color: '#38bdf8' },
  { name: 'Fuel', icon: '⛽', color: '#f87171' },
  { name: 'Healthcare', icon: '🏥', color: '#fb7185' },
  { name: 'Education', icon: '📚', color: '#818cf8' },
  { name: 'Shopping', icon: '🛍️', color: '#c084fc' },
  { name: 'Entertainment', icon: '🎬', color: '#f472b6' },
  { name: 'Travel', icon: '✈️', color: '#22d3ee' },
  { name: 'Insurance', icon: '🛡️', color: '#2dd4bf' },
  { name: 'Personal care', icon: '🧴', color: '#e879f9' },
  { name: 'Family', icon: '👨‍👩‍👧', color: '#fbbf24' },
  { name: 'Gifts and donations', icon: '🎁', color: '#f472b6' },
  { name: 'Investments', icon: '📈', color: '#34d399' },
  { name: 'Loan interest', icon: '🏦', color: '#f87171' },
  { name: 'Miscellaneous', icon: '📦', color: '#94a3b8' },
]);

export const DEFAULT_INCOME_CATEGORIES = Object.freeze([
  { name: 'Salary', icon: '💼', color: '#34d399' },
  { name: 'Business income', icon: '🏢', color: '#2dd4bf' },
  { name: 'Interest', icon: '🏛️', color: '#38bdf8' },
  { name: 'Dividends', icon: '📊', color: '#60a5fa' },
  { name: 'Rental income', icon: '🔑', color: '#a78bfa' },
  { name: 'Refunds', icon: '↩️', color: '#22d3ee' },
  { name: 'Gifts', icon: '🎉', color: '#f472b6' },
  { name: 'Other income', icon: '💰', color: '#94a3b8' },
]);

export const DEFAULT_FAMILY_MEMBERS = Object.freeze([
  { name: 'Self', relationship: 'Self', icon: '🧑', is_active: true },
  { name: 'Household / Shared', relationship: 'Shared', icon: '🏡', is_active: true },
]);

export const FAMILY_RELATIONSHIPS = Object.freeze([
  'Self',
  'Spouse',
  'Child',
  'Parent',
  'Sibling',
  'Other family member',
  'Shared',
]);

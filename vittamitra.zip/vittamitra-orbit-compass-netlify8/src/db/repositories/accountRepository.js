import { BaseRepository } from './baseRepository.js';
import {
  ACCOUNT_CLASS,
  ACCOUNT_TYPE_ORDER,
  getAccountTypeMeta,
  isLiabilityAccount,
} from '../../constants/accountTypes.js';
import { normalizeAccountName } from '../../utils/normalize.js';
import { parseRupeesToPaise, sumPaise } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';
import { computeReconciledAccountBalance } from '../../services/ledgerRules.js';

export class AccountRepository extends BaseRepository {
  constructor(db) {
    super(db, 'accounts', { syncable: true });
  }

  async _getActivePostings() {
    try {
      const all = await this.db.table('ledger_postings').toArray();
      return all.filter((p) => !p.deleted_at);
    } catch {
      return [];
    }
  }

  async list({ includeArchived = false, asOfDate = null } = {}) {
    const [all, postings] = await Promise.all([
      this.getAll({ includeDeleted: false }),
      this._getActivePostings(),
    ]);

    return all
      .filter((a) => (includeArchived ? true : !a.is_archived))
      .map((a) => ({
        ...a,
        current_balance_paise: computeReconciledAccountBalance(a, postings, asOfDate),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  /**
   * Reconcile a single account as of a specific date ("YYYY-MM-DD"),
   * excluding all transactions occurring after `asOfDate`.
   */
  async getReconciledAccountAsOf(accountId, asOfDate) {
    const [acc, postings] = await Promise.all([
      this.getById(accountId),
      this._getActivePostings(),
    ]);
    if (!acc) return null;
    const balanceAsOfPaise = computeReconciledAccountBalance(acc, postings, asOfDate || null);
    return {
      ...acc,
      current_balance_paise: balanceAsOfPaise,
      as_of_date: asOfDate || null,
    };
  }

  async listGrouped() {
    const all = await this.list({ includeArchived: true });
    const active = all.filter((a) => !a.is_archived);
    const archived = all.filter((a) => a.is_archived);

    const groups = ACCOUNT_TYPE_ORDER.map((typeCode) => ({
      meta: getAccountTypeMeta(typeCode),
      items: active.filter((a) => getAccountTypeMeta(a.type).code === typeCode),
    }));

    return { groups, archived };
  }

  async findByName(rawName) {
    const norm = normalizeAccountName(rawName);
    const all = await this.getAll({ includeDeleted: false });
    const match = all.find((a) => a.normalized_key === norm.normalized_key) || null;
    return { match, normalized: norm };
  }

  async createAccount({
    name,
    type = 'bank_account',
    institution = '',
    identifier_masked = '',
    opening_balance_paise = 0,
    opening_balance_rupees = undefined,
    credit_limit_paise = 0,
    credit_limit_rupees = undefined,
    opening_date = toLocalDateString(),
    currency = 'INR',
    color = null,
    icon = null,
    include_in_available_balance = undefined,
    notes = '',
  }) {
    const norm = normalizeAccountName(name);
    if (!norm.name) throw new Error('Account name is required');

    const { match } = await this.findByName(norm.name);
    if (match) {
      throw new Error(`Account "${norm.name}" already exists`);
    }

    const typeMeta = getAccountTypeMeta(type);
    const openingPaise =
      opening_balance_rupees !== undefined
        ? parseRupeesToPaise(opening_balance_rupees, { allowNegative: typeMeta.code !== 'credit_card' })
        : opening_balance_paise;

    if (!Number.isSafeInteger(openingPaise)) {
      throw new Error('Opening balance must be integer paise');
    }

    let limitPaise = 0;
    if (typeMeta.code === 'credit_card') {
      limitPaise =
        credit_limit_rupees !== undefined && String(credit_limit_rupees).trim() !== ''
          ? parseRupeesToPaise(credit_limit_rupees, { allowNegative: false })
          : credit_limit_paise || 0;
    }

    const includeAvailable =
      include_in_available_balance !== undefined
        ? Boolean(include_in_available_balance)
        : typeMeta.defaultIncludeInAvailableBalance;

    return this.create({
      name: norm.name,
      normalized_key: norm.normalized_key,
      type: typeMeta.code,
      account_class: typeMeta.accountClass,
      institution: String(institution || '').trim(),
      identifier_masked: String(identifier_masked || '').trim(),
      opening_balance_paise: openingPaise,
      credit_limit_paise: limitPaise,
      opening_date: opening_date || toLocalDateString(),
      currency: currency || 'INR',
      color: color || typeMeta.color,
      icon: icon || typeMeta.icon,
      include_in_available_balance: includeAvailable,
      is_archived: false,
      notes: String(notes || '').trim(),
    });
  }

  async updateAccount(id, patch) {
    const current = await this.getById(id);
    if (!current) throw new Error('Account not found');

    const nextPatch = { ...patch };
    const nextType = patch.type ? getAccountTypeMeta(patch.type).code : getAccountTypeMeta(current.type).code;

    if (patch.name !== undefined) {
      const norm = normalizeAccountName(patch.name);
      if (!norm.name) throw new Error('Account name cannot be empty');
      const all = await this.getAll({ includeDeleted: false });
      const duplicate = all.find((a) => a.id !== id && a.normalized_key === norm.normalized_key);
      if (duplicate) {
        throw new Error(`Account "${norm.name}" already exists`);
      }
      nextPatch.name = norm.name;
      nextPatch.normalized_key = norm.normalized_key;
    }

    if (patch.type !== undefined) {
      const typeMeta = getAccountTypeMeta(patch.type);
      nextPatch.type = typeMeta.code;
      nextPatch.account_class = typeMeta.accountClass;
    }

    if (patch.opening_balance_rupees !== undefined) {
      nextPatch.opening_balance_paise = parseRupeesToPaise(patch.opening_balance_rupees, {
        allowNegative: nextType !== 'credit_card',
      });
      delete nextPatch.opening_balance_rupees;
    }

    if (patch.credit_limit_rupees !== undefined) {
      const rawLimit = String(patch.credit_limit_rupees).trim();
      nextPatch.credit_limit_paise =
        rawLimit === '' ? 0 : parseRupeesToPaise(rawLimit, { allowNegative: false });
      delete nextPatch.credit_limit_rupees;
    }

    return this.update(id, nextPatch);
  }

  async setArchived(id, isArchived) {
    return this.update(id, { is_archived: Boolean(isArchived) });
  }

  static getCreditCardMetrics(account) {
    const rawBalance =
      account.current_balance_paise !== undefined
        ? account.current_balance_paise
        : account.opening_balance_paise || 0;
    const outstandingPaise = Math.max(0, rawBalance);
    const overpaymentCreditPaise = rawBalance < 0 ? Math.abs(rawBalance) : 0;
    const limitPaise = account.credit_limit_paise || 0;
    const availableCreditPaise = Math.max(0, limitPaise - rawBalance);
    return {
      outstandingPaise,
      overpaymentCreditPaise,
      limitPaise,
      availableCreditPaise,
    };
  }

  async getBalanceSummary() {
    const activeAccounts = await this.list({ includeArchived: false });

    const assetAccounts = activeAccounts.filter((a) => !isLiabilityAccount(a));
    const liabilityAccounts = activeAccounts.filter((a) => isLiabilityAccount(a));
    const availableAccounts = assetAccounts.filter((a) => a.include_in_available_balance);
    const creditCards = liabilityAccounts.filter((a) => getAccountTypeMeta(a.type).code === 'credit_card');

    return {
      activeCount: activeAccounts.length,
      assetCount: assetAccounts.length,
      liabilityCount: liabilityAccounts.length,
      creditCardCount: creditCards.length,
      totalAvailableBalancePaise: sumPaise(availableAccounts.map((a) => a.current_balance_paise || 0)),
      totalAssetBalancePaise: sumPaise(assetAccounts.map((a) => a.current_balance_paise || 0)),
      totalCreditCardLiabilityPaise: sumPaise(
        creditCards.map((a) => AccountRepository.getCreditCardMetrics(a).outstandingPaise)
      ),
      totalCreditLimitPaise: sumPaise(creditCards.map((a) => a.credit_limit_paise || 0)),
      totalAvailableCreditPaise: sumPaise(
        creditCards.map((a) => AccountRepository.getCreditCardMetrics(a).availableCreditPaise)
      ),
      totalLiabilityBalancePaise: sumPaise(
        liabilityAccounts.map((a) => Math.max(0, a.current_balance_paise || 0))
      ),
      accountClass: ACCOUNT_CLASS,
    };
  }
}

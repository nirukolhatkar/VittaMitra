import { renderClipboardBar, setPageContext } from './services/txContextClipboard.js';

/**
 * Hash-based SPA router with Orbit (Home & Add Transaction) / Compass (all other views)
 * design switching, active navigation highlighting, and contextual action syncing.
 */

const ORBIT_ROUTES = new Set(['home', 'add-transaction']);

export class Router {
  constructor(routes, { onBeforeNavigate } = {}) {
    this.routes = routes;
    this.onBeforeNavigate = onBeforeNavigate;
  }

  getCurrentRouteKey() {
    const raw = (window.location.hash || '#/home').replace(/^#\/?/, '').split('?')[0];
    return this.routes[raw] ? raw : 'home';
  }

  async resolve(ctx) {
    const key = this.getCurrentRouteKey();
    const route = this.routes[key];
    if (!route) return;

    if (typeof this.onBeforeNavigate === 'function') {
      this.onBeforeNavigate(key, route);
    }

    const design = ORBIT_ROUTES.has(key) ? 'orbit' : 'compass';
    document.documentElement.setAttribute('data-design', design);
    document.documentElement.setAttribute('data-route-active', key);

    const isAddPage = key === 'add-transaction';
    document.getElementById('topbar-search-btn')?.classList.toggle('hidden', isAddPage);
    document.getElementById('topbar-add-btn')?.classList.toggle('hidden', isAddPage);

    const titleEl = document.getElementById('topbar-title');
    if (titleEl) titleEl.textContent = route.title;

    const backBtn = document.getElementById('topbar-back');
    if (backBtn) {
      if (route.parentRoute) {
        backBtn.classList.remove('hidden');
        backBtn.onclick = () => {
          window.location.hash = `#/${route.parentRoute}`;
        };
      } else {
        backBtn.classList.add('hidden');
        backBtn.onclick = null;
      }
    }

    const activeNavKey = route.navGroup || key;
    document.querySelectorAll('[data-route]').forEach((el) => {
      const target = el.getAttribute('data-route');
      el.classList.toggle('active', target === key || target === activeNavKey);
    });

    // Clear stale page context before rendering the next route
    setPageContext(ctx, null);

    const main = document.getElementById('app-main');
    if (main) {
      await route.render(main, ctx);
    }

    renderClipboardBar(ctx);
  }

  start(ctx) {
    window.addEventListener('hashchange', () => this.resolve(ctx));
    if (!window.location.hash) {
      window.location.hash = '#/home';
    }
    return this.resolve(ctx);
  }
}

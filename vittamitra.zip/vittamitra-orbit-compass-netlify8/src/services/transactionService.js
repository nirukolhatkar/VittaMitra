import { generateUUID } from '../utils/uuid.js';
import { nowIsoUtc, toLocalDateTimeString } from '../utils/date.js';
import { parseRupeesToPaise } from '../utils/money.js';
import { buildBalanceAdjustmentPostings, buildLedgerPostings, validateSplitReconciliation } from './ledgerRules.js';

/**
 * Controlled Transaction & Double-Entry Ledger Service (Phase 2).
 */
export class TransactionService {
  constructor(db, repos) {
    this.db = db;
    this.repos = repos;
  }

  static normalizeDateTime(dateStr, timeStr) {
    const now = toLocalDateTimeString();
    const datePart = dateStr && /^\d{4}-\d{2}-\d{2}$/.test(dateStr) ? dateStr : now.slice(0, 10);
    let timePart = now.slice(11, 19);
    if (timeStr) {
      if (/^\d{2}:\d{2}:\d{2}$/.test(timeStr)) timePart = timeStr;
      else if (/^\d{2}:\d{2}$/.test(timeStr)) timePart = `${timeStr}:00`;
    }
    return {
      date_key: datePart,
      occurred_at_local: `${datePart} ${timePart}`,
    };
  }

  /**
   * Advanced filter engine supporting all inclusion/exclusion permutations:
   * - years: string[] (e.g. ['2026', '2025'])
   * - months: string[] (e.g. ['2026-11', '2026-10'])
   * - startDate / endDate: "YYYY-MM-DD"
   * - type: 'all' | 'expense' | 'income' | 'transfer'
   * - categoryIds: string[], categoryMode: 'include' | 'exclude'
   * - accountIds: string[], accountMode: 'include' | 'exclude'
   * - tagIds: string[], tagMode: 'any' | 'all' | 'exclude'
   * - familyIds: string[], familyMode: 'include' | 'exclude'
   * - search: free text across description, notes, reference_no
   * - sort: 'desc' | 'asc' | 'amount_desc' | 'amount_asc'
   */
  async listTransactions({
    monthYear = null,
    years = [],
    months = [],
    startDate = null,
    endDate = null,
    type = null,
    accountId = null,
    accountIds = [],
    accountMode = 'include',
    categoryId = null,
    categoryIds = [],
    categoryMode = 'include',
    tagId = null,
    tagIds = [],
    tagMode = 'any',
    familyMemberId = null,
    familyIds = [],
    familyMode = 'include',
    search = '',
    sort = 'desc',
  } = {}) {
    const [allTx, allTxTags] = await Promise.all([
      this.db.table('transactions').toArray(),
      this.db.table('transaction_tags').toArray(),
    ]);

    const tagsByTx = new Map();
    for (const tt of allTxTags) {
      if (tt.deleted_at) continue;
      if (!tagsByTx.has(tt.transaction_id)) tagsByTx.set(tt.transaction_id, []);
      tagsByTx.get(tt.transaction_id).push(tt.tag_id);
    }

    let monthPrefix = null;
    if (monthYear) {
      monthPrefix = `${monthYear.year}-${String(monthYear.month + 1).padStart(2, '0')}`;
    }

    const effAccountIds = accountIds.length > 0 ? accountIds : accountId ? [accountId] : [];
    const effCategoryIds = categoryIds.length > 0 ? categoryIds : categoryId ? [categoryId] : [];
    const effTagIds = tagIds.length > 0 ? tagIds : tagId ? [tagId] : [];
    const effFamilyIds = familyIds.length > 0 ? familyIds : familyMemberId ? [familyMemberId] : [];
    const q = String(search || '').trim().toLowerCase();

    const filtered = allTx
      .filter((tx) => {
        if (tx.deleted_at) return false;
        const dKey = String(tx.date_key || '');

        if (monthPrefix && !dKey.startsWith(monthPrefix)) return false;

        // Multi-select Year / Month pills (OR across selected periods)
        if (years.length > 0 || months.length > 0) {
          const matchesYear = years.length > 0 && years.includes(dKey.slice(0, 4));
          const matchesMonth = months.length > 0 && months.includes(dKey.slice(0, 7));
          if (!matchesYear && !matchesMonth) return false;
        }

        if (startDate && dKey < startDate) return false;
        if (endDate && dKey > endDate) return false;
        if (type && type !== 'all' && tx.type !== type) return false;

        // Account inclusion / exclusion
        if (effAccountIds.length > 0) {
          const matchesAcc =
            effAccountIds.includes(tx.account_id) ||
            (tx.to_account_id && effAccountIds.includes(tx.to_account_id));
          if (accountMode === 'exclude' ? matchesAcc : !matchesAcc) return false;
        }

        // Category inclusion / exclusion
        if (effCategoryIds.length > 0) {
          const matchesCat = Boolean(tx.category_id && effCategoryIds.includes(tx.category_id));
          if (categoryMode === 'exclude' ? matchesCat : !matchesCat) return false;
        }

        // Family inclusion / exclusion
        if (effFamilyIds.length > 0) {
          const matchesFam = Boolean(tx.family_member_id && effFamilyIds.includes(tx.family_member_id));
          if (familyMode === 'exclude' ? matchesFam : !matchesFam) return false;
        }

        // Tags: Includes any / Includes all / Excludes
        const txTagIds = tagsByTx.get(tx.id) || [];
        if (effTagIds.length > 0) {
          if (tagMode === 'all') {
            if (!effTagIds.every((id) => txTagIds.includes(id))) return false;
          } else if (tagMode === 'exclude') {
            if (effTagIds.some((id) => txTagIds.includes(id))) return false;
          } else {
            if (!effTagIds.some((id) => txTagIds.includes(id))) return false;
          }
        }

        if (q) {
          const hay = `${tx.description || ''} ${tx.notes || ''} ${tx.reference_no || ''}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .map((tx) => ({
        ...tx,
        tag_ids: tagsByTx.get(tx.id) || [],
      }));

    filtered.sort((a, b) => {
      if (sort === 'amount_desc') return b.amount_paise - a.amount_paise;
      if (sort === 'amount_asc') return a.amount_paise - b.amount_paise;
      const cmp = String(a.occurred_at_local || '').localeCompare(String(b.occurred_at_local || ''));
      return sort === 'asc' ? cmp : -cmp;
    });

    return filtered;
  }

  async getTransactionById(id) {
    const tx = await this.db.table('transactions').get(id);
    if (!tx || tx.deleted_at) return null;
    const [txTags, splits] = await Promise.all([
      this.db.table('transaction_tags').toArray(),
      this.db.table('transaction_splits').toArray(),
    ]);
    return {
      ...tx,
      tag_ids: txTags.filter((t) => !t.deleted_at && t.transaction_id === id).map((t) => t.tag_id),
      splits: splits.filter((s) => !s.deleted_at && s.transaction_id === id),
    };
  }

  async countByCategory(categoryId) {
    const all = await this.db.table('transactions').toArray();
    return all.filter((tx) => !tx.deleted_at && tx.category_id === categoryId).length;
  }

  /**
   * Return distinct previously used descriptions/notes ordered by frequency & recency
   * for instant autocomplete suggestions while typing.
   */
  async getRecentDescriptions(limit = 0) {
    const all = await this.db.table('transactions').toArray();
    const stats = new Map();
    for (const tx of all) {
      if (tx.deleted_at) continue;
      for (const raw of [tx.description, tx.notes]) {
        const desc = String(raw || '').trim();
        if (!desc) continue;
        const key = desc.toLowerCase();
        const prev = stats.get(key);
        if (!prev) {
          stats.set(key, { text: desc, count: 1, latest: tx.occurred_at_local || '' });
        } else {
          prev.count += 1;
          if ((tx.occurred_at_local || '') > prev.latest) {
            prev.latest = tx.occurred_at_local || '';
            prev.text = desc;
          }
        }
      }
    }
    const sorted = Array.from(stats.values())
      .sort((a, b) => b.count - a.count || b.latest.localeCompare(a.latest))
      .map((item) => item.text);
    return limit && limit > 0 ? sorted.slice(0, limit) : sorted;
  }

  async findPossibleDuplicates({ type, amount_paise, date_key, account_id, to_account_id = null, description = '', excludeId = null }) {
    const all = await this.db.table('transactions').toArray();
    const normDesc = String(description || '').trim().toLowerCase();
    return all.filter((tx) => {
      if (tx.deleted_at) return false;
      if (excludeId && tx.id === excludeId) return false;
      if (tx.type !== type) return false;
      if (tx.amount_paise !== amount_paise) return false;
      if (tx.date_key !== date_key) return false;
      if (tx.account_id !== account_id) return false;
      if (type === 'transfer' && (tx.to_account_id || null) !== (to_account_id || null)) return false;
      if (normDesc && String(tx.description || '').trim().toLowerCase() !== normDesc) return false;
      return true;
    });
  }

  async createTransaction({
    type,
    amount_paise,
    amount_rupees = undefined,
    date = null,
    time = null,
    occurred_at_local = null,
    category_id = null,
    account_id,
    to_account_id = null,
    description = '',
    notes = '',
    family_member_id = null,
    reference_no = '',
    tag_ids = [],
    splits = [],
  }) {
    if (!['expense', 'income', 'transfer'].includes(type)) {
      throw new Error(`Invalid transaction type: "${type}"`);
    }

    const amountPaise =
      amount_rupees !== undefined ? parseRupeesToPaise(amount_rupees, { allowNegative: false }) : amount_paise;
    if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) {
      throw new Error('Transaction amount must be greater than ₹0.00');
    }

    const sourceAccount = await this.repos.accounts.getById(account_id);
    if (!sourceAccount) throw new Error('Please select a valid account / payment mode');

    let destinationAccount = null;
    if (type === 'transfer') {
      destinationAccount = await this.repos.accounts.getById(to_account_id);
      if (!destinationAccount) throw new Error('Please select a destination account for the transfer');
      if (destinationAccount.id === sourceAccount.id) {
        throw new Error('Source and destination accounts must be different');
      }
    } else if (!category_id && (!splits || splits.length === 0)) {
      throw new Error('Please select a category');
    }

    const isSplit = Array.isArray(splits) && splits.length > 0;
    if (isSplit) {
      validateSplitReconciliation(amountPaise, splits);
    }

    let dateKey;
    let localTs;
    if (occurred_at_local && /^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}(:\d{2})?$/.test(occurred_at_local)) {
      localTs = occurred_at_local.length === 16 ? `${occurred_at_local}:00` : occurred_at_local;
      dateKey = localTs.slice(0, 10);
    } else {
      const normalized = TransactionService.normalizeDateTime(date, time);
      dateKey = normalized.date_key;
      localTs = normalized.occurred_at_local;
    }

    const txId = generateUUID();
    const now = nowIsoUtc();

    const txRecord = {
      id: txId,
      user_id: null,
      type,
      amount_paise: amountPaise,
      date_key: dateKey,
      occurred_at_local: localTs,
      category_id: type === 'transfer' ? null : category_id || null,
      account_id: sourceAccount.id,
      to_account_id: destinationAccount ? destinationAccount.id : null,
      description: String(description || '').trim(),
      notes: String(notes || '').trim(),
      family_member_id: family_member_id || null,
      reference_no: String(reference_no || '').trim(),
      is_split: isSplit,
      recurring_rule_id: null,
      bill_id: null,
      import_batch_id: null,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    };

    const rawPostings = buildLedgerPostings({
      transactionId: txId,
      type,
      amountPaise,
      sourceAccount,
      destinationAccount,
    });

    const postingRecords = rawPostings.map((p) => ({
      ...p,
      id: generateUUID(),
      user_id: null,
      occurred_at_local: localTs,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const uniqueTagIds = Array.from(new Set((tag_ids || []).filter(Boolean)));
    const tagLinks = uniqueTagIds.map((tagId) => ({
      id: generateUUID(),
      user_id: null,
      transaction_id: txId,
      tag_id: tagId,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const splitRecords = isSplit
      ? splits.map((s) => ({
          id: generateUUID(),
          user_id: null,
          transaction_id: txId,
          category_id: s.category_id,
          amount_paise: s.amount_paise,
          notes: String(s.notes || '').trim(),
          created_at: now,
          updated_at: now,
          version: 1,
          deleted_at: null,
        }))
      : [];

    const stores = ['transactions', 'ledger_postings', 'transaction_tags', 'transaction_splits', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').add(txRecord);
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: txRecord.id,
        operation: 'insert',
        version: txRecord.version,
        payload: txRecord,
        retry_count: 0,
        last_error: null,
        queued_at: now,
      });

      for (const p of postingRecords) {
        await this.db.table('ledger_postings').add(p);
        await this.db.table('sync_queue').add({
          table_name: 'ledger_postings',
          record_id: p.id,
          operation: 'insert',
          version: p.version,
          payload: p,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }

      for (const tl of tagLinks) {
        await this.db.table('transaction_tags').add(tl);
        await this.db.table('sync_queue').add({
          table_name: 'transaction_tags',
          record_id: tl.id,
          operation: 'insert',
          version: tl.version,
          payload: tl,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }

      for (const sp of splitRecords) {
        await this.db.table('transaction_splits').add(sp);
        await this.db.table('sync_queue').add({
          table_name: 'transaction_splits',
          record_id: sp.id,
          operation: 'insert',
          version: sp.version,
          payload: sp,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }
    });

    const settingsPatch = { default_account_id: sourceAccount.id };
    if (type === 'expense' && category_id) settingsPatch.default_expense_category_id = category_id;
    if (type === 'income' && category_id) settingsPatch.default_income_category_id = category_id;
    await this.repos.settings.updateSettings(settingsPatch).catch(() => {});

    return { ...txRecord, tag_ids: uniqueTagIds, postings: postingRecords };
  }

  /**
   * One-tap copy/paste (clone) an existing transaction directly without opening the edit form.
   */
  async cloneTransaction(id, overrides = {}) {
    const {
      date = null,
      account_id = null,
      to_account_id = null,
      category_id = null,
      type = null,
      family_member_id = null,
      add_tag_id = null,
      add_tag_ids = null,
      tag_ids = null,
    } = overrides || {};

    const orig = await this.getTransactionById(id);
    if (!orig) throw new Error('Transaction not found');
    const nowTs = toLocalDateTimeString();

    let nextType = type && ['expense', 'income', 'transfer'].includes(type) ? type : orig.type;
    if (nextType === 'debt') {
      nextType = 'expense';
    }
    let nextCategoryId = category_id !== null ? category_id : orig.category_id;
    if (category_id && !type && nextType === 'transfer') {
      const cat = await this.repos.categories.getById(category_id);
      if (cat && (cat.type === 'expense' || cat.type === 'income')) {
        nextType = cat.type;
      }
    }
    if (nextType === 'transfer') {
      nextCategoryId = null;
    }

    const nextAccountId = account_id || orig.account_id;
    let nextToAccountId = nextType === 'transfer' ? (to_account_id || orig.to_account_id) : null;
    if (nextType === 'transfer' && nextToAccountId === nextAccountId) {
      if (orig.account_id && orig.account_id !== nextAccountId) {
        nextToAccountId = orig.account_id;
      } else {
        const activeAccounts = await this.repos.accounts.list({ includeArchived: false });
        const alt = activeAccounts.find((a) => a.id !== nextAccountId);
        if (alt) nextToAccountId = alt.id;
      }
    }

    let nextTagIds = Array.isArray(tag_ids) ? [...tag_ids] : [...(orig.tag_ids || [])];
    if (add_tag_id && !nextTagIds.includes(add_tag_id)) {
      nextTagIds.push(add_tag_id);
    }
    if (Array.isArray(add_tag_ids)) {
      for (const tid of add_tag_ids) {
        if (tid && !nextTagIds.includes(tid)) nextTagIds.push(tid);
      }
    }

    return this.createTransaction({
      type: nextType,
      amount_paise: orig.amount_paise,
      date: date || nowTs.slice(0, 10),
      time: nowTs.slice(11, 19),
      category_id: nextCategoryId,
      account_id: nextAccountId,
      to_account_id: nextToAccountId,
      description: orig.description,
      notes: orig.notes,
      family_member_id: family_member_id !== null ? family_member_id : orig.family_member_id,
      reference_no: orig.reference_no,
      tag_ids: nextTagIds,
    });
  }

  async updateTransaction(id, patch) {
    const existing = await this.getTransactionById(id);
    if (!existing) throw new Error('Transaction not found');

    const type = patch.type || existing.type;
    const amountPaise =
      patch.amount_rupees !== undefined
        ? parseRupeesToPaise(patch.amount_rupees, { allowNegative: false })
        : patch.amount_paise !== undefined
          ? patch.amount_paise
          : existing.amount_paise;

    if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) {
      throw new Error('Transaction amount must be greater than ₹0.00');
    }

    const accountId = patch.account_id || existing.account_id;
    const toAccountId = type === 'transfer' ? (patch.to_account_id ?? existing.to_account_id) : null;
    const categoryId = type === 'transfer' ? null : (patch.category_id ?? existing.category_id);

    const sourceAccount = await this.repos.accounts.getById(accountId);
    if (!sourceAccount) throw new Error('Source account not found');

    let destinationAccount = null;
    if (type === 'transfer') {
      destinationAccount = await this.repos.accounts.getById(toAccountId);
      if (!destinationAccount) throw new Error('Destination account is required for transfers');
      if (destinationAccount.id === sourceAccount.id) {
        throw new Error('Source and destination accounts must be different');
      }
    } else if (!categoryId) {
      throw new Error('Category is required');
    }

    let dateKey = existing.date_key;
    let localTs = existing.occurred_at_local;
    if (patch.date || patch.time) {
      const norm = TransactionService.normalizeDateTime(
        patch.date || existing.date_key,
        patch.time || existing.occurred_at_local.slice(11, 19)
      );
      dateKey = norm.date_key;
      localTs = norm.occurred_at_local;
    }

    const now = nowIsoUtc();
    const updatedTx = {
      ...existing,
      type,
      amount_paise: amountPaise,
      date_key: dateKey,
      occurred_at_local: localTs,
      category_id: categoryId,
      account_id: sourceAccount.id,
      to_account_id: destinationAccount ? destinationAccount.id : null,
      description: patch.description !== undefined ? String(patch.description).trim() : existing.description,
      notes: patch.notes !== undefined ? String(patch.notes).trim() : existing.notes,
      family_member_id: patch.family_member_id !== undefined ? (patch.family_member_id || null) : existing.family_member_id,
      reference_no: patch.reference_no !== undefined ? String(patch.reference_no).trim() : existing.reference_no,
      updated_at: now,
      version: (existing.version || 1) + 1,
    };
    delete updatedTx.tag_ids;
    delete updatedTx.splits;

    const newPostings = buildLedgerPostings({
      transactionId: id,
      type,
      amountPaise,
      sourceAccount,
      destinationAccount,
    }).map((p) => ({
      ...p,
      id: generateUUID(),
      user_id: existing.user_id ?? null,
      occurred_at_local: localTs,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const nextTagIds = patch.tag_ids !== undefined ? Array.from(new Set(patch.tag_ids.filter(Boolean))) : existing.tag_ids;
    const newTagLinks = nextTagIds.map((tagId) => ({
      id: generateUUID(),
      user_id: existing.user_id ?? null,
      transaction_id: id,
      tag_id: tagId,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const [oldPostings, oldTags] = await Promise.all([
      this.db.table('ledger_postings').toArray(),
      this.db.table('transaction_tags').toArray(),
    ]);
    const activeOldPostings = oldPostings.filter((p) => !p.deleted_at && p.transaction_id === id);
    const activeOldTags = oldTags.filter((t) => !t.deleted_at && t.transaction_id === id);

    const stores = ['transactions', 'ledger_postings', 'transaction_tags', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').put(updatedTx);
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: updatedTx.id,
        operation: 'update',
        version: updatedTx.version,
        payload: updatedTx,
        retry_count: 0,
        last_error: null,
        queued_at: now,
      });

      for (const oldP of activeOldPostings) {
        const tomb = { ...oldP, deleted_at: now, updated_at: now, version: (oldP.version || 1) + 1 };
        await this.db.table('ledger_postings').put(tomb);
        await this.db.table('sync_queue').add({
          table_name: 'ledger_postings',
          record_id: tomb.id,
          operation: 'delete',
          version: tomb.version,
          payload: tomb,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }

      for (const np of newPostings) {
        await this.db.table('ledger_postings').add(np);
        await this.db.table('sync_queue').add({
          table_name: 'ledger_postings',
          record_id: np.id,
          operation: 'insert',
          version: np.version,
          payload: np,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }

      for (const oldT of activeOldTags) {
        const tomb = { ...oldT, deleted_at: now, updated_at: now, version: (oldT.version || 1) + 1 };
        await this.db.table('transaction_tags').put(tomb);
        await this.db.table('sync_queue').add({
          table_name: 'transaction_tags',
          record_id: tomb.id,
          operation: 'delete',
          version: tomb.version,
          payload: tomb,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }

      for (const nt of newTagLinks) {
        await this.db.table('transaction_tags').add(nt);
        await this.db.table('sync_queue').add({
          table_name: 'transaction_tags',
          record_id: nt.id,
          operation: 'insert',
          version: nt.version,
          payload: nt,
          retry_count: 0,
          last_error: null,
          queued_at: now,
        });
      }
    });

    return { ...updatedTx, tag_ids: nextTagIds, postings: newPostings };
  }

  async softDeleteTransaction(id) {
    const existing = await this.db.table('transactions').get(id);
    if (!existing || existing.deleted_at) return null;

    const now = nowIsoUtc();
    const [allPostings, allTags, allSplits] = await Promise.all([
      this.db.table('ledger_postings').toArray(),
      this.db.table('transaction_tags').toArray(),
      this.db.table('transaction_splits').toArray(),
    ]);

    const childPostings = allPostings.filter((p) => !p.deleted_at && p.transaction_id === id);
    const childTags = allTags.filter((t) => !t.deleted_at && t.transaction_id === id);
    const childSplits = allSplits.filter((s) => !s.deleted_at && s.transaction_id === id);

    const txTomb = { ...existing, deleted_at: now, updated_at: now, version: (existing.version || 1) + 1 };

    const stores = ['transactions', 'ledger_postings', 'transaction_tags', 'transaction_splits', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').put(txTomb);
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: txTomb.id,
        operation: 'delete',
        version: txTomb.version,
        payload: txTomb,
        retry_count: 0,
        last_error: null,
        queued_at: now,
      });

      for (const [tbl, rows] of [
        ['ledger_postings', childPostings],
        ['transaction_tags', childTags],
        ['transaction_splits', childSplits],
      ]) {
        for (const r of rows) {
          const tomb = { ...r, deleted_at: now, updated_at: now, version: (r.version || 1) + 1 };
          await this.db.table(tbl).put(tomb);
          await this.db.table('sync_queue').add({
            table_name: tbl,
            record_id: tomb.id,
            operation: 'delete',
            version: tomb.version,
            payload: tomb,
            retry_count: 0,
            last_error: null,
            queued_at: now,
          });
        }
      }
    });

    return {
      transactionId: id,
      deletedAt: now,
      postingIds: childPostings.map((p) => p.id),
      tagLinkIds: childTags.map((t) => t.id),
      splitIds: childSplits.map((s) => s.id),
    };
  }

  /**
   * Atomically restore a soft-deleted transaction and the exact child postings/tags/splits
   * deleted with it (powers the Undo button).
   */
  async restoreTransaction(undoToken) {
    if (!undoToken?.transactionId) return null;
    const tx = await this.db.table('transactions').get(undoToken.transactionId);
    if (!tx || !tx.deleted_at) return null;

    const now = nowIsoUtc();
    const restoredTx = { ...tx, deleted_at: null, updated_at: now, version: (tx.version || 1) + 1 };

    const stores = ['transactions', 'ledger_postings', 'transaction_tags', 'transaction_splits', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').put(restoredTx);
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: restoredTx.id,
        operation: 'update',
        version: restoredTx.version,
        payload: restoredTx,
        retry_count: 0,
        last_error: null,
        queued_at: now,
      });

      const restoreIds = [
        ['ledger_postings', undoToken.postingIds || []],
        ['transaction_tags', undoToken.tagLinkIds || []],
        ['transaction_splits', undoToken.splitIds || []],
      ];

      for (const [tbl, ids] of restoreIds) {
        for (const rid of ids) {
          const rec = await this.db.table(tbl).get(rid);
          if (!rec || !rec.deleted_at) continue;
          const restored = { ...rec, deleted_at: null, updated_at: now, version: (rec.version || 1) + 1 };
          await this.db.table(tbl).put(restored);
          await this.db.table('sync_queue').add({
            table_name: tbl,
            record_id: restored.id,
            operation: 'update',
            version: restored.version,
            payload: restored,
            retry_count: 0,
            last_error: null,
            queued_at: now,
          });
        }
      }
    });

    return restoredTx;
  }

  async bulkSoftDelete(ids) {
    const undoTokens = [];
    for (const id of ids) {
      const token = await this.softDeleteTransaction(id);
      if (token) undoTokens.push(token);
    }
    return undoTokens;
  }

  async restoreBulkTransactions(undoTokens) {
    let count = 0;
    for (const token of undoTokens || []) {
      const res = await this.restoreTransaction(token);
      if (res) count += 1;
    }
    return count;
  }

  async getMonthlySummary(year, monthIndex0) {
    const txs = await this.listTransactions({ monthYear: { year, month: monthIndex0 } });
    let incomePaise = 0;
    let expensePaise = 0;
    const expenseByCategory = new Map();

    for (const tx of txs) {
      if (tx.type === 'income') {
        incomePaise += tx.amount_paise;
      } else if (tx.type === 'expense') {
        expensePaise += tx.amount_paise;
        if (tx.category_id) {
          expenseByCategory.set(
            tx.category_id,
            (expenseByCategory.get(tx.category_id) || 0) + tx.amount_paise
          );
        }
      }
    }

    const netSavingsPaise = incomePaise - expensePaise;
    const topCategories = Array.from(expenseByCategory.entries())
      .map(([category_id, total_paise]) => ({ category_id, total_paise }))
      .sort((a, b) => b.total_paise - a.total_paise);

    return {
      transactionCount: txs.length,
      incomePaise,
      expensePaise,
      netSavingsPaise,
      topCategories,
      transactions: txs,
    };
  }

  async getFrequentTransactions(days = 7, limit = 5) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffKey = `${cutoff.getFullYear()}-${String(cutoff.getMonth() + 1).padStart(2, '0')}-${String(cutoff.getDate()).padStart(2, '0')}`;

    const recent = await this.listTransactions({ startDate: cutoffKey });
    const buckets = new Map();

    for (const tx of recent) {
      const sig = `${tx.type}|${tx.category_id || ''}|${tx.account_id}|${tx.to_account_id || ''}|${tx.amount_paise}|${(tx.description || '').toLowerCase()}`;
      const existing = buckets.get(sig);
      if (existing) existing.count += 1;
      else buckets.set(sig, { count: 1, sample: tx });
    }

    return Array.from(buckets.values())
      .sort((a, b) => b.count - a.count || b.sample.occurred_at_local.localeCompare(a.sample.occurred_at_local))
      .slice(0, limit);
  }


  /**
   * Preview a Balance Adjustment (As-On-Date) without mutating the ledger.
   * Returns calculated balance as of `date`, signed delta, direction, and whether
   * subsequent transactions exist after `date`.
   */
  async previewBalanceAdjustment({ account_id, date, actual_balance_paise, actual_balance_rupees = undefined, excludeTxId = null }) {
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      throw new Error('Please select a valid adjustment date');
    }
    const account = await this.repos.accounts.getById(account_id);
    if (!account) throw new Error('Account not found');

    const actualPaise =
      actual_balance_rupees !== undefined
        ? parseRupeesToPaise(actual_balance_rupees, { allowNegative: true })
        : actual_balance_paise;
    if (!Number.isSafeInteger(actualPaise)) {
      throw new Error('Please enter a valid monetary balance');
    }

    const allPostings = (await this.db.table('ledger_postings').toArray()).filter(
      (p) => !p.deleted_at && p.account_id === account.id && (!excludeTxId || p.transaction_id !== excludeTxId)
    );
    let calculatedAsOfPaise = account.opening_balance_paise || 0;
    let hasSubsequentTransactions = false;
    let subsequentNetPaise = 0;

    for (const p of allPostings) {
      const pDate = String(p.occurred_at_local || '').slice(0, 10);
      if (pDate && pDate > date) {
        hasSubsequentTransactions = true;
        subsequentNetPaise += p.balance_delta_paise;
      } else {
        calculatedAsOfPaise += p.balance_delta_paise;
      }
    }

    const deltaPaise = actualPaise - calculatedAsOfPaise;
    const projectedCurrentBalancePaise = actualPaise + subsequentNetPaise;

    return {
      account,
      date,
      calculatedAsOfPaise,
      actualPaise,
      deltaPaise,
      direction: deltaPaise > 0 ? 'increase' : deltaPaise < 0 ? 'decrease' : 'none',
      hasSubsequentTransactions,
      subsequentNetPaise,
      projectedCurrentBalancePaise,
    };
  }

  /**
   * Creates a dedicated BALANCE_ADJUSTMENT ledger entry as of `date`.
   * - Never modifies opening_balance_paise or existing transactions.
   * - Excluded from regular income, expense, budgets, and category analytics.
   * - Protected by idempotency_key against duplicate submissions.
   */
  async createBalanceAdjustment({
    account_id,
    date,
    actual_balance_paise,
    actual_balance_rupees = undefined,
    notes = '',
    idempotency_key = null,
  }) {
    if (idempotency_key) {
      const existingAll = await this.db.table('transactions').toArray();
      const dup = existingAll.find((t) => !t.deleted_at && t.type === 'BALANCE_ADJUSTMENT' && t.idempotency_key === idempotency_key);
      if (dup) return dup;
    }

    const preview = await this.previewBalanceAdjustment({
      account_id,
      date,
      actual_balance_paise,
      actual_balance_rupees,
    });

    if (preview.deltaPaise === 0) {
      throw new Error('Actual balance matches the calculated balance — no adjustment needed');
    }

    const txId = generateUUID();
    const now = nowIsoUtc();
    const localTs = `${preview.date} 23:59:59`;
    const cleanNotes = String(notes || '').trim();
    const dirLabel = preview.deltaPaise > 0 ? 'increase' : 'decrease';

    const txRecord = {
      id: txId,
      user_id: null,
      type: 'BALANCE_ADJUSTMENT',
      amount_paise: Math.abs(preview.deltaPaise),
      adjustment_delta_paise: preview.deltaPaise,
      adjustment_direction: dirLabel,
      previous_balance_paise: preview.calculatedAsOfPaise,
      target_balance_paise: preview.actualPaise,
      idempotency_key: idempotency_key || generateUUID(),
      date_key: preview.date,
      occurred_at_local: localTs,
      category_id: null,
      account_id: preview.account.id,
      to_account_id: null,
      description: cleanNotes || 'Balance Adjustment',
      notes: cleanNotes,
      family_member_id: null,
      reference_no: '',
      is_split: false,
      recurring_rule_id: null,
      bill_id: null,
      import_batch_id: null,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    };

    const rawPostings = buildBalanceAdjustmentPostings({
      transactionId: txId,
      account: preview.account,
      deltaPaise: preview.deltaPaise,
    });

    const postingRecords = rawPostings.map((p) => ({
      ...p,
      id: generateUUID(),
      user_id: null,
      occurred_at_local: localTs,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const stores = ['transactions', 'ledger_postings', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').add(txRecord);
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: txRecord.id,
        operation: 'insert',
        payload: txRecord,
        queued_at: now,
      });
      for (const p of postingRecords) {
        await this.db.table('ledger_postings').add(p);
      }
    });

    return txRecord;
  }

  /**
   * Updates an existing BALANCE_ADJUSTMENT entry and atomically replaces its ledger postings.
   */
  async updateBalanceAdjustment(id, { date, actual_balance_paise, actual_balance_rupees = undefined, notes = '' }) {
    const existing = await this.getTransactionById(id);
    if (!existing || existing.type !== 'BALANCE_ADJUSTMENT') {
      throw new Error('Balance adjustment entry not found');
    }

    const nextDate = date || existing.date_key;
    const preview = await this.previewBalanceAdjustment({
      account_id: existing.account_id,
      date: nextDate,
      actual_balance_paise,
      actual_balance_rupees,
      excludeTxId: existing.id,
    });

    if (preview.deltaPaise === 0) {
      throw new Error('Updated balance matches the calculated balance — delete this adjustment instead');
    }

    const now = nowIsoUtc();
    const localTs = `${preview.date} 23:59:59`;
    const cleanNotes = String(notes ?? existing.notes ?? '').trim();
    const updatedTx = {
      ...existing,
      amount_paise: Math.abs(preview.deltaPaise),
      adjustment_delta_paise: preview.deltaPaise,
      adjustment_direction: preview.deltaPaise > 0 ? 'increase' : 'decrease',
      previous_balance_paise: preview.calculatedAsOfPaise,
      target_balance_paise: preview.actualPaise,
      date_key: preview.date,
      occurred_at_local: localTs,
      description: cleanNotes || 'Balance Adjustment',
      notes: cleanNotes,
      updated_at: now,
      version: (existing.version || 1) + 1,
    };

    const rawPostings = buildBalanceAdjustmentPostings({
      transactionId: existing.id,
      account: preview.account,
      deltaPaise: preview.deltaPaise,
    });
    const newPostings = rawPostings.map((p) => ({
      ...p,
      id: generateUUID(),
      user_id: null,
      occurred_at_local: localTs,
      created_at: now,
      updated_at: now,
      version: 1,
      deleted_at: null,
    }));

    const stores = ['transactions', 'ledger_postings', 'sync_queue'];
    await this.db.transaction('rw', stores, async () => {
      await this.db.table('transactions').put(updatedTx);
      const oldPostings = (await this.db.table('ledger_postings').toArray()).filter(
        (p) => !p.deleted_at && p.transaction_id === existing.id
      );
      for (const op of oldPostings) {
        await this.db.table('ledger_postings').put({ ...op, deleted_at: now, updated_at: now });
      }
      for (const np of newPostings) {
        await this.db.table('ledger_postings').add(np);
      }
      await this.db.table('sync_queue').add({
        table_name: 'transactions',
        record_id: updatedTx.id,
        operation: 'update',
        payload: updatedTx,
        queued_at: now,
      });
    });

    return updatedTx;
  }

}

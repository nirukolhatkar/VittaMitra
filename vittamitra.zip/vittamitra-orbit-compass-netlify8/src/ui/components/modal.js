import { escapeHtml } from '../../utils/dom.js';

/**
 * Accessible modal dialog helper.
 */
export function openModal({ title, bodyHtml, onMount }) {
  const root = document.getElementById('modal-root');
  if (!root) return;

  root.innerHTML = `
    <div class="modal-panel" role="document">
      <div class="modal-header">
        <h2 class="modal-title">${escapeHtml(title)}</h2>
        <button type="button" class="icon-btn" data-modal-close aria-label="Close">✕</button>
      </div>
      <div class="modal-body">${bodyHtml}</div>
    </div>
  `;

  root.classList.remove('hidden');
  root.setAttribute('aria-hidden', 'false');

  const handleBackdrop = (e) => {
    if (e.target === root || e.target.closest('[data-modal-close]')) {
      closeModal();
    }
  };
  const handleKey = (e) => {
    if (e.key === 'Escape') closeModal();
  };

  root._cleanup = () => {
    root.removeEventListener('click', handleBackdrop);
    window.removeEventListener('keydown', handleKey);
  };

  root.addEventListener('click', handleBackdrop);
  window.addEventListener('keydown', handleKey);

  if (typeof onMount === 'function') {
    onMount(root.querySelector('.modal-panel'), closeModal);
  }
}

export function closeModal() {
  const root = document.getElementById('modal-root');
  if (!root) return;
  if (typeof root._cleanup === 'function') {
    root._cleanup();
    root._cleanup = null;
  }
  root.classList.add('hidden');
  root.setAttribute('aria-hidden', 'true');
  root.innerHTML = '';
}

import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString } from '../../utils/money.js';
import { toLocalDateString } from '../../utils/date.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';

const billsState = {
  tab: 'bills', // 'bills' | 'recurring' | 'reminders'
  billFilter: 'upcoming', // 'upcoming' | 'overdue' | 'paid'
};

export async function renderBillsView(container, ctx) {
  const { repos, services } = ctx;
  const [settings, accounts, categories, categorized, recurringRules, dueRules] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.list({ includeArchived: false }),
    repos.categories.list({ includeArchived: false }),
    services.billsRecurring.getBillsCategorized(),
    repos.recurring.listAll(),
    services.billsRecurring.getDueRecurringRules(),
  ]);

  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');
  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const catMap = new Map(categories.map((c) => [c.id, c]));
  const expCats = categories.filter((c) => c.type === 'expense');

  const openBillModal = (existing = null) => {
    const isEdit = Boolean(existing);
    openModal({
      title: isEdit ? 'Edit Bill' : 'Add Bill',
      bodyHtml: `
        <form id="bill-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Bill Name</label>
              <input name="name" class="form-control" required maxlength="60"
                value="${escapeHtml(existing?.name || '')}" placeholder="e.g. Electricity, Rent, EMI">
            </div>
            <div class="form-group">
              <label class="form-label">Amount (₹)</label>
              <input name="amount_rupees" class="form-control" inputmode="decimal" required
                value="${existing ? paiseToDecimalString(existing.amount_paise) : ''}" placeholder="0.00">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Due Date</label>
              <input name="due_date" type="date" class="form-control" required
                value="${escapeHtml(existing?.due_date || toLocalDateString())}">
            </div>
            <div class="form-group">
              <label class="form-label">Frequency</label>
              <select name="frequency" class="form-control">
                ${[
                  ['monthly', 'Monthly'],
                  ['once', 'One-time'],
                  ['quarterly', 'Quarterly'],
                  ['half_yearly', 'Half-yearly'],
                  ['yearly', 'Yearly'],
                ]
                  .map(([v, l]) => `<option value="${v}" ${(existing?.frequency || 'monthly') === v ? 'selected' : ''}>${l}</option>`)
                  .join('')}
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Category</label>
              <select name="category_id" class="form-control">
                ${expCats.map((c) => `<option value="${c.id}" ${existing?.category_id === c.id ? 'selected' : ''}>${escapeHtml(c.icon)} ${escapeHtml(c.name)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Payment Account</label>
              <select name="account_id" class="form-control">
                <option value="">Select later</option>
                ${accounts.map((a) => `<option value="${a.id}" ${existing?.account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Reminder Date</label>
            <input name="reminder_date" type="date" class="form-control"
              value="${escapeHtml(existing?.reminder_date || existing?.due_date || toLocalDateString())}">
          </div>
          <div class="form-group">
            <label class="form-label">Notes (optional)</label>
            <input name="notes" class="form-control" value="${escapeHtml(existing?.notes || '')}" placeholder="Consumer no. or note">
          </div>
          <div class="modal-footer" style="justify-content:space-between;">
            ${isEdit ? '<button type="button" class="btn btn-danger btn-sm" id="bill-del-btn">Delete</button>' : '<div></div>'}
            <div class="row-actions">
              <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
              <button type="submit" class="btn btn-primary">${isEdit ? 'Save' : 'Add Bill'}</button>
            </div>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#bill-del-btn')?.addEventListener('click', async () => {
          await repos.bills.softDelete(existing.id);
          close();
          renderBillsView(container, ctx);
          showToast(`Bill "${existing.name}" deleted`, {
            actionLabel: 'Undo',
            onAction: async () => {
              await repos.bills.restore(existing.id);
              renderBillsView(container, ctx);
              showToast('Bill restored');
            },
          });
        });

        panel.querySelector('#bill-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const payload = {
            name: fd.get('name'),
            amount_rupees: fd.get('amount_rupees'),
            due_date: fd.get('due_date'),
            frequency: fd.get('frequency'),
            category_id: fd.get('category_id') || null,
            account_id: fd.get('account_id') || null,
            reminder_date: fd.get('reminder_date') || fd.get('due_date'),
            notes: fd.get('notes') || '',
          };
          try {
            if (isEdit) {
              await repos.bills.updateBill(existing.id, payload);
              showToast('Bill updated');
            } else {
              await repos.bills.createBill(payload);
              showToast('Bill added');
            }
            close();
            renderBillsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openRecurringModal = (existing = null) => {
    const isEdit = Boolean(existing);
    if (accounts.length === 0) {
      showToast('Add an account first before creating a recurring rule', { type: 'error' });
      return;
    }
    const rType = existing?.type || 'expense';
    openModal({
      title: isEdit ? 'Edit Recurring Rule' : 'Add Recurring Transaction',
      bodyHtml: `
        <form id="rec-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Name</label>
              <input name="name" class="form-control" required maxlength="60"
                value="${escapeHtml(existing?.name || '')}" placeholder="e.g. Salary, SIP, Rent, EMI">
            </div>
            <div class="form-group">
              <label class="form-label">Amount (₹)</label>
              <input name="amount_rupees" class="form-control" inputmode="decimal" required
                value="${existing ? paiseToDecimalString(existing.amount_paise) : ''}" placeholder="0.00">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Type</label>
              <select name="type" id="rec-type" class="form-control">
                <option value="expense" ${rType === 'expense' ? 'selected' : ''}>Expense</option>
                <option value="income" ${rType === 'income' ? 'selected' : ''}>Income</option>
                <option value="transfer" ${rType === 'transfer' ? 'selected' : ''}>Transfer</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Frequency</label>
              <select name="frequency" class="form-control">
                ${[
                  ['monthly', 'Monthly'],
                  ['weekly', 'Weekly'],
                  ['daily', 'Daily'],
                  ['quarterly', 'Quarterly'],
                  ['half_yearly', 'Half-yearly'],
                  ['yearly', 'Yearly'],
                  ['custom_days', 'Custom (every N days)'],
                ]
                  .map(([v, l]) => `<option value="${v}" ${(existing?.frequency || 'monthly') === v ? 'selected' : ''}>${l}</option>`)
                  .join('')}
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group" id="rec-cat-wrap">
              <label class="form-label">Category</label>
              <select name="category_id" class="form-control">
                ${categories.map((c) => `<option value="${c.id}" ${existing?.category_id === c.id ? 'selected' : ''}>${escapeHtml(c.icon)} ${escapeHtml(c.name)} (${c.type})</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Account</label>
              <select name="account_id" class="form-control" required>
                ${accounts.map((a) => `<option value="${a.id}" ${existing?.account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="form-group ${rType === 'transfer' ? '' : 'hidden'}" id="rec-to-wrap">
            <label class="form-label">Destination Account</label>
            <select name="to_account_id" class="form-control">
              ${accounts.map((a) => `<option value="${a.id}" ${existing?.to_account_id === a.id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
            </select>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Next Due Date</label>
              <input name="next_due_date" type="date" class="form-control" required
                value="${escapeHtml(existing?.next_due_date || toLocalDateString())}">
            </div>
            <div class="form-group">
              <label class="form-label">End Date (optional)</label>
              <input name="end_date" type="date" class="form-control"
                value="${escapeHtml(existing?.end_date || '')}">
            </div>
          </div>
          <div class="form-group">
            <label class="checkbox-row">
              <input type="checkbox" name="auto_post" ${existing?.auto_post ? 'checked' : ''}>
              <span>Auto-post automatically when due (off = review &amp; confirm)</span>
            </label>
          </div>
          <div class="modal-footer" style="justify-content:space-between;">
            ${isEdit ? '<button type="button" class="btn btn-danger btn-sm" id="rec-del-btn">Delete</button>' : '<div></div>'}
            <div class="row-actions">
              <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
              <button type="submit" class="btn btn-primary">${isEdit ? 'Save' : 'Create Rule'}</button>
            </div>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        const typeSel = panel.querySelector('#rec-type');
        const toWrap = panel.querySelector('#rec-to-wrap');
        typeSel.addEventListener('change', () => {
          toWrap.classList.toggle('hidden', typeSel.value !== 'transfer');
        });

        panel.querySelector('#rec-del-btn')?.addEventListener('click', async () => {
          await repos.recurring.softDelete(existing.id);
          close();
          renderBillsView(container, ctx);
          showToast(`Rule "${existing.name}" deleted`, {
            actionLabel: 'Undo',
            onAction: async () => {
              await repos.recurring.restore(existing.id);
              renderBillsView(container, ctx);
              showToast('Recurring rule restored');
            },
          });
        });

        panel.querySelector('#rec-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          const payload = {
            name: fd.get('name'),
            type: fd.get('type'),
            amount_rupees: fd.get('amount_rupees'),
            frequency: fd.get('frequency'),
            category_id: fd.get('type') === 'transfer' ? null : fd.get('category_id'),
            account_id: fd.get('account_id'),
            to_account_id: fd.get('type') === 'transfer' ? fd.get('to_account_id') : null,
            next_due_date: fd.get('next_due_date'),
            start_date: existing?.start_date || fd.get('next_due_date'),
            end_date: fd.get('end_date') || null,
            auto_post: panel.querySelector('[name="auto_post"]').checked,
          };
          try {
            if (isEdit) {
              await repos.recurring.updateRule(existing.id, payload);
              showToast('Recurring rule updated');
            } else {
              await repos.recurring.createRule(payload);
              showToast('Recurring rule created');
            }
            close();
            renderBillsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const tabBar = `
    <div class="segmented" style="width:100%; justify-content:space-between;">
      <button type="button" style="flex:1;" data-br-tab="bills" class="${billsState.tab === 'bills' ? 'active' : ''}">
        Bills (${categorized.upcoming.length + categorized.overdue.length})
      </button>
      <button type="button" style="flex:1;" data-br-tab="recurring" class="${billsState.tab === 'recurring' ? 'active' : ''}">
        Recurring (${recurringRules.length})
      </button>
      <button type="button" style="flex:1;" data-br-tab="reminders" class="${billsState.tab === 'reminders' ? 'active' : ''}">
        Reminders (${categorized.activeReminders.length + dueRules.length})
      </button>
    </div>
  `;

  if (billsState.tab === 'bills') {
    const activeList =
      billsState.billFilter === 'overdue'
        ? categorized.overdue
        : billsState.billFilter === 'paid'
          ? categorized.paid
          : categorized.upcoming;

    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <div class="toolbar">
          <div class="segmented">
            <button type="button" data-bill-flt="upcoming" class="${billsState.billFilter === 'upcoming' ? 'active' : ''}">Upcoming (${categorized.upcoming.length})</button>
            <button type="button" data-bill-flt="overdue" class="${billsState.billFilter === 'overdue' ? 'active' : ''}">Overdue (${categorized.overdue.length})</button>
            <button type="button" data-bill-flt="paid" class="${billsState.billFilter === 'paid' ? 'active' : ''}">Paid (${categorized.paid.length})</button>
          </div>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-bill">+ Add Bill</button>
        </div>

        ${
          activeList.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">📅</div>
                <h3 class="empty-state-title">No ${billsState.billFilter} bills</h3>
                <p class="empty-state-text">Track electricity, rent, internet, insurance, school fees, EMI, and credit card bills.</p>
              </div>`
            : `<div class="grouped-card">
                ${activeList
                  .map((b) => {
                    const cat = b.category_id ? catMap.get(b.category_id) : null;
                    const acc = b.account_id ? accMap.get(b.account_id) : null;
                    return `
                      <div class="grouped-row">
                        <div class="list-row-main" style="flex:1; min-width:0; cursor:pointer;" data-edit-bill="${b.id}">
                          <span class="avatar-badge">${escapeHtml(cat?.icon || '📅')}</span>
                          <div style="min-width:0;">
                            <div class="item-title">
                              ${escapeHtml(b.name)}
                              <span class="badge ${b.status === 'paid' ? 'badge-asset' : billsState.billFilter === 'overdue' ? 'badge-liability' : 'badge-muted'}">${escapeHtml(b.frequency)}</span>
                            </div>
                            <div class="item-meta">Due ${escapeHtml(b.due_date)}${acc ? ` · ${escapeHtml(acc.name)}` : ''}</div>
                          </div>
                        </div>
                        <div class="row-actions">
                          <strong style="font-variant-numeric:tabular-nums;">${fmt(b.amount_paise)}</strong>
                          ${
                            b.status !== 'paid'
                              ? `<button type="button" class="btn btn-primary btn-sm" data-pay-bill="${b.id}">Pay</button>`
                              : ''
                          }
                        </div>
                      </div>`;
                  })
                  .join('')}
              </div>`
        }
      </div>
    `;

    container.querySelectorAll('[data-bill-flt]').forEach((b) => {
      b.addEventListener('click', () => {
        billsState.billFilter = b.getAttribute('data-bill-flt');
        renderBillsView(container, ctx);
      });
    });
    container.querySelector('#btn-add-bill')?.addEventListener('click', () => openBillModal());
    container.querySelectorAll('[data-edit-bill]').forEach((el) => {
      el.addEventListener('click', async () => {
        const b = await repos.bills.getById(el.getAttribute('data-edit-bill'));
        if (b) openBillModal(b);
      });
    });
    container.querySelectorAll('[data-pay-bill]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const res = await services.billsRecurring.markBillPaid(btn.getAttribute('data-pay-bill'));
          showToast(
            res.nextBill
              ? `Bill marked paid & next cycle scheduled (${res.nextBill.due_date})`
              : 'Bill marked paid'
          );
          renderBillsView(container, ctx);
        } catch (err) {
          showToast(err.message, { type: 'error' });
        }
      });
    });
  } else if (billsState.tab === 'recurring') {
    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <div class="toolbar">
          <div class="item-meta">Review &amp; confirm by default; opt-in auto-post available per rule.</div>
          <button type="button" class="btn btn-primary btn-sm" id="btn-add-rec">+ Add Rule</button>
        </div>

        ${
          dueRules.length > 0
            ? `<section class="card stack" style="gap:10px; border-color:var(--accent);">
                <div class="card-title">Due for Review &amp; Confirm (${dueRules.length})</div>
                <div class="grouped-card">
                  ${dueRules
                    .map(
                      (r) => `
                      <div class="grouped-row" style="padding:10px 12px;">
                        <div>
                          <div class="item-title">${escapeHtml(r.name)}</div>
                          <div class="item-meta">Due ${escapeHtml(r.next_due_date)} · ${escapeHtml(r.type)} · ${fmt(r.amount_paise)}</div>
                        </div>
                        <div class="row-actions">
                          <button type="button" class="btn btn-primary btn-sm" data-post-rec="${r.id}">Post</button>
                          <button type="button" class="btn btn-secondary btn-sm" data-skip-rec="${r.id}">Skip</button>
                        </div>
                      </div>`
                    )
                    .join('')}
                </div>
              </section>`
            : ''
        }

        ${
          recurringRules.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🔁</div>
                <h3 class="empty-state-title">No recurring rules yet</h3>
                <p class="empty-state-text">Set up Salary, Rent, SIP, Insurance, Subscriptions, or Loan EMIs.</p>
              </div>`
            : `<div class="grouped-card">
                ${recurringRules
                  .map((r) => {
                    const acc = accMap.get(r.account_id);
                    return `
                      <div class="grouped-row grouped-row-clickable" data-edit-rec="${r.id}">
                        <div style="min-width:0;">
                          <div class="item-title">
                            ${escapeHtml(r.name)}
                            <span class="badge ${r.is_active ? 'badge-asset' : 'badge-muted'}">${r.is_active ? r.frequency : 'Paused'}</span>
                            ${r.auto_post ? '<span class="badge badge-accent">Auto</span>' : ''}
                          </div>
                          <div class="item-meta">Next: ${escapeHtml(r.next_due_date)} · ${escapeHtml(acc?.name || '')}</div>
                        </div>
                        <strong style="font-variant-numeric:tabular-nums;">${fmt(r.amount_paise)}</strong>
                      </div>`;
                  })
                  .join('')}
              </div>`
        }
      </div>
    `;

    container.querySelector('#btn-add-rec')?.addEventListener('click', () => openRecurringModal());
    container.querySelectorAll('[data-edit-rec]').forEach((el) => {
      el.addEventListener('click', async () => {
        const r = await repos.recurring.getById(el.getAttribute('data-edit-rec'));
        if (r) openRecurringModal(r);
      });
    });
    container.querySelectorAll('[data-post-rec]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const res = await services.billsRecurring.postRecurringOccurrence(btn.getAttribute('data-post-rec'));
          showToast(`Posted "${res.rule.name}" — next due ${res.rule.next_due_date}`);
          renderBillsView(container, ctx);
        } catch (err) {
          showToast(err.message, { type: 'error' });
        }
      });
    });
    container.querySelectorAll('[data-skip-rec]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await services.billsRecurring.skipRecurringOccurrence(btn.getAttribute('data-skip-rec'));
        showToast('Occurrence skipped to next cycle');
        renderBillsView(container, ctx);
      });
    });
  } else {
    // Reminders tab
    const totalAlerts = categorized.activeReminders.length + dueRules.length;
    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        ${
          totalAlerts === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🔔</div>
                <h3 class="empty-state-title">All caught up!</h3>
                <p class="empty-state-text">No pending bill reminders or due recurring transactions today.</p>
              </div>`
            : `<div class="grouped-card">
                ${categorized.activeReminders
                  .map(
                    (b) => `
                    <div class="grouped-row">
                      <div>
                        <div class="item-title">📅 ${escapeHtml(b.name)} (${fmt(b.amount_paise)})</div>
                        <div class="item-meta">Bill due ${escapeHtml(b.due_date)}</div>
                      </div>
                      <div class="row-actions">
                        <button type="button" class="btn btn-primary btn-sm" data-rem-pay="${b.id}">Pay</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-rem-snooze="${b.id}">+3d</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-rem-dismiss="${b.id}">✕</button>
                      </div>
                    </div>`
                  )
                  .join('')}
                ${dueRules
                  .map(
                    (r) => `
                    <div class="grouped-row">
                      <div>
                        <div class="item-title">🔁 ${escapeHtml(r.name)} (${fmt(r.amount_paise)})</div>
                        <div class="item-meta">Recurring due ${escapeHtml(r.next_due_date)}</div>
                      </div>
                      <div class="row-actions">
                        <button type="button" class="btn btn-primary btn-sm" data-post-rec="${r.id}">Post</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-skip-rec="${r.id}">Skip</button>
                      </div>
                    </div>`
                  )
                  .join('')}
              </div>`
        }
      </div>
    `;

    container.querySelectorAll('[data-rem-pay]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await services.billsRecurring.markBillPaid(btn.getAttribute('data-rem-pay'));
        showToast('Bill marked paid');
        renderBillsView(container, ctx);
      });
    });
    container.querySelectorAll('[data-rem-snooze]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await services.billsRecurring.snoozeBillReminder(btn.getAttribute('data-rem-snooze'), 3);
        showToast('Reminder snoozed for 3 days');
        renderBillsView(container, ctx);
      });
    });
    container.querySelectorAll('[data-rem-dismiss]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await services.billsRecurring.dismissBillReminder(btn.getAttribute('data-rem-dismiss'));
        showToast('Reminder dismissed');
        renderBillsView(container, ctx);
      });
    });
    container.querySelectorAll('[data-post-rec]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await services.billsRecurring.postRecurringOccurrence(btn.getAttribute('data-post-rec'));
        showToast('Recurring transaction posted');
        renderBillsView(container, ctx);
      });
    });
    container.querySelectorAll('[data-skip-rec]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await services.billsRecurring.skipRecurringOccurrence(btn.getAttribute('data-skip-rec'));
        showToast('Skipped to next cycle');
        renderBillsView(container, ctx);
      });
    });
  }

  container.querySelectorAll('[data-br-tab]').forEach((b) => {
    b.addEventListener('click', () => {
      billsState.tab = b.getAttribute('data-br-tab');
      renderBillsView(container, ctx);
    });
  });
}

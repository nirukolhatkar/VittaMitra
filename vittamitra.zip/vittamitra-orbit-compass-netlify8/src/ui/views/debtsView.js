import { escapeHtml } from '../../utils/dom.js';
import { formatINR, paiseToDecimalString, parseRupeesToPaise } from '../../utils/money.js';
import { toLocalDateString, toLocalDateTimeString } from '../../utils/date.js';
import { DEBT_EVENT_TYPES, DEBT_STATUS, DEBT_TYPES } from '../../db/repositories/debtRepository.js';
import { openModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { setPageContext } from '../../services/txContextClipboard.js';

const debtViewState = {
  tab: 'list', // 'list' | 'reminders' | 'analytics'
  selectedDebtId: null,
  direction: 'all', // 'all' | 'RECEIVABLE' | 'PAYABLE'
  status: 'all', // 'all' | 'active' | 'settled' | 'overdue'
  person: '',
  familyMemberId: '',
  startDate: '',
  endDate: '',
  search: '',
};

function downloadFileBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function statusBadgeHtml(status) {
  if (status === DEBT_STATUS.SETTLED) {
    return `<span class="badge badge-asset">Settled</span>`;
  }
  if (status === DEBT_STATUS.OVERDUE) {
    return `<span class="badge badge-liability">Overdue</span>`;
  }
  if (status === DEBT_STATUS.PARTIALLY_SETTLED) {
    return `<span class="badge" style="background:rgba(56,189,248,0.16); color:#38bdf8;">Partial</span>`;
  }
  if (status === DEBT_STATUS.WRITTEN_OFF) {
    return `<span class="badge badge-muted">Written Off</span>`;
  }
  return `<span class="badge badge-accent">Active</span>`;
}

function eventLabel(type) {
  const map = {
    [DEBT_EVENT_TYPES.LENT]: 'Money Lent',
    [DEBT_EVENT_TYPES.BORROWED]: 'Money Borrowed',
    [DEBT_EVENT_TYPES.PRINCIPAL_RECEIVED]: 'Repayment Received',
    [DEBT_EVENT_TYPES.PRINCIPAL_PAID]: 'Repayment Paid',
    [DEBT_EVENT_TYPES.INTEREST_RECEIVED]: 'Interest Received',
    [DEBT_EVENT_TYPES.INTEREST_PAID]: 'Interest Paid',
    [DEBT_EVENT_TYPES.PRINCIPAL_ADJUSTMENT]: 'Principal Adjustment',
    [DEBT_EVENT_TYPES.DEBT_WRITTEN_OFF]: 'Written Off',
    [DEBT_EVENT_TYPES.DEBT_FORGIVEN]: 'Debt Forgiven',
  };
  return map[type] || type;
}

export async function renderDebtsView(container, ctx) {
  const { repos, services, state } = ctx;
  if (state.selectedDebtId) {
    debtViewState.selectedDebtId = state.selectedDebtId;
    state.selectedDebtId = null;
  }

  const [settings, accounts, family] = await Promise.all([
    repos.settings.getSettings(),
    repos.accounts.list({ includeArchived: false }),
    repos.family.list({ includeInactive: false }),
  ]);

  // Debt source/destination accounts: bank, cash, wallet (exclude credit cards per scope)
  const cashAccounts = accounts.filter((a) => a.type !== 'credit_card');
  const accMap = new Map(accounts.map((a) => [a.id, a]));
  const famMap = new Map(family.map((f) => [f.id, f]));
  const show = settings.show_balances !== false;
  const fmt = (p) => (show ? formatINR(p) : '*****');

  // ---------- Modals ----------
  const openCreateDebtModal = (debtType) => {
    const isLent = debtType === DEBT_TYPES.RECEIVABLE;
    const nowTs = toLocalDateTimeString();
    if (cashAccounts.length === 0) {
      showToast('Create at least one Bank, Cash, or Wallet account first.', { type: 'error' });
      return;
    }

    openModal({
      title: isLent ? '💸 Lend Money (Receivable)' : '🤝 Borrow Money (Payable)',
      bodyHtml: `
        <form id="debt-create-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Person's Name</label>
              <input name="counterparty_name" class="form-control" required maxlength="60" placeholder="e.g. Rahul, Uncle">
            </div>
            <div class="form-group">
              <label class="form-label">Contact (Optional)</label>
              <input name="counterparty_contact" class="form-control" maxlength="40" placeholder="Phone / Note">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Amount (₹)</label>
              <input name="amount_rupees" class="form-control" inputmode="decimal" required placeholder="10000">
            </div>
            <div class="form-group">
              <label class="form-label">${isLent ? 'Source Account' : 'Destination Account'}</label>
              <select name="account_id" class="form-control" required>
                ${cashAccounts.map((a) => `<option value="${a.id}">${escapeHtml(a.icon)} ${escapeHtml(a.name)}</option>`).join('')}
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Date</label>
              <input name="date" type="date" class="form-control" required value="${toLocalDateString()}">
            </div>
            <div class="form-group">
              <label class="form-label">Time</label>
              <input name="time" type="time" class="form-control" required value="${nowTs.slice(11, 16)}">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Expected Repayment Date</label>
              <input name="expected_repayment_date" type="date" class="form-control">
            </div>
            <div class="form-group">
              <label class="form-label">Interest Rate (% p.a., opt.)</label>
              <input name="interest_rate" type="number" step="0.1" min="0" class="form-control" placeholder="0">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Family Attribution</label>
              <select name="family_member_id" class="form-control">
                <option value="">Unassigned</option>
                ${family.map((m) => `<option value="${m.id}">${escapeHtml(m.icon)} ${escapeHtml(m.name)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Attachment (opt., max 5MB)</label>
              <input id="debt-init-att" type="file" accept="image/*,application/pdf" class="form-control" style="padding:5px; font-size:0.8rem;">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Description &amp; Notes</label>
            <input name="description" class="form-control" maxlength="120" placeholder="${isLent ? 'e.g. Emergency help for Rahul' : 'e.g. Short-term bridge loan'}">
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">${isLent ? 'Record Lending' : 'Record Borrowing'}</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#debt-create-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            const res = await services.debts.createDebt({
              debt_type: debtType,
              counterparty_name: fd.get('counterparty_name'),
              counterparty_contact: fd.get('counterparty_contact'),
              amount_rupees: fd.get('amount_rupees'),
              account_id: fd.get('account_id'),
              date: fd.get('date'),
              time: fd.get('time'),
              expected_repayment_date: fd.get('expected_repayment_date') || null,
              interest_rate: fd.get('interest_rate') || null,
              family_member_id: fd.get('family_member_id') || null,
              description: fd.get('description'),
            });
            const attInput = panel.querySelector('#debt-init-att');
            if (attInput?.files?.[0] && res.transaction) {
              await repos.attachments.saveAttachment(res.transaction.id, attInput.files[0]);
            }
            showToast(isLent ? 'Money lent recorded in ledger' : 'Money borrowed recorded in ledger');
            close();
            renderDebtsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openRepaymentModal = (debt, { interestOnly = false } = {}) => {
    const isRec = debt.debt_type === DEBT_TYPES.RECEIVABLE;
    const outPaise = debt.reconciliation.outstandingPrincipalPaise;
    openModal({
      title: interestOnly
        ? `💹 Record Interest (${debt.counterparty_name})`
        : `💵 Record Repayment (${debt.counterparty_name})`,
      bodyHtml: `
        <form id="debt-repay-form">
          ${
            !interestOnly
              ? `<div class="card" style="background:var(--bg-surface-elevated); padding:10px; margin-bottom:10px;">
                  <div class="item-meta">Outstanding Principal: <strong>${fmt(outPaise)}</strong></div>
                </div>`
              : ''
          }
          <div class="form-row">
            ${
              !interestOnly
                ? `<div class="form-group">
                    <label class="form-label">Principal Amount (₹)</label>
                    <input name="principal_rupees" class="form-control" inputmode="decimal"
                      value="${paiseToDecimalString(outPaise)}" placeholder="0.00">
                  </div>`
                : ''
            }
            <div class="form-group">
              <label class="form-label">Interest ${isRec ? 'Received' : 'Paid'} (₹)</label>
              <input name="interest_rupees" class="form-control" inputmode="decimal"
                value="${interestOnly ? '' : '0'}" ${interestOnly ? 'required' : ''} placeholder="0.00">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">${isRec ? 'Receiving Account' : 'Paying Account'}</label>
              <select name="account_id" class="form-control" required>
                ${cashAccounts.map((a) => `<option value="${a.id}">${escapeHtml(a.icon)} ${escapeHtml(a.name)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Date</label>
              <input name="date" type="date" class="form-control" required value="${toLocalDateString()}">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Notes (Optional)</label>
            <input name="notes" class="form-control" maxlength="120" placeholder="e.g. Partial UPI settlement">
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Save to Ledger</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#debt-repay-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await services.debts.recordRepayment(debt.id, {
              account_id: fd.get('account_id'),
              principal_rupees: interestOnly ? '0' : (fd.get('principal_rupees') || '0'),
              interest_rupees: fd.get('interest_rupees') || '0',
              date: fd.get('date'),
              notes: fd.get('notes'),
            });
            showToast(interestOnly ? 'Interest recorded in ledger' : 'Repayment recorded & balance reconciled');
            close();
            renderDebtsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openAdjustmentModal = (debt) => {
    const isRec = debt.debt_type === DEBT_TYPES.RECEIVABLE;
    const outPaise = debt.reconciliation.outstandingPrincipalPaise;
    openModal({
      title: `⚖️ Auditable Adjustment / ${isRec ? 'Write-Off' : 'Forgive'}`,
      bodyHtml: `
        <form id="debt-adj-form">
          <p class="card-subtitle" style="margin-bottom:10px;">
            Outstanding balances cannot be edited directly. Every change creates an auditable ledger event.
          </p>
          <div class="form-group">
            <label class="form-label">Action Type</label>
            <select name="event_type" class="form-control">
              <option value="${isRec ? DEBT_EVENT_TYPES.DEBT_WRITTEN_OFF : DEBT_EVENT_TYPES.DEBT_FORGIVEN}">
                ${isRec ? 'Write Off Uncollectible Receivable' : 'Mark Payable Forgiven'}
              </option>
              <option value="${DEBT_EVENT_TYPES.PRINCIPAL_ADJUSTMENT}">Principal Adjustment (+/-)</option>
            </select>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Amount (₹)</label>
              <input name="amount_rupees" class="form-control" inputmode="decimal" required
                value="${paiseToDecimalString(outPaise)}">
            </div>
            <div class="form-group">
              <label class="form-label">Date</label>
              <input name="date" type="date" class="form-control" required value="${toLocalDateString()}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Reason / Audit Note</label>
            <input name="notes" class="form-control" required maxlength="120" placeholder="e.g. Mutual settlement discount">
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Record Auditable Event</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#debt-adj-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await services.debts.recordAdjustmentOrWriteOff(debt.id, {
              event_type: fd.get('event_type'),
              amount_rupees: fd.get('amount_rupees'),
              date: fd.get('date'),
              notes: fd.get('notes'),
            });
            showToast('Auditable adjustment recorded');
            close();
            renderDebtsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openEditDetailsModal = (debt) => {
    openModal({
      title: 'Edit Debt Details (Metadata Only)',
      bodyHtml: `
        <form id="debt-edit-meta-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Person's Name</label>
              <input name="counterparty_name" class="form-control" required value="${escapeHtml(debt.counterparty_name)}">
            </div>
            <div class="form-group">
              <label class="form-label">Contact</label>
              <input name="counterparty_contact" class="form-control" value="${escapeHtml(debt.counterparty_contact || '')}">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Expected Repayment Date</label>
              <input name="expected_repayment_date" type="date" class="form-control" value="${escapeHtml(debt.expected_repayment_date || '')}">
            </div>
            <div class="form-group">
              <label class="form-label">Interest Rate (% p.a.)</label>
              <input name="interest_rate" type="number" step="0.1" class="form-control" value="${debt.interest_rate ?? ''}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Description</label>
            <input name="description" class="form-control" value="${escapeHtml(debt.description || '')}">
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <input name="notes" class="form-control" value="${escapeHtml(debt.notes || '')}">
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Save Details</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#debt-edit-meta-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            await services.debts.editDebtDetails(debt.id, {
              counterparty_name: fd.get('counterparty_name'),
              counterparty_contact: fd.get('counterparty_contact'),
              expected_repayment_date: fd.get('expected_repayment_date') || null,
              interest_rate: fd.get('interest_rate'),
              description: fd.get('description'),
              notes: fd.get('notes'),
            });
            showToast('Debt details updated');
            close();
            renderDebtsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  const openEditEventModal = (ev) => {
    openModal({
      title: `Edit Event: ${eventLabel(ev.event_type)}`,
      bodyHtml: `
        <form id="debt-edit-ev-form">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Principal (₹)</label>
              <input name="principal_rupees" class="form-control" inputmode="decimal" value="${paiseToDecimalString(ev.principal_paise || 0)}">
            </div>
            <div class="form-group">
              <label class="form-label">Interest (₹)</label>
              <input name="interest_rupees" class="form-control" inputmode="decimal" value="${paiseToDecimalString(ev.interest_paise || 0)}">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Date</label>
              <input name="event_date" type="date" class="form-control" required value="${escapeHtml(ev.event_date || '')}">
            </div>
            ${
              ev.account_id
                ? `<div class="form-group">
                    <label class="form-label">Account</label>
                    <select name="account_id" class="form-control">
                      ${cashAccounts.map((a) => `<option value="${a.id}" ${a.id === ev.account_id ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
                    </select>
                  </div>`
                : ''
            }
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <input name="notes" class="form-control" value="${escapeHtml(ev.notes || '')}">
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="flex:1;">Update Event &amp; Ledger</button>
          </div>
        </form>
      `,
      onMount: (panel, close) => {
        panel.querySelector('#debt-edit-ev-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(e.target);
          try {
            const pPaise = parseRupeesToPaise(fd.get('principal_rupees') || '0', {
              allowZero: true,
              allowNegative: ev.event_type === DEBT_EVENT_TYPES.PRINCIPAL_ADJUSTMENT,
            });
            const iPaise = parseRupeesToPaise(fd.get('interest_rupees') || '0', { allowZero: true, allowNegative: false });
            await services.debts.editDebtEvent(ev.id, {
              principal_paise: pPaise,
              interest_paise: iPaise,
              event_date: fd.get('event_date'),
              account_id: fd.get('account_id') || ev.account_id,
              notes: fd.get('notes'),
            });
            showToast('Event & linked ledger postings updated');
            close();
            renderDebtsView(container, ctx);
          } catch (err) {
            showToast(err.message, { type: 'error' });
          }
        });
      },
    });
  };

  // ---------- Dedicated Debt Detail Screen ----------
  if (debtViewState.selectedDebtId) {
    const detail = await services.debts.getDebtDetail(debtViewState.selectedDebtId);
    if (!detail) {
      debtViewState.selectedDebtId = null;
      return renderDebtsView(container, ctx);
    }

    const r = detail.reconciliation;
    const isRec = detail.debt_type === DEBT_TYPES.RECEIVABLE;
    const fam = detail.family_member_id ? famMap.get(detail.family_member_id) : null;

    // Fetch attachments linked to any transaction of this debt
    const allAtts = [];
    for (const ev of r.events) {
      if (ev.transaction_id) {
        const atts = await repos.attachments.listByTransaction(ev.transaction_id);
        allAtts.push(...atts);
      }
    }

    container.innerHTML = `
      <div class="stack">
        <div class="toolbar">
          <button type="button" class="btn btn-secondary btn-sm" id="btn-debt-back">← All Debts</button>
          ${statusBadgeHtml(detail.status)}
        </div>

        <section class="hero-card">
          <div class="toolbar" style="margin-bottom:4px;">
            <span class="hero-label">${isRec ? '💸 Lent to (Receivable)' : '🤝 Borrowed from (Payable)'}</span>
            ${detail.expected_repayment_date ? `<span class="item-meta">Due ${escapeHtml(detail.expected_repayment_date)}</span>` : ''}
          </div>
          <div class="item-title" style="font-size:1.15rem;">${escapeHtml(detail.counterparty_name)}</div>
          ${detail.counterparty_contact ? `<div class="item-meta">${escapeHtml(detail.counterparty_contact)}</div>` : ''}
          <div class="hero-balance" style="margin-top:6px;">${fmt(r.outstandingPrincipalPaise)}</div>
          <div class="item-meta">Outstanding Principal (${r.progressPct}% cleared)</div>

          <div class="progress-track" style="height:7px; margin:10px 0;">
            <div class="progress-fill" style="width:${r.progressPct}%; background:${isRec ? '#22c55e' : '#38bdf8'};"></div>
          </div>

          <div class="grid-3" style="gap:8px;">
            <div>
              <div class="item-meta">Original</div>
              <div class="item-title" style="font-size:0.86rem;">${fmt(r.originalPrincipalPaise)}</div>
            </div>
            <div>
              <div class="item-meta">Repaid</div>
              <div class="item-title text-success" style="font-size:0.86rem;">${fmt(r.principalRepaidPaise)}</div>
            </div>
            <div>
              <div class="item-meta">Interest ${isRec ? 'Recd' : 'Paid'}</div>
              <div class="item-title" style="font-size:0.86rem; color:var(--accent);">${fmt(r.interestTotalPaise)}</div>
            </div>
          </div>
        </section>

        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          ${r.outstandingPrincipalPaise > 0 ? `<button type="button" class="btn btn-primary btn-sm" id="btn-rec-repay">+ Record Repayment</button>` : ''}
          <button type="button" class="btn btn-secondary btn-sm" id="btn-rec-int">+ Interest</button>
          ${r.outstandingPrincipalPaise > 0 ? `<button type="button" class="btn btn-secondary btn-sm" id="btn-rec-adj">⚖️ Adjust / ${isRec ? 'Write-Off' : 'Forgive'}</button>` : ''}
          <button type="button" class="btn btn-secondary btn-sm" id="btn-edit-meta">Edit Details</button>
          <button type="button" class="btn btn-danger btn-sm" id="btn-del-debt">Delete</button>
        </div>

        <section class="card stack" style="gap:6px;">
          <div class="item-meta"><strong>Started:</strong> ${escapeHtml(detail.start_date)} ${detail.interest_rate ? `· Rate: ${detail.interest_rate}% p.a.` : ''} ${fam ? `· ${escapeHtml(fam.name)}` : ''}</div>
          ${detail.description ? `<div class="item-meta"><strong>Description:</strong> ${escapeHtml(detail.description)}</div>` : ''}
          ${detail.notes ? `<div class="item-meta"><strong>Notes:</strong> ${escapeHtml(detail.notes)}</div>` : ''}
          ${
            allAtts.length > 0
              ? `<div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:4px;">
                  ${allAtts.map((a) => `<button type="button" class="btn btn-secondary btn-sm" data-view-debt-att="${a.local_blob_key}">📎 ${escapeHtml(a.file_name)}</button>`).join('')}
                </div>`
              : ''
          }
        </section>

        <section class="stack" style="gap:8px;">
          <div class="section-heading">
            <span class="section-heading-left">Chronological Event History (${r.events.length})</span>
            <span class="item-meta">Linked to Central Ledger</span>
          </div>
          <div class="grouped-card">
            ${r.events
              .map((ev) => {
                const acc = ev.account_id ? accMap.get(ev.account_id) : null;
                return `
                  <div class="grouped-row" style="align-items:flex-start;">
                    <div style="flex:1; min-width:0;">
                      <div class="item-title" style="font-size:0.86rem;">${escapeHtml(eventLabel(ev.event_type))}</div>
                      <div class="item-meta">
                        ${escapeHtml(ev.event_date)} ${acc ? `· ${escapeHtml(acc.name)}` : ''}
                        ${ev.notes ? ` · ${escapeHtml(ev.notes)}` : ''}
                      </div>
                      <div class="item-meta" style="margin-top:3px;">
                        ${ev.principal_paise ? `Principal: <strong>${fmt(ev.principal_paise)}</strong>` : ''}
                        ${ev.interest_paise ? `${ev.principal_paise ? ' · ' : ''}Interest: <strong class="text-success">${fmt(ev.interest_paise)}</strong>` : ''}
                      </div>
                    </div>
                    <div class="row-actions">
                      <button type="button" class="btn btn-secondary btn-sm" data-edit-ev="${ev.id}" title="Edit event">✏️</button>
                      <button type="button" class="btn btn-danger btn-sm" data-del-ev="${ev.id}" title="Delete & reverse ledger">🗑</button>
                    </div>
                  </div>
                `;
              })
              .join('')}
          </div>
        </section>
      </div>
    `;

    container.querySelector('#btn-debt-back')?.addEventListener('click', () => {
      debtViewState.selectedDebtId = null;
      renderDebtsView(container, ctx);
    });
    container.querySelector('#btn-rec-repay')?.addEventListener('click', () => openRepaymentModal(detail, { interestOnly: false }));
    container.querySelector('#btn-rec-int')?.addEventListener('click', () => openRepaymentModal(detail, { interestOnly: true }));
    container.querySelector('#btn-rec-adj')?.addEventListener('click', () => openAdjustmentModal(detail));
    container.querySelector('#btn-edit-meta')?.addEventListener('click', () => openEditDetailsModal(detail));
    container.querySelector('#btn-del-debt')?.addEventListener('click', async () => {
      try {
        await services.debts.deleteDebt(detail.id);
        debtViewState.selectedDebtId = null;
        showToast('Debt deleted');
        renderDebtsView(container, ctx);
      } catch (err) {
        showToast(err.message, { type: 'error', durationMs: 4500 });
      }
    });
    container.querySelectorAll('[data-edit-ev]').forEach((b) => {
      b.addEventListener('click', () => {
        const ev = r.events.find((e) => e.id === b.getAttribute('data-edit-ev'));
        if (ev) openEditEventModal(ev);
      });
    });
    container.querySelectorAll('[data-del-ev]').forEach((b) => {
      b.addEventListener('click', async () => {
        await services.debts.deleteDebtEvent(b.getAttribute('data-del-ev'));
        showToast('Event deleted & ledger reversed');
        renderDebtsView(container, ctx);
      });
    });
    container.querySelectorAll('[data-view-debt-att]').forEach((b) => {
      b.addEventListener('click', async () => {
        const blob = await repos.attachments.getBlob(b.getAttribute('data-view-debt-att'));
        if (blob) window.open(URL.createObjectURL(blob), '_blank');
      });
    });
    return;
  }

  // ---------- Main Debt Tracker Dashboard ----------
  const summary = await services.debts.getDashboardSummary({
    direction: debtViewState.direction,
    status: debtViewState.status,
    person: debtViewState.person,
    familyMemberId: debtViewState.familyMemberId,
    startDate: debtViewState.startDate,
    endDate: debtViewState.endDate,
    search: debtViewState.search,
  });

  const uniquePersons = Array.from(new Set(summary.allDebts.map((d) => d.counterparty_name))).sort();

  const tabBar = `
    <div class="segmented" style="width:100%; justify-content:space-between;">
      <button type="button" style="flex:1;" data-debt-tab="list" class="${debtViewState.tab === 'list' ? 'active' : ''}">Debts (${summary.allDebts.length})</button>
      <button type="button" style="flex:1;" data-debt-tab="reminders" class="${debtViewState.tab === 'reminders' ? 'active' : ''}">Reminders (${summary.reminders.length})</button>
      <button type="button" style="flex:1;" data-debt-tab="analytics" class="${debtViewState.tab === 'analytics' ? 'active' : ''}">Insights &amp; Export</button>
    </div>
  `;

  if (debtViewState.tab === 'reminders') {
    container.innerHTML = `
      <div class="stack">
        ${tabBar}
        ${
          summary.reminders.length === 0
            ? `<div class="empty-state">
                <div class="empty-state-icon">🔔</div>
                <h3 class="empty-state-title">No upcoming or overdue debt reminders</h3>
                <p class="empty-state-text">Set an optional Expected Repayment Date on any lent or borrowed debt to track reminders here.</p>
              </div>`
            : `<div class="grouped-card">
                ${summary.reminders
                  .map(
                    ({ debt, isOverdue, dueDate }) => `
                    <div class="grouped-row" style="align-items:flex-start;">
                      <div style="flex:1; min-width:0; cursor:pointer;" data-open-debt="${debt.id}">
                        <div class="item-title">
                          ${escapeHtml(debt.counterparty_name)}
                          ${isOverdue ? '<span class="badge badge-liability">Overdue</span>' : '<span class="badge badge-accent">Upcoming</span>'}
                        </div>
                        <div class="item-meta">
                          ${debt.debt_type === DEBT_TYPES.RECEIVABLE ? 'Receivable' : 'Payable'} · Due ${escapeHtml(dueDate)} · Outstanding ${fmt(debt.reconciliation.outstandingPrincipalPaise)}
                        </div>
                      </div>
                      <div class="row-actions">
                        <button type="button" class="btn btn-primary btn-sm" data-quick-repay="${debt.id}">Repay</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-dismiss-rem="${debt.id}">Dismiss</button>
                      </div>
                    </div>`
                  )
                  .join('')}
              </div>`
        }
      </div>
    `;
    container.querySelectorAll('[data-open-debt]').forEach((el) => {
      el.addEventListener('click', () => {
        debtViewState.selectedDebtId = el.getAttribute('data-open-debt');
        renderDebtsView(container, ctx);
      });
    });
    container.querySelectorAll('[data-quick-repay]').forEach((b) => {
      b.addEventListener('click', () => {
        const d = summary.allDebts.find((x) => x.id === b.getAttribute('data-quick-repay'));
        if (d) openRepaymentModal(d);
      });
    });
    container.querySelectorAll('[data-dismiss-rem]').forEach((b) => {
      b.addEventListener('click', async () => {
        await services.debts.dismissReminder(b.getAttribute('data-dismiss-rem'));
        showToast('Reminder dismissed');
        renderDebtsView(container, ctx);
      });
    });
  } else if (debtViewState.tab === 'analytics') {
    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <section class="grid-2">
          <div class="metric-card">
            <div class="metric-label">Total Lent</div>
            <div class="item-title">${fmt(summary.totalLentPaise)}</div>
            <div class="item-meta text-success">Recovered: ${fmt(summary.totalPrincipalRecoveredPaise)}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Total Borrowed</div>
            <div class="item-title">${fmt(summary.totalBorrowedPaise)}</div>
            <div class="item-meta text-success">Repaid: ${fmt(summary.totalPrincipalRepaidPaise)}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Outstanding Receivables</div>
            <div class="item-title text-success">${fmt(summary.totalReceivablesPaise)}</div>
            <div class="item-meta text-danger">Overdue: ${fmt(summary.overdueReceivablesPaise)}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Outstanding Payables</div>
            <div class="item-title text-danger">${fmt(summary.totalPayablesPaise)}</div>
            <div class="item-meta text-danger">Overdue: ${fmt(summary.overduePayablesPaise)}</div>
          </div>
        </section>

        <section class="card stack" style="gap:8px;">
          <div class="card-title">Person-Wise Outstanding Balances</div>
          ${
            summary.personWise.length === 0
              ? '<div class="item-meta">No active outstanding balances.</div>'
              : `<div class="grouped-card">
                  ${summary.personWise
                    .map(
                      (p) => `
                      <div class="grouped-row">
                        <div>
                          <div class="item-title">${escapeHtml(p.name)}</div>
                          <div class="item-meta">Lent: ${fmt(p.receivablePaise)} · Borrowed: ${fmt(p.payablePaise)}</div>
                        </div>
                        <strong class="${p.netPaise >= 0 ? 'text-success' : 'text-danger'}">
                          ${p.netPaise >= 0 ? '+' : ''}${fmt(p.netPaise)}
                        </strong>
                      </div>`
                    )
                    .join('')}
                </div>`
          }
        </section>

        <section class="card stack" style="gap:10px;">
          <div>
            <div class="card-title">📥 Export Debt Register</div>
            <p class="card-subtitle">Exports all debts with Debt ID, Counterparty, Type, Original, Repaid, Outstanding, Interest, Dates &amp; Status.</p>
          </div>
          <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" style="flex:1;" id="btn-export-debt-xlsx">📥 Download Excel (.xlsx)</button>
            <button type="button" class="btn btn-secondary" id="btn-export-debt-csv">📄 Download CSV</button>
          </div>
        </section>
      </div>
    `;

    container.querySelector('#btn-export-debt-xlsx')?.addEventListener('click', async () => {
      const { bytes, rowCount } = await services.debts.exportDebtRegisterXlsx();
      downloadFileBlob(
        new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
        `VittaMitra_Debt_Register_${toLocalDateString()}.xlsx`
      );
      showToast(`Exported ${rowCount} debts to Excel`);
    });
    container.querySelector('#btn-export-debt-csv')?.addEventListener('click', async () => {
      const { csv, rowCount } = await services.debts.exportDebtRegisterCsv();
      downloadFileBlob(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `VittaMitra_Debt_Register_${toLocalDateString()}.csv`);
      showToast(`Exported ${rowCount} debts to CSV`);
    });
  } else {
    // List Dashboard Tab
    container.innerHTML = `
      <div class="stack">
        ${tabBar}

        <div style="display:flex; gap:8px;">
          <button type="button" class="btn btn-primary" style="flex:1;" id="btn-lend-money">💸 Lend Money</button>
          <button type="button" class="btn btn-secondary" style="flex:1;" id="btn-borrow-money">🤝 Borrow Money</button>
        </div>

        <section class="grid-3" style="gap:8px;">
          <div class="metric-card" style="padding:10px;">
            <div class="metric-label">Receivables</div>
            <div class="item-title text-success" style="font-size:0.92rem;">${fmt(summary.totalReceivablesPaise)}</div>
            ${summary.overdueReceivablesPaise > 0 ? `<div class="item-meta text-danger">Due: ${fmt(summary.overdueReceivablesPaise)}</div>` : ''}
          </div>
          <div class="metric-card" style="padding:10px;">
            <div class="metric-label">Payables</div>
            <div class="item-title text-danger" style="font-size:0.92rem;">${fmt(summary.totalPayablesPaise)}</div>
            ${summary.overduePayablesPaise > 0 ? `<div class="item-meta text-danger">Due: ${fmt(summary.overduePayablesPaise)}</div>` : ''}
          </div>
          <div class="metric-card" style="padding:10px;">
            <div class="metric-label">Net Position</div>
            <div class="item-title ${summary.netDebtPositionPaise >= 0 ? 'text-success' : 'text-danger'}" style="font-size:0.92rem;">
              ${summary.netDebtPositionPaise >= 0 ? '+' : ''}${fmt(summary.netDebtPositionPaise)}
            </div>
          </div>
        </section>

        <!-- Search & Filters (non-blurring search input) -->
        <div class="stack" style="gap:8px;">
          <input id="debt-search-input" type="search" class="search-input-pill"
            placeholder="🔍 Search by person's name or description…" value="${escapeHtml(debtViewState.search)}">

          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <select id="debt-f-dir" class="filter-inline-select">
              <option value="all" ${debtViewState.direction === 'all' ? 'selected' : ''}>All Directions</option>
              <option value="${DEBT_TYPES.RECEIVABLE}" ${debtViewState.direction === DEBT_TYPES.RECEIVABLE ? 'selected' : ''}>Lent (Receivable)</option>
              <option value="${DEBT_TYPES.PAYABLE}" ${debtViewState.direction === DEBT_TYPES.PAYABLE ? 'selected' : ''}>Borrowed (Payable)</option>
            </select>
            <select id="debt-f-status" class="filter-inline-select">
              <option value="all" ${debtViewState.status === 'all' ? 'selected' : ''}>All Statuses</option>
              <option value="active" ${debtViewState.status === 'active' ? 'selected' : ''}>Active</option>
              <option value="overdue" ${debtViewState.status === 'overdue' ? 'selected' : ''}>Overdue</option>
              <option value="settled" ${debtViewState.status === 'settled' ? 'selected' : ''}>Settled</option>
            </select>
            ${
              uniquePersons.length > 0
                ? `<select id="debt-f-person" class="filter-inline-select">
                    <option value="">All People</option>
                    ${uniquePersons.map((p) => `<option value="${escapeHtml(p)}" ${debtViewState.person === p ? 'selected' : ''}>${escapeHtml(p)}</option>`).join('')}
                  </select>`
                : ''
            }
          </div>
        </div>

        <div id="debt-list-slot" class="stack"></div>
      </div>
    `;

    const listSlot = container.querySelector('#debt-list-slot');
    const renderListOnly = async () => {
      const cur = await services.debts.getDashboardSummary({
        direction: debtViewState.direction,
        status: debtViewState.status,
        person: debtViewState.person,
        familyMemberId: debtViewState.familyMemberId,
        startDate: debtViewState.startDate,
        endDate: debtViewState.endDate,
        search: debtViewState.search,
      });

      if (cur.debts.length === 0) {
        listSlot.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon">🤝</div>
            <h3 class="empty-state-title">No debt records found</h3>
            <p class="empty-state-text">Tap <strong>Lend Money</strong> or <strong>Borrow Money</strong> above to log a personal debt with full double-entry ledger integration.</p>
          </div>
        `;
        return;
      }

      listSlot.innerHTML = cur.debts
        .map((d) => {
          const r = d.reconciliation;
          const isRec = d.debt_type === DEBT_TYPES.RECEIVABLE;
          return `
            <article class="card stack" style="gap:8px; cursor:pointer;" data-open-debt="${d.id}">
              <div class="toolbar">
                <div>
                  <div class="item-title">${escapeHtml(d.counterparty_name)}</div>
                  <div class="item-meta">
                    ${isRec ? 'Lent (Receivable)' : 'Borrowed (Payable)'}
                    ${d.expected_repayment_date ? ` · Due ${escapeHtml(d.expected_repayment_date)}` : ''}
                  </div>
                </div>
                ${statusBadgeHtml(d.status)}
              </div>

              <div class="grid-3" style="gap:6px;">
                <div>
                  <div class="item-meta">Original</div>
                  <div class="item-title" style="font-size:0.84rem;">${fmt(r.originalPrincipalPaise)}</div>
                </div>
                <div>
                  <div class="item-meta">Repaid</div>
                  <div class="item-title text-success" style="font-size:0.84rem;">${fmt(r.principalRepaidPaise)}</div>
                </div>
                <div>
                  <div class="item-meta">Outstanding</div>
                  <div class="item-title ${isRec ? 'text-success' : 'text-danger'}" style="font-size:0.84rem;">${fmt(r.outstandingPrincipalPaise)}</div>
                </div>
              </div>

              <div class="progress-track" style="height:5px;">
                <div class="progress-fill" style="width:${r.progressPct}%; background:${isRec ? '#22c55e' : '#38bdf8'};"></div>
              </div>
            </article>
          `;
        })
        .join('');

      listSlot.querySelectorAll('[data-open-debt]').forEach((card) => {
        card.addEventListener('click', () => {
          debtViewState.selectedDebtId = card.getAttribute('data-open-debt');
          renderDebtsView(container, ctx);
        });
      });
    };

    await renderListOnly();

    container.querySelector('#btn-lend-money')?.addEventListener('click', () => openCreateDebtModal(DEBT_TYPES.RECEIVABLE));
    container.querySelector('#btn-borrow-money')?.addEventListener('click', () => openCreateDebtModal(DEBT_TYPES.PAYABLE));
    container.querySelector('#debt-search-input')?.addEventListener('input', (e) => {
      debtViewState.search = e.target.value;
      renderListOnly();
    });
    container.querySelector('#debt-f-dir')?.addEventListener('change', (e) => {
      debtViewState.direction = e.target.value;
      renderListOnly();
    });
    container.querySelector('#debt-f-status')?.addEventListener('change', (e) => {
      debtViewState.status = e.target.value;
      renderListOnly();
    });
    container.querySelector('#debt-f-person')?.addEventListener('change', (e) => {
      debtViewState.person = e.target.value;
      renderListOnly();
    });
  }

  container.querySelectorAll('[data-debt-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      debtViewState.tab = btn.getAttribute('data-debt-tab');
      renderDebtsView(container, ctx);
    });
  });
}

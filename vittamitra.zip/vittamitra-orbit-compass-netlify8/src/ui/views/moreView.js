import { getStorageDiagnostics } from '../../services/storageService.js';
import { formatINR } from '../../utils/money.js';

export async function renderMoreView(container, ctx) {
  const { db, repos, services } = ctx;
  const [settings, categories, family, tags, txs, budgets, categorizedBills, dueRecurring, nw, debtSummary, diag] = await Promise.all([
    repos.settings.getSettings(),
    repos.categories.list({ includeArchived: false }),
    repos.family.list({ includeInactive: false }),
    repos.tags.list({ includeArchived: false }),
    services.transactions.listTransactions(),
    repos.budgets.listAll(),
    services.billsRecurring.getBillsCategorized(),
    services.billsRecurring.getDueRecurringRules(),
    services.wealth.getNetWorthSummary(),
    services.debts.getDashboardSummary(),
    getStorageDiagnostics(db),
  ]);

  const show = settings.show_balances !== false;
  const overdueCount = categorizedBills.overdue.length;
  const upcomingCount = categorizedBills.upcoming.length;
  const dueRecCount = dueRecurring.length;
  const billsSub = overdueCount > 0
    ? `${overdueCount} overdue · ${upcomingCount} upcoming`
    : dueRecCount > 0
      ? `${dueRecCount} recurring due`
      : `${upcomingCount} upcoming`;

  const driveSub = settings.gdrive_connected
    ? `Auto-backup ${settings.gdrive_auto_upload !== false ? 'ON' : 'paused'} · ${settings.gdrive_last_backup_at ? String(settings.gdrive_last_backup_at).slice(0, 10) : 'Connected'}`
    : 'Connect once for scheduled auto-backup & recovery';

  const debtNet = debtSummary.netDebtPositionPaise;
  const debtSub = debtSummary.allDebts.length > 0
    ? (show ? `Net ${debtNet >= 0 ? '+' : ''}${formatINR(debtNet)}` : `${debtSummary.allDebts.length} active`)
    : 'Lent & Borrowed';

  container.innerHTML = `
    <div class="stack">
      <div class="card">
        <div class="list-row-main" style="justify-content:space-between;">
          <div class="list-row-main">
            <span class="brand-mark">₹</span>
            <div>
              <div class="item-title">Personal Finance Manager</div>
              <div class="item-meta">
                Offline-first PWA · ${diag.online ? 'Online' : 'Offline'} · ${txs.length.toLocaleString('en-IN')} tx
              </div>
            </div>
          </div>
          <a href="#/import-export" class="btn btn-secondary btn-sm">Backup</a>
        </div>
      </div>

      <section class="grid-2" aria-label="Core modules">
        <a href="#/transactions" class="tile-card">
          <span class="tile-icon">🧾</span>
          <div>
            <div class="tile-title">Transactions</div>
            <div class="tile-sub">${txs.length} recorded</div>
          </div>
        </a>

        <a href="#/debts" class="tile-card">
          <span class="tile-icon">🤝</span>
          <div>
            <div class="tile-title">Debt Tracker</div>
            <div class="tile-sub">${debtSub}</div>
          </div>
        </a>

        <a href="#/bills" class="tile-card">
          <span class="tile-icon">📅</span>
          <div>
            <div class="tile-title">Bills &amp; Recurring</div>
            <div class="tile-sub ${overdueCount > 0 ? 'text-danger' : ''}">${billsSub}</div>
          </div>
        </a>

        <a href="#/investments" class="tile-card">
          <span class="tile-icon">📈</span>
          <div>
            <div class="tile-title">Investments &amp; Loans</div>
            <div class="tile-sub">${nw.investmentsCount} inv · ${nw.activeLoansCount} loans</div>
          </div>
        </a>

        <a href="#/networth" class="tile-card">
          <span class="tile-icon">💎</span>
          <div>
            <div class="tile-title">Net Worth</div>
            <div class="tile-sub">${show ? formatINR(nw.netWorthPaise) : '*****'}</div>
          </div>
        </a>

        <a href="#/budgets" class="tile-card">
          <span class="tile-icon">🎯</span>
          <div>
            <div class="tile-title">Budgets</div>
            <div class="tile-sub">${budgets.length} active</div>
          </div>
        </a>

        <a href="#/categories" class="tile-card">
          <span class="tile-icon">🏷️</span>
          <div>
            <div class="tile-title">Categories</div>
            <div class="tile-sub">${categories.length} active</div>
          </div>
        </a>

        <a href="#/tags" class="tile-card">
          <span class="tile-icon">#️⃣</span>
          <div>
            <div class="tile-title">Tags</div>
            <div class="tile-sub">${tags.length} active</div>
          </div>
        </a>
      </section>

      <div class="section-heading">
        <span class="section-heading-left">More options</span>
      </div>

      <div class="grouped-card">
        <a href="#/family" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span>👨‍👩‍👧</span>
            <div>
              <div class="item-title">Family Members</div>
              <div class="item-meta">${family.length} active profile${family.length === 1 ? '' : 's'}</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>

        <a href="#/statement-import" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span class="avatar-badge">📄</span>
            <div>
              <div class="item-title">Smart Statement Import</div>
              <div class="item-meta">Upload PDF, CSV, XLS &amp; XLSX statements locally</div>
            </div>
          </div>
          <span class="item-meta">›</span>
        </a>
        <a href="#/import-export" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span>☁️</span>
            <div>
              <div class="item-title">Google Drive Auto-Backup &amp; Excel Sync</div>
              <div class="item-meta">${driveSub}</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>

        <a href="#/settings" class="grouped-row grouped-row-clickable">
          <div class="list-row-main">
            <span>🛡️</span>
            <div>
              <div class="item-title">Settings, Integrity Audit &amp; Migration Test</div>
              <div class="item-meta">INR, FY 1 Apr – 31 Mar, Storage &amp; Recovery Self-Test</div>
            </div>
          </div>
          <span class="text-muted">›</span>
        </a>
      </div>
    </div>
  `;
}
